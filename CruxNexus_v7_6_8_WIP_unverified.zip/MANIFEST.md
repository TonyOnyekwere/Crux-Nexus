# CruxNexus v7.6.7 implementation manifest

This archive is based on the v7.6.6 baseline and implements Gate 1 (financial and commerce correctness). The authoritative description of what exists and what is verified is `apps/commerce-api/CURRENT_IMPLEMENTATION_STATE.md` and `apps/commerce-api/MVP_RELEASE_v7_6_7.md`.

## Implemented closure

- Dedicated non-superuser `DATABASE_WORKER_URL` and explicit forced-RLS worker policies.
- Worker role has role-level `app.worker_context=1`; no BYPASSRLS is used.
- All Commerce merchant mutations enforce the declared tenant-role permissions.
- Entitlement staff allocation/deallocation requires `MANAGE_STAFF`.
- Onboarding and journey storefront creation both use canonical `TenantService.create_storefront()`.
- Checkout/provider failure immediately releases inventory reservations.
- Commerce webhook unknown outcomes remain durable and are reconciled by the webhook worker.
- Tenant suspension provenance is durable and subscription restoration cannot override a governance suspension.
- Grace period and subscription-period lengths are governance data.
- Durable append-only audit table records governance, suspension and staff-allocation actions.
- Durable `worker_jobs` supports leases, attempts, retry scheduling and dead-letter state.
- Outbox relay publishes to Redis Streams and records transport metadata.
- Control Center is now a separate deployable under `apps/control-center-api` with its own database schema, admin RBAC/MFA, governance records and authenticated one-way synchronization into Commerce.
- Commerce receives synchronized policy, plan and provider registry state through platform-only endpoints.
- Commerce and Control Center dependency versions are pinned.
- Runbooks, current-state documentation and worker architecture ADR are aligned with the executable implementation.

## Verification status

Authoring-environment verification:
- full source `compileall`: PASS
- Commerce model static checker: PASS
- test-reference static checker: PASS
- review gate: PASS
- Alembic head: 044
- Control Center source/migrations compile: PASS
- CI workflow YAML parse: PASS
- ZIP integrity: PASS

Not independently executed here: live PostgreSQL/Redis integration tests and real Paystack/Flutterwave/SendGrid sandbox traffic, because this authoring environment lacks the required runtime services/credentials and external package installation is unavailable. Those are kept as CI/deployment verification gates rather than claimed as passed.
