# CruxNexus

CruxNexus is a Commerce Operating System built as a modular Commerce Plane with a separately deployable Control Center and asynchronous worker runtime.

## Services
- `apps/commerce-api`: merchant/runtime API, PostgreSQL RLS, payment and commerce domains.
- `apps/commerce-api/app/workers`: lifecycle, reconciliation, durable jobs and event relay.
- `apps/control-center-api`: platform governance, admin MFA/RBAC and durable governance synchronization.

## Development
1. Copy each service `.env.example` to `.env`.
2. Run PostgreSQL and Redis.
3. Apply Commerce migrations through `048`.
4. Apply Control Center migrations through `005`.
5. Start Commerce API and worker separately.
6. Start Control Center.

## Verification
```powershell
cd apps/commerce-api
python -m pytest
python scripts/review_gate_check.py
```

The repository distinguishes source/static verification from live PostgreSQL, Redis, SendGrid and payment-provider certification. Those require real deployment credentials and services.

## Architecture
Governance decides in Control Center. Commerce operates synchronously. Workers execute deferred commands and reconciliation. Durable outbox events are transported through Redis Streams.
