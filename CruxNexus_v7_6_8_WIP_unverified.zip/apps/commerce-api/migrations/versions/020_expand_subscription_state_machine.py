"""Expand merchant_subscriptions status to the full locked state machine.

The CruxNexus Merchant Onboarding & Activation Architecture (2026-09-17,
section 6) locks this subscription state machine:

    PENDING_SELECTION -> TRIAL_ACTIVE | PAYMENT_PENDING
    TRIAL_ACTIVE      -> ACTIVE | TRIAL_EXPIRED
    PAYMENT_PENDING   -> ACTIVE | PAYMENT_FAILED
    ACTIVE            -> PAST_DUE | CANCELLED | SUSPENDED
    PAST_DUE          -> ACTIVE | SUSPENDED
    TRIAL_EXPIRED     -> ACTIVE
    SUSPENDED         -> ACTIVE
    PAYMENT_FAILED    -> PAYMENT_PENDING | ACTIVE

Migration 019 (same day) added 'past_due' to the previous
chk_subscription_status_transition constraint. This migration replaces
that constraint again to add the four states introduced by the locked
architecture: 'pending_selection', 'payment_pending', 'payment_failed',
'trial_expired'. 'expired' is kept for backward compatibility with any
already-persisted rows, but is no longer written by application code —
the trial-expiration worker (app/workers/trial_expiration.py) now writes
'trial_expired' instead, matching the locked architecture's naming
exactly (there is no separate bare "EXPIRED" state in the locked
diagram).

Revision ID: 020
Revises: 019
"""

from alembic import op

revision = "020"
down_revision = "019"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE merchant_subscriptions DROP CONSTRAINT chk_subscription_status_transition"
    )
    op.execute(
        """
        ALTER TABLE merchant_subscriptions
        ADD CONSTRAINT chk_subscription_status_transition
        CHECK (
            status IN (
                'pending_selection', 'trialing', 'payment_pending',
                'payment_failed', 'active', 'past_due', 'trial_expired',
                'suspended', 'cancelled', 'expired'
            )
        )
        """
    )


def downgrade() -> None:
    op.execute(
        "ALTER TABLE merchant_subscriptions DROP CONSTRAINT chk_subscription_status_transition"
    )
    op.execute(
        """
        ALTER TABLE merchant_subscriptions
        ADD CONSTRAINT chk_subscription_status_transition
        CHECK (
            status IN ('trialing', 'active', 'past_due', 'cancelled', 'expired', 'suspended')
        )
        """
    )
