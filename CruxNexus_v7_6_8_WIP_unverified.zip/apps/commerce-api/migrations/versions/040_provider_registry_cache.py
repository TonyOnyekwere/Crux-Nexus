"""Add Control Center synchronized provider registry cache."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision="040"
down_revision="039"
branch_labels=None
depends_on=None

def upgrade():
    op.create_table("provider_registry_cache",
        sa.Column("id",postgresql.UUID(as_uuid=True),primary_key=True),
        sa.Column("provider_type",sa.String(40),nullable=False,unique=True),
        sa.Column("enabled",sa.Boolean(),nullable=False,server_default=sa.true()),
        sa.Column("priority",sa.Integer(),nullable=False,server_default="100"),
        sa.Column("governance_version",sa.String(80),nullable=False,server_default="initial"),
        sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),
    )
    op.execute(sa.text("INSERT INTO provider_registry_cache (id,provider_type,enabled,priority,governance_version) VALUES (:id,'paystack',true,10,'initial'),(:id2,'flutterwave',true,20,'initial')"), {"id":"00000000-0000-0000-0000-000000000001","id2":"00000000-0000-0000-0000-000000000002"})

def downgrade(): op.drop_table("provider_registry_cache")
