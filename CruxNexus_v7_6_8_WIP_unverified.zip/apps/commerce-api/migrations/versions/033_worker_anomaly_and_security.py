"""Worker anomaly deduplication and tenant RLS registry completion."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "033"
down_revision = "032"
branch_labels = None
depends_on = None


def upgrade() -> None:
    uuid = postgresql.UUID(as_uuid=True)
    op.create_table(
        "allocation_anomalies",
        sa.Column("id", uuid, primary_key=True),
        sa.Column("merchant_entitlement_id", uuid, sa.ForeignKey("merchant_entitlements.id", ondelete="CASCADE"), nullable=False),
        sa.Column("anomaly_type", sa.String(80), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="open"),
        sa.Column("granted_quantity", sa.Integer(), nullable=False),
        sa.Column("allocated_quantity", sa.Integer(), nullable=False),
        sa.Column("opened_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("resolved_at", sa.DateTime(timezone=True)),
        sa.UniqueConstraint("merchant_entitlement_id", "anomaly_type", name="uq_allocation_anomaly"),
    )
    op.create_index("ix_allocation_anomalies_entitlement", "allocation_anomalies", ["merchant_entitlement_id"])
    # This is platform governance state, not merchant-owned data. It therefore
    # remains outside the tenant RLS registry and is protected by the control/
    # worker authorization boundary.


def downgrade() -> None:
    op.drop_index("ix_allocation_anomalies_entitlement", table_name="allocation_anomalies")
    op.drop_table("allocation_anomalies")
