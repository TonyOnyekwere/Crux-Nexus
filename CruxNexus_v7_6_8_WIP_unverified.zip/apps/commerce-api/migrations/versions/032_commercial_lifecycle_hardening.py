"""Gate 1 commercial correctness hardening."""
from alembic import op
import sqlalchemy as sa

revision = "032"
down_revision = "031"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "commerce_payments",
        sa.Column("requires_refund", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.create_check_constraint(
        "ck_orders_status",
        "orders",
        "status IN ('pending_payment','awaiting_transfer','payment_failed','confirmed','fulfilling','shipped','completed','cancelled')",
    )
    op.create_check_constraint(
        "ck_orders_payment_status",
        "orders",
        "payment_status IN ('pending','paid','failed')",
    )
    op.create_index("ix_commerce_payments_provider_status_created", "commerce_payments", ["provider", "status", "created_at"])


def downgrade() -> None:
    op.drop_index("ix_commerce_payments_provider_status_created", table_name="commerce_payments")
    op.drop_constraint("ck_orders_payment_status", "orders", type_="check")
    op.drop_constraint("ck_orders_status", "orders", type_="check")
    op.drop_column("commerce_payments", "requires_refund")
