"""Foundation hardening: durable worker fencing, checkout idempotency and governance versions."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision="041"
down_revision="040"
branch_labels=None
depends_on=None

def upgrade():
    u=postgresql.UUID(as_uuid=True)
    op.add_column("worker_jobs", sa.Column("lease_token", u, nullable=True))
    op.create_index("ix_worker_jobs_running_lease", "worker_jobs", ["status","lease_until"])
    op.create_table("commerce_checkout_idempotency",
        sa.Column("id",u,primary_key=True),
        sa.Column("tenant_id",u,sa.ForeignKey("tenants.id",ondelete="CASCADE"),nullable=False),
        sa.Column("idempotency_key",sa.String(255),nullable=False),
        sa.Column("request_fingerprint",sa.String(64),nullable=False),
        sa.Column("status",sa.String(20),nullable=False,server_default="processing"),
        sa.Column("response_payload",postgresql.JSONB,nullable=True),
        sa.Column("created_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),
        sa.Column("completed_at",sa.DateTime(timezone=True),nullable=True),
        sa.UniqueConstraint("tenant_id","idempotency_key",name="uq_checkout_idempotency_tenant_key"),
    )
    op.create_index("ix_checkout_idempotency_created", "commerce_checkout_idempotency", ["created_at"])
    op.add_column("commerce_governance_policy", sa.Column("governance_version",sa.String(80),nullable=False,server_default="initial"))
    op.add_column("subscription_plans", sa.Column("governance_version",sa.String(80),nullable=False,server_default="initial"))

def downgrade():
    op.drop_column("subscription_plans","governance_version")
    op.drop_column("commerce_governance_policy","governance_version")
    op.drop_index("ix_checkout_idempotency_created",table_name="commerce_checkout_idempotency")
    op.drop_table("commerce_checkout_idempotency")
    op.drop_index("ix_worker_jobs_running_lease",table_name="worker_jobs")
    op.drop_column("worker_jobs","lease_token")
