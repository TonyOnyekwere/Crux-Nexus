"""v2 onboarding foundation (CRX-FE-003 WP1).

  * merchant_trial_history: UNIQUE (merchant_account_id) - one trial per merchant account, ever,
    enforced by the database so concurrent requests cannot race past an application check.
    Existing duplicate rows are DETECTED FIRST and abort the migration with the offending merchant ids;
    this migration never deletes or merges history.
  * onboarding_idempotency_keys: per-session replay records bound to operation, actor and request hash.
  * onboarding_slug_reservations: short-lived slug holds; expired rows never block (replaced by upsert).

Revision ID: 049
Revises: 048
"""
import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "049"
down_revision = "048"
branch_labels = None
depends_on = None

TRIAL_UNIQUE_NAME = "uq_merchant_trial_history_merchant"

DUPLICATE_TRIAL_SQL = """
    SELECT merchant_account_id, count(*) AS n
    FROM merchant_trial_history
    GROUP BY merchant_account_id
    HAVING count(*) > 1
    ORDER BY merchant_account_id
"""


def find_duplicate_trial_merchants(connection) -> list[tuple[str, int]]:
    """Merchants that already hold more than one trial-history row (blocks the unique constraint)."""
    rows = connection.execute(sa.text(DUPLICATE_TRIAL_SQL)).fetchall()
    return [(str(row[0]), int(row[1])) for row in rows]


def upgrade() -> None:
    connection = op.get_bind()
    duplicates = find_duplicate_trial_merchants(connection)
    if duplicates:
        listing = ", ".join(f"{merchant} ({count} rows)" for merchant, count in duplicates[:20])
        raise RuntimeError(
            "Cannot enforce one trial per merchant account: merchant_trial_history already contains "
            f"duplicate rows for {len(duplicates)} merchant(s): {listing}. Resolve them deliberately "
            "(this migration does not delete or merge history) and re-run."
        )
    op.create_unique_constraint(TRIAL_UNIQUE_NAME, "merchant_trial_history", ["merchant_account_id"])

    op.create_table(
        "onboarding_idempotency_keys",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column(
            "session_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("onboarding_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("key", sa.String(128), nullable=False),
        sa.Column("operation", sa.String(60), nullable=False),
        sa.Column("actor", sa.String(80), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="in_progress"),
        sa.Column("response_status", sa.Integer(), nullable=True),
        sa.Column("response_body", postgresql.JSONB(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("session_id", "key", name="uq_onboarding_idempotency_session_key"),
        sa.CheckConstraint("status IN ('in_progress', 'completed')", name="ck_onboarding_idempotency_status"),
        sa.CheckConstraint("char_length(key) BETWEEN 16 AND 128", name="ck_onboarding_idempotency_key_length"),
        sa.CheckConstraint("char_length(request_hash) = 64", name="ck_onboarding_idempotency_hash_length"),
        sa.CheckConstraint(
            "(status = 'completed') = (response_status IS NOT NULL)", name="ck_onboarding_idempotency_completed_result"
        ),
    )
    op.create_index("ix_onboarding_idempotency_expires_at", "onboarding_idempotency_keys", ["expires_at"])

    op.create_table(
        "onboarding_slug_reservations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("slug_normalized", sa.String(64), nullable=False),
        sa.Column(
            "session_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("onboarding_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.UniqueConstraint("slug_normalized", name="uq_onboarding_slug_reservations_slug"),
        sa.UniqueConstraint("session_id", name="uq_onboarding_slug_reservations_session"),
        sa.CheckConstraint("slug_normalized = lower(slug_normalized)", name="ck_onboarding_slug_reservations_lower"),
    )
    op.create_index("ix_onboarding_slug_reservations_expires_at", "onboarding_slug_reservations", ["expires_at"])


def downgrade() -> None:
    op.drop_index("ix_onboarding_slug_reservations_expires_at", table_name="onboarding_slug_reservations")
    op.drop_table("onboarding_slug_reservations")
    op.drop_index("ix_onboarding_idempotency_expires_at", table_name="onboarding_idempotency_keys")
    op.drop_table("onboarding_idempotency_keys")
    op.drop_constraint(TRIAL_UNIQUE_NAME, "merchant_trial_history", type_="unique")
