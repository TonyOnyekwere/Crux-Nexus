"""Create financial_transactions and provider_webhook_events.

Locked Onboarding & Activation Architecture, sections 10-11.

financial_transactions is the canonical subscription-payment transaction
identity (CNX-TXN-*) that exists independently of whichever provider
(Paystack/Flutterwave) processed it — domain code and reporting query
this table, never a provider's own transaction ID as the source of truth.

provider_webhook_events is the immutable inbox every provider webhook
lands in before anything else happens to it: signature validation
happens before a row is even written (a failed-signature request is
rejected, not stored), then the raw event is persisted, deduplicated, and
only then translated into a normalized PaymentEvent that the subscription
engine acts on. UNIQUE(provider_code, provider_event_id) is what makes
"safe for replay, safe for duplication" (section 11) an enforced database
guarantee rather than a hopeful application-layer check.

Neither table has any provider adapter code behind it yet — see
CRX-P0-022 for why the actual Paystack/Flutterwave adapters are staged as
a later phase (they need real sandbox credentials this pass didn't have
access to). This migration only lays the schema both will write to.

Revision ID: 022
Revises: 021
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "022"
down_revision = "021"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "financial_transactions",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        # Human/externally-referenceable transaction ID, independent of
        # the internal UUID and of any provider's own reference.
        sa.Column("reference", sa.String(64), nullable=False, unique=True),
        sa.Column(
            "merchant_account_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("merchant_accounts.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "subscription_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("merchant_subscriptions.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "subscription_plan_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("subscription_plans.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("provider", sa.String(30), nullable=False),
        sa.Column("provider_reference", sa.String(255), nullable=True),
        sa.Column("amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="NGN"),
        # See PaymentAuthorizationType in app/kernel/payments/types.py —
        # not every payment method auto-renews a subscription, so this is
        # modeled separately from provider/status.
        sa.Column("payment_method", sa.String(30), nullable=True),
        sa.Column("authorization_type", sa.String(30), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint(
            "provider IN ('paystack', 'flutterwave')",
            name="chk_financial_transaction_provider",
        ),
        sa.CheckConstraint(
            "status IN ('pending', 'successful', 'failed', 'reversed', 'abandoned')",
            name="chk_financial_transaction_status",
        ),
    )
    op.create_index(
        "ix_financial_transactions_merchant_account_id",
        "financial_transactions",
        ["merchant_account_id"],
    )
    op.create_index(
        "ix_financial_transactions_subscription_id",
        "financial_transactions",
        ["subscription_id"],
    )
    op.create_index(
        "ix_financial_transactions_provider_reference",
        "financial_transactions",
        ["provider", "provider_reference"],
    )

    op.create_table(
        "provider_webhook_events",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column("provider_code", sa.String(30), nullable=False),
        # The provider's own event/transaction identifier - this is what
        # the uniqueness guarantee is keyed on, not our internal id.
        sa.Column("provider_event_id", sa.String(255), nullable=False),
        sa.Column("event_type", sa.String(100), nullable=True),
        # Raw provider payload, stored verbatim and never mutated -
        # normalization happens in application code that reads this row,
        # not by editing it.
        sa.Column("raw_payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("signature_verified", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("processed", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("processing_error", sa.Text(), nullable=True),
        sa.Column(
            "received_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.UniqueConstraint(
            "provider_code", "provider_event_id", name="uk_provider_webhook_event"
        ),
    )
    op.create_index(
        "ix_provider_webhook_events_processed",
        "provider_webhook_events",
        ["processed", "received_at"],
    )


def downgrade() -> None:
    op.drop_table("provider_webhook_events")
    op.drop_table("financial_transactions")
