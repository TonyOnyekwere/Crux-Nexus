"""Add durable worker jobs and external event transport metadata."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision="039"
down_revision="038"
branch_labels=None
depends_on=None

def upgrade():
    uuid=postgresql.UUID(as_uuid=True)
    op.create_table("worker_jobs",
        sa.Column("id",uuid,primary_key=True), sa.Column("job_type",sa.String(120),nullable=False),
        sa.Column("payload",postgresql.JSONB,nullable=False), sa.Column("status",sa.String(20),nullable=False,server_default="queued"),
        sa.Column("available_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),
        sa.Column("attempts",sa.Integer(),nullable=False,server_default="0"), sa.Column("max_attempts",sa.Integer(),nullable=False,server_default="8"),
        sa.Column("lease_until",sa.DateTime(timezone=True)), sa.Column("locked_by",sa.String(120)), sa.Column("last_error",sa.Text()),
        sa.Column("created_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")), sa.Column("completed_at",sa.DateTime(timezone=True)),
    )
    op.create_index("ix_worker_jobs_claim","worker_jobs",["status","available_at","created_at"])
    op.add_column("outbox_events",sa.Column("transport_id",sa.String(255)))
    op.add_column("outbox_events",sa.Column("attempt_count",sa.Integer(),nullable=False,server_default="0"))
    op.add_column("outbox_events",sa.Column("last_error",sa.Text()))

def downgrade():
    op.drop_column("outbox_events","last_error"); op.drop_column("outbox_events","attempt_count"); op.drop_column("outbox_events","transport_id")
    op.drop_index("ix_worker_jobs_claim",table_name="worker_jobs"); op.drop_table("worker_jobs")
