"""Align the userstatus Postgres enum with the Python UserStatus model.

Migration 001 created the `userstatus` enum as ('guest', 'active',
'disabled'). The Python model (app/contexts/identity/domain/entities.py)
defines UserStatus as ACTIVE=active, INACTIVE=inactive, SUSPENDED=suspended.
Only 'active' overlaps. Setting a user's status to INACTIVE or SUSPENDED
anywhere in the app would fail at the database with an invalid-enum-value
error — this has presumably gone unnoticed only because nothing in the
current codebase ever sets a status other than the ACTIVE default.

This migration adds the two missing values. It intentionally does NOT
remove 'guest' or 'disabled' — Postgres enum value removal requires
recreating the type, which is riskier than it's worth here since neither
value is referenced anywhere in the application (checked: only
UserStatus.ACTIVE is ever assigned), and there is no evidence any existing
row uses them. If they're confirmed unused in every environment this runs
against, dropping them can be a later, separate, deliberate migration.

Revision ID: 018
Revises: 017
"""

from alembic import op

revision = "018"
down_revision = "017"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ALTER TYPE ... ADD VALUE cannot be used in the same transaction as a
    # statement that reads/writes the new value, but adding it alone (and
    # using it only in later, separate transactions/migrations) is safe.
    op.execute("ALTER TYPE userstatus ADD VALUE IF NOT EXISTS 'inactive'")
    op.execute("ALTER TYPE userstatus ADD VALUE IF NOT EXISTS 'suspended'")


def downgrade() -> None:
    # Postgres does not support removing enum values without recreating
    # the type. Since 'guest' and 'disabled' (the two values this
    # migration doesn't touch) were never removed either, downgrading
    # this migration is a no-op by design rather than a destructive
    # type-rebuild; if 'inactive'/'suspended' are already in use by rows
    # at downgrade time, removing them would require a manual, deliberate
    # migration anyway.
    pass
