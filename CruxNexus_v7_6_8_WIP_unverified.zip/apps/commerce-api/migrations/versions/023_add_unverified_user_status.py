"""Add 'unverified' to the userstatus Postgres enum.

Migration 018 aligned the Python UserStatus model (active/inactive/
suspended) with the Postgres enum. The locked Onboarding & Activation
Architecture (2026-09-17) adds a fourth Python-side value, UNVERIFIED,
which new accounts now default to (see IdentityService.create_user) —
without this migration, that write would fail with an invalid-enum-value
error the same way INACTIVE/SUSPENDED did before migration 018.

Revision ID: 023
Revises: 022
"""

from alembic import op

revision = "023"
down_revision = "022"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TYPE userstatus ADD VALUE IF NOT EXISTS 'unverified'")


def downgrade() -> None:
    # See migration 018's downgrade for why removing a Postgres enum
    # value is intentionally a no-op here rather than a type rebuild.
    pass
