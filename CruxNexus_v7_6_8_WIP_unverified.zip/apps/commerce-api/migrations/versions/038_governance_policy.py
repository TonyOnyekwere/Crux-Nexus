"""Persist commercial policy so lifecycle behavior is governance data, not code constants."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
import uuid
revision="038"
down_revision="037"
branch_labels=None
depends_on=None

def upgrade():
    op.create_table("commerce_governance_policy",
        sa.Column("id",postgresql.UUID(as_uuid=True),primary_key=True),
        sa.Column("policy_key",sa.String(80),nullable=False,unique=True,server_default="default"),
        sa.Column("grace_period_days",sa.Integer(),nullable=False,server_default="3"),
        sa.Column("monthly_period_days",sa.Integer(),nullable=False,server_default="30"),
        sa.Column("yearly_period_days",sa.Integer(),nullable=False,server_default="365"),
        sa.Column("allow_early_renewal",sa.Boolean(),nullable=False,server_default=sa.false()),
        sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),
    )
    op.execute(sa.text("INSERT INTO commerce_governance_policy (id, policy_key) VALUES (:id, 'default')"), {"id": str(uuid.uuid4())})

def downgrade():
    op.drop_table("commerce_governance_policy")
