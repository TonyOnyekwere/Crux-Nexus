"""Gate 1 commerce correctness: currency authority, merchant-configured payment/fulfillment methods,
order cancellation reason + fulfillment method, checkout idempotency lease/recovery link.

  * Currency: storefront_profiles / products / orders / commerce_payments are constrained to the four
    supported currencies (NGN, GHS, KES, ZAR). The storefront currency is the single authority.
  * storefront_profiles: contact_email, pod_enabled, bank_transfer_enabled, bank_transfer_details (JSONB),
    bank_transfer_window_hours (1..168, default 24), pickup_enabled, delivery_enabled. Everything defaults
    OFF so a merchant must opt in explicitly (publication requires at least one payment method and one
    fulfillment method).
  * merchant_payment_connections.enabled: the merchant's own switch for offering a provider.
  * orders: fulfillment_method (delivery|pickup), delivery_address nullable only for pickup,
    cancellation_reason.
  * commerce_checkout_idempotency: processing_since (lease start) and order_id (recovery link), status CHECK.

Revision ID: 048
Revises: 047
"""
import os
import re
from urllib.parse import unquote, urlparse

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "048"
down_revision = "047"
branch_labels = None
depends_on = None

CUR = "currency IN ('NGN','GHS','KES','ZAR')"


def _worker_role():
    """Same resolution as migrations 036/046: the worker role exists only when DATABASE_WORKER_URL is set."""
    raw = os.environ.get("DATABASE_WORKER_URL")
    if not raw:
        return None
    user = unquote(urlparse(raw).username or "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", user) or user == "postgres":
        return None
    return user


def upgrade():
    # ---- currency authority
    op.create_check_constraint("ck_storefront_currency", "storefront_profiles", CUR)
    op.create_check_constraint("ck_product_currency", "products", CUR)
    op.create_check_constraint("ck_order_currency", "orders", CUR)
    op.create_check_constraint("ck_commerce_payment_currency", "commerce_payments", CUR)

    # ---- merchant-configured payment + fulfillment methods
    op.add_column("storefront_profiles", sa.Column("contact_email", sa.String(320), nullable=True))
    for name in ("pod_enabled", "bank_transfer_enabled", "pickup_enabled", "delivery_enabled"):
        op.add_column("storefront_profiles", sa.Column(name, sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("storefront_profiles", sa.Column("bank_transfer_details", postgresql.JSONB(), nullable=True))
    op.add_column("storefront_profiles", sa.Column("bank_transfer_window_hours", sa.Integer(), nullable=False, server_default="24"))
    op.create_check_constraint("ck_storefront_bank_transfer_window", "storefront_profiles",
                               "bank_transfer_window_hours BETWEEN 1 AND 168")
    op.add_column("merchant_payment_connections", sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.true()))

    # ---- orders
    op.add_column("orders", sa.Column("fulfillment_method", sa.String(20), nullable=False, server_default="delivery"))
    op.add_column("orders", sa.Column("cancellation_reason", sa.String(40), nullable=True))
    op.alter_column("orders", "delivery_address", existing_type=sa.Text(), nullable=True)
    op.create_check_constraint("ck_order_fulfillment_method", "orders", "fulfillment_method IN ('delivery','pickup')")
    op.create_check_constraint("ck_order_delivery_address_required", "orders",
                               "fulfillment_method = 'pickup' OR delivery_address IS NOT NULL")

    # ---- checkout idempotency lease / recovery
    op.add_column("commerce_checkout_idempotency", sa.Column(
        "processing_since", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")))
    op.add_column("commerce_checkout_idempotency", sa.Column(
        "order_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("orders.id", ondelete="SET NULL"), nullable=True))
    op.create_check_constraint("ck_checkout_idempotency_status", "commerce_checkout_idempotency",
                               "status IN ('processing','completed','failed')")
    op.create_index("ix_commerce_checkout_idempotency_tenant_status", "commerce_checkout_idempotency", ["tenant_id", "status"])

    # The recovery worker finalizes abandoned checkouts across tenants (same worker-context policy form as 036).
    worker = _worker_role()
    if worker:
        ident = '"' + worker.replace('"', '""') + '"'
        op.execute(
            f"CREATE POLICY commerce_checkout_idempotency_worker_access ON commerce_checkout_idempotency TO {ident} "
            f"USING (current_user = '{worker}' AND current_setting('app.worker_context', true) = '1') "
            f"WITH CHECK (current_user = '{worker}' AND current_setting('app.worker_context', true) = '1')"
        )


def downgrade():
    op.execute("DROP POLICY IF EXISTS commerce_checkout_idempotency_worker_access ON commerce_checkout_idempotency")
    op.drop_index("ix_commerce_checkout_idempotency_tenant_status", table_name="commerce_checkout_idempotency")
    op.drop_constraint("ck_checkout_idempotency_status", "commerce_checkout_idempotency", type_="check")
    op.drop_column("commerce_checkout_idempotency", "order_id")
    op.drop_column("commerce_checkout_idempotency", "processing_since")
    op.drop_constraint("ck_order_delivery_address_required", "orders", type_="check")
    op.drop_constraint("ck_order_fulfillment_method", "orders", type_="check")
    op.execute("UPDATE orders SET delivery_address = 'PICKUP' WHERE delivery_address IS NULL")
    op.alter_column("orders", "delivery_address", existing_type=sa.Text(), nullable=False)
    op.drop_column("orders", "cancellation_reason")
    op.drop_column("orders", "fulfillment_method")
    op.drop_column("merchant_payment_connections", "enabled")
    op.drop_constraint("ck_storefront_bank_transfer_window", "storefront_profiles", type_="check")
    for name in ("bank_transfer_window_hours", "bank_transfer_details", "delivery_enabled", "pickup_enabled",
                 "bank_transfer_enabled", "pod_enabled", "contact_email"):
        op.drop_column("storefront_profiles", name)
    op.drop_constraint("ck_commerce_payment_currency", "commerce_payments", type_="check")
    op.drop_constraint("ck_order_currency", "orders", type_="check")
    op.drop_constraint("ck_product_currency", "products", type_="check")
    op.drop_constraint("ck_storefront_currency", "storefront_profiles", type_="check")
