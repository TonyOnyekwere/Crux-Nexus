"""Fix capacity calculation usage and add plan-based entitlement source.

This migration:
1. Introduces PLAN_GRANT as a valid entitlement source value.
2. Updates existing admin_grant entitlements that represent plan-based
   capacity to plan_grant.
3. Adds an index for efficient capacity queries.
4. Adds a constraint ensuring entitlement quantities are positive.

Note:
merchant_entitlements.source is VARCHAR(50), not a PostgreSQL enum.
Therefore no ALTER TYPE operation is required.
"""

from alembic import op


revision = "013"
down_revision = "012"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # merchant_entitlements.source is VARCHAR(50), so "plan_grant"
    # requires no PostgreSQL enum alteration.

    # Update existing admin_grant entitlements to plan_grant where they
    # represent storefront/staff capacity allocations.
    op.execute(
        """
        UPDATE merchant_entitlements
        SET source = 'plan_grant'
        WHERE source = 'admin_grant'
          AND entitlement_type IN ('extra_storefront', 'extra_staff')
        """
    )

    # Add index for efficient capacity queries.
    op.create_index(
        "ix_merchant_entitlements_account_type_status",
        "merchant_entitlements",
        [
            "merchant_account_id",
            "entitlement_type",
            "status",
        ],
    )

    # Ensure entitlement quantities are always positive.
    op.execute(
        """
        ALTER TABLE merchant_entitlements
        ADD CONSTRAINT chk_entitlement_quantity_positive
        CHECK (quantity > 0)
        """
    )


def downgrade() -> None:
    # Remove quantity constraint.
    op.execute(
        """
        ALTER TABLE merchant_entitlements
        DROP CONSTRAINT IF EXISTS chk_entitlement_quantity_positive
        """
    )

    # Remove index.
    op.drop_index(
        "ix_merchant_entitlements_account_type_status",
        table_name="merchant_entitlements",
    )

    # Revert plan-based grants to the previous source.
    op.execute(
        """
        UPDATE merchant_entitlements
        SET source = 'admin_grant'
        WHERE source = 'plan_grant'
        """
    )