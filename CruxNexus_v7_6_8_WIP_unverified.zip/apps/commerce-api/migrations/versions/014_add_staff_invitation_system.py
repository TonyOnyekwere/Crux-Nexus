"""Add staff invitation system.

This migration implements the secure staff invitation flow:
Create Staff Invitation → Send Notification → Accept → Create/Link Account
→ Activate Membership → Grant Access

Key features:
- Invitations are stored with hashed tokens for security
- Invitations have PENDING/ACCEPTED/EXPIRED/CANCELLED status
- No active membership is created until invitation is accepted
- Staff members don't need pre-existing accounts
- Multi-channel notification support
- Invitation token establishes tenant context

Revision ID: 014
Revises: 013
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "014"
down_revision = "013"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()

    # Create the enum only if it does not already exist.
    # Railway may already contain this type from a previous/partial schema
    # operation, so this must be idempotent.
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1
                FROM pg_type
                WHERE typname = 'invitation_status'
            ) THEN
                CREATE TYPE invitation_status AS ENUM (
                    'PENDING',
                    'ACCEPTED',
                    'EXPIRED',
                    'CANCELLED'
                );
            END IF;
        END
        $$;
        """
    )

    # Reuse the existing PostgreSQL enum instead of attempting to create it.
    invitation_status_enum = postgresql.ENUM(
        'PENDING',
        'ACCEPTED',
        'EXPIRED',
        'CANCELLED',
        name='invitation_status',
        create_type=False,
    )

    # Create staff invitations table.
    op.create_table(
        'staff_invitations',
        sa.Column(
            'id',
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text('gen_random_uuid()')
        ),
        sa.Column(
            'tenant_id',
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey('tenants.id', ondelete='CASCADE'),
            nullable=False
        ),
        sa.Column(
            'invited_email',
            sa.String(255),
            nullable=False
        ),
        sa.Column(
            'role',
            sa.String(50),
            nullable=False,
            server_default='staff'
        ),
        sa.Column(
            'token_hash',
            sa.String(255),
            nullable=False,
            unique=True
        ),
        sa.Column(
            'status',
            invitation_status_enum,
            nullable=False,
            server_default='PENDING'
        ),
        sa.Column(
            'invited_by',
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey('users.id', ondelete='SET NULL'),
            nullable=True
        ),
        sa.Column(
            'accepted_at',
            sa.DateTime(timezone=True),
            nullable=True
        ),
        sa.Column(
            'accepted_by',
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey('users.id', ondelete='SET NULL'),
            nullable=True
        ),
        sa.Column(
            'expires_at',
            sa.DateTime(timezone=True),
            nullable=False
        ),
        sa.Column(
            'notification_channel',
            sa.String(50),
            nullable=True
        ),
        sa.Column(
            'notification_sent_at',
            sa.DateTime(timezone=True),
            nullable=True
        ),
        sa.Column(
            'created_at',
            sa.DateTime(timezone=True),
            server_default=sa.text('NOW()'),
            nullable=False
        ),
        sa.Column(
            'updated_at',
            sa.DateTime(timezone=True),
            server_default=sa.text('NOW()'),
            onupdate=sa.text('NOW()'),
            nullable=False
        ),

        sa.Index(
            'ix_staff_invitations_tenant_id',
            'tenant_id'
        ),
        sa.Index(
            'ix_staff_invitations_invited_email',
            'invited_email'
        ),
        sa.Index(
            'ix_staff_invitations_token_hash',
            'token_hash'
        ),
        sa.Index(
            'ix_staff_invitations_status',
            'status'
        ),
        sa.Index(
            'ix_staff_invitations_expires_at',
            'expires_at'
        ),
    )

    # Add constraints.
    op.execute(
        """
        ALTER TABLE staff_invitations
        ADD CONSTRAINT chk_invitation_expiration
        CHECK (expires_at > created_at)
        """
    )

    op.execute(
        """
        ALTER TABLE staff_invitations
        ADD CONSTRAINT chk_invitation_token_hash_not_empty
        CHECK (LENGTH(token_hash) > 0)
        """
    )

    op.execute(
        """
        ALTER TABLE staff_invitations
        ADD CONSTRAINT chk_invitation_email_format
        CHECK (
            invited_email ~*
            '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'
        )
        """
    )

    # Document the security model.
    op.execute(
        """
        COMMENT ON TABLE staff_invitations IS
        'Staff invitations provide a secure invitation flow without requiring
        pre-existing accounts.

        Security model:
        - PENDING: Invitation created, notification sent, awaiting acceptance
        - ACCEPTED: Invitation accepted, user account created/linked,
          membership activated
        - EXPIRED: Invitation expired, no longer valid
        - CANCELLED: Invitation cancelled by inviter

        The invitation token is stored hashed and establishes tenant context,
        so staff members do not need to know the tenant ID in advance.

        Notification channels:
        email, whatsapp, sms
        '
        """
    )


def downgrade() -> None:
    # Remove constraints.
    op.execute(
        """
        ALTER TABLE staff_invitations
        DROP CONSTRAINT IF EXISTS chk_invitation_email_format
        """
    )

    op.execute(
        """
        ALTER TABLE staff_invitations
        DROP CONSTRAINT IF EXISTS chk_invitation_token_hash_not_empty
        """
    )

    op.execute(
        """
        ALTER TABLE staff_invitations
        DROP CONSTRAINT IF EXISTS chk_invitation_expiration
        """
    )

    # Drop table.
    op.drop_table('staff_invitations')

    # Only drop the enum if it is not used by another table.
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1
                FROM pg_attribute a
                JOIN pg_type t ON t.oid = a.atttypid
                WHERE t.typname = 'invitation_status'
                  AND a.attnum > 0
                  AND NOT a.attisdropped
            ) THEN
                DROP TYPE IF EXISTS invitation_status;
            END IF;
        END
        $$;
        """
    )