"""Create otp_codes.

Locked Onboarding & Activation Architecture, section 19-20: OTP
verification is mandatory before a user can proceed past the identity
step. Codes are stored hashed (sha256), never in plaintext — the same
convention already used for staff invitation tokens
(app/contexts/billing/application/staff_invitation_service.py).

One user can have multiple rows over time (a fresh code is issued per
resend/retry); only the most recent unconsumed, unexpired row for a given
(user_id, purpose) is valid at verification time.

Revision ID: 024
Revises: 023
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "024"
down_revision = "023"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "otp_codes",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("channel", sa.String(20), nullable=False),
        # The email address or phone number the code was actually sent
        # to - captured at send time so a later change to the user's
        # profile email/phone can't retroactively alter what a given
        # code was proof of.
        sa.Column("destination", sa.String(320), nullable=False),
        sa.Column("purpose", sa.String(50), nullable=False, server_default="account_verification"),
        sa.Column("code_hash", sa.String(64), nullable=False),
        sa.Column("attempts", sa.Integer, nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer, nullable=False, server_default="5"),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("consumed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "channel IN ('email', 'sms')",
            name="chk_otp_code_channel",
        ),
    )
    op.create_index(
        "ix_otp_codes_user_purpose_created",
        "otp_codes",
        ["user_id", "purpose", "created_at"],
    )


def downgrade() -> None:
    op.drop_table("otp_codes")
