"""Merchant-owned payment credentials/events/webhook routing + generalized entitlements.

Payments: customer money settles directly in each merchant's own provider account.
  * merchant_payment_credentials : AES-GCM sealed secrets (see infrastructure/secrets), tenant RLS.
  * merchant_payment_events      : per-merchant webhook inbox, tenant RLS; unique per (connection, event id)
                                    because provider event ids are only unique per provider ACCOUNT.
  * payment_webhook_routes       : NON-secret routing table (random token -> tenant, connection). A merchant
                                    webhook carries no tenant context, so it is routed here, after which the
                                    session is bound to that tenant and everything else is read under RLS.
                                    Deliberately holds no credentials and no payload.
  * commerce_payments.connection_id records which merchant connection a payment used.

Entitlements: merchant_entitlements.entitlement_type is already a free String(50) (no DB enum), so the
generalization needs no data rewrite: it is now an opaque KEY (e.g. extra_staff, custom_domain), with a
`kind` (capability | resource | add_on) and `grant_metadata` JSONB in which the Control Center states what the
grant gives (capabilities and per-unit limit bonuses). Existing rows are classified as 'resource'.

Revision ID: 046
Revises: 045
"""
import os
import re
from urllib.parse import unquote, urlparse

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "046"
down_revision = "045"
branch_labels = None
depends_on = None

TENANT_TABLES = ("merchant_payment_credentials", "merchant_payment_events")
UUID = postgresql.UUID(as_uuid=True)


def _worker_role():
    """Same resolution as migration 036: the worker role exists only when DATABASE_WORKER_URL is set."""
    raw = os.environ.get("DATABASE_WORKER_URL")
    if not raw:
        return None
    user = unquote(urlparse(raw).username or "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", user) or user == "postgres":
        return None
    return user


def upgrade():
    op.add_column("merchant_payment_connections", sa.Column("verified_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("merchant_payment_connections", sa.Column("last_error", sa.String(500), nullable=True))

    op.create_table(
        "merchant_payment_credentials",
        sa.Column("id", UUID, primary_key=True),
        sa.Column("tenant_id", UUID, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("connection_id", UUID, sa.ForeignKey("merchant_payment_connections.id", ondelete="CASCADE"), nullable=False),
        sa.Column("provider", sa.String(40), nullable=False),
        sa.Column("key_version", sa.String(40), nullable=False),
        sa.Column("nonce", sa.LargeBinary(), nullable=False),
        sa.Column("ciphertext", sa.LargeBinary(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("rotated_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("connection_id", name="uq_merchant_payment_credentials_connection"),
    )
    op.create_index("ix_merchant_payment_credentials_tenant_id", "merchant_payment_credentials", ["tenant_id"])

    op.create_table(
        "merchant_payment_events",
        sa.Column("id", UUID, primary_key=True),
        sa.Column("tenant_id", UUID, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("connection_id", UUID, sa.ForeignKey("merchant_payment_connections.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_id", sa.String(255), nullable=False),
        sa.Column("event_type", sa.String(100), nullable=False),
        sa.Column("reference", sa.String(255), nullable=True),
        sa.Column("raw_payload", postgresql.JSONB(), nullable=False),
        sa.Column("processed", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("processing_error", sa.String(500), nullable=True),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.UniqueConstraint("connection_id", "event_id", name="uq_merchant_payment_event_identity"),
    )
    op.create_index("ix_merchant_payment_events_tenant_processed", "merchant_payment_events", ["tenant_id", "processed"])

    op.create_table(
        "payment_webhook_routes",
        sa.Column("webhook_token", sa.String(64), primary_key=True),
        sa.Column("tenant_id", UUID, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("connection_id", UUID, sa.ForeignKey("merchant_payment_connections.id", ondelete="CASCADE"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.UniqueConstraint("connection_id", name="uq_payment_webhook_routes_connection"),
    )

    op.add_column("commerce_payments", sa.Column("connection_id", UUID, sa.ForeignKey("merchant_payment_connections.id", ondelete="RESTRICT"), nullable=True))
    op.create_index("ix_commerce_payments_connection_id", "commerce_payments", ["connection_id"])

    for table in TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"CREATE POLICY {table}_tenant_isolation ON {table} "
            f"USING (tenant_id::text = current_setting('app.current_tenant_id', true)) "
            f"WITH CHECK (tenant_id::text = current_setting('app.current_tenant_id', true))"
        )

    # The worker sweeps unprocessed merchant events across tenants. It is granted that table ONLY;
    # it gets no blanket access to merchant_payment_credentials (it binds each payment's tenant
    # before loading credentials, so a worker bug cannot read another merchant's secrets).
    worker = _worker_role()
    if worker:
        ident = '"' + worker.replace('"', '""') + '"'
        op.execute(
            f"CREATE POLICY merchant_payment_events_worker_access ON merchant_payment_events TO {ident} "
            f"USING (current_user = '{worker}' AND current_setting('app.worker_context', true) = '1') "
            f"WITH CHECK (current_user = '{worker}' AND current_setting('app.worker_context', true) = '1')"
        )

    # ---- generalized entitlements
    op.add_column("merchant_entitlements", sa.Column("kind", sa.String(20), nullable=False, server_default="add_on"))
    op.add_column("merchant_entitlements", sa.Column("grant_metadata", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")))
    op.execute("UPDATE merchant_entitlements SET kind = 'resource' WHERE entitlement_type IN ('extra_storefront', 'extra_staff')")
    op.create_check_constraint("ck_merchant_entitlement_kind", "merchant_entitlements", "kind IN ('capability','resource','add_on')")
    op.create_check_constraint("ck_merchant_entitlement_key_format", "merchant_entitlements", "entitlement_type ~ '^[a-z][a-z0-9_.]{1,48}$'")


def downgrade():
    op.drop_constraint("ck_merchant_entitlement_key_format", "merchant_entitlements", type_="check")
    op.drop_constraint("ck_merchant_entitlement_kind", "merchant_entitlements", type_="check")
    op.drop_column("merchant_entitlements", "grant_metadata")
    op.drop_column("merchant_entitlements", "kind")
    op.execute("DROP POLICY IF EXISTS merchant_payment_events_worker_access ON merchant_payment_events")
    for table in reversed(TENANT_TABLES):
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
    op.drop_index("ix_commerce_payments_connection_id", table_name="commerce_payments")
    op.drop_column("commerce_payments", "connection_id")
    op.drop_table("payment_webhook_routes")
    op.drop_index("ix_merchant_payment_events_tenant_processed", table_name="merchant_payment_events")
    op.drop_table("merchant_payment_events")
    op.drop_index("ix_merchant_payment_credentials_tenant_id", table_name="merchant_payment_credentials")
    op.drop_table("merchant_payment_credentials")
    op.drop_column("merchant_payment_connections", "last_error")
    op.drop_column("merchant_payment_connections", "verified_at")
