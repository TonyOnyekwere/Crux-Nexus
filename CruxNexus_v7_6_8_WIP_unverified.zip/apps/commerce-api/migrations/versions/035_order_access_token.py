"""Replace phone-based guest order authorization with a bearer token."""
from alembic import op
import sqlalchemy as sa

revision = "035"
down_revision = "034"
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.add_column("orders", sa.Column("access_token_hash", sa.String(64), nullable=True))
    # Existing MVP orders are historical; no new public lookup is permitted
    # for them until a token exists. Keep nullable only for old rows.
    op.create_index("ix_orders_access_token_hash", "orders", ["access_token_hash"])

def downgrade() -> None:
    op.drop_index("ix_orders_access_token_hash", table_name="orders")
    op.drop_column("orders", "access_token_hash")
