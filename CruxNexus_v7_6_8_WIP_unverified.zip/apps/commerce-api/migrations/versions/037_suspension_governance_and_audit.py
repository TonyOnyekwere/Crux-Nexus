"""Add explicit suspension provenance and durable audit records."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision="037"
down_revision="036"
branch_labels=None
depends_on=None

def upgrade():
    uuid=postgresql.UUID(as_uuid=True)
    op.create_table("tenant_suspensions",
        sa.Column("id",uuid,primary_key=True),
        sa.Column("tenant_id",uuid,sa.ForeignKey("tenants.id",ondelete="CASCADE"),nullable=False),
        sa.Column("reason",sa.String(120),nullable=False),
        sa.Column("source",sa.String(40),nullable=False),
        sa.Column("suspended_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),
        sa.Column("suspended_by",uuid,nullable=True),
        sa.Column("restorable_by_subscription",sa.Boolean(),nullable=False,server_default=sa.false()),
        sa.Column("governance_override",sa.Boolean(),nullable=False,server_default=sa.false()),
        sa.Column("restored_at",sa.DateTime(timezone=True)),
        sa.Column("notes",sa.Text()),
    )
    op.create_index("ix_tenant_suspensions_tenant_active","tenant_suspensions",["tenant_id","restored_at"])
    op.create_table("audit_events",
        sa.Column("id",uuid,primary_key=True),
        sa.Column("event_type",sa.String(100),nullable=False),
        sa.Column("occurred_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),
        sa.Column("user_id",uuid,nullable=True),
        sa.Column("tenant_id",uuid,nullable=True),
        sa.Column("actor_type",sa.String(40),nullable=False,server_default="system"),
        sa.Column("success",sa.Boolean(),nullable=False,server_default=sa.true()),
        sa.Column("reason",sa.Text()),
        sa.Column("metadata",postgresql.JSONB,nullable=False,server_default=sa.text("'{}'::jsonb")),
    )
    op.create_index("ix_audit_events_type_time","audit_events",["event_type","occurred_at"])
    op.create_index("ix_audit_events_tenant_time","audit_events",["tenant_id","occurred_at"])

def downgrade():
    op.drop_index("ix_audit_events_tenant_time",table_name="audit_events")
    op.drop_index("ix_audit_events_type_time",table_name="audit_events")
    op.drop_table("audit_events")
    op.drop_index("ix_tenant_suspensions_tenant_active",table_name="tenant_suspensions")
    op.drop_table("tenant_suspensions")
