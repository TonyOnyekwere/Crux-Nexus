"""Add phone_number to users.

Fixes a real OTP vulnerability found in external review: the OTP request
endpoint accepted `destination` directly from the client with no
validation that it belonged to the authenticated user. For channel=email
the fix is to always use user.email server-side. For channel=sms there
was nothing to bind to at all — no phone number existed anywhere on the
User model — so allowing a client-supplied destination was the only
option, which is exactly the vulnerability. This column is what closes
that gap: SMS OTP now requires a phone_number already on file, set
through a dedicated endpoint (not this migration), never accepted
inline on the OTP request itself.

Nullable: not every user will have set a phone number, and requiring
SMS OTP without one is the intended behavior (reject the request with a
clear error), not a reason to force a value here.

Revision ID: 025
Revises: 024
"""

from alembic import op
import sqlalchemy as sa

revision = "025"
down_revision = "024"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("users", sa.Column("phone_number", sa.String(20), nullable=True))


def downgrade() -> None:
    op.drop_column("users", "phone_number")
