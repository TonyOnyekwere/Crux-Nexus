"""Enforce trial history - one lifetime introductory trial per merchant.

This migration adds constraints to ensure a merchant can only have one
lifetime introductory trial per subscription plan, preventing trial abuse.

Key changes:
1. Add unique constraint on (merchant_account_id, subscription_plan_id)
   in merchant_trial_history to enforce one lifetime trial per merchant
   and subscription plan.
2. Add check constraint to ensure trial ended_at is set when status is not TRIALING.
3. Add index for efficient trial history queries.

Note:
The subscription_id index already exists from an earlier migration and is
therefore not recreated here.

Revision ID: 016
Revises: 015
"""

from alembic import op

revision = "016"
down_revision = "015"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Enforce one lifetime introductory trial per merchant and subscription plan.
    op.execute(
        """
        ALTER TABLE merchant_trial_history
        ADD CONSTRAINT uk_merchant_plan_trial
        UNIQUE (merchant_account_id, subscription_plan_id)
        """
    )

    # Ensure completed trials always have an end timestamp,
    # while active trials must not have ended_at set.
    op.execute(
        """
        ALTER TABLE merchant_trial_history
        ADD CONSTRAINT chk_trial_ended_at
        CHECK (
            (status = 'trialing' AND ended_at IS NULL) OR
            (status != 'trialing' AND ended_at IS NOT NULL)
        )
        """
    )

    # Add index for efficient trial history queries.
    op.create_index(
        "ix_merchant_trial_history_account_status",
        "merchant_trial_history",
        ["merchant_account_id", "status"],
    )

    # Document the lifetime trial policy.
    op.execute(
        """
        COMMENT ON TABLE merchant_trial_history IS
        'One lifetime introductory trial per merchant per plan.

        The unique constraint (merchant_account_id, subscription_plan_id)
        ensures that a merchant can only have one lifetime trial record
        for each subscription plan.

        This prevents trial abuse while allowing merchants to trial
        different subscription plans.

        Trial flow:
        - status = trialing: Trial is active, ended_at is NULL
        - status = active: Trial converted to paid subscription, ended_at is set
        - status = cancelled: Trial was cancelled, ended_at is set
        - status = expired: Trial expired without conversion, ended_at is set
        '
        """
    )


def downgrade() -> None:
    # Remove trial policy documentation.
    op.execute(
        """
        COMMENT ON TABLE merchant_trial_history IS NULL
        """
    )

    # Remove account/status index created by this migration.
    op.drop_index(
        "ix_merchant_trial_history_account_status",
        table_name="merchant_trial_history",
    )

    # Remove trial completion check constraint.
    op.execute(
        """
        ALTER TABLE merchant_trial_history
        DROP CONSTRAINT IF EXISTS chk_trial_ended_at
        """
    )

    # Remove lifetime trial uniqueness constraint.
    op.execute(
        """
        ALTER TABLE merchant_trial_history
        DROP CONSTRAINT IF EXISTS uk_merchant_plan_trial
        """
    )

