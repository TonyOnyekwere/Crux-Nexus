"""Remove development payment simulator and finalize MVP plan pricing.

The onboarding journey is now production payment only. The historical 029
migration created the simulator for development; this migration removes its
runtime data/table and restores the financial transaction provider invariant.
"""
from alembic import op
import sqlalchemy as sa

revision = "031"
down_revision = "030"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("DROP TABLE IF EXISTS test_payment_simulations")
    op.drop_constraint("chk_financial_transaction_provider", "financial_transactions", type_="check")
    op.create_check_constraint(
        "chk_financial_transaction_provider",
        "financial_transactions",
        "provider IN ('paystack', 'flutterwave')",
    )

    # These are the MVP commercial prices already used by the development
    # journey. They become actual platform configuration, not code fallbacks.
    op.execute("""
        UPDATE subscription_plans
        SET price_amount = CASE code
            WHEN 'starter' THEN 5000.00
            WHEN 'business' THEN 15000.00
            WHEN 'enterprise' THEN 40000.00
            ELSE price_amount
        END,
        price_currency = CASE code
            WHEN 'starter' THEN 'NGN'
            WHEN 'business' THEN 'NGN'
            WHEN 'enterprise' THEN 'NGN'
            ELSE price_currency
        END,
        billing_interval = CASE
            WHEN billing_interval IS NULL THEN 'monthly'
            ELSE billing_interval
        END
        WHERE code IN ('starter', 'business', 'enterprise')
    """)

    op.alter_column("subscription_plans", "price_amount", nullable=False)
    op.alter_column("subscription_plans", "price_currency", nullable=False)
    op.alter_column("subscription_plans", "billing_interval", nullable=False)
    op.create_check_constraint(
        "chk_subscription_plan_price_positive",
        "subscription_plans",
        "price_amount > 0",
    )
    op.create_check_constraint(
        "chk_subscription_plan_currency",
        "subscription_plans",
        "price_currency = upper(price_currency) AND length(price_currency) = 3",
    )


def downgrade() -> None:
    op.drop_constraint("chk_subscription_plan_currency", "subscription_plans", type_="check")
    op.drop_constraint("chk_subscription_plan_price_positive", "subscription_plans", type_="check")
    op.alter_column("subscription_plans", "billing_interval", nullable=True)
    op.alter_column("subscription_plans", "price_currency", nullable=True)
    op.alter_column("subscription_plans", "price_amount", nullable=True)
    op.drop_constraint("chk_financial_transaction_provider", "financial_transactions", type_="check")
    op.create_check_constraint(
        "chk_financial_transaction_provider",
        "financial_transactions",
        "provider IN ('paystack', 'flutterwave', 'test')",
    )
