from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "044"
down_revision = "043"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("subscription_plans", sa.Column("capabilities", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")))
    op.add_column("subscription_plans", sa.Column("resource_limits", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")))
    op.create_check_constraint("ck_product_reserved_lte_stock", "products", "reserved_stock <= stock")
    op.create_check_constraint("ck_order_status", "orders", "status IN ('pending_payment','awaiting_transfer','payment_failed','confirmed','fulfilling','shipped','delivered','completed','cancelled')")
    op.create_check_constraint("ck_order_payment_status", "orders", "payment_status IN ('pending','paid','failed','refunded','partially_refunded')")
    op.create_table(
        "storefront_configurations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("theme", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("fonts", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("layout", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("component_slots", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("custom_css", sa.Text(), nullable=True),
        sa.Column("custom_domain", sa.String(255), nullable=True, unique=True),
        sa.Column("custom_domain_status", sa.String(30), nullable=False, server_default="none"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_check_constraint("ck_storefront_custom_domain_status", "storefront_configurations", "custom_domain_status IN ('none','pending','verified','disabled')")
    op.create_table(
        "merchant_payment_connections",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("provider", sa.String(40), nullable=False),
        sa.Column("status", sa.String(30), nullable=False, server_default="pending"),
        sa.Column("account_reference", sa.String(255), nullable=True),
        sa.Column("credential_reference", sa.String(255), nullable=True),
        sa.Column("configuration", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("tenant_id", "provider", name="uq_merchant_payment_connection_provider"),
    )
    op.create_index("ix_merchant_payment_connections_tenant_id", "merchant_payment_connections", ["tenant_id"])
    op.create_check_constraint("ck_merchant_payment_connection_status", "merchant_payment_connections", "status IN ('pending','connected','disabled','error')")

def downgrade():
    op.drop_column("subscription_plans", "resource_limits")
    op.drop_column("subscription_plans", "capabilities")
    op.drop_constraint("ck_merchant_payment_connection_status", "merchant_payment_connections", type_="check")
    op.drop_index("ix_merchant_payment_connections_tenant_id", table_name="merchant_payment_connections")
    op.drop_table("merchant_payment_connections")
    op.drop_constraint("ck_storefront_custom_domain_status", "storefront_configurations", type_="check")
    op.drop_table("storefront_configurations")
    op.drop_constraint("ck_order_payment_status", "orders", type_="check")
    op.drop_constraint("ck_order_status", "orders", type_="check")
    op.drop_constraint("ck_product_reserved_lte_stock", "products", type_="check")
