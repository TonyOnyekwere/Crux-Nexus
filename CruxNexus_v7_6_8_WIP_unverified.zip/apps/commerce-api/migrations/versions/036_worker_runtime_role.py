"""Create dedicated worker runtime role and explicit system execution RLS policies."""
import os
import re
from urllib.parse import urlparse, unquote
from alembic import op

revision = "036"
down_revision = "035"
branch_labels = None
depends_on = None

COMMERCE_TABLES = ["storefront_profiles", "products", "inventory_movements", "customers", "carts", "cart_items", "orders", "order_items", "commerce_payments", "fulfillments"]

def _credentials():
    raw = os.environ.get("DATABASE_WORKER_URL")
    if not raw:
        return None, None
    parsed = urlparse(raw)
    user = unquote(parsed.username or "")
    password = unquote(parsed.password or "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", user):
        raise RuntimeError("DATABASE_WORKER_URL username must be a simple PostgreSQL role identifier")
    if not password:
        raise RuntimeError("DATABASE_WORKER_URL must contain a worker-role password")
    return user, password

def upgrade():
    user, password = _credentials()
    if not user:
        return
    if user == "postgres":
        raise RuntimeError("DATABASE_WORKER_URL must not use the postgres superuser")
    ident='"'+user.replace('"','""')+'"'
    escaped=password.replace("'", "''")
    op.execute(f"DO $$ BEGIN CREATE ROLE {ident} LOGIN PASSWORD '{escaped}' NOSUPERUSER NOBYPASSRLS; EXCEPTION WHEN duplicate_object THEN ALTER ROLE {ident} NOSUPERUSER NOBYPASSRLS PASSWORD '{escaped}'; END $$;")
    op.execute(f"ALTER ROLE {ident} SET app.worker_context = '1'")
    op.execute(f"GRANT USAGE ON SCHEMA public TO {ident}")
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {ident}")
    op.execute(f"GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {ident}")
    op.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {ident}")
    op.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO {ident}")
    for table in COMMERCE_TABLES:
        policy=f"{table}_worker_access"
        op.execute(f"DROP POLICY IF EXISTS {policy} ON {table}")
        op.execute(f"CREATE POLICY {policy} ON {table} TO {ident} USING (current_user = '{user}' AND current_setting('app.worker_context', true) = '1') WITH CHECK (current_user = '{user}' AND current_setting('app.worker_context', true) = '1')")
    op.execute(f"DROP POLICY IF EXISTS tenants_worker_access ON tenants")
    op.execute(f"CREATE POLICY tenants_worker_access ON tenants TO {ident} USING (current_user = '{user}' AND current_setting('app.worker_context', true) = '1') WITH CHECK (current_user = '{user}' AND current_setting('app.worker_context', true) = '1')")

def downgrade():
    user,_=_credentials()
    if not user: return
    ident='"'+user.replace('"','""')+'"'
    for table in COMMERCE_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_worker_access ON {table}")
    op.execute("DROP POLICY IF EXISTS tenants_worker_access ON tenants")
