"""Move verified subscription activation into durable worker jobs."""
from alembic import op
import sqlalchemy as sa
revision="043"
down_revision="042"
branch_labels=None
depends_on=None
def upgrade(): op.add_column("financial_transactions",sa.Column("subscription_activation_applied",sa.Boolean(),nullable=False,server_default=sa.false()))
def downgrade(): op.drop_column("financial_transactions","subscription_activation_applied")
