"""Add merchant_name to merchant_onboarding_requests.

Fixed a real gap (external review): OnboardingService.onboard_merchant's
idempotency fingerprint compared user_id/plan_code/storefront_slug but
not merchant_name, because the ledger table (migration 015) never stored
it. That meant the same Idempotency-Key could be reused with a different
merchant_name and still be treated as "the same request" - exactly the
key-reuse-with-different-parameters case IdempotencyKeyConflictError
exists to catch.

Nullable for compatibility with any pre-existing rows (none expected in
practice, since this hasn't been run against a live database yet, but
non-destructive is the safer default regardless).

Revision ID: 026
Revises: 025
"""

from alembic import op
import sqlalchemy as sa

revision = "026"
down_revision = "025"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "merchant_onboarding_requests", sa.Column("merchant_name", sa.String(255), nullable=True)
    )


def downgrade() -> None:
    op.drop_column("merchant_onboarding_requests", "merchant_name")
