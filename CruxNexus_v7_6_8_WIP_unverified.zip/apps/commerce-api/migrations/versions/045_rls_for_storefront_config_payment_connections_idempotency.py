"""Tenant isolation for the three tenant-owned tables created after the original
commerce RLS pass: storefront_configurations and merchant_payment_connections
(migration 044) and commerce_checkout_idempotency (migration 041).

Each has tenant_id NOT NULL, so each gets ENABLE + FORCE ROW LEVEL SECURITY and
a tenant isolation policy with BOTH using and with-check, identical in form to
the policies on the other commerce tables. Tenant-first indexes are added for
the architecture gate (tenant_id as the leading column).

merchant_payment_connections is intentionally NOT given a webhook-access policy:
credential/account references must never be readable under the webhook flag.

Revision ID: 045
Revises: 044
"""
from alembic import op

revision = "045"
down_revision = "044"
branch_labels = None
depends_on = None

TABLES = ("storefront_configurations", "merchant_payment_connections", "commerce_checkout_idempotency")


def upgrade():
    # Tenant-first indexes the architecture gate (scripts/check_tenant_indexes.py) found missing on
    # older commerce tables. Literal calls on purpose: the gate reads migration source with a regex.
    op.create_index("ix_storefront_profiles_tenant_id", "storefront_profiles", ["tenant_id"])
    op.create_index("ix_carts_tenant_status", "carts", ["tenant_id", "status"])
    op.create_index("ix_order_items_tenant_order", "order_items", ["tenant_id", "order_id"])
    op.create_index("ix_fulfillments_tenant_status", "fulfillments", ["tenant_id", "status"])
    op.create_index("ix_storefront_configurations_tenant_id", "storefront_configurations", ["tenant_id"])
    op.create_index("ix_commerce_checkout_idempotency_tenant_key", "commerce_checkout_idempotency", ["tenant_id", "idempotency_key"])
    for table in TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"CREATE POLICY {table}_tenant_isolation ON {table} "
            f"USING (tenant_id::text = current_setting('app.current_tenant_id', true)) "
            f"WITH CHECK (tenant_id::text = current_setting('app.current_tenant_id', true))"
        )


def downgrade():
    for table in reversed(TABLES):
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY")
    op.drop_index("ix_commerce_checkout_idempotency_tenant_key", table_name="commerce_checkout_idempotency")
    op.drop_index("ix_storefront_configurations_tenant_id", table_name="storefront_configurations")
    op.drop_index("ix_fulfillments_tenant_status", table_name="fulfillments")
    op.drop_index("ix_order_items_tenant_order", table_name="order_items")
    op.drop_index("ix_carts_tenant_status", table_name="carts")
    op.drop_index("ix_storefront_profiles_tenant_id", table_name="storefront_profiles")
