"""Add pricing fields to subscription_plans.

Required for real subscription payment initiation (a merchant must be
charged a specific amount), but the actual production Starter/Business/
Enterprise Naira prices and billing interval are a business decision that
has NOT been supplied as of this migration (Kratos was explicit: do not
invent pricing to complete the code). All three columns are nullable and
left NULL — SubscriptionPaymentService.initiate_payment (see that module)
checks for this explicitly and refuses to proceed with a clear
"plan pricing not configured" error rather than charging an invented
amount or accepting one from the request.

price_amount uses NUMERIC, not float, for the same reason financial_transactions.amount
does (migration 022) - exact decimal arithmetic for money.

Revision ID: 027
Revises: 026
"""

from alembic import op
import sqlalchemy as sa

revision = "027"
down_revision = "026"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("subscription_plans", sa.Column("price_amount", sa.Numeric(14, 2), nullable=True))
    op.add_column("subscription_plans", sa.Column("price_currency", sa.String(3), nullable=True))
    op.add_column(
        "subscription_plans",
        sa.Column("billing_interval", sa.String(20), nullable=True),
    )
    op.execute(
        "ALTER TABLE subscription_plans ADD CONSTRAINT chk_billing_interval "
        "CHECK (billing_interval IS NULL OR billing_interval IN ('monthly', 'annual'))"
    )


def downgrade() -> None:
    op.execute("ALTER TABLE subscription_plans DROP CONSTRAINT IF EXISTS chk_billing_interval")
    op.drop_column("subscription_plans", "billing_interval")
    op.drop_column("subscription_plans", "price_currency")
    op.drop_column("subscription_plans", "price_amount")
