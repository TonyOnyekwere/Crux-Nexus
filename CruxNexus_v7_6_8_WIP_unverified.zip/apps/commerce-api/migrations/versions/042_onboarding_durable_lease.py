"""Add explicit onboarding lease owner/expiry."""
from alembic import op
import sqlalchemy as sa
revision="042"
down_revision="041"
branch_labels=None
depends_on=None
def upgrade():
    op.add_column("merchant_onboarding_requests",sa.Column("lease_owner",sa.String(120),nullable=True))
    op.add_column("merchant_onboarding_requests",sa.Column("lease_expires_at",sa.DateTime(timezone=True),nullable=True))
def downgrade():
    op.drop_column("merchant_onboarding_requests","lease_expires_at")
    op.drop_column("merchant_onboarding_requests","lease_owner")
