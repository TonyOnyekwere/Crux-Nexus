"""Commerce OS MVP data plane.

Creates the durable merchant runtime: storefront profile, products, guest
customers/carts, orders, commerce payments and fulfillment. All tenant-owned
records are RLS protected in the same migration that creates them.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "030"
down_revision = "029"
branch_labels = None
depends_on = None


def upgrade():
    uuid = postgresql.UUID(as_uuid=True)
    now = sa.text("now()")
    op.create_table(
        "storefront_profiles",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("business_name", sa.String(160), nullable=False), sa.Column("description", sa.Text()), sa.Column("category", sa.String(80)), sa.Column("phone", sa.String(30)), sa.Column("city", sa.String(100)), sa.Column("address", sa.Text()), sa.Column("currency", sa.String(3), nullable=False, server_default="NGN"), sa.Column("published", sa.Boolean(), nullable=False, server_default=sa.false()), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now),
    )
    op.create_table(
        "products",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("name", sa.String(180), nullable=False), sa.Column("slug", sa.String(180), nullable=False), sa.Column("description", sa.Text()), sa.Column("sku", sa.String(80), nullable=False), sa.Column("price", sa.Numeric(14,2), nullable=False), sa.Column("currency", sa.String(3), nullable=False, server_default="NGN"), sa.Column("stock", sa.Integer(), nullable=False, server_default="0"), sa.Column("reserved_stock", sa.Integer(), nullable=False, server_default="0"), sa.Column("published", sa.Boolean(), nullable=False, server_default=sa.false()), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now),
        sa.CheckConstraint("price >= 0", name="ck_product_price_nonnegative"), sa.CheckConstraint("stock >= 0", name="ck_product_stock_nonnegative"), sa.CheckConstraint("reserved_stock >= 0", name="ck_product_reserved_nonnegative"),
    )
    op.create_index("uq_product_tenant_sku", "products", ["tenant_id","sku"], unique=True)
    op.create_index("uq_product_tenant_slug", "products", ["tenant_id","slug"], unique=True)
    op.create_index("ix_products_tenant_published", "products", ["tenant_id","published"])
    op.create_table(
        "inventory_movements",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("product_id", uuid, sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False), sa.Column("quantity_delta", sa.Integer(), nullable=False, server_default="0"), sa.Column("reserved_delta", sa.Integer(), nullable=False, server_default="0"), sa.Column("reason", sa.String(120), nullable=False), sa.Column("reference", sa.String(120)), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now),
    )
    op.create_index("ix_inventory_movements_tenant_product", "inventory_movements", ["tenant_id","product_id","created_at"])
    op.create_table(
        "customers",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("name", sa.String(160), nullable=False), sa.Column("email", sa.String(320)), sa.Column("phone", sa.String(30), nullable=False), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now),
    )
    op.create_index("ix_customer_tenant_phone", "customers", ["tenant_id","phone"])
    op.create_table(
        "carts",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("token", sa.String(96), nullable=False, unique=True), sa.Column("customer_id", uuid, sa.ForeignKey("customers.id", ondelete="SET NULL")), sa.Column("status", sa.String(20), nullable=False, server_default="open"), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.CheckConstraint("status IN ('open','converted','abandoned')", name="ck_cart_status"),
    )
    op.create_table(
        "cart_items",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("cart_id", uuid, sa.ForeignKey("carts.id", ondelete="CASCADE"), nullable=False), sa.Column("product_id", uuid, sa.ForeignKey("products.id", ondelete="RESTRICT"), nullable=False), sa.Column("quantity", sa.Integer(), nullable=False), sa.Column("unit_price", sa.Numeric(14,2), nullable=False), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.CheckConstraint("quantity > 0", name="ck_cart_item_quantity_positive"),
    )
    op.create_index("ix_cart_items_tenant", "cart_items", ["tenant_id","cart_id"])
    op.create_index("uq_cart_product", "cart_items", ["cart_id","product_id"], unique=True)
    op.create_table(
        "orders",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("customer_id", uuid, sa.ForeignKey("customers.id", ondelete="SET NULL")), sa.Column("order_number", sa.String(40), nullable=False, unique=True), sa.Column("status", sa.String(30), nullable=False, server_default="pending_payment"), sa.Column("payment_status", sa.String(20), nullable=False, server_default="pending"), sa.Column("fulfillment_status", sa.String(30), nullable=False, server_default="unfulfilled"), sa.Column("subtotal", sa.Numeric(14,2), nullable=False), sa.Column("delivery_fee", sa.Numeric(14,2), nullable=False, server_default="0"), sa.Column("total", sa.Numeric(14,2), nullable=False), sa.Column("currency", sa.String(3), nullable=False, server_default="NGN"), sa.Column("delivery_address", sa.Text(), nullable=False), sa.Column("notes", sa.Text()), sa.Column("reservation_expires_at", sa.DateTime(timezone=True)), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.CheckConstraint("total >= 0", name="ck_order_total_nonnegative"),
    )
    op.create_index("ix_orders_tenant_status", "orders", ["tenant_id","status"])
    op.create_index("ix_orders_tenant_created", "orders", ["tenant_id","created_at"])
    op.create_table(
        "order_items",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("order_id", uuid, sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False), sa.Column("product_id", uuid, sa.ForeignKey("products.id", ondelete="RESTRICT"), nullable=False), sa.Column("product_name", sa.String(180), nullable=False), sa.Column("sku", sa.String(80), nullable=False), sa.Column("quantity", sa.Integer(), nullable=False), sa.Column("unit_price", sa.Numeric(14,2), nullable=False), sa.Column("line_total", sa.Numeric(14,2), nullable=False), sa.CheckConstraint("quantity > 0", name="ck_order_item_quantity_positive"),
    )
    op.create_index("ix_order_items_order", "order_items", ["order_id"])
    op.create_table(
        "commerce_payments",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("order_id", uuid, sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False), sa.Column("reference", sa.String(80), nullable=False, unique=True), sa.Column("provider_reference", sa.String(255)), sa.Column("provider", sa.String(30), nullable=False), sa.Column("amount", sa.Numeric(14,2), nullable=False), sa.Column("currency", sa.String(3), nullable=False, server_default="NGN"), sa.Column("status", sa.String(20), nullable=False, server_default="pending"), sa.Column("authorization_url", sa.Text()), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.CheckConstraint("status IN ('pending','successful','failed','abandoned')", name="ck_commerce_payment_status"),
    )
    op.create_index("ix_commerce_payments_tenant", "commerce_payments", ["tenant_id","status"])
    op.create_table(
        "fulfillments",
        sa.Column("id", uuid, primary_key=True), sa.Column("tenant_id", uuid, sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False), sa.Column("order_id", uuid, sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, unique=True), sa.Column("status", sa.String(30), nullable=False, server_default="unfulfilled"), sa.Column("carrier", sa.String(120)), sa.Column("tracking_number", sa.String(120)), sa.Column("notes", sa.Text()), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=now), sa.CheckConstraint("status IN ('unfulfilled','processing','shipped','delivered','cancelled')", name="ck_fulfillment_status"),
    )

    for table in ["storefront_profiles","products","inventory_movements","customers","carts","cart_items","orders","order_items","commerce_payments","fulfillments"]:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (tenant_id::text = current_setting('app.current_tenant_id', true)) WITH CHECK (tenant_id::text = current_setting('app.current_tenant_id', true))")
    # Provider webhooks are authenticated before this flag is set by the API.
    # It permits a global webhook handler to locate a payment, after which the
    # handler binds app.current_tenant_id before mutating merchant data.
    for table in ["commerce_payments", "orders", "order_items", "fulfillments"]:
        op.execute(f"CREATE POLICY {table}_webhook_access ON {table} USING (current_setting('app.webhook_context', true) = '1') WITH CHECK (current_setting('app.webhook_context', true) = '1')")
    # Public storefront reads are intentionally limited to active tenant rows.
    # The API sets this transaction-local flag only after resolving a public
    # storefront request; tenant-owned commerce tables remain tenant-bound.
    op.execute("CREATE POLICY tenant_public_storefront_read ON tenants USING (status = 'active' AND current_setting('app.public_storefront', true) = '1')")



def downgrade():
    op.execute("DROP POLICY IF EXISTS tenant_public_storefront_read ON tenants")
    for table in ["commerce_payments", "orders", "order_items", "fulfillments"]:
        op.execute(f"DROP POLICY IF EXISTS {table}_webhook_access ON {table}")
    for table in ["fulfillments","commerce_payments","order_items","orders","cart_items","carts","customers","inventory_movements","products","storefront_profiles"]:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}")
        op.drop_table(table)
