"""Make onboarding fully atomic and idempotent.

This migration ensures merchant onboarding is a single atomic transaction
that either succeeds completely or rolls back entirely, preventing partial
merchant/subscription/entitlement/tenant creation.

Key changes:
1. Add partial unique index on (merchant_account_id, subscription_plan_id)
   for TRIALING subscriptions to prevent duplicate trial onboarding.
2. Add unique constraint on (merchant_account_id, user_id) to prevent duplicate
   merchant account user relationships.
3. Add idempotency token column/table for onboarding requests.
4. Add check constraint to ensure completed onboarding requests have a merchant.
5. Add check constraint to validate subscription status values.

Revision ID: 015
Revises: 014
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "015"
down_revision = "014"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # PostgreSQL does not support WHERE clauses on UNIQUE constraints.
    # Use a partial unique index to allow only one TRIALING subscription
    # per merchant and subscription plan.
    op.execute(
        """
        CREATE UNIQUE INDEX uk_merchant_trialing_plan
        ON merchant_subscriptions (merchant_account_id, subscription_plan_id)
        WHERE status = 'trialing'
        """
    )

    # Note: Unique constraint on (merchant_account_id, user_id) already exists
    # from migration 003 (uq_merchant_user). We add a partial unique index for
    # trialing subscriptions instead, which is the new constraint needed.

    # Add idempotency token table for onboarding requests.
    op.create_table(
        "merchant_onboarding_requests",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "idempotency_key",
            sa.String(255),
            nullable=False,
            unique=True,
        ),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "plan_code",
            sa.String(50),
            nullable=False,
        ),
        sa.Column(
            "storefront_slug",
            sa.String(100),
            nullable=False,
        ),
        sa.Column(
            "merchant_account_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("merchant_accounts.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "status",
            sa.String(50),
            nullable=False,
            server_default="pending",
        ),
        sa.Column(
            "completed_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "error_message",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("NOW()"),
            nullable=False,
        ),
        sa.Index(
            "ix_merchant_onboarding_requests_idempotency_key",
            "idempotency_key",
        ),
        sa.Index(
            "ix_merchant_onboarding_requests_user_id",
            "user_id",
        ),
        sa.Index(
            "ix_merchant_onboarding_requests_status",
            "status",
        ),
    )

    # Completed onboarding requests must reference a merchant account.
    op.execute(
        """
        ALTER TABLE merchant_onboarding_requests
        ADD CONSTRAINT chk_onboarding_completed_has_merchant
        CHECK (
            (status != 'completed' AND merchant_account_id IS NULL) OR
            (status = 'completed' AND merchant_account_id IS NOT NULL)
        )
        """
    )

    # Validate allowed subscription status values.
    op.execute(
        """
        ALTER TABLE merchant_subscriptions
        ADD CONSTRAINT chk_subscription_status_transition
        CHECK (
            status IN ('trialing', 'active', 'cancelled', 'expired', 'suspended')
        )
        """
    )


def downgrade() -> None:
    # Remove subscription status check constraint.
    op.execute(
        """
        ALTER TABLE merchant_subscriptions
        DROP CONSTRAINT IF EXISTS chk_subscription_status_transition
        """
    )

    # Remove onboarding completion check constraint.
    op.execute(
        """
        ALTER TABLE merchant_onboarding_requests
        DROP CONSTRAINT IF EXISTS chk_onboarding_completed_has_merchant
        """
    )

    # Drop idempotency table.
    op.drop_table("merchant_onboarding_requests")

    # Partial unique index is an INDEX, not a constraint.
    op.execute(
        """
        DROP INDEX IF EXISTS uk_merchant_trialing_plan
        """
    )

    # Note: uq_merchant_user constraint is not removed here because it was
    # added in migration 003 and should be removed in migration 003's downgrade.