"""Create onboarding_sessions and onboarding_step_events.

Per the locked CruxNexus Merchant Onboarding & Activation Architecture
(2026-09-17), sections 15/48-52. This is the resumable session that the
onboarding journey (welcome -> account -> verify -> plan -> trial/pay-now
-> store -> product -> review -> launch) runs on top of. It replaces
nothing: merchant_onboarding_requests (migration 015) remains the
idempotency ledger for the atomic provisioning transaction; this is the
journey/session layer above it. A session's `launch` step is what
eventually calls the existing OnboardingService.onboard_merchant with an
idempotency key derived from the session.

owner_user_id is nullable because a session can exist before an account
does (the "Welcome"/business-context steps precede account creation in
the locked journey). tenant_id is nullable until launch succeeds.
`version` is the optimistic-concurrency column for If-Match-style
cross-device-safe updates (section 50).

Revision ID: 021
Revises: 020
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "021"
down_revision = "020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "onboarding_sessions",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column("device_session_token", sa.String(255), nullable=False, unique=True),
        sa.Column("owner_email", sa.String(320), nullable=True),
        sa.Column(
            "owner_user_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("flow_version", sa.String(20), nullable=False, server_default="v1"),
        sa.Column("current_step", sa.String(50), nullable=False, server_default="welcome"),
        sa.Column(
            "completed_steps",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default="[]",
        ),
        sa.Column(
            "payload",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default="{}",
        ),
        sa.Column("status", sa.String(30), nullable=False, server_default="in_progress"),
        sa.Column("version", sa.Integer, nullable=False, server_default="1"),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("launch_attempt_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("last_launch_error", sa.Text(), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "status IN ('in_progress', 'launching', 'completed', 'abandoned', 'expired', 'recovery_required')",
            name="chk_onboarding_session_status",
        ),
    )
    op.create_index(
        "ix_onboarding_sessions_owner_user_id",
        "onboarding_sessions",
        ["owner_user_id"],
    )
    op.create_index(
        "ix_onboarding_sessions_owner_email",
        "onboarding_sessions",
        ["owner_email"],
    )
    op.create_index(
        "ix_onboarding_sessions_status_expires",
        "onboarding_sessions",
        ["status", "expires_at"],
    )

    op.create_table(
        "onboarding_step_events",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "session_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("onboarding_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("step", sa.String(50), nullable=False),
        sa.Column("event_type", sa.String(30), nullable=False),
        sa.Column(
            "event_metadata",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default="{}",
        ),
        sa.Column(
            "occurred_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "event_type IN ('step_entered', 'step_completed', 'step_failed', 'abandoned_from')",
            name="chk_onboarding_step_event_type",
        ),
    )
    op.create_index(
        "ix_onboarding_step_events_session_id",
        "onboarding_step_events",
        ["session_id"],
    )
    op.create_index(
        "ix_onboarding_step_events_step_event_type",
        "onboarding_step_events",
        ["step", "event_type"],
    )


def downgrade() -> None:
    op.drop_table("onboarding_step_events")
    op.drop_table("onboarding_sessions")
