"""Apply the ADR-0009 control-plane RLS policy to the tenants table.

ADR-0009 ("Tenants Table as Platform Control Plane Data") documents this
policy as ACCEPTED and already implemented:

    CREATE POLICY tenant_management_isolation ON tenants
    USING (false)
    WITH CHECK (false)

That policy was never actually written to a migration. No prior revision
enables RLS on `tenants` at all, so the table has had no database-level
protection since it was created in migration 001 — despite the ADR and
several remediation records describing it as done.

This migration makes the ADR true. All application access to `tenants`
continues to go through `TenantService` using the standard (non-RLS-bound)
session, exactly as it does today — this migration only closes off
*direct* table access (ad hoc queries, a future compromised low-privilege
role, a mistyped raw SQL statement) from ever reading or writing rows in
the tenant registry.

Revision ID: 017
Revises: 016
"""

from alembic import op

revision = "017"
down_revision = "016"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TABLE tenants ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE tenants FORCE ROW LEVEL SECURITY")
    op.execute(
        """
        CREATE POLICY tenant_management_isolation ON tenants
        USING (false)
        WITH CHECK (false)
        """
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS tenant_management_isolation ON tenants")
    op.execute("ALTER TABLE tenants NO FORCE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE tenants DISABLE ROW LEVEL SECURITY")
