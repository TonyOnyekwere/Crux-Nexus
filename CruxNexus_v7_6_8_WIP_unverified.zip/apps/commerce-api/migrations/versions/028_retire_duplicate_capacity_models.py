"""Retire storefront_staff_capacity and storefront_entitlement_allocations.

Establishing one canonical entitlement/allocation model — a prerequisite
explicitly called out before adding an entitlement-reconciliation worker
loop, since a worker reconciling between three competing models would
just formalize the confusion rather than resolve it.

Verified by inspection (grep across app/ for every symbol/table name,
2026-09-24) that both retired tables have ZERO real usage anywhere in
application code — no service, route, or worker ever reads or writes
either one. Only `staff_capacity_allocations` (StaffCapacityAllocation)
is actually wired into CapacityService/EntitlementAllocationService.

- storefront_entitlement_allocations (StorefrontEntitlementAllocation):
  its own docstring describes literally the same purpose as
  StaffCapacityAllocation ("allows merchant-owned extra staff capacity
  to be distributed across storefronts") with an equivalent schema
  (entitlement FK, tenant_id, quantity) — a duplicate from an earlier
  design iteration that staff_capacity_allocations superseded without
  the old table ever being cleaned up.
- storefront_staff_capacity (StorefrontStaffCapacity): a different,
  third approach — a cached/denormalized per-storefront capacity value
  (base_staff_capacity + additional_staff_capacity) rather than the
  dynamically-computed approach CapacityService.get_storefront_staff_capacity
  actually uses (plan config + live entitlement/allocation sums). Never
  adopted; would need its own cache-invalidation logic to ever be
  correct, which the dynamic approach doesn't.

Revision ID: 028
Revises: 027
"""

from alembic import op

revision = "028"
down_revision = "027"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_table("storefront_entitlement_allocations")
    op.drop_table("storefront_staff_capacity")


def downgrade() -> None:
    # Recreates the tables' shape for rollback safety, but does not
    # restore any data (both were confirmed empty of meaningful state —
    # nothing ever wrote to them) and does not restore any application
    # code path that used them, since none existed.
    import sqlalchemy as sa
    from sqlalchemy.dialects import postgresql

    op.create_table(
        "storefront_staff_capacity",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
            unique=True,
        ),
        sa.Column("base_staff_capacity", sa.Integer, nullable=False, server_default="0"),
        sa.Column("additional_staff_capacity", sa.Integer, nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_table(
        "storefront_entitlement_allocations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "entitlement_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("merchant_entitlements.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("quantity", sa.Integer, nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
