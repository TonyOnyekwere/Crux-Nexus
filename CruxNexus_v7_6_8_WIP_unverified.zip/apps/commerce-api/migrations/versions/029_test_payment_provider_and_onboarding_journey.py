"""Development payment simulator support + onboarding journey lookup index.

CRX-P0-030.

1. financial_transactions.provider CHECK now also allows 'test'. The value
   can only ever be written when ENABLE_TEST_PAYMENT_PROVIDER is on outside
   production (Settings refuses that combination at startup), but the
   constraint must permit it for the simulator to run the real pipeline.
2. test_payment_simulations: the simulator's stand-in for "the provider's own
   record of the charge" - what verify_transaction independently re-queries,
   exactly as Paystack/Flutterwave verify would. Empty in production.
3. Partial unique index: at most one non-terminal onboarding session per
   owner, so a user can't fork parallel journeys that each provision a
   merchant.

Revision ID: 029
Revises: 028
"""

from alembic import op
import sqlalchemy as sa

revision = "029"
down_revision = "028"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_constraint("chk_financial_transaction_provider", "financial_transactions", type_="check")
    op.create_check_constraint(
        "chk_financial_transaction_provider",
        "financial_transactions",
        "provider IN ('paystack', 'flutterwave', 'test')",
    )

    op.create_table(
        "test_payment_simulations",
        sa.Column("reference", sa.String(100), primary_key=True),
        sa.Column("amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False),
        sa.Column("outcome", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint("outcome IN ('pending', 'success', 'failed')", name="chk_test_payment_outcome"),
    )

    op.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS uq_one_open_onboarding_session_per_owner
        ON onboarding_sessions (owner_user_id)
        WHERE owner_user_id IS NOT NULL
          AND status IN ('in_progress', 'launching', 'recovery_required')
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS uq_one_open_onboarding_session_per_owner")
    op.drop_table("test_payment_simulations")
    op.drop_constraint("chk_financial_transaction_provider", "financial_transactions", type_="check")
    op.create_check_constraint(
        "chk_financial_transaction_provider",
        "financial_transactions",
        "provider IN ('paystack', 'flutterwave')",
    )
