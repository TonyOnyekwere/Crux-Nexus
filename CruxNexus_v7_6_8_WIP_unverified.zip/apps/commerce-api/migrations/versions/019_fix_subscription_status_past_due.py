"""Add 'past_due' to the merchant_subscriptions status check constraint.

Migration 015 added chk_subscription_status_transition restricting
merchant_subscriptions.status to ('trialing', 'active', 'cancelled',
'expired', 'suspended'). The Python SubscriptionStatus enum
(app/contexts/billing/domain/merchant_subscription.py) also defines
PAST_DUE = "past_due", used nowhere in the current codebase yet (there is
no real payment processing), but any future code that sets a
subscription to PAST_DUE after a failed renewal charge would fail at the
database with a check-constraint violation. Since this column is a plain
sa.String(50), not a native Postgres enum type, fixing it is a
straightforward constraint replacement (no ALTER TYPE ADD VALUE
transaction rules to worry about, unlike migration 018's userstatus fix).

Revision ID: 019
Revises: 018
"""

from alembic import op

revision = "019"
down_revision = "018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE merchant_subscriptions DROP CONSTRAINT chk_subscription_status_transition"
    )
    op.execute(
        """
        ALTER TABLE merchant_subscriptions
        ADD CONSTRAINT chk_subscription_status_transition
        CHECK (
            status IN ('trialing', 'active', 'past_due', 'cancelled', 'expired', 'suspended')
        )
        """
    )


def downgrade() -> None:
    op.execute(
        "ALTER TABLE merchant_subscriptions DROP CONSTRAINT chk_subscription_status_transition"
    )
    op.execute(
        """
        ALTER TABLE merchant_subscriptions
        ADD CONSTRAINT chk_subscription_status_transition
        CHECK (
            status IN ('trialing', 'active', 'cancelled', 'expired', 'suspended')
        )
        """
    )
