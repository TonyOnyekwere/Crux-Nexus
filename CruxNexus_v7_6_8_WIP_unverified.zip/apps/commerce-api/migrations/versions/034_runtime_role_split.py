"""Establish a non-superuser runtime database role for the Commerce API.

DATABASE_URL remains the migration/admin connection. DATABASE_RUNTIME_URL is
used by the API and worker. The runtime role is explicitly NO BYPASSRLS so
merchant-owned Commerce tables are always subject to PostgreSQL RLS.
"""
import os
import re
from urllib.parse import urlparse, unquote

from alembic import op

revision = "034"
down_revision = "033"
branch_labels = None
depends_on = None


def _runtime_credentials():
    raw = os.environ.get("DATABASE_RUNTIME_URL")
    if not raw:
        return None, None
    parsed = urlparse(raw)
    user = unquote(parsed.username or "")
    password = unquote(parsed.password or "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", user):
        raise RuntimeError("DATABASE_RUNTIME_URL username must be a simple PostgreSQL role identifier")
    if not password:
        raise RuntimeError("DATABASE_RUNTIME_URL must contain a runtime-role password")
    return user, password


def upgrade() -> None:
    user, password = _runtime_credentials()
    if not user:
        # Non-production/local environments may still use one database URL.
        # Production Settings requires DATABASE_RUNTIME_URL, so production
        # cannot silently skip this hardening migration.
        return
    if user == "postgres":
        raise RuntimeError("DATABASE_RUNTIME_URL must not use the postgres superuser")
    escaped = password.replace("'", "''")
    ident = '"' + user.replace('"', '""') + '"'
    op.execute(f"DO $$ BEGIN CREATE ROLE {ident} LOGIN PASSWORD '{escaped}' NOSUPERUSER NOBYPASSRLS; EXCEPTION WHEN duplicate_object THEN ALTER ROLE {ident} NOSUPERUSER NOBYPASSRLS PASSWORD '{escaped}'; END $$;")
    op.execute(f"GRANT USAGE ON SCHEMA public TO {ident}")
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {ident}")
    op.execute(f"GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {ident}")
    op.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {ident}")
    op.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO {ident}")
    # Tenant registry is platform-owned state. It is not merchant-owned RLS
    # data; the non-superuser runtime role may access it, while Commerce data
    # remains protected by tenant RLS policies.
    op.execute(f"DROP POLICY IF EXISTS tenants_runtime_access ON tenants")
    op.execute(f"CREATE POLICY tenants_runtime_access ON tenants TO {ident} USING (true) WITH CHECK (true)")


def downgrade() -> None:
    user, _ = _runtime_credentials()
    if not user:
        return
    ident = '"' + user.replace('"', '""') + '"'
    op.execute("DROP POLICY IF EXISTS tenants_runtime_access ON tenants")
