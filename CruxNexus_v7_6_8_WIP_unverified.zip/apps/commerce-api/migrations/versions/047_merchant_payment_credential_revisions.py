"""Immutable merchant payment credential REVISIONS.

A merchant may replace the provider account behind a connection. Payments already initiated against
the old account must still be verified against THAT account, never the new one. Therefore a credential
is never mutated: each replacement is a new revision; every commerce payment records the exact
revision it was initiated with; a retired revision stays available while any payment that used it is
non-terminal (pending) or still needs a refund, and is only then purged (secret material zeroed, row
kept as history).

  * merchant_payment_credentials : + revision, status (pending|active|retired|purged), aad_version,
                                    retired_at, purged_at; nonce/ciphertext nullable (NULL once purged).
                                    One row per (connection, revision); at most ONE active per connection.
                                    aad_version 1 = legacy AAD (tenant|connection|provider), 2 = revision AAD.
  * commerce_payments            : + credential_id (RESTRICT) = the revision used at initiation.

Revision ID: 047
Revises: 046
"""
import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "047"
down_revision = "046"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("merchant_payment_credentials", sa.Column("revision", sa.Integer(), nullable=False, server_default="1"))
    op.add_column("merchant_payment_credentials", sa.Column("status", sa.String(20), nullable=False, server_default="active"))
    op.add_column("merchant_payment_credentials", sa.Column("aad_version", sa.SmallInteger(), nullable=False, server_default="1"))
    op.add_column("merchant_payment_credentials", sa.Column("retired_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("merchant_payment_credentials", sa.Column("purged_at", sa.DateTime(timezone=True), nullable=True))
    op.alter_column("merchant_payment_credentials", "nonce", existing_type=sa.LargeBinary(), nullable=True)
    op.alter_column("merchant_payment_credentials", "ciphertext", existing_type=sa.LargeBinary(), nullable=True)
    op.drop_constraint("uq_merchant_payment_credentials_connection", "merchant_payment_credentials", type_="unique")
    op.create_unique_constraint("uq_merchant_payment_credentials_revision", "merchant_payment_credentials", ["connection_id", "revision"])
    op.create_check_constraint("ck_merchant_payment_credentials_status", "merchant_payment_credentials",
                               "status IN ('pending','active','retired','purged')")
    op.create_check_constraint("ck_merchant_payment_credentials_purged", "merchant_payment_credentials",
                               "(status = 'purged') = (ciphertext IS NULL AND nonce IS NULL)")
    op.execute("CREATE UNIQUE INDEX uq_merchant_payment_credentials_one_active ON merchant_payment_credentials (connection_id) WHERE status = 'active'")
    op.execute("CREATE UNIQUE INDEX uq_merchant_payment_credentials_one_pending ON merchant_payment_credentials (connection_id) WHERE status = 'pending'")
    op.create_index("ix_merchant_payment_credentials_tenant_conn_status", "merchant_payment_credentials", ["tenant_id", "connection_id", "status"])

    op.add_column("commerce_payments", sa.Column(
        "credential_id", postgresql.UUID(as_uuid=True),
        sa.ForeignKey("merchant_payment_credentials.id", ondelete="RESTRICT"), nullable=True))
    op.create_index("ix_commerce_payments_credential_id", "commerce_payments", ["credential_id"])


def downgrade():
    op.drop_index("ix_commerce_payments_credential_id", table_name="commerce_payments")
    op.drop_column("commerce_payments", "credential_id")
    op.drop_index("ix_merchant_payment_credentials_tenant_conn_status", table_name="merchant_payment_credentials")
    op.execute("DROP INDEX IF EXISTS uq_merchant_payment_credentials_one_pending")
    op.execute("DROP INDEX IF EXISTS uq_merchant_payment_credentials_one_active")
    op.drop_constraint("ck_merchant_payment_credentials_purged", "merchant_payment_credentials", type_="check")
    op.drop_constraint("ck_merchant_payment_credentials_status", "merchant_payment_credentials", type_="check")
    op.drop_constraint("uq_merchant_payment_credentials_revision", "merchant_payment_credentials", type_="unique")
    # Downgrade keeps only the newest non-purged revision per connection (the single-row model).
    op.execute("""
        DELETE FROM merchant_payment_credentials c
        USING merchant_payment_credentials newer
        WHERE c.connection_id = newer.connection_id AND c.revision < newer.revision
    """)
    op.execute("DELETE FROM merchant_payment_credentials WHERE ciphertext IS NULL")
    op.create_unique_constraint("uq_merchant_payment_credentials_connection", "merchant_payment_credentials", ["connection_id"])
    op.alter_column("merchant_payment_credentials", "ciphertext", existing_type=sa.LargeBinary(), nullable=False)
    op.alter_column("merchant_payment_credentials", "nonce", existing_type=sa.LargeBinary(), nullable=False)
    for col in ("purged_at", "retired_at", "aad_version", "status", "revision"):
        op.drop_column("merchant_payment_credentials", col)
