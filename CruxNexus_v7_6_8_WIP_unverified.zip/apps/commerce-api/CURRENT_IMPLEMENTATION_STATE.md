# CruxNexus Current Implementation State

This document is the runtime implementation source of truth for the Commerce API MVP. Historical remediation/review documents may describe earlier repository states and are not authoritative for current capabilities.

## Implemented Commerce Plane

- Identity, password authentication, JWT and OTP verification.
- Real SendGrid email delivery for OTP and staff invitation email.
- Merchant provisioning, subscriptions, trials, payment activation and entitlements.
- Storefront profile and readiness-gated publishing.
- Products and inventory movements; stock changes use the inventory adjustment authority.
- Guest customers, carts and header-based cart bearer tokens.
- Server-owned checkout totals; MVP delivery fee is calculated server-side as zero until logistics pricing exists.
- Durable orders, order items and a secure per-order access token.
- Paystack and Flutterwave payment initialization, signed webhooks and independent provider verification.
- Commerce payment reconciliation and late-payment/refund-required handling for already-cancelled orders.
- Fulfillment transitions with payment/state guards.
- Subscription lifecycle worker: ACTIVE -> PAST_DUE -> SUSPENDED, with grace period and storefront suspension.
- Trial, onboarding, entitlement, commerce reservation, webhook, event relay and subscription lifecycle workers.
- Shared worker database engine/session factory.
- Tenant RLS for merchant-owned Commerce tables and a non-superuser runtime database role.
- Prometheus `/metrics` endpoint with worker run and failure counters.

## Worker execution

The worker process runs the seven existing lifecycle/reconciliation loops plus one durable job executor. The lifecycle loops retain their explicit domain responsibility; new deferred commands use `worker_jobs` with leases, attempts, retries and dead-letter state rather than creating another polling loop.

The worker uses a dedicated `DATABASE_WORKER_URL` role with `NOSUPERUSER`, `NOBYPASSRLS`, and explicit PostgreSQL worker policies. Commerce RLS remains forced.

## Control Plane

`apps/control-center-api` is a separate deployable with its own PostgreSQL schema, platform-admin identities, TOTP MFA, RBAC, governance policy, subscription-plan governance, provider registry and durable platform audit. Approved governance state synchronizes one-way into Commerce through service-authenticated endpoints. Commerce never connects directly to the Control Center database.

## Deliberate remaining product scope

Logistics providers, shipment/tracking integrations, multi-channel notifications, product variants/pricing/promotions, customer accounts, search, analytics/intelligence, evidence/trust/fraud, refunds/disputes, data export/exit, production DR verification and frontend applications remain the next product domains. They are not represented as implemented merely because the current backend can support them.

## Runtime requirements

Production requires:

- `DATABASE_URL`: migration/admin connection.
- `DATABASE_RUNTIME_URL`: non-superuser, non-BYPASSRLS merchant API connection.
- `DATABASE_WORKER_URL`: separate non-superuser, non-BYPASSRLS system-worker connection.
- `REDIS_URL`.
- strong JWT/application/control-center secrets.
- SendGrid credentials.
- at least one Paystack or Flutterwave credential.
- HTTPS `PUBLIC_APP_URL`.

Apply all Alembic migrations through the current head before starting the worker.

## Commerce context boundary

Commerce is a first-class bounded context under `app/contexts/commerce/`. Its persistence models and domain invariants live under `domain/`, application-level commerce payment behavior lives under `application/services/`, and HTTP adapters/schemas live under `api/`. The package exports the existing `merchant` and `public` routers so external API contracts remain stable while the implementation is no longer concentrated in a single `commerce.py` module.

## Commercial/runtime closure fixes in v7.6.2 work

The current implementation also closes the identified Gate A defects: onboarding storefront provisioning delegates to the canonical tenant/capacity path; ACTIVE subscriptions reject new pay-now charges; definitive provider rejection closes the subscription payment state; Flutterwave webhooks normalize `tx_ref`; provider-not-found webhook outcomes are terminal rather than endlessly retryable; stale subscription reconciliation claims one row per commit; expired entitlements are excluded synchronously from staff capacity; staff deallocation locks the allocation and entitlement rows; and worker success counters are incremented after successful sweeps.

- Commerce worker access to forced-RLS tables is explicitly authorized through a dedicated worker role and PostgreSQL worker policies.
- Commerce mutation endpoints enforce the declared tenant-role permission matrix.
- Subscription suspension records carry source, reason and restoration authority; subscription payment cannot override a Control Center governance suspension.
- Commercial lifecycle policy is stored as governance state rather than hardcoded grace/period constants.
- Definitive Commerce payment failure immediately releases reserved inventory.
- Commerce webhook retries remain durable when provider outcomes are unknown.
- Outbox publication uses Redis Streams and records transport identifiers/attempt errors.
- Durable worker jobs provide lease/retry/dead-letter semantics.
- Durable audit records cover governance, suspension and staff-allocation mutations.
- Dependencies are pinned for reproducible installs.


## v7.6.3 foundation hardening
- Alembic head: 044.
- Control Center Alembic head: 005.
- Checkout requires tenant-scoped `Idempotency-Key` and stores replayable responses.
- Definitive stale commerce payment failure releases reservations immediately.
- Generic external-payment initialization exceptions remain pending for reconciliation.
- Worker jobs use committed leases plus fencing tokens and reclaim expired running jobs.
- Verified subscription activation is a durable `billing.activate_subscription` worker command.
- Duplicate Commerce payment webhook boundary is retired; billing webhook inbox is canonical.
- Staff admission serializes on the merchant account row.
- Control Center governance changes use a durable synchronization outbox with versioned payloads.
- Control Center plan pricing validates amount, currency and billing interval before commit.


## v7.6.5
Boot/runtime defects closed; canonical order/fulfillment rules in `commerce/domain/fulfillment_rules.py`; RLS migration 045; tier entitlement engine (`app/kernel/access/entitlement_policy.py`); presentation, custom-domain and payment-connection APIs. Not live-certified. See `MVP_RELEASE_v7_6_5.md`.


## v7.6.6
Merchant-owned customer payments (sealed credentials, per-merchant webhooks, connection-gated checkout, worker reconciliation with merchant credentials); generalized entitlements and add-on policy folding; baseline plan matrix as Control Center data; payment-channel-separation CI gate. Not live-certified. See `MVP_RELEASE_v7_6_6.md`.


## v7.6.7
Gate 1 (financial/commerce correctness): immutable payment credential revisions, subscription charge lock, currency authority (NGN/GHS/KES/ZAR), late bank-transfer integrity, POD reservation policy, checkout idempotency recovery, atomic worker lease fencing, merchant-configured payment/fulfillment methods, single public storefront boundary with readiness gate, legacy routes retired (410), production vault requirement, working rate limiting, route-template metrics, ORM/import cleanup. Commerce migration head 048. Not live-certified. See `MVP_RELEASE_v7_6_7.md`.
