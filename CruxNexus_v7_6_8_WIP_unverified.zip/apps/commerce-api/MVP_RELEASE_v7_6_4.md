# CruxNexus v7.6.4 Product-Foundation Continuation

This release continues from v7.6.3 without redefining CruxNexus.

## Implemented
- Fixed executable route decorator/import defects in Commerce routes.
- Fixed missing runtime imports in merchant management, onboarding, tenant management, and identity.
- Canonicalized order and fulfillment transitions so `confirmed → fulfilling → shipped → delivered → completed` is reachable.
- Preserved POD as a merchant-selected payment method that may fulfill before payment; payment is confirmed at delivery.
- Prepaid/transfer orders require confirmed payment before fulfillment.
- Inventory is deducted at shipment and reservation is released on cancellation.
- Added DB constraints for order/payment state and `reserved_stock <= stock`.
- Added deterministic product lock ordering for checkout.
- Added generated storefront slug behavior from business name when the merchant does not explicitly supply one.
- Added Control Center-owned dynamic plan `capabilities` and `resource_limits`.
- Added independent storefront presentation configuration: theme, fonts, layout, component slots, custom CSS, and custom-domain state.
- Added the merchant payment-connection persistence boundary without making CruxNexus the payment intermediary.
- Added the Product Constitution as a repository-level non-negotiable contract.
- Added executable CI import gate and ruff undefined-name checks.

## Not falsely claimed complete
Merchant-owned credential secret management, provider-specific merchant-account execution, custom-domain DNS/verification workflow, visual builder frontend, logistics adapters, refunds/disputes, customer accounts, discovery/search/analytics, export jobs, full behavioral Postgres/RLS certification, and provider sandboxes remain implementation work.
