# CruxNexus v7.6.7 — Gate 1: financial and commerce correctness

Base: CruxNexus_MVP_v7_6_6.zip (the canonical baseline). Implements the locked Gate 1 order, one item at a time,
with the decisions recorded in `docs/CRUXNEXUS_PRODUCT_CONSTITUTION.md` section 16. No architecture reset; nothing added
that was not asked for. Migrations 047 and 048 are new; head is **048**.

## Review claims checked against the code (what was real)
Confirmed and fixed: #1 charge lock, #2 credential versioning, #3 currency, #4 publication boundary, #6 legacy configuration route,
#10 bank-transfer confirmation, #11 POD reservation policy, #12 idempotency recovery, #13 lease fencing, #19 rate limiting
(worse than reported: the key function was `async`, the 429 handler returned a dict, and the key trusted a client header),
#20 metrics cardinality, #25 production vault requirement, #26 duplicate `__table_args__` (Product and Order; Order's status CHECKs
were silently dropped from ORM metadata), #27 wildcard imports (30 removed).
Not real / already fixed in the baseline: "onboarding creates the storefront published=True" (it already created it `published=False`);
production already required a payment provider and an https `PUBLIC_APP_URL`.

## The 15 Gate 1 items
1. **Credential revisions** (047). `merchant_payment_credentials` gains revision/status/aad_version/retired_at/purged_at; one ACTIVE per connection;
   `commerce_payments.credential_id` records the revision used. Replacing credentials verifies the NEW revision with the provider first and only
   then retires the old one; a failed or inconclusive replacement never breaks a working connection; a slow verification cannot overwrite a newer
   change (compare against the highest revision). Webhooks authenticate with the payment's own revision (then the active one); reconciliation and
   event processing verify against the payment's revision regardless of what the connection points to now. Disconnecting retires the revision and
   keeps the sealed secret ONLY while a payment is pending or owed a refund; purge happens under each tenant's own binding (no cross-tenant read
   of the credentials table). Ciphertexts are bound to their revision id (AAD v2); legacy rows stay readable (AAD v1).
2. **Subscription charge lock.** `domain/charge_lock.py`: SUCCESS -> paid; FAILED/ABANDONED -> terminal; NOT_FOUND terminal only past the provider's
   conclusive window (Paystack: 120 s, because it creates the record at initialize; **Flutterwave: never, until a sandbox confirms its behaviour**);
   PENDING/UNKNOWN/unrecognized -> block, at any age. Provider status normalization fixed: Paystack `ongoing`/`queued` were being mapped to FAILED
   (a customer could still pay them); now in-flight. New ABANDONED and UNKNOWN states.
3. **Currency authority** (048). NGN/GHS/KES/ZAR; storefront currency is the single authority; products take it from the storefront (clients cannot
   set it); checkout rejects mismatches; order, payment and the provider charge use it; changing it is locked once products or orders exist;
   a profile edit can no longer silently reset it to NGN (the old upsert did). DB CHECKs on four tables.
4. **Bank-transfer integrity.** `plan_late_bank_transfer`: live reservation -> confirm; expired but not cancelled -> re-check stock; worker-expired
   order -> may reopen only if stock re-reserves; anything deliberately cancelled/failed -> refund-required, never revived. Cancellation reason is recorded
   (`orders.cancellation_reason`). Re-reservation locks products in a fixed order, all-or-nothing, and writes the ledger.
5. **POD lifecycle.** No reservation deadline for pay-on-delivery; held until fulfilled or cancelled.
6. **Checkout idempotency recovery.** Only a duplicate key is a replay (the blanket `except Exception` hid real faults). Rows carry a lease
   (`processing_since`) and a link to their order; a replay past the lease, or the worker, rebuilds the response from durable state. The order access
   token is no longer stored: shown once to the original caller, omitted on replay/recovery.
7. **Worker lease fencing.** `complete_job`/`fail_job` are atomic compare-and-set on (id, running, locked_by, lease_token) with the lease checked
   against the DATABASE clock; a stale worker raises `LeaseLostError`, and because its effects share the transaction they are rolled back.
8. **Merchant-configured payment methods.** `storefront_profiles`: pod_enabled, bank_transfer_enabled/details/window, pickup_enabled, delivery_enabled
   (all default OFF); per-connection `enabled`. `GET/PUT /commerce/payment-methods/config`, `PUT /commerce/fulfillment-methods`,
   `PUT /commerce/payment-connections/{provider}/availability`. Checkout validates every method through `payment_methods.method_availability`;
   bank-transfer instructions and pay-before time are returned to the customer; checkout accepts `fulfillment_method` (delivery|pickup).
9. **Publication boundary.** `resolve_public_storefront` is the only public resolver (ten duplicated copies removed): tenant active + profile exists +
   explicitly published + commercially entitled; everything else is a uniform 404. Publishing runs the readiness rules (published product, usable
   payment method, fulfillment method, contact details, business name); `GET /storefront/readiness`, `POST /storefront/unpublish`.
10. **Legacy routes retired (410)**: `GET/PUT /storefront/configuration`, `GET /payment-connections`, `PUT /payment-connections/{provider}`,
    `POST /payment-connections/{provider}/disable`. The repository contains no frontend and no other consumer.
11. **Production startup** refuses to boot without a valid `CREDENTIAL_ENCRYPTION_KEYS` set (and active version present).
12. **Rate limiting actually applied** (SlowAPI over Redis, in-memory fallback if Redis is down): login 10/min; registration 20/h; OTP; credential
    intake 5/h per merchant under a 30/h IP ceiling; checkout 30/min per IP+store under 120/min per IP; merchant webhooks 300/min per webhook token
    (not per shared provider IP) under a 3000/min IP flood ceiling; platform webhooks per provider; default 300/min per IP; health and metrics
    exempt. Client IP honours exactly `TRUSTED_PROXY_HOPS` (default 1) entries from the right of X-Forwarded-For. 429 is a valid JSON response with Retry-After.
13. **Metrics** label by route template. (Also fixed: CORS did not allow `X-Cart-Token` / `X-Order-Token`, so a browser storefront could not use carts.)
14. **`__table_args__`** merged (Product, Order); guard test + gate.
15. **Wildcard imports** replaced by explicit imports; 206 unused imports removed from the commerce context and the files touched.

Also: stale `docs/CRX-P0-030-...` deleted; the repository gate now fails on any reference to the removed payment simulator in docs, tests,
config or code (migrations 029/031 are history and kept).

## Verification (precise)
- EXECUTED here and passing: credential revisions 7, charge lock 9, currency authority 7, payment methods/reservations 15,
  Gate 1 hardening 11, vault 9 (real AES-GCM), merchant payment rules 6, fulfillment rules 14, entitlement/presentation/add-on 35,
  Control Center plan policy 8. Compile (both services), undefined-name gate (0, both services), payment-channel separation gate (0),
  review gate 43/43 (3 new checks fail on v7.6.6 and pass now), model-attribute checker 0, ORM table classification, tenant-index gate,
  ci.yml parse, migration chain 001-048 single head.
- WRITTEN, NOT EXECUTED (need PostgreSQL / Redis / HTTP in CI): `tests/integration/test_worker_job_fencing.py`, `tests/integration/test_rate_limiting.py`,
  `tests/unit/test_production_startup_requirements.py` (needs pydantic-settings), the updated `test_payment_initiation_safety.py`, and every DB-backed
  path above (migrations 047/048, revision lifecycle, late bank transfer, recovery worker, publication resolver, readiness, new routes).
  `import app.main` itself could not be run here (dependencies unavailable); CI is the authority.
- Not claimed: ruff/black/mypy cleanliness (black and the OpenAPI artifact were not run), provider sandbox behaviour.

## Needs your attention
1. **Order tracking now follows the public boundary.** Customers of a store that is unpublished, suspended or lapsed can no longer look up their order.
   If you want order tracking exempt (reasonable: they already paid), say so and it is a one-line change to a lenient resolver.
2. **Flutterwave** "not found" never unlocks a retry, so an abandoned Flutterwave subscription checkout blocks a new charge until Flutterwave reports a
   terminal state. Confirm its unknown-reference behaviour in a sandbox, then give it a conclusive window.
3. **Provider "pending" forever.** By your rule nothing times out into a second charge. There is no operator override yet; a subscription stuck behind a
   provider that never resolves needs a Control Center action (not built).
4. Existing storefronts get pod/bank/pickup/delivery all OFF by migration, so they cannot publish until the merchant opts in.
5. `/metrics` is still public.
6. Delivery fee is still a server-owned zero; the delivery/pickup switches are the first slice of the fulfillment domain, not the domain.
7. Deploy: apply 047 then 048; set `CREDENTIAL_ENCRYPTION_KEYS` (production now refuses to start without it); set `TRUSTED_PROXY_HOPS` to the real
   number of proxies in front of the app; keep Redis reachable (rate limits degrade to per-instance otherwise).

## Still open (unchanged, per the locked order)
Gate 2 entitlement authority consolidation (staff/storefront capacity still read the legacy columns; most plan limits are data but not yet
enforced), Gate 3 concurrency-safe limit consumption (product/domain/provider counts are still check-then-insert), Gate 4 CI/runtime
certification (OpenAPI artifact regeneration, black, mypy, live runs), Gate 5 product domains.
