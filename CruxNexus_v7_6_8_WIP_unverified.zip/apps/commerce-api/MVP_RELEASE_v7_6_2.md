# CruxNexus MVP v7.6.2

## Purpose
Close the current v7.6.1 runtime and architecture gaps without weakening RLS, duplicating lifecycle authority, or adding another Commerce monolith.

## Key changes
- Dedicated worker DB role and RLS policies.
- Commerce RBAC enforcement.
- Canonical onboarding provisioning.
- Suspension provenance and governance-safe reactivation.
- Governance-backed subscription lifecycle policy.
- Immediate reservation release on definitive payment failure.
- Durable commerce webhook retry path.
- Durable worker jobs with retry/dead-letter state.
- Redis Streams event transport.
- Durable audit records.
- Separate Control Center API/database boundary with MFA/RBAC and one-way governance synchronization.
- Pinned dependencies and reconciled worker architecture documentation.

## Current product boundary
This is the hardened Commerce OS MVP backend plus the initial real Control Plane service. Logistics, advanced notification channels, variants/pricing/promotions, search, analytics/intelligence, trust/fraud/evidence, disputes/refunds, data export, DR verification and frontend applications remain product-expansion domains rather than being represented as complete in this release.
