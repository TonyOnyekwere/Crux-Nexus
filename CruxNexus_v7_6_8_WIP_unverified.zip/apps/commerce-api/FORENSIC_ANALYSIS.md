# FORENSIC ANALYSIS: Storefront Creation Capacity Enforcement

## CRITICAL FINDING: Duplicate Routes Pointing to Same Function

The codebase has TWO different storefront creation endpoints that both point to the SAME `create_storefront` function:

### Route 1: `/api/v1/storefronts`
**File:** `app/contexts/tenant_management/api/routes.py` (line 32)
```python
@router.post("/storefronts", status_code=status.HTTP_201_CREATED)
async def create_storefront(
    payload: StorefrontCreate,
    db: AsyncSession = Depends(get_db),
    merchant_context: dict = Depends(get_current_merchant_context),
):
```

### Route 2: `/api/v1/merchant/storefronts`  
**File:** `app/contexts/merchant_management/api/routes.py` (line 9-14)
```python
router.add_api_route(
    "/storefronts",
    create_storefront,  # This is imported from tenant_management
    methods=["POST"],
    name="merchant_create_storefront",
)
```

## CODE PATH TRACING

### Full Flow for Both Endpoints:

```text
POST /api/v1/storefronts OR /api/v1/merchant/storefronts
        ↓
TenantService.create_storefront (line 30)
        ↓
CapacityService.create_storefront_with_capacity_check (line 67)
        ↓
SELECT merchant_accounts FOR UPDATE (line 332)
        ↓
can_create_storefront() (line 337)
        ↓
get_storefront_capacity() (line 338)
        ↓
get_active_storefront_count() (line 339)
        ↓
Raise CapacityExceededError if full (line 340)
        ↓
Create Tenant (line 354-359)
        ↓
Create MerchantAccountTenant (line 362-367)
        ↓
Create TenantMembership (line 370-374)
        ↓
COMMIT
```

## CAPACITY CALCULATION LOGIC

### Current Implementation (capacity.py line 37-89):
```python
async def get_storefront_capacity(merchant_account_id: UUID) -> int:
    # Get merchant's active subscription
    subscription = await get_active_subscription(merchant_account_id)
    
    # Get subscription plan
    plan = await get_plan(subscription.subscription_plan_id)
    
    # Get active extra storefront entitlements
    extra_quantity = sum(MerchantEntitlement.quantity)
    
    # Effective capacity = included + actual entitlement capacity
    return plan.included_storefronts + extra_quantity
```

## DATA FROM YOUR BUSINESS MERCHANT

Based on your DB analysis:
- Plan: Business (included=1, max_extra=1)
- Expected capacity: 1 + 1 = 2 storefronts
- Actual merchant_account_tenants: 1
- Entitlements: extra_storefront=1, extra_staff=2 (both admin_grant)
- Capacity calculation: 1 + 1 = 2 ✅
- Yet you created ~4 storefronts

## THE BUG ANALYSIS

### Potential Bug 1: Route Conflict
The user may have been calling `/api/v1/storefronts` instead of `/api/v1/merchant/storefronts`, but both should call the same capacity check.

### Potential Bug 2: Capacity Check Not Working
The capacity calculation should show capacity=2, but the API allowed creating 4+ storefronts. This suggests either:
- The capacity check is being bypassed
- The capacity calculation is returning wrong value
- The active storefront count is wrong

### Potential Bug 3: Transaction Rollback Issue
If the capacity check passes but then something fails later in the transaction, the storefront might be created without the merchant_account_tenants association.

### Potential Bug 4: Different Deployment State
The Railway deployment might not have the latest code changes we made.

## NEXT FORENSIC STEPS

1. **Verify which endpoint was actually called** - Check server logs to see which route handled the requests
2. **Check capacity calculation in production** - Add logging to see what values are being calculated
3. **Verify entitlements are being counted** - The entitlement records exist but may not be counted correctly
4. **Check transaction boundaries** - Verify the entire creation is atomic

## INVITATION SYSTEM REQUIREMENTS

You also specified the invitation system requirements:

### Current Staff Invitation Bug:
- Current behavior: `USER_NOT_FOUND → must register first`
- Required behavior: Invitation flow without requiring pre-existing account

### Required Invitation Flow:
```text
Create Staff Invitation → Send Notification → Accept → Create/Link Account → Activate Membership → Grant Access
```

### Required Invitation Schema:
```sql
staff_invitations:
- id
- tenant_id
- invited_email
- role
- token_hash
- status (PENDING, ACCEPTED, EXPIRED)
- expires_at
- invited_by
- accepted_at
- accepted_by
```

### Security Requirements:
- Invitation should NOT create active membership immediately
- Staff member should not need to know tenant ID
- Invitation token establishes context
- Multi-channel notification support (WhatsApp, Email, SMS)