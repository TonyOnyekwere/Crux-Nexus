# CruxNexus v7.6.3 Foundation Hardening

> Superseded implementation state: v7.6.4 continues the foundation and product-constitution work without changing the product definition.

## Scope

v7.6.3 closes the remaining foundation-level correctness and governance defects identified in the v7.6.2 executable-source assessment.

### Closed

- Checkout request idempotency with tenant-scoped durable response replay.
- Late successful commerce payments cannot resurrect an order after its reservation is gone.
- Definitive stale-provider commerce failures release inventory immediately.
- Generic provider-initialization exceptions remain recoverable instead of being incorrectly terminalized.
- Subscription payment amount/currency mismatch moves `PAYMENT_PENDING` to `PAYMENT_FAILED`.
- Verified subscription activation is executed by a durable worker command with idempotent application.
- Worker claims use committed leases, fencing tokens and expired-running-job reclamation.
- Outbox relay partial failures are no longer counted as successful worker sweeps.
- Staff admission serializes on the merchant account capacity authority.
- Manager-capable staff allocation resolves the merchant through tenant membership rather than owner-only lookup.
- Duplicate commerce webhook processing boundary is retired. Billing webhook inbox is canonical.
- Control Center governance writes use a durable synchronization outbox.
- Governance state is versioned and Commerce rejects stale versions.
- Control Center pricing validates amount, currency and billing interval before persistence.
- Control Center admin login has database-backed lockout after repeated failures.
- Onboarding idempotency has explicit lease owner/expiry fields.
- Stale onboarding tests and obsolete route references were corrected.
- Root README now documents the service topology and verification model.
- Python cache artifacts are removed from the release archive.

## Migration heads

- Commerce: `043`
- Control Center: `004`

## Verification performed in the authoring environment

- Python compileall: PASS
- Commerce model static checker: PASS, 0 issues
- Test-reference checker: PASS, 0 issues
- Foundation review gate: PASS, 40 checks
- Alembic head discovery: Commerce `043`, Control Center `004`
- ZIP integrity: verified before release

## Not claimed as live-certified here

The authoring environment does not contain the production/staging PostgreSQL and Redis services or vendor credentials required to claim:

- live PostgreSQL/RLS isolation
- multi-session concurrency execution
- live Redis Streams
- Railway runtime execution
- SendGrid delivery
- Paystack sandbox execution
- Flutterwave sandbox execution
- provider webhook delivery

Those are deployment certification gates, not source-level implementation claims.

## Product-domain boundary

Variants/SKU, advanced pricing/promotions, customer accounts/Ghost Buyer, logistics, full notification channels, communication, evidence/trust/fraud, search/analytics, disputes/refunds, frontend applications and disaster-recovery/load certification remain subsequent Commerce OS product domains. v7.6.3 does not falsely label those domains as complete.
