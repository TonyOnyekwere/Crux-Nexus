# CruxNexus Capacity System Analysis

## ARCHITECTURAL INTENT

### Commercial Model
The architecture defines three subscription tiers with specific capacity rules:

**STARTER Plan:**
- Included: 1 storefront, 0 staff
- Can purchase: 0 extra storefronts, 0 extra staff
- Total capacity: 1 storefront, 0 staff

**BUSINESS Plan:**
- Included: 1 storefront, 3 staff  
- Can purchase: 1 extra storefront, 2 extra staff
- Total capacity: 2 storefronts, 5 staff

**ENTERPRISE Plan:**
- Included: 1 storefront, 8 staff
- Can purchase: 2 extra storefronts, 4 extra staff
- Total capacity: 3 storefronts, 12 staff

### Capacity Calculation Formula
```text
Effective Capacity = Plan.IncludedCapacity + PurchasedEntitlements
```

Where:
- `Plan.IncludedCapacity` is what the plan provides automatically
- `PurchasedEntitlements` are additional capacity purchased beyond the plan
- `Plan.MaxExtra*` fields are LIMITS on what can be purchased, not automatic capacity

## CURRENT IMPLEMENTATION STATE

### Database Schema (Migration 003)
```sql
subscription_plans:
- included_storefronts (1 for all plans)
- base_staff_per_storefront (0, 3, 8)
- max_extra_storefronts (0, 1, 2)  - THESE ARE LIMITS
- max_extra_staff (0, 2, 4)        - THESE ARE LIMITS

merchant_entitlements:
- entitlement_type (extra_storefront, extra_staff)
- quantity (amount of purchased capacity)
- status (active, expired, etc.)
```

### Current Capacity Logic
```python
capacity = plan.included_storefronts + sum(merchant_entitlements.quantity)
```

### Current Onboarding Logic
- Creates MerchantAccount
- Creates MerchantSubscription
- Creates Tenant (storefront)
- Does NOT create entitlements automatically

## IDENTIFIED BUGS

### Bug 1: Missing Automatic Entitlements
**Problem:** Onboarding does not create entitlement records for plan-based extra capacity.

**Expected:** When a BUSINESS merchant is onboarded, they should automatically get:
- +1 extra storefront entitlement (giving 2 total storefront capacity)
- +2 extra staff entitlement (giving 5 total staff capacity)

**Actual:** Merchant gets only the included capacity (1 storefront, 3 staff) and must purchase additional capacity.

### Bug 2: Plan Limits Confusion
**Problem:** The `max_extra_storefronts` and `max_extra_staff` fields are being interpreted inconsistently.

**Current behavior:** Sometimes treated as automatic capacity, sometimes as limits.

**Correct behavior:** These should be LIMITS on what can be purchased, enforced when granting entitlements.

### Bug 3: Capacity Enforcement Bypass
**Problem:** User reported creating 4 storefronts on BUSINESS plan (should be limited to 2).

**Root cause:** Capacity calculation or enforcement is not working correctly.

## RECOMMENDED CORRECT IMPLEMENTATION

### 1. Onboarding Should Grant Plan-Based Entitlements
```python
# During onboarding, automatically grant plan-based extra capacity
if plan.max_extra_storefronts > 0:
    entitlement = MerchantEntitlement(
        merchant_account_id=merchant_account.id,
        entitlement_type="extra_storefront",
        quantity=plan.max_extra_storefronts,
        source="plan_grant",
        status="active"
    )
    self.db.add(entitlement)
```

### 2. Capacity Calculation Remains Correct
```python
# Current formula is correct
capacity = plan.included_storefronts + sum(entitlements.quantity)
```

### 3. Plan Limits Are Enforced When Granting
```python
# When purchasing additional capacity, check plan limits
if existing_entitlements + new_quantity > plan.max_extra_storefronts:
    raise CapacityExceededError()
```

### 4. Resulting Behavior
**STARTER merchant:**
- Onboarding: 1 included storefront, 0 entitlements
- Total capacity: 1 storefront
- Can purchase: 0 (plan limit)

**BUSINESS merchant:**
- Onboarding: 1 included storefront, +1 extra storefront entitlement, +2 extra staff entitlement
- Total capacity: 2 storefronts, 5 staff
- Can purchase: 0 (already at plan limit)

**ENTERPRISE merchant:**
- Onboarding: 1 included storefront, +2 extra storefront entitlement, +4 extra staff entitlement
- Total capacity: 3 storefronts, 12 staff
- Can purchase: 0 (already at plan limit)

## IMMEDIATE FIX NEEDED

Restore the automatic entitlement granting in onboarding that was removed, but do it correctly:
- Grant entitlements based on plan.max_extra_* values
- Source should be "plan_grant" not "admin_grant"
- This gives merchants their full plan capacity immediately
- Plan limits then prevent purchasing beyond plan capacity