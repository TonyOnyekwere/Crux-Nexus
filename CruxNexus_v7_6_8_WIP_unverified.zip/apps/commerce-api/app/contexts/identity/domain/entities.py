from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import Column, DateTime, Enum as SQLEnum, String
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class UserStatus(str, enum.Enum):
    """Locked Onboarding & Activation Architecture (2026-09-17), section
    19-20: account creation and identity verification are separate
    states — a merchant is not treated as verified merely because a User
    row exists. UNVERIFIED users can still authenticate (they need a
    session to reach the OTP step and resume onboarding if they close the
    browser) but must be blocked from payment-adjacent operations until
    OTP-verified — see the mandatory-verification-gate check in the
    onboarding activation-mode step (Phase 4, not yet built)."""

    UNVERIFIED = "unverified"
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"


class AuthProvider(str, enum.Enum):
    PASSWORD = "password"
    GOOGLE = "google"
    APPLE = "apple"


class User(Base):
    __tablename__ = "users"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    email = Column(
        String,
        nullable=False,
        unique=True,
        index=True,
    )

    password_hash = Column(
        String,
        nullable=True,
    )

    auth_provider = Column(
        SQLEnum(
            AuthProvider,
            name="authprovider",
            values_callable=lambda enum_cls: [
                member.value for member in enum_cls
            ],
        ),
        nullable=False,
        default=AuthProvider.PASSWORD,
    )

    # Nullable — SMS OTP requires this to already be set (migration 025);
    # there is no client-supplied-destination path for OTP delivery.
    phone_number = Column(String(20), nullable=True)

    status = Column(
        SQLEnum(
            UserStatus,
            name="userstatus",
            values_callable=lambda enum_cls: [
                member.value for member in enum_cls
            ],
        ),
        nullable=False,
        default=UserStatus.UNVERIFIED,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class CruxNexusError(Exception):
    """Base exception for all CruxNexus domain errors."""
    code: str

    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(message)


class StaleVersionError(CruxNexusError):
    code = "stale_version"

    def __init__(self, current_state: dict):
        message = "Resource has been modified by another transaction"
        self.current_state = current_state
        super().__init__(self.code, message)


class InvalidTransitionError(CruxNexusError):
    code = "invalid_transition"

    def __init__(self, current_status: str, allowed_transitions: list[str]):
        message = f"Cannot transition from {current_status}"
        self.allowed_transitions = allowed_transitions
        super().__init__(self.code, message)