from datetime import datetime, timezone
import uuid

from sqlalchemy import CheckConstraint, Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class OTPCode(Base):
    """A single OTP issuance. See migration 024. Never store the raw
    code — only code_hash (sha256), matching the convention already used
    for staff invitation tokens."""

    __tablename__ = "otp_codes"
    __table_args__ = (
        CheckConstraint("channel IN ('email', 'sms')", name="chk_otp_code_channel"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )

    channel = Column(String(20), nullable=False)

    destination = Column(String(320), nullable=False)

    purpose = Column(String(50), nullable=False, default="account_verification")

    code_hash = Column(String(64), nullable=False)

    attempts = Column(Integer, nullable=False, default=0)

    max_attempts = Column(Integer, nullable=False, default=5)

    expires_at = Column(DateTime(timezone=True), nullable=False)

    consumed_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
