"""OTP verification service.

Locked Onboarding & Activation Architecture, section 19-20. Handles the
mandatory identity verification gate: generate a code, send it via
OTPProvider, and verify it, moving the user from UNVERIFIED to ACTIVE on
success.

Security properties, matching the conventions already established
elsewhere in this codebase (staff invitation tokens, password hashing):
- the raw code is never persisted, only its sha256 hash
- a code is single-use (consumed_at set on successful verification)
- attempts are capped (max_attempts) - exceeding it invalidates the code
  rather than allowing unlimited guesses
- codes expire (default 10 minutes) - matching typical OTP UX and short
  enough to limit a stolen/guessed code's window
- generating a new code does not invalidate a prior unexpired one
  server-side (the most recent one is what's checked against), but the
  provider only ever sends the newest one, so in practice only the latest
  code is usable by the user - this deliberately does not attempt to
  "cancel" older outstanding codes, since a DB-level cancellation adds
  complexity for a case (racing resends) that the max_attempts/expiry
  limits already bound the risk of. Documented here so this isn't
  mistaken for an oversight if it comes up in review.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.identity.domain.entities import User, UserStatus
from app.contexts.identity.domain.otp_code import OTPCode
from app.infrastructure.otp.provider import get_otp_provider

OTP_LENGTH = 6
OTP_EXPIRY_MINUTES = 10
OTP_MAX_ATTEMPTS = 5
OTP_RESEND_COOLDOWN_SECONDS = 60
OTP_MAX_REQUESTS_PER_HOUR = 5


class OTPResendTooSoonError(ValueError):
    def __init__(self, retry_after_seconds: int):
        self.retry_after_seconds = retry_after_seconds
        super().__init__(f"Wait {retry_after_seconds}s before requesting another code.")


class OTPRateLimitExceededError(ValueError):
    pass


class OTPVerificationError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


class OTPService:
    def __init__(self, db: AsyncSession):
        self.db = db

    def _hash(self, raw_code: str) -> str:
        return hashlib.sha256(raw_code.encode()).hexdigest()

    async def request_code(self, *, user_id, channel: str):
        """Returns (OTPCode, OTPDeliveryResult) - see the delivery.sent
        comment below for why both are returned rather than just the code."""
        """Generate, store (hashed), and attempt delivery of a fresh code.

        `destination` is NOT a caller-supplied parameter — this was a
        real vulnerability found in external review: the original
        version accepted destination directly from the request body,
        meaning a client could verify a code sent to an address/number
        they don't control and still flip their own account to ACTIVE
        (verify_code only checks user_id, not which destination the code
        went to). Destination is now always derived server-side from the
        user's own registered contact info.
        """
        if channel not in ("email", "sms"):
            raise ValueError(f"Unsupported OTP channel: {channel}")

        # Resend-race fix (external review): the cooldown and hourly-cap
        # checks below are read-then-write, so N concurrent requests could
        # all read "no recent code" and all issue one, bypassing both
        # limits. Locking the user's row serialises request_code per user;
        # the lock is held until the commit at the end of this method, so
        # the second request sees the first one's OTPCode row.
        user_lock = await self.db.execute(
            select(User).where(User.id == user_id).with_for_update()
        )
        if user_lock.scalar_one_or_none() is None:
            raise ValueError("User not found.")

        now = datetime.now(timezone.utc)

        # Rate limiting (external review fix): previously unlimited -
        # a caller could hammer this endpoint, which becomes a real cost
        # once a paid SMS/email vendor is wired in, and is an abuse vector
        # regardless. Two independent limits: a short cooldown between
        # any two requests, and a rolling hourly cap.
        recent_result = await self.db.execute(
            select(OTPCode)
            .where(OTPCode.user_id == user_id, OTPCode.purpose == "account_verification")
            .order_by(OTPCode.created_at.desc())
            .limit(1)
        )
        most_recent = recent_result.scalar_one_or_none()
        if most_recent is not None:
            created_at = (
                most_recent.created_at
                if most_recent.created_at.tzinfo
                else most_recent.created_at.replace(tzinfo=timezone.utc)
            )
            elapsed = (now - created_at).total_seconds()
            if elapsed < OTP_RESEND_COOLDOWN_SECONDS:
                raise OTPResendTooSoonError(int(OTP_RESEND_COOLDOWN_SECONDS - elapsed))

        hour_ago = now - timedelta(hours=1)
        count_result = await self.db.execute(
            select(func.count(OTPCode.id)).where(
                OTPCode.user_id == user_id,
                OTPCode.purpose == "account_verification",
                OTPCode.created_at >= hour_ago,
            )
        )
        requests_this_hour = count_result.scalar() or 0
        if requests_this_hour >= OTP_MAX_REQUESTS_PER_HOUR:
            raise OTPRateLimitExceededError(
                f"Too many verification code requests. Try again later."
            )

        user_result = await self.db.execute(select(User).where(User.id == user_id))
        user = user_result.scalar_one_or_none()
        if user is None:
            raise ValueError("User not found.")

        if channel == "email":
            destination = user.email
        else:
            if not user.phone_number:
                raise ValueError(
                    "No phone number on file for this account. Set a phone "
                    "number before requesting an SMS code."
                )
            destination = user.phone_number

        raw_code = "".join(secrets.choice("0123456789") for _ in range(OTP_LENGTH))

        otp = OTPCode(
            user_id=user_id,
            channel=channel,
            destination=destination,
            purpose="account_verification",
            code_hash=self._hash(raw_code),
            max_attempts=OTP_MAX_ATTEMPTS,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=OTP_EXPIRY_MINUTES),
        )
        self.db.add(otp)
        await self.db.flush()

        provider = get_otp_provider()
        delivery = await provider.send_code(channel=channel, destination=destination, code=raw_code)
        # The delivery result is preserved so callers never claim a code was
        # delivered when the configured provider rejected the message.

        await self.db.commit()
        return otp, delivery

    async def verify_code(self, *, user_id, submitted_code: str) -> None:
        """Verify the most recent unconsumed code for this user. Raises
        OTPVerificationError with a machine-readable `code` on failure;
        the caller (route) maps that to the right HTTP status.

        Row-locked with FOR UPDATE (external review fix): without it, two
        concurrent verification attempts (two wrong guesses, or a correct
        guess racing a wrong one) could both read the same attempts count
        or the same unconsumed state before either commits, letting the
        max_attempts cap be bypassed or a code be "consumed" twice. Same
        lock pattern already used for staff invitation acceptance.
        """
        result = await self.db.execute(
            select(OTPCode)
            .where(
                OTPCode.user_id == user_id,
                OTPCode.purpose == "account_verification",
                OTPCode.consumed_at.is_(None),
            )
            .order_by(OTPCode.created_at.desc())
            .limit(1)
            .with_for_update()
        )
        otp = result.scalar_one_or_none()

        if otp is None:
            raise OTPVerificationError("NO_ACTIVE_CODE", "No active verification code. Request a new one.")

        now = datetime.now(timezone.utc)
        expires_at = otp.expires_at if otp.expires_at.tzinfo else otp.expires_at.replace(tzinfo=timezone.utc)
        if expires_at < now:
            raise OTPVerificationError("CODE_EXPIRED", "This code has expired. Request a new one.")

        if otp.attempts >= otp.max_attempts:
            raise OTPVerificationError(
                "TOO_MANY_ATTEMPTS", "Too many incorrect attempts. Request a new code."
            )

        if self._hash(submitted_code) != otp.code_hash:
            otp.attempts += 1
            await self.db.commit()
            raise OTPVerificationError("INCORRECT_CODE", "Incorrect code.")

        otp.consumed_at = now

        user_result = await self.db.execute(select(User).where(User.id == user_id))
        user = user_result.scalar_one_or_none()
        if user is not None and user.status == UserStatus.UNVERIFIED:
            user.status = UserStatus.ACTIVE

        await self.db.commit()
