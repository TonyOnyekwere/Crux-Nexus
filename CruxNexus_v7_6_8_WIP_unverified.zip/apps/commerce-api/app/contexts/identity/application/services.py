from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from passlib.context import CryptContext
from app.contexts.identity.domain.entities import User, UserStatus, AuthProvider
import uuid

# Configure bcrypt with 12 rounds for strong password hashing
pwd_context = CryptContext(schemes=["bcrypt"], bcrypt__rounds=12, deprecated="auto")


class IdentityService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_user(
        self,
        email: str,
        password: str | None = None,
        auth_provider: AuthProvider = AuthProvider.PASSWORD,
    ) -> User:
        """Create a global user account (no tenant association)."""
        # Fixed a real gap (external review): no email normalization
        # existed anywhere, so "Tony@example.com" and "tony@example.com"
        # could become distinct rows - affecting login, lockout keys,
        # invitation matching, and duplicate-account detection. Normalize
        # once, here, at the single write path new users go through.
        email = email.strip().lower()

        password_hash = None
        if password and auth_provider == AuthProvider.PASSWORD:
            password_hash = pwd_context.hash(password)

        result = await self.db.execute(
            select(User).where(User.email == email)
        )
        if result.scalar_one_or_none():
            raise ValueError("Email already registered")

        user = User(
            id=uuid.uuid4(),
            email=email,
            password_hash=password_hash,
            auth_provider=auth_provider,
            # UNVERIFIED, not ACTIVE: locked architecture section 19-20
            # makes OTP verification mandatory before payment-adjacent
            # onboarding steps. auth_provider is currently always PASSWORD
            # in practice (Google/Apple enum values exist but nothing
            # implements them yet) — if a real OAuth provider is added
            # later, an already-provider-verified email may reasonably
            # skip this state, but defaulting conservatively to
            # UNVERIFIED for every provider until that's actually built
            # is the safer choice than guessing which providers to trust.
            status=UserStatus.UNVERIFIED,
        )

        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        return user

    async def verify_password(self, user: User, password: str) -> bool:
        if not user.password_hash:
            return False
        return pwd_context.verify(password, user.password_hash)

    async def get_user_by_email(self, email: str) -> User | None:
        # Normalize the lookup side to match create_user's write-side
        # normalization - otherwise a login/lookup with different casing
        # than however the account was originally created would miss.
        result = await self.db.execute(
            select(User).where(User.email == email.strip().lower())
        )
        return result.scalar_one_or_none()

    async def get_user_by_id(self, user_id: uuid.UUID) -> User | None:
        result = await self.db.execute(
            select(User).where(User.id == user_id)
        )
        return result.scalar_one_or_none()
