import logging
from uuid import UUID
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import (
    create_global_access_token,
    create_tenant_access_token,
    get_current_user_id,
)
from app.contexts.identity.application.services import IdentityService
from app.contexts.identity.domain.entities import UserStatus
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus
from app.contexts.tenant_management.domain.membership import MembershipStatus, TenantMembership
from app.database import get_db
from app.database.models import User
from app.infrastructure.account_lockout import LoginAttemptTracker, AccountLockoutError
from app.infrastructure.audit import audit_logger
from app.config import get_settings

from .schemas import (
    OTPConfirmSchema,
    OTPRequestSchema,
    PhoneNumberUpdateSchema,
    StorefrontSummary,
    SwitchTenantRequest,
    TenantAccessTokenResponse,
    TokenResponse,
    UserCreate,
    UserLogin,
    UserResponse,
)
from app.infrastructure.rate_limiter import key_ip, key_ip_tenant, limiter

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(prefix="/api/v1/identity", tags=["identity"])


def get_login_tracker(request: Request) -> Optional[LoginAttemptTracker]:
    """Get login attempt tracker from request state."""
    if hasattr(request.app.state, 'redis_client'):
        return LoginAttemptTracker(request.app.state.redis_client)
    return None


@router.post("/users", status_code=status.HTTP_201_CREATED)
@limiter.limit("20/hour", key_func=key_ip)
async def create_user(
    request: Request,
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
):
    """Register a global user account."""
    try:
        service = IdentityService(db)
        user = await service.create_user(
            email=user_data.email,
            password=user_data.password,
            auth_provider=user_data.auth_provider,
        )

        # Audit log account creation
        audit_logger.log_event(
            event_type="account_created",
            email=user.email,
            user_id=str(user.id),
            success=True,
        )

        return {"data": UserResponse.model_validate(user).model_dump()}
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "VALIDATION_ERROR", "message": str(exc), "details": {}}},
        )
    except IntegrityError:
        await db.rollback()
        logger.exception("Database integrity error while creating user")
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": {
                    "code": "USER_CONFLICT",
                    "message": "User could not be created because of a data conflict.",
                    "details": {},
                }
            },
        )
    except Exception:
        logger.exception("Failed to create user")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": {
                    "code": "USER_CREATE_FAILED",
                    "message": "Failed to create user.",
                    "details": {},
                }
            },
        )


@router.post("/login", response_model=dict)
@limiter.limit("10/minute", key_func=key_ip)
async def login(
    request: Request,
    login_data: UserLogin,
    db: AsyncSession = Depends(get_db)
):
    """Authenticate user and return a global merchant access token."""
    # Get client info for audit logging
    ip_address = request.client.host if request.client else "unknown"
    user_agent = request.headers.get("user-agent", "unknown")

    # Check account lockout before attempting authentication
    tracker = get_login_tracker(request)
    if tracker:
        try:
            # Check if already locked out
            is_locked = await tracker.is_locked_out(login_data.email)
            if is_locked:
                lockout_info = await tracker.get_lockout_info(login_data.email)
                logger.warning(f"Login attempt on locked account: {login_data.email}")
                audit_logger.log_login_attempt(
                    email=login_data.email,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    success=False,
                    reason="Account locked due to too many failed attempts",
                )
                raise HTTPException(
                    status_code=status.HTTP_423_LOCKED,
                    detail={
                        "error": {
                            "code": "ACCOUNT_LOCKED",
                            "message": f"Account temporarily locked. Try again after {lockout_info['unlock_at']}",
                            "details": {"unlock_at": lockout_info['unlock_at'].isoformat()},
                        }
                    },
                )
        except AccountLockoutError as e:
            logger.warning(f"Account lockout error: {login_data.email} - {str(e)}")
            audit_logger.log_login_attempt(
                email=login_data.email,
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                reason="Account locked",
            )
            raise HTTPException(
                status_code=status.HTTP_423_LOCKED,
                detail={
                    "error": {
                        "code": "ACCOUNT_LOCKED",
                        "message": str(e),
                        "details": {},
                    }
                },
            )

    try:
        service = IdentityService(db)
        user = await service.get_user_by_email(login_data.email)

        if not user or not await service.verify_password(user, login_data.password):
            # Record failed attempt
            if tracker:
                try:
                    attempt_count = await tracker.record_failed_attempt(login_data.email)
                    logger.warning(f"Failed login attempt {attempt_count}/5 for {login_data.email}")
                except AccountLockoutError as e:
                    # Account just got locked
                    audit_logger.log_account_locked(
                        email=login_data.email,
                        ip_address=ip_address,
                        unlock_at=e.unlock_at,
                        attempts=5,
                    )
                    raise HTTPException(
                        status_code=status.HTTP_423_LOCKED,
                        detail={
                            "error": {
                                "code": "ACCOUNT_LOCKED",
                                "message": str(e),
                                "details": {},
                            }
                        },
                    )

            # Audit log failed attempt
            audit_logger.log_login_attempt(
                email=login_data.email,
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                reason="Invalid credentials",
            )

            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": {
                        "code": "INVALID_CREDENTIALS",
                        "message": "Incorrect email or password.",
                        "details": {},
                    }
                },
            )

        # Reject non-active accounts. Previously the login route checked
        # only email+password, so a SUSPENDED or INACTIVE user (statuses
        # that, before migration 019, couldn't even be persisted — see
        # that migration for the enum mismatch this depended on) could
        # still log in as long as their credentials were correct.
        # UNVERIFIED may still log in — they need a session to reach the
        # OTP step and resume onboarding if they closed the browser
        # (locked architecture section 19-20). Only INACTIVE/SUSPENDED
        # block login entirely; payment-adjacent operations get their own,
        # stricter UNVERIFIED check at the point they're attempted.
        if user.status not in (UserStatus.ACTIVE, UserStatus.UNVERIFIED):
            audit_logger.log_login_attempt(
                email=login_data.email,
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                reason=f"account_status_{user.status.value if hasattr(user.status, 'value') else user.status}",
                user_id=str(user.id),
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": {
                        "code": "ACCOUNT_NOT_ACTIVE",
                        "message": "This account is not active.",
                        "details": {},
                    }
                },
            )

        # Successful login - reset failed attempts
        if tracker:
            await tracker.record_successful_login(login_data.email)

        # Create access token
        access_token = create_global_access_token(user_id=user.id, email=user.email)

        # Audit log successful login
        audit_logger.log_login_attempt(
            email=login_data.email,
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            user_id=str(user.id),
        )

        return {
            "data": TokenResponse(
                access_token=access_token,
                user=UserResponse.model_validate(user),
            ).model_dump()
        }
    except HTTPException:
        raise
    except Exception:
        logger.exception("Login failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": {
                    "code": "LOGIN_FAILED",
                    "message": "Login failed.",
                    "details": {},
                }
            },
        )


@router.get("/storefronts")
async def list_accessible_storefronts(
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    result = await db.execute(
        select(TenantMembership, Tenant)
        .join(Tenant, Tenant.id == TenantMembership.tenant_id)
        .where(
            TenantMembership.user_id == user_id,
            TenantMembership.status == MembershipStatus.ACTIVE.value,
            Tenant.status != TenantStatus.ARCHIVED,
        )
    )
    rows = result.all()
    from app.contexts.merchant_management.domain.entities import MerchantAccount
    from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
    accessible=[]
    for membership, tenant in rows:
        merchant = await db.scalar(select(MerchantAccount).join(MerchantAccountTenant, MerchantAccountTenant.merchant_account_id==MerchantAccount.id).where(MerchantAccountTenant.tenant_id==tenant.id))
        if tenant.status == TenantStatus.SUSPENDED or (merchant is not None and merchant.status != "active"):
            continue
        accessible.append(StorefrontSummary(tenant_id=tenant.id, slug=tenant.slug, role=membership.role))
    storefronts = accessible
    return {"data": [item.model_dump() for item in storefronts]}


@router.post("/switch-tenant")
async def switch_tenant(
    payload: SwitchTenantRequest,
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    """
    Switch tenant context with full membership verification.

    This endpoint verifies:
    1. User has active membership to the requested tenant
    2. Tenant is not archived
    3. Membership has a valid role

    Only then does it issue a tenant-scoped token.
    """
    result = await db.execute(
        select(TenantMembership, Tenant)
        .join(Tenant, Tenant.id == TenantMembership.tenant_id)
        .where(
            TenantMembership.user_id == user_id,
            TenantMembership.tenant_id == payload.tenant_id,
        )
    )
    row = result.one_or_none()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "MEMBERSHIP_REQUIRED",
                    "message": "No active membership for this storefront.",
                    "details": {},
                }
            },
        )

    membership, tenant = row
    if getattr(membership, "status", None) != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "MEMBERSHIP_INACTIVE",
                    "message": "Membership is not active for this storefront.",
                    "details": {},
                }
            },
        )

    if tenant.status in (TenantStatus.ARCHIVED, TenantStatus.SUSPENDED):
        # Fixed an inconsistency (external review): this previously only
        # rejected ARCHIVED, so a SUSPENDED tenant would still get a
        # token issued here - only to be rejected later by
        # get_current_tenant_context/get_verified_tenant_context (see
        # app/auth/tenant_context.py, which correctly rejects both).
        # Same boundary should reject the same states in the same place.
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "TENANT_INACTIVE",
                    "message": "This storefront is not accessible.",
                    "details": {},
                }
            },
        )

    token = create_tenant_access_token(
        user_id=user_id,
        tenant_id=tenant.id,
        membership_id=membership.id,
        role=membership.role,
    )
    return {
        "data": TenantAccessTokenResponse(
            access_token=token,
            tenant_id=tenant.id,
            role=membership.role,
        ).model_dump()
    }


@router.get("/users/me")
async def get_current_user(
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    service = IdentityService(db)
    user = await service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": {
                    "code": "USER_NOT_FOUND",
                    "message": "User not found.",
                    "details": {},
                }
            },
        )
    return {"data": UserResponse.model_validate(user).model_dump()}


@router.post("/verify/request", status_code=status.HTTP_200_OK)
@limiter.limit("10/hour", key_func=key_ip_tenant)
@limiter.limit("30/hour", key_func=key_ip)
async def request_verification_code(
    request: Request,
    request_data: OTPRequestSchema,
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    """Send (or resend) an OTP code for account verification.

    Locked architecture section 19-20: mandatory before a merchant can
    proceed past identity in the onboarding journey. Requires an
    authenticated (but possibly still UNVERIFIED) session — UNVERIFIED
    users can log in specifically so they can reach this endpoint.
    """
    from app.contexts.identity.application.otp_service import (
        OTPRateLimitExceededError,
        OTPResendTooSoonError,
        OTPService,
    )

    otp_service = OTPService(db)
    try:
        _otp, delivery = await otp_service.request_code(
            user_id=user_id,
            channel=request_data.channel,
        )
    except OTPResendTooSoonError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={"error": {"code": "OTP_RESEND_TOO_SOON", "message": str(exc), "details": {"retry_after_seconds": exc.retry_after_seconds}}},
            headers={"Retry-After": str(exc.retry_after_seconds)},
        )
    except OTPRateLimitExceededError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={"error": {"code": "OTP_RATE_LIMIT_EXCEEDED", "message": str(exc), "details": {}}},
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "OTP_REQUEST_FAILED", "message": str(exc), "details": {}}},
        )
    if not delivery.sent:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"error": {"code": "OTP_DELIVERY_UNAVAILABLE", "message": delivery.detail or "OTP delivery is unavailable.", "details": {}}},
        )
    return {"data": {"message": f"A verification code was sent via {request_data.channel}."}}


@router.post("/verify/confirm", status_code=status.HTTP_200_OK)
@limiter.limit("30/hour", key_func=key_ip_tenant)
@limiter.limit("100/hour", key_func=key_ip)
async def confirm_verification_code(
    request: Request,
    request_data: OTPConfirmSchema,
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    """Confirm an OTP code, moving the user from UNVERIFIED to ACTIVE."""
    from app.contexts.identity.application.otp_service import OTPService, OTPVerificationError

    otp_service = OTPService(db)
    try:
        await otp_service.verify_code(user_id=user_id, submitted_code=request_data.code)
    except OTPVerificationError as exc:
        status_code = (
            status.HTTP_429_TOO_MANY_REQUESTS
            if exc.code == "TOO_MANY_ATTEMPTS"
            else status.HTTP_400_BAD_REQUEST
        )
        raise HTTPException(
            status_code=status_code,
            detail={"error": {"code": exc.code, "message": str(exc), "details": {}}},
        )

    return {"data": {"message": "Account verified."}}


@router.patch("/me/phone", status_code=status.HTTP_200_OK)
async def update_phone_number(
    request_data: PhoneNumberUpdateSchema,
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    """Set/update the authenticated user's phone number.

    Added to close a real gap (external review): migration 025 added
    users.phone_number specifically so SMS OTP has a legitimate,
    server-known destination to bind to, but no endpoint existed to
    actually set it - SMS OTP was structurally supported but had no way
    to ever become reachable. Deliberately minimal (no phone verification
    step of its own yet - the OTP flow is what verifies it, once
    requested against it).
    """
    from sqlalchemy import select as _select

    result = await db.execute(_select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "USER_NOT_FOUND", "message": "User not found.", "details": {}}},
        )

    user.phone_number = request_data.phone_number
    await db.commit()

    return {"data": {"phone_number": user.phone_number}}
