"""Currency authority (pure, no I/O).

Locked decision: a storefront has exactly ONE currency, chosen from NGN, GHS, KES, ZAR (default NGN).
That currency is the single authority for every product, cart, order and payment of that storefront;
checkout rejects anything else. There are no mixed-currency carts or orders. The storefront currency can
only be changed while it cannot contradict existing money records.
"""

from __future__ import annotations

from typing import Iterable, Optional

SUPPORTED_CURRENCIES = ("NGN", "GHS", "KES", "ZAR")
DEFAULT_CURRENCY = "NGN"


class CurrencyError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def normalize_currency(value: Optional[str]) -> str:
    """Canonical upper-case supported currency, or CurrencyError. None/blank -> the default."""
    if value is None or str(value).strip() == "":
        return DEFAULT_CURRENCY
    code = str(value).strip().upper()
    if code not in SUPPORTED_CURRENCIES:
        raise CurrencyError("UNSUPPORTED_CURRENCY", f"Currency '{code}' is not supported. Use one of: {', '.join(SUPPORTED_CURRENCIES)}.")
    return code


def check_currency_change(*, current: str, requested: str, product_count: int, order_count: int) -> None:
    """A storefront's currency may change only while nothing priced in the old currency exists."""
    if requested == current:
        return
    if product_count or order_count:
        raise CurrencyError(
            "CURRENCY_LOCKED",
            "The storefront currency cannot change once products or orders exist. "
            f"({product_count} product(s), {order_count} order(s))",
        )


def mismatched_currencies(storefront_currency: str, line_currencies: Iterable[str]) -> list:
    """Currencies in a cart that differ from the storefront's. Empty list = a valid single-currency cart."""
    return sorted({c for c in line_currencies if (c or "").upper() != storefront_currency.upper()})


def assert_single_currency_cart(storefront_currency: str, line_currencies: Iterable[str]) -> None:
    bad = mismatched_currencies(storefront_currency, line_currencies)
    if bad:
        raise CurrencyError(
            "CURRENCY_MISMATCH",
            f"This cart contains items priced in {', '.join(bad)}, but the store sells in {storefront_currency}.",
        )
