"""Pure order/fulfillment state rules (no I/O, no framework imports).

Single source of truth for both transition tables and the fulfillment planner.

    fulfillment: unfulfilled -> processing -> shipped -> delivered
    order:       confirmed   -> fulfilling -> shipped -> delivered -> completed

Payment gate: an order may enter fulfillment when it is CONFIRMED and either
already paid, or pay-on-delivery (cash is due at the door and becomes paid on
delivery). Prepaid and bank-transfer orders must be paid first.

Cancellation is allowed only BEFORE shipment. Stock is deducted at shipment,
so cancelling a shipped order would release a reservation that no longer
exists (corrupting other orders' reservations). Post-shipment problems belong
to returns, which are a separate domain.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

POD = "pay_on_delivery"

ORDER_TRANSITIONS: dict[str, set[str]] = {
    "pending_payment": {"confirmed", "payment_failed", "cancelled"},
    "awaiting_transfer": {"confirmed", "payment_failed", "cancelled"},
    "payment_failed": {"pending_payment", "cancelled"},
    "confirmed": {"fulfilling", "cancelled"},
    "fulfilling": {"shipped", "cancelled"},
    "shipped": {"delivered"},
    "delivered": {"completed"},
    "completed": set(),
    "cancelled": set(),
}

FULFILLMENT_TRANSITIONS: dict[str, set[str]] = {
    "unfulfilled": {"processing", "cancelled"},
    "processing": {"shipped", "cancelled"},
    "shipped": {"delivered"},
    "delivered": set(),
    "cancelled": set(),
}

CANCELLABLE_ORDER_STATUSES = frozenset(
    {"pending_payment", "awaiting_transfer", "payment_failed", "confirmed", "fulfilling"}
)

STOCK_NONE, STOCK_COMMIT, STOCK_RELEASE = "none", "commit", "release"


class FulfillmentRuleError(ValueError):
    """Illegal fulfillment change; the message is safe to return to the client."""


@dataclass(frozen=True)
class FulfillmentPlan:
    noop: bool
    order_status: str
    fulfillment_status: str
    stock_effect: str = STOCK_NONE
    mark_pod_paid: bool = False
    flag_refund: bool = False


def plan_fulfillment_change(
    *,
    order_status: str,
    payment_status: str,
    payment_provider: Optional[str],
    fulfillment_status: str,
    target: str,
) -> FulfillmentPlan:
    if target == fulfillment_status:
        return FulfillmentPlan(True, order_status, fulfillment_status)
    if target not in FULFILLMENT_TRANSITIONS:
        raise FulfillmentRuleError(f"Unknown fulfillment status '{target}'.")
    if target not in FULFILLMENT_TRANSITIONS.get(fulfillment_status, set()):
        raise FulfillmentRuleError(f"Fulfillment cannot move from {fulfillment_status} to {target}.")

    is_pod = payment_provider == POD
    paid_or_pod = payment_status == "paid" or is_pod

    if target == "processing":
        if order_status != "confirmed":
            raise FulfillmentRuleError(f"Order must be confirmed to start fulfillment (is {order_status}).")
        if not paid_or_pod:
            raise FulfillmentRuleError("Order must be paid before fulfillment begins.")
        return FulfillmentPlan(False, "fulfilling", "processing")

    if target == "shipped":
        if order_status != "fulfilling":
            raise FulfillmentRuleError(f"Only an order being fulfilled can be shipped (is {order_status}).")
        if not paid_or_pod:
            raise FulfillmentRuleError("Order must be paid before it ships.")
        return FulfillmentPlan(False, "shipped", "shipped", stock_effect=STOCK_COMMIT)

    if target == "delivered":
        if order_status != "shipped":
            raise FulfillmentRuleError(f"Only a shipped order can be delivered (is {order_status}).")
        return FulfillmentPlan(
            False, "delivered", "delivered",
            mark_pod_paid=(is_pod and payment_status != "paid"),
        )

    # target == "cancelled"
    if order_status not in CANCELLABLE_ORDER_STATUSES:
        raise FulfillmentRuleError(
            f"An order that is {order_status} cannot be cancelled; shipped orders need a return."
        )
    return FulfillmentPlan(
        False, "cancelled", "cancelled", stock_effect=STOCK_RELEASE,
        flag_refund=(payment_status == "paid" and not is_pod),
    )
