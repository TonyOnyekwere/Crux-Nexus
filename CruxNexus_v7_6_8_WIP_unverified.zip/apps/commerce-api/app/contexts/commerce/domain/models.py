"""Commerce persistence models."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import Boolean, CheckConstraint, Column, DateTime, ForeignKey, Index, Integer, LargeBinary, Numeric, SmallInteger, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID as PGUUID, JSONB
from app.database import Base

class StorefrontProfile(Base):
    __tablename__ = "storefront_profiles"
    __table_args__ = (
        CheckConstraint("currency IN ('NGN','GHS','KES','ZAR')", name="ck_storefront_currency"),
        CheckConstraint("bank_transfer_window_hours BETWEEN 1 AND 168", name="ck_storefront_bank_transfer_window"),
    )
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True)
    business_name = Column(String(160), nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String(80), nullable=True)
    phone = Column(String(30), nullable=True)
    city = Column(String(100), nullable=True)
    address = Column(Text, nullable=True)
    currency = Column(String(3), nullable=False, default="NGN")
    contact_email = Column(String(320), nullable=True)
    # Merchant-controlled payment methods (online providers are enabled per connection).
    pod_enabled = Column(Boolean, nullable=False, default=False)
    bank_transfer_enabled = Column(Boolean, nullable=False, default=False)
    bank_transfer_details = Column(JSONB, nullable=True)
    bank_transfer_window_hours = Column(Integer, nullable=False, default=24)
    # Merchant-enabled fulfillment methods.
    pickup_enabled = Column(Boolean, nullable=False, default=False)
    delivery_enabled = Column(Boolean, nullable=False, default=False)
    published = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class StorefrontConfiguration(Base):
    __tablename__ = "storefront_configurations"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True)
    theme = Column(JSONB, nullable=False, default=dict)
    fonts = Column(JSONB, nullable=False, default=dict)
    layout = Column(JSONB, nullable=False, default=dict)
    component_slots = Column(JSONB, nullable=False, default=dict)
    custom_css = Column(Text, nullable=True)
    custom_domain = Column(String(255), nullable=True, unique=True)
    custom_domain_status = Column(String(30), nullable=False, default="none")
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    __table_args__ = (CheckConstraint("custom_domain_status IN ('none','pending','verified','disabled')", name="ck_storefront_custom_domain_status"),)


class MerchantPaymentConnection(Base):
    __tablename__ = "merchant_payment_connections"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    provider = Column(String(40), nullable=False)
    status = Column(String(30), nullable=False, default="pending")
    account_reference = Column(String(255), nullable=True)
    credential_reference = Column(String(255), nullable=True)
    configuration = Column(JSONB, nullable=False, default=dict)
    verified_at = Column(DateTime(timezone=True), nullable=True)
    last_error = Column(String(500), nullable=True)
    # Merchant's own on/off switch for offering this provider at checkout (independent of platform governance).
    enabled = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        UniqueConstraint("tenant_id", "provider", name="uq_merchant_payment_connection_provider"),
        CheckConstraint("status IN ('pending','connected','disabled','error')", name="ck_merchant_payment_connection_status"),
    )


class Product(Base):
    __tablename__ = "products"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(180), nullable=False)
    slug = Column(String(180), nullable=False)
    description = Column(Text, nullable=True)
    sku = Column(String(80), nullable=False)
    price = Column(Numeric(14, 2), nullable=False)
    currency = Column(String(3), nullable=False, default="NGN")
    stock = Column(Integer, nullable=False, default=0)
    reserved_stock = Column(Integer, nullable=False, default=0)
    published = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        CheckConstraint("price >= 0", name="ck_product_price_nonnegative"),
        CheckConstraint("stock >= 0", name="ck_product_stock_nonnegative"),
        CheckConstraint("reserved_stock >= 0", name="ck_product_reserved_nonnegative"),
        CheckConstraint("reserved_stock <= stock", name="ck_product_reserved_lte_stock"),
        Index("uq_product_tenant_sku", "tenant_id", "sku", unique=True),
        Index("uq_product_tenant_slug", "tenant_id", "slug", unique=True),
        Index("ix_products_tenant_published", "tenant_id", "published"),
        CheckConstraint("currency IN ('NGN','GHS','KES','ZAR')", name="ck_product_currency"),
    )


class InventoryMovement(Base):
    __tablename__ = "inventory_movements"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(PGUUID(as_uuid=True), ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    quantity_delta = Column(Integer, nullable=False, default=0)
    reserved_delta = Column(Integer, nullable=False, default=0)
    reason = Column(String(120), nullable=False)
    reference = Column(String(120), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))


class Customer(Base):
    __tablename__ = "customers"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(160), nullable=False)
    email = Column(String(320), nullable=True)
    phone = Column(String(30), nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (Index("ix_customer_tenant_phone", "tenant_id", "phone"),)


class Cart(Base):
    __tablename__ = "carts"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    token = Column(String(96), nullable=False, unique=True, index=True)
    customer_id = Column(PGUUID(as_uuid=True), ForeignKey("customers.id", ondelete="SET NULL"), nullable=True)
    status = Column(String(20), nullable=False, default="open")
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (CheckConstraint("status IN ('open','converted','abandoned')", name="ck_cart_status"),)


class CartItem(Base):
    __tablename__ = "cart_items"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    cart_id = Column(PGUUID(as_uuid=True), ForeignKey("carts.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(PGUUID(as_uuid=True), ForeignKey("products.id", ondelete="RESTRICT"), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Numeric(14, 2), nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        CheckConstraint("quantity > 0", name="ck_cart_item_quantity_positive"),
        Index("uq_cart_product", "cart_id", "product_id", unique=True),
    )


class Order(Base):
    __tablename__ = "orders"
    __table_args__ = (
        Index("ix_orders_tenant_status", "tenant_id", "status"),
        Index("ix_orders_tenant_created", "tenant_id", "created_at"),
        CheckConstraint("status IN ('pending_payment','awaiting_transfer','payment_failed','confirmed','fulfilling','shipped','delivered','completed','cancelled')", name="ck_order_status"),
        CheckConstraint("payment_status IN ('pending','paid','failed','refunded','partially_refunded')", name="ck_order_payment_status"),
        CheckConstraint("total >= 0", name="ck_order_total_nonnegative"),
        CheckConstraint("currency IN ('NGN','GHS','KES','ZAR')", name="ck_order_currency"),
        CheckConstraint("fulfillment_method IN ('delivery','pickup')", name="ck_order_fulfillment_method"),
        CheckConstraint("fulfillment_method = 'pickup' OR delivery_address IS NOT NULL", name="ck_order_delivery_address_required"),
    )
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    customer_id = Column(PGUUID(as_uuid=True), ForeignKey("customers.id", ondelete="SET NULL"), nullable=True)
    order_number = Column(String(40), nullable=False, unique=True)
    status = Column(String(30), nullable=False, default="pending_payment")
    payment_status = Column(String(20), nullable=False, default="pending")
    fulfillment_status = Column(String(30), nullable=False, default="unfulfilled")
    subtotal = Column(Numeric(14, 2), nullable=False)
    delivery_fee = Column(Numeric(14, 2), nullable=False, default=Decimal("0"))
    total = Column(Numeric(14, 2), nullable=False)
    currency = Column(String(3), nullable=False, default="NGN")
    # delivery | pickup (merchant-enabled; see StorefrontProfile.delivery_enabled / pickup_enabled)
    fulfillment_method = Column(String(20), nullable=False, default="delivery")
    delivery_address = Column(Text, nullable=True)
    # Why a cancelled order was cancelled (reservation_expired | merchant | payment_failed | ...); lets a late
    # bank-transfer confirmation distinguish an expired reservation from a deliberate cancellation.
    cancellation_reason = Column(String(40), nullable=True)
    notes = Column(Text, nullable=True)
    access_token_hash = Column(String(64), nullable=True)
    reservation_expires_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class OrderItem(Base):
    __tablename__ = "order_items"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    order_id = Column(PGUUID(as_uuid=True), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(PGUUID(as_uuid=True), ForeignKey("products.id", ondelete="RESTRICT"), nullable=False)
    product_name = Column(String(180), nullable=False)
    sku = Column(String(80), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Numeric(14, 2), nullable=False)
    line_total = Column(Numeric(14, 2), nullable=False)
    __table_args__ = (CheckConstraint("quantity > 0", name="ck_order_item_quantity_positive"),)


class CommercePayment(Base):
    __tablename__ = "commerce_payments"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    order_id = Column(PGUUID(as_uuid=True), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)
    reference = Column(String(80), nullable=False, unique=True)
    provider_reference = Column(String(255), nullable=True)
    provider = Column(String(30), nullable=False)
    amount = Column(Numeric(14, 2), nullable=False)
    currency = Column(String(3), nullable=False, default="NGN")
    status = Column(String(20), nullable=False, default="pending")
    authorization_url = Column(Text, nullable=True)
    # Which MERCHANT-owned provider connection this payment used (NULL for pay-on-delivery / bank transfer).
    connection_id = Column(PGUUID(as_uuid=True), ForeignKey("merchant_payment_connections.id", ondelete="RESTRICT"), nullable=True, index=True)
    # The exact credential REVISION used when this payment was initiated; verification and webhooks use
    # this revision, never whatever the connection points to later.
    credential_id = Column(PGUUID(as_uuid=True), ForeignKey("merchant_payment_credentials.id", ondelete="RESTRICT"), nullable=True, index=True)
    requires_refund = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        CheckConstraint("status IN ('pending','successful','failed','abandoned')", name="ck_commerce_payment_status"),
        CheckConstraint("currency IN ('NGN','GHS','KES','ZAR')", name="ck_commerce_payment_currency"),
    )


class CommerceCheckoutIdempotency(Base):
    __tablename__ = "commerce_checkout_idempotency"
    __table_args__ = (
        UniqueConstraint("tenant_id", "idempotency_key", name="uq_checkout_idempotency_tenant_key"),
        CheckConstraint("status IN ('processing','completed','failed')", name="ck_checkout_idempotency_status"),
    )
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    idempotency_key = Column(String(255), nullable=False)
    request_fingerprint = Column(String(64), nullable=False)
    status = Column(String(20), nullable=False, default="processing")
    response_payload = Column(JSONB, nullable=True)
    # Lease + link so a crash between "order committed" and "response recorded" is recoverable by the worker.
    processing_since = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    order_id = Column(PGUUID(as_uuid=True), ForeignKey("orders.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime(timezone=True), nullable=True)


class Fulfillment(Base):
    __tablename__ = "fulfillments"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    order_id = Column(PGUUID(as_uuid=True), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, unique=True)
    status = Column(String(30), nullable=False, default="unfulfilled")
    carrier = Column(String(120), nullable=True)
    tracking_number = Column(String(120), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (CheckConstraint("status IN ('unfulfilled','processing','shipped','delivered','cancelled')", name="ck_fulfillment_status"),)


# ------------------------------ Schemas ---------------------------------



class MerchantPaymentCredential(Base):
    """Sealed merchant provider secrets. Never serialized to any API response."""
    __tablename__ = "merchant_payment_credentials"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    connection_id = Column(PGUUID(as_uuid=True), ForeignKey("merchant_payment_connections.id", ondelete="CASCADE"), nullable=False)
    provider = Column(String(40), nullable=False)
    key_version = Column(String(40), nullable=False)
    # NULL once the revision is purged (status 'purged'); the row stays as payment history.
    nonce = Column(LargeBinary, nullable=True)
    ciphertext = Column(LargeBinary, nullable=True)
    # Immutable credential revisions: replacing a merchant's provider account creates revision N+1; a
    # payment always verifies against the revision it was initiated with. pending|active|retired|purged
    revision = Column(Integer, nullable=False, default=1)
    status = Column(String(20), nullable=False, default="active")
    aad_version = Column(SmallInteger, nullable=False, default=2)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    rotated_at = Column(DateTime(timezone=True), nullable=True)
    retired_at = Column(DateTime(timezone=True), nullable=True)
    purged_at = Column(DateTime(timezone=True), nullable=True)


class MerchantPaymentEvent(Base):
    """Per-merchant webhook inbox (verified with that merchant's own credentials)."""
    __tablename__ = "merchant_payment_events"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    connection_id = Column(PGUUID(as_uuid=True), ForeignKey("merchant_payment_connections.id", ondelete="CASCADE"), nullable=False)
    event_id = Column(String(255), nullable=False)
    event_type = Column(String(100), nullable=False)
    reference = Column(String(255), nullable=True)
    raw_payload = Column(JSONB, nullable=False)
    processed = Column(Boolean, nullable=False, default=False)
    processed_at = Column(DateTime(timezone=True), nullable=True)
    processing_error = Column(String(500), nullable=True)
    received_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    __table_args__ = (UniqueConstraint("connection_id", "event_id", name="uq_merchant_payment_event_identity"),)


class PaymentWebhookRoute(Base):
    """NON-secret routing row: random token -> (tenant, connection). Not tenant-scoped on purpose."""
    __tablename__ = "payment_webhook_routes"
    webhook_token = Column(String(64), primary_key=True)
    tenant_id = Column(PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False)
    connection_id = Column(PGUUID(as_uuid=True), ForeignKey("merchant_payment_connections.id", ondelete="CASCADE"), nullable=False, unique=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
