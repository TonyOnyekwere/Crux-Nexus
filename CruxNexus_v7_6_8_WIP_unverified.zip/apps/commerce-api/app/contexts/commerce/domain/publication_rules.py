"""Storefront publication rules (pure, no I/O).

A storefront may become public ONLY when all of these hold:
  * at least one published product
  * at least one enabled payment method (merchant-enabled AND actually usable)
  * at least one enabled fulfillment method
  * required merchant/storefront contact details exist
and it must be, additionally: owned by an ACTIVE tenant, commercially entitled to operate, explicitly
marked published, and not suspended by the Control Center. One resolver enforces the public side so no
individual route can forget a condition.
"""

from __future__ import annotations

from typing import Optional

NO_PUBLISHED_PRODUCT = "NO_PUBLISHED_PRODUCT"
NO_PAYMENT_METHOD = "NO_PAYMENT_METHOD"
NO_FULFILLMENT_METHOD = "NO_FULFILLMENT_METHOD"
CONTACT_MISSING = "CONTACT_DETAILS_MISSING"
BUSINESS_NAME_MISSING = "BUSINESS_NAME_MISSING"

_MESSAGES = {
    NO_PUBLISHED_PRODUCT: "Publish at least one product.",
    NO_PAYMENT_METHOD: "Enable at least one payment method that customers can actually use.",
    NO_FULFILLMENT_METHOD: "Enable at least one fulfillment method (delivery or pickup).",
    CONTACT_MISSING: "Add a contact phone number or email address for your store.",
    BUSINESS_NAME_MISSING: "Add your business name.",
}


def _present(value: Optional[str]) -> bool:
    return bool(value and str(value).strip())


def readiness_problems(
    *,
    business_name: Optional[str],
    phone: Optional[str],
    contact_email: Optional[str],
    published_product_count: int,
    enabled_payment_methods: list,
    pickup_enabled: bool,
    delivery_enabled: bool,
) -> list:
    """Unmet requirements as [{'code', 'message'}]; an empty list means ready to publish."""
    codes = []
    if not _present(business_name):
        codes.append(BUSINESS_NAME_MISSING)
    if not (_present(phone) or _present(contact_email)):
        codes.append(CONTACT_MISSING)
    if published_product_count < 1:
        codes.append(NO_PUBLISHED_PRODUCT)
    if not enabled_payment_methods:
        codes.append(NO_PAYMENT_METHOD)
    if not (pickup_enabled or delivery_enabled):
        codes.append(NO_FULFILLMENT_METHOD)
    return [{"code": c, "message": _MESSAGES[c]} for c in codes]


def public_access(*, tenant_status: Optional[str], profile_exists: bool, profile_published: bool, commercially_blocked: bool) -> bool:
    """Is the storefront publicly reachable right now? Every condition must hold; any failure is simply
    'not found' to the public (no state is revealed)."""
    return (
        tenant_status == "active"
        and profile_exists
        and bool(profile_published)
        and not commercially_blocked
    )
