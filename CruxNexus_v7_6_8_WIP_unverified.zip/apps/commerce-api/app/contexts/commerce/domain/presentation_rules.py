"""Pure validation for merchant-owned storefront presentation (no I/O).

The merchant owns how their storefront looks; the TIER decides how deep that
customization may go (see app.kernel.access.entitlement_policy). Capability and
limit KEYS below are only names: whether a plan grants them is Control Center
data, so tiers can change without touching this code.

Security stance: merchant CSS and fonts are served to that merchant's own
customers from a CruxNexus origin, so they are validated hard. CSS may style but
never load anything, run anything, or escape its container.
"""

from __future__ import annotations

import ipaddress
import json
import re
from typing import Mapping, Optional

# Capability keys (Control Center plan `capabilities`)
CAP_THEME = "storefront.theme_customization"   # theme tokens, fonts, layout
CAP_SLOTS = "storefront.component_slots"       # arranging storefront components
CAP_CSS = "storefront.custom_css"
CAP_DOMAIN = "storefront.custom_domain"

# Limit keys (Control Center plan `resource_limits`)
LIMIT_PRODUCTS = "products"
LIMIT_SLOTS = "storefront.component_slots"     # max number of configured slots
LIMIT_CSS_BYTES = "storefront.custom_css_bytes"
LIMIT_DOMAINS = "storefront.custom_domains"
LIMIT_PAYMENT_PROVIDERS = "payments.providers"

MAX_JSON_BYTES = 32_000
DEFAULT_CSS_BYTES = 20_000
HARD_CSS_BYTES = 100_000  # absolute ceiling regardless of any plan limit

_FONT_FAMILY = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 \-]{0,59}$")
_TOKEN_KEY = re.compile(r"^[a-z][a-z0-9_\-]{0,39}$")
_COLOR = re.compile(r"^(#[0-9a-fA-F]{3,8}|[a-zA-Z]{3,30})$")
_SLOT_NAME = re.compile(r"^[a-z][a-z0-9_\-]{0,39}$")

_CSS_FORBIDDEN = (
    r"@import", r"@charset", r"@namespace", r"url\s*\(", r"expression\s*\(", r"behavio[u]?r\s*:",
    r"-moz-binding", r"javascript\s*:", r"vbscript\s*:", r"data\s*:", r"</?\s*style", r"<\s*/?\s*script",
    r"\\\s*[0-9a-fA-F]{1,6}", r"image-set\s*\(", r"src\s*:", r"@font-face", r"position\s*:\s*fixed",
)
_CSS_FORBIDDEN_RE = re.compile("|".join(_CSS_FORBIDDEN), re.IGNORECASE)

RESERVED_LABELS = frozenset({"www", "api", "admin", "app", "mail", "cruxnexus", "control", "static", "cdn"})


class PresentationError(ValueError):
    """Invalid presentation input; message is safe to show the merchant."""


def _json_size(value) -> int:
    return len(json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))


def validate_json_blob(name: str, value) -> dict:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise PresentationError(f"{name} must be an object.")
    if _json_size(value) > MAX_JSON_BYTES:
        raise PresentationError(f"{name} is too large.")
    return dict(value)


def validate_theme(theme) -> dict:
    theme = validate_json_blob("theme", theme)
    for key, val in theme.items():
        if not _TOKEN_KEY.match(str(key)):
            raise PresentationError(f"Invalid theme key '{key}'.")
        if isinstance(val, str) and not _COLOR.match(val) and len(val) > 60:
            raise PresentationError(f"Theme value for '{key}' is too long.")
        if isinstance(val, str) and re.search(r"[<>{};]|url\s*\(|javascript\s*:", val, re.IGNORECASE):
            raise PresentationError(f"Theme value for '{key}' contains forbidden characters.")
        if not isinstance(val, (str, int, float, bool)):
            raise PresentationError(f"Theme value for '{key}' must be a simple value.")
    return theme


def validate_fonts(fonts) -> dict:
    fonts = validate_json_blob("fonts", fonts)
    for role, family in fonts.items():
        if not _TOKEN_KEY.match(str(role)):
            raise PresentationError(f"Invalid font role '{role}'.")
        if not isinstance(family, str) or not _FONT_FAMILY.match(family):
            raise PresentationError(f"Font family for '{role}' must be a plain font name.")
    return fonts


def validate_layout(layout) -> dict:
    layout = validate_json_blob("layout", layout)
    for key, val in layout.items():
        if not _TOKEN_KEY.match(str(key)):
            raise PresentationError(f"Invalid layout key '{key}'.")
        if not isinstance(val, (str, int, float, bool)):
            raise PresentationError(f"Layout value for '{key}' must be a simple value.")
    return layout


def validate_slots(slots) -> dict:
    slots = validate_json_blob("component_slots", slots)
    for name, spec in slots.items():
        if not _SLOT_NAME.match(str(name)):
            raise PresentationError(f"Invalid slot name '{name}'.")
        if not isinstance(spec, Mapping) or _json_size(spec) > 4_000:
            raise PresentationError(f"Slot '{name}' must be a small object.")
    return slots


def validate_css(css: Optional[str], *, max_bytes: Optional[int] = None) -> Optional[str]:
    if css is None or css.strip() == "":
        return None
    ceiling = min(max_bytes if max_bytes is not None else DEFAULT_CSS_BYTES, HARD_CSS_BYTES)
    if len(css.encode("utf-8")) > ceiling:
        raise PresentationError(f"Custom CSS exceeds the {ceiling}-byte limit.")
    found = _CSS_FORBIDDEN_RE.search(css)
    if found:
        raise PresentationError(f"Custom CSS may not contain '{found.group(0).strip()}'.")
    if css.count("{") != css.count("}"):
        raise PresentationError("Custom CSS has unbalanced braces.")
    return css


def normalize_hostname(raw: str, *, platform_domains: tuple = ()) -> str:
    host = (raw or "").strip().lower().rstrip(".")
    if not host or len(host) > 253:
        raise PresentationError("Enter a valid domain name.")
    if re.search(r"[\s/:@?#*_]", host):
        raise PresentationError("Enter a bare domain name, e.g. shop.example.com.")
    try:
        ipaddress.ip_address(host)
        raise PresentationError("An IP address cannot be used as a custom domain.")
    except ValueError as exc:
        if isinstance(exc, PresentationError):
            raise
    labels = host.split(".")
    if len(labels) < 2 or any(not re.match(r"^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?$", lab) for lab in labels):
        raise PresentationError("Enter a valid domain name.")
    if not re.match(r"^[a-z]{2,63}$", labels[-1]) and not labels[-1].startswith("xn--"):
        raise PresentationError("Enter a valid domain name.")
    for platform in platform_domains:
        platform = platform.lower().lstrip(".")
        if host == platform or host.endswith("." + platform):
            raise PresentationError("That domain belongs to the platform.")
    if labels[0] in RESERVED_LABELS and len(labels) == 2:
        raise PresentationError("That domain name is reserved.")
    return host


def required_capabilities(*, theme=None, fonts=None, layout=None, slots=None, css=None) -> set:
    """Which capabilities a presentation update needs (only for parts being SET)."""
    need = set()
    if theme is not None or fonts is not None or layout is not None:
        need.add(CAP_THEME)
    if slots is not None:
        need.add(CAP_SLOTS)
    if css is not None:
        need.add(CAP_CSS)
    return need
