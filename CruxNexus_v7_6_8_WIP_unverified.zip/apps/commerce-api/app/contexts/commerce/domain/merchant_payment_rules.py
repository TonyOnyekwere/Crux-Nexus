"""Pure rules for MERCHANT-OWNED payment connections (no I/O).

Two completely separate financial relationships exist in CruxNexus:
  A. Merchant -> CruxNexus : subscription billing. Uses CruxNexus-owned provider credentials
     (app.infrastructure.payments registry + billing webhook inbox).
  B. Customer -> Merchant  : checkout. Uses ONLY the merchant's own provider account, via a
     connection + sealed credentials. CruxNexus orchestrates and records provider-confirmed
     transaction state; it never receives, holds, or routes the money.
The subscription channel is never a customer checkout gateway. This is enforced in CI by
scripts/check_payment_channel_separation.py.
"""

from __future__ import annotations

import re
import secrets
from typing import Mapping, Tuple

CONNECTABLE_PROVIDERS = ("paystack", "flutterwave")

_PAYSTACK_SECRET = re.compile(r"^sk_(live|test)_[A-Za-z0-9]{10,120}$")
_FLW_SECRET = re.compile(r"^FLWSECK(_TEST)?-[A-Za-z0-9_\-]{10,160}$")
_FLW_WEBHOOK_HASH = re.compile(r"^[\x21-\x7e]{8,128}$")  # printable, no spaces


class CredentialValidationError(ValueError):
    """Safe-to-show validation message. Never includes the submitted value."""


def validate_credentials(provider: str, payload: Mapping, *, allow_test_keys: bool) -> Tuple[dict, str]:
    """Returns (clean secrets to seal, mode 'live'|'test'). Unknown fields are rejected."""
    provider = (provider or "").lower()
    if provider not in CONNECTABLE_PROVIDERS:
        raise CredentialValidationError(f"Unsupported payment provider '{provider}'.")
    data = dict(payload or {})

    def take(name: str, required: bool = True):
        value = data.pop(name, None)
        if value is None or (isinstance(value, str) and not value.strip()):
            if required:
                raise CredentialValidationError(f"'{name}' is required for {provider}.")
            return None
        if not isinstance(value, str):
            raise CredentialValidationError(f"'{name}' must be text.")
        return value.strip()

    if provider == "paystack":
        secret = take("secret_key")
        match = _PAYSTACK_SECRET.match(secret)
        if not match:
            raise CredentialValidationError("That does not look like a Paystack secret key (expected sk_live_... or sk_test_...).")
        mode = match.group(1)
        clean = {"secret_key": secret}
    else:
        secret = take("secret_key")
        match = _FLW_SECRET.match(secret)
        if not match:
            raise CredentialValidationError("That does not look like a Flutterwave secret key (expected FLWSECK-... or FLWSECK_TEST-...).")
        mode = "test" if match.group(1) else "live"
        webhook_hash = take("webhook_secret_hash")
        if not _FLW_WEBHOOK_HASH.match(webhook_hash):
            raise CredentialValidationError("The webhook secret hash must be 8-128 visible characters.")
        clean = {"secret_key": secret, "webhook_secret_hash": webhook_hash}

    if data:
        raise CredentialValidationError(f"Unexpected field(s): {', '.join(sorted(data))}.")
    if mode == "test" and not allow_test_keys:
        raise CredentialValidationError("Test-mode keys cannot be connected in production. Use your live keys.")
    return clean, mode


def generate_webhook_token() -> str:
    """Unguessable routing token (256 bits). It identifies WHICH merchant connection a webhook
    belongs to; authenticity still comes from the provider signature, verified with that
    merchant's own credentials."""
    return secrets.token_urlsafe(32)


def webhook_path(token: str) -> str:
    return f"/api/v1/payments/webhooks/{token}"


# ---- credential revisions ------------------------------------------------------------------------
# A merchant may replace the provider account behind a connection. Credentials are therefore IMMUTABLE
# REVISIONS: every payment records the revision it was initiated with and is verified against that
# revision for life. A retired revision stays usable while any payment that used it still needs it.

REVISION_STATUSES = ("pending", "active", "retired", "purged")


def payment_needs_credentials(*, status: str, requires_refund: bool) -> bool:
    """True while a payment may still need its provider credentials: it is unresolved (pending), or it
    was paid and a refund is still owed. Terminal, settled payments do not."""
    return status == "pending" or bool(requires_refund)


def revision_purgeable(*, revision_status: str, referencing_payments) -> bool:
    """A RETIRED revision may be purged (secret zeroed, row kept as history) only when every payment
    that used it has settled. `referencing_payments` is an iterable of (status, requires_refund)."""
    if revision_status != "retired":
        return False
    return not any(payment_needs_credentials(status=s, requires_refund=r) for s, r in referencing_payments)


def webhook_signature_candidates(*, payment_revision_id, active_revision_id) -> list:
    """Which credential revisions may authenticate an incoming merchant webhook, in order. The payment's
    own revision is tried first (it may be retired); the active revision covers events for references we
    do not know. Never more than these two, never duplicated."""
    ordered = []
    for candidate in (payment_revision_id, active_revision_id):
        if candidate is not None and candidate not in ordered:
            ordered.append(candidate)
    return ordered


def next_revision_number(existing_revisions) -> int:
    return (max(existing_revisions) if existing_revisions else 0) + 1


def may_activate(*, candidate_revision: int, highest_revision: int, candidate_status: str) -> bool:
    """Activation after provider verification is only valid if nothing newer was started meanwhile and
    this revision is still the pending one (a concurrent replace/delete must win over a slow verify)."""
    return candidate_status == "pending" and candidate_revision == highest_revision
