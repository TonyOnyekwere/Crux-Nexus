"""Commerce domain invariants and pure policy helpers."""
from __future__ import annotations

from decimal import Decimal
from fastapi import HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.tenant_management.domain.entities import Tenant
from .models import Order

# Re-exported: the single canonical transition tables live in fulfillment_rules.
from .fulfillment_rules import FULFILLMENT_TRANSITIONS, ORDER_TRANSITIONS  # noqa: F401


def transition_order(order: Order, target: str) -> None:
    if target == order.status:
        return
    allowed = ORDER_TRANSITIONS.get(order.status, set())
    if target not in allowed:
        raise HTTPException(409, f"Order cannot transition from {order.status} to {target}")
    order.status = target


def server_delivery_fee(tenant: Tenant, payload: object) -> Decimal:
    """MVP delivery policy: server-owned zero fee until logistics pricing exists."""
    return Decimal("0")


async def set_public_tenant_context(db: AsyncSession, slug: str) -> Tenant:
    """Resolve an active public storefront and establish its RLS context."""
    await db.execute(text("SELECT set_config('app.public_storefront', '1', true)"))
    tenant = (
        await db.execute(
            select(Tenant).where(Tenant.slug == slug, Tenant.status == "active")
        )
    ).scalar_one_or_none()
    if tenant is None:
        raise HTTPException(status_code=404, detail="Storefront not found")
    await db.execute(
        text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"),
        {"tenant_id": str(tenant.id)},
    )
    return tenant
