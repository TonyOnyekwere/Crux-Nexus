"""Merchant-configured payment methods and reservation lifecycle (pure, no I/O).

Locked decisions:
  * The merchant decides which payment methods their storefront offers (pay on delivery, bank transfer,
    and each connected online provider individually). Platform governance may additionally disable a
    provider; it can never force one on.
  * BANK TRANSFER holds stock for a merchant-configurable window (default 24h). Expiry releases the
    reservation. A LATE merchant confirmation re-checks stock: if the units can be re-reserved the order
    is confirmed; if not, the payment is recorded and flagged refund-required. An order is never
    resurrected merely because money arrived - and a deliberately cancelled order is never reopened.
  * PAY ON DELIVERY holds stock from confirmation until the order is fulfilled or cancelled. No
    automatic reservation expiry.
  * ONLINE payment holds stock for a short window (1h); the merchant's own provider confirms the money.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Mapping, Optional, Tuple

POD = "pay_on_delivery"
BANK = "bank_transfer"
ONLINE_PROVIDERS = frozenset({"paystack", "flutterwave"})

DEFAULT_BANK_WINDOW_HOURS = 24
MIN_BANK_WINDOW_HOURS, MAX_BANK_WINDOW_HOURS = 1, 168
ONLINE_RESERVATION = timedelta(hours=1)

EXPIRED_REASON = "reservation_expired"


class PaymentConfigError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


# ---- configuration validation ---------------------------------------------------------------------
_ACCOUNT_NUMBER = re.compile(r"^[0-9]{6,20}$")
_TEXT = re.compile(r"^[^\x00-\x08\x0b\x0c\x0e-\x1f<>]{1,120}$")
_ALLOWED_BANK_KEYS = {"bank_name", "account_name", "account_number", "instructions"}


def validate_bank_transfer_details(details) -> dict:
    """Where customers send the money. Plain text only; no markup; no secrets."""
    if not isinstance(details, Mapping):
        raise PaymentConfigError("INVALID_BANK_DETAILS", "Bank transfer details must be an object.")
    extra = set(details) - _ALLOWED_BANK_KEYS
    if extra:
        raise PaymentConfigError("INVALID_BANK_DETAILS", f"Unexpected field(s): {', '.join(sorted(extra))}.")
    out = {}
    for key in ("bank_name", "account_name"):
        value = str(details.get(key, "")).strip()
        if not _TEXT.match(value):
            raise PaymentConfigError("INVALID_BANK_DETAILS", f"'{key}' is required (1-120 plain-text characters).")
        out[key] = value
    number = str(details.get("account_number", "")).replace(" ", "").strip()
    if not _ACCOUNT_NUMBER.match(number):
        raise PaymentConfigError("INVALID_BANK_DETAILS", "'account_number' must be 6-20 digits.")
    out["account_number"] = number
    instructions = details.get("instructions")
    if instructions not in (None, ""):
        text = str(instructions).strip()
        if len(text) > 500 or re.search(r"[<>\x00-\x08\x0b\x0c\x0e-\x1f]", text):
            raise PaymentConfigError("INVALID_BANK_DETAILS", "'instructions' must be plain text up to 500 characters.")
        out["instructions"] = text
    return out


def validate_bank_window_hours(hours) -> int:
    if isinstance(hours, bool) or not isinstance(hours, int) or not (MIN_BANK_WINDOW_HOURS <= hours <= MAX_BANK_WINDOW_HOURS):
        raise PaymentConfigError(
            "INVALID_BANK_WINDOW", f"The bank-transfer window must be {MIN_BANK_WINDOW_HOURS}-{MAX_BANK_WINDOW_HOURS} hours.")
    return hours


# ---- availability at checkout -----------------------------------------------------------------------
def method_availability(
    *,
    method: str,
    pod_enabled: bool,
    bank_transfer_enabled: bool,
    bank_transfer_details,
    connected_providers: set,
    platform_enabled_providers: set,
) -> Tuple[bool, str]:
    """May a customer pay with `method` at this merchant right now?"""
    if method == POD:
        return (True, "OK") if pod_enabled else (False, "PAYMENT_METHOD_NOT_ENABLED")
    if method == BANK:
        if not bank_transfer_enabled:
            return False, "PAYMENT_METHOD_NOT_ENABLED"
        if not bank_transfer_details:
            return False, "BANK_TRANSFER_NOT_CONFIGURED"
        return True, "OK"
    if method in ONLINE_PROVIDERS:
        if method not in platform_enabled_providers:
            return False, "PROVIDER_DISABLED_BY_PLATFORM"
        if method not in connected_providers:
            return False, "PAYMENT_PROVIDER_NOT_CONNECTED"
        return True, "OK"
    return False, "UNKNOWN_PAYMENT_METHOD"


def enabled_methods(*, pod_enabled, bank_transfer_enabled, bank_transfer_details, connected_providers, platform_enabled_providers) -> list:
    out = []
    for method in (POD, BANK, *sorted(ONLINE_PROVIDERS)):
        ok, _ = method_availability(
            method=method, pod_enabled=pod_enabled, bank_transfer_enabled=bank_transfer_enabled,
            bank_transfer_details=bank_transfer_details, connected_providers=connected_providers,
            platform_enabled_providers=platform_enabled_providers)
        if ok:
            out.append(method)
    return out


# ---- reservation lifecycle --------------------------------------------------------------------------
def initial_order_state(method: str) -> Tuple[str, str]:
    """(order status, payment status) at checkout. POD is confirmed on placement (cash due at the door);
    bank transfer waits for the merchant to confirm receipt; online waits for the provider."""
    if method == POD:
        return "confirmed", "pending"
    if method == BANK:
        return "awaiting_transfer", "pending"
    return "pending_payment", "pending"


def reservation_deadline(method: str, now: datetime, *, bank_window_hours: int = DEFAULT_BANK_WINDOW_HOURS) -> Optional[datetime]:
    """When the stock hold lapses on its own. POD: never (held until fulfilled or cancelled)."""
    if method == POD:
        return None
    if method == BANK:
        return now + timedelta(hours=validate_bank_window_hours(bank_window_hours))
    return now + ONLINE_RESERVATION


def reservation_is_live(*, order_status: str, reserved_units_held: bool, deadline: Optional[datetime], now: datetime,
                        method: str) -> bool:
    """Does the order really still own its stock? The movement ledger says units are held AND the
    deadline (if the method has one) has not passed. POD has no deadline."""
    if not reserved_units_held:
        return False
    if method == POD:
        return True
    return deadline is not None and deadline > now


# ---- late bank-transfer confirmation ----------------------------------------------------------------
CONFIRM = "confirm"                              # reservation still valid
RERESERVE_AND_CONFIRM = "rereserve_and_confirm"  # expired but not yet cancelled; stock still available
REOPEN_AND_CONFIRM = "reopen_and_confirm"        # worker cancelled it for expiry; stock still available
REFUND_REQUIRED = "refund_required"              # money recorded; order NOT revived
ALREADY_CONFIRMED = "already_confirmed"

_PAST_CONFIRMATION = {"confirmed", "fulfilling", "shipped", "delivered", "completed"}


def plan_late_bank_transfer(*, order_status: str, cancellation_reason: Optional[str], reservation_live: bool,
                            can_rereserve: bool) -> str:
    """What to do when the merchant confirms a bank transfer. Never revives an order just because money
    arrived; re-reserving stock is the only way an expired order may come back, and only an order that
    EXPIRED (not one deliberately cancelled) is eligible."""
    if order_status in _PAST_CONFIRMATION:
        return ALREADY_CONFIRMED
    if order_status == "awaiting_transfer":
        if reservation_live:
            return CONFIRM
        return RERESERVE_AND_CONFIRM if can_rereserve else REFUND_REQUIRED
    if order_status == "cancelled" and cancellation_reason == EXPIRED_REASON:
        return REOPEN_AND_CONFIRM if can_rereserve else REFUND_REQUIRED
    return REFUND_REQUIRED   # deliberately cancelled, payment_failed, pending_payment (online) ... never revived
