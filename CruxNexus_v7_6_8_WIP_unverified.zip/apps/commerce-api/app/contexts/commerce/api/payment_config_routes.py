"""Merchant-controlled payment and fulfillment configuration.

The merchant decides which payment methods and fulfillment methods their storefront offers; nothing is
on by default. Online providers are additionally gated by the merchant's own verified connection and by
platform governance (which can disable a provider but never force one on).
"""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.authorization import Permission, require_permission
from app.auth.jwt_handler import get_verified_tenant_context
from app.contexts.billing.domain.provider_registry import ProviderRegistryEntry
from app.contexts.commerce.application.services import merchant_payments as mp
from app.contexts.commerce.domain import payment_methods as pm
from app.contexts.commerce.domain.models import MerchantPaymentConnection, StorefrontProfile
from app.database import get_db

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce-payment-config"])


def _tid(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))


def _err(code: str, message: str, status: int = 422) -> HTTPException:
    return HTTPException(status, detail={"error": {"code": code, "message": message, "details": {}}})


class PaymentMethodConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    pod_enabled: bool | None = None
    bank_transfer_enabled: bool | None = None
    bank_transfer_details: dict | None = None
    bank_transfer_window_hours: int | None = None


class FulfillmentMethodConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    pickup_enabled: bool | None = None
    delivery_enabled: bool | None = None


class ProviderAvailability(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool


async def _profile(db: AsyncSession, tid: UUID, *, lock: bool = False) -> StorefrontProfile:
    q = select(StorefrontProfile).where(StorefrontProfile.tenant_id == tid)
    row = (await db.execute(q.with_for_update() if lock else q)).scalar_one_or_none()
    if row is None:
        raise _err("STOREFRONT_NOT_CONFIGURED", "Set up your storefront first.", 409)
    return row


async def _view(db: AsyncSession, tid: UUID, profile: StorefrontProfile) -> dict:
    connections = (await db.execute(select(MerchantPaymentConnection).where(MerchantPaymentConnection.tenant_id == tid)
                                    .order_by(MerchantPaymentConnection.provider))).scalars().all()
    connected = await mp.connected_providers(db, tid)
    platform_enabled = set((await db.execute(select(ProviderRegistryEntry.provider_type).where(ProviderRegistryEntry.enabled.is_(True)))).scalars().all())
    return {
        "pod_enabled": profile.pod_enabled,
        "bank_transfer_enabled": profile.bank_transfer_enabled,
        "bank_transfer_details": profile.bank_transfer_details,
        "bank_transfer_window_hours": profile.bank_transfer_window_hours,
        "providers": [{"provider": c.provider, "status": c.status, "enabled": c.enabled, "mode": (c.configuration or {}).get("mode"),
                       "platform_enabled": c.provider in platform_enabled} for c in connections],
        "available_to_customers": pm.enabled_methods(
            pod_enabled=profile.pod_enabled, bank_transfer_enabled=profile.bank_transfer_enabled,
            bank_transfer_details=profile.bank_transfer_details, connected_providers=connected,
            platform_enabled_providers=platform_enabled),
        "fulfillment": {"pickup_enabled": profile.pickup_enabled, "delivery_enabled": profile.delivery_enabled},
    }


@router.get("/payment-methods/config")
async def get_payment_config(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tid(ctx)
    return {"data": await _view(db, tid, await _profile(db, tid))}


@router.put("/payment-methods/config")
async def put_payment_config(payload: PaymentMethodConfig, db: AsyncSession = Depends(get_db),
                             ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tid(ctx)
    profile = await _profile(db, tid, lock=True)
    sent = payload.model_dump(exclude_unset=True)
    try:
        if "bank_transfer_details" in sent and sent["bank_transfer_details"] is not None:
            sent["bank_transfer_details"] = pm.validate_bank_transfer_details(sent["bank_transfer_details"])
        if "bank_transfer_window_hours" in sent:
            sent["bank_transfer_window_hours"] = pm.validate_bank_window_hours(sent["bank_transfer_window_hours"])
    except pm.PaymentConfigError as exc:
        raise _err(exc.code, exc.message)
    for key, value in sent.items():
        setattr(profile, key, value)
    if profile.bank_transfer_enabled and not profile.bank_transfer_details:
        raise _err("BANK_TRANSFER_NOT_CONFIGURED", "Add your bank account details before enabling bank transfer.")
    await db.commit()
    return {"data": await _view(db, tid, profile)}


@router.put("/fulfillment-methods")
async def put_fulfillment_methods(payload: FulfillmentMethodConfig, db: AsyncSession = Depends(get_db),
                                  ctx: dict = Depends(get_verified_tenant_context)):
    """Which ways a customer may receive an order. Detailed delivery configuration (zones, fees, carriers)
    is a later domain; these switches are the merchant's own decision and gate publication and checkout."""
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tid(ctx)
    profile = await _profile(db, tid, lock=True)
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(profile, key, value)
    await db.commit()
    return {"data": {"pickup_enabled": profile.pickup_enabled, "delivery_enabled": profile.delivery_enabled}}


@router.put("/payment-connections/{provider}/availability")
async def put_provider_availability(provider: str, payload: ProviderAvailability, db: AsyncSession = Depends(get_db),
                                    ctx: dict = Depends(get_verified_tenant_context)):
    """The merchant's own on/off switch for offering a connected provider at checkout."""
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    row = (await db.execute(select(MerchantPaymentConnection).where(
        MerchantPaymentConnection.tenant_id == _tid(ctx), MerchantPaymentConnection.provider == provider.lower()
    ).with_for_update())).scalar_one_or_none()
    if row is None:
        raise _err("PAYMENT_PROVIDER_NOT_CONNECTED", "That provider has not been connected.", 404)
    row.enabled = payload.enabled
    await db.commit()
    return {"data": {"provider": row.provider, "status": row.status, "enabled": row.enabled}}
