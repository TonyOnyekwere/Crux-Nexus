"""Commerce HTTP adapter."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_verified_tenant_context
from app.database import get_db
from app.contexts.commerce.domain.models import OrderItem, Product
from app.contexts.commerce.domain.invariants import Order

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce"])

@router.get("/dashboard")
async def dashboard(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    tid = _tenant_id(ctx)
    products = await db.scalar(select(Product.id).where(Product.tenant_id == tid).limit(1))
    orders = await db.scalar(select(Order.id).where(Order.tenant_id == tid).limit(1))
    return {"data": {"tenant_id": str(tid), "has_products": products is not None, "has_orders": orders is not None}}

