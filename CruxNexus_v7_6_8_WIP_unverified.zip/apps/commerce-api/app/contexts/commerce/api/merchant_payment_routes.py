"""Merchant-owned payment connections: credential intake, per-merchant webhook ingestion.

Credentials are WRITE-ONLY: no endpoint ever returns them. Customer money moves directly
between the customer and the merchant's own provider account; this module only records
provider-confirmed state.
"""
from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.authorization import Permission, require_permission
from app.auth.jwt_handler import get_verified_tenant_context
from app.contexts.commerce.application.services import merchant_payments as mp
from app.contexts.commerce.domain import merchant_payment_rules as rules
from app.contexts.commerce.domain.models import MerchantPaymentConnection, MerchantPaymentEvent, PaymentWebhookRoute
from app.database import get_db
from app.infrastructure.payments.adapter import PaymentProviderAdapter
from app.infrastructure.secrets.credential_vault import VaultDecryptionError, VaultNotConfigured
from app.infrastructure.rate_limiter import key_ip, key_ip_tenant, key_webhook_token, limiter

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/commerce", tags=["merchant-payments"])
webhook_router = APIRouter(prefix="/api/v1/payments/webhooks", tags=["merchant-payment-webhooks"])


def _tid(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))


class CredentialsPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    secret_key: str
    webhook_secret_hash: str | None = None


@router.put("/payment-connections/{provider}/credentials")
@limiter.limit("5/hour", key_func=key_ip_tenant)
@limiter.limit("30/hour", key_func=key_ip)
async def put_credentials(request: Request, provider: str, payload: CredentialsPayload, db: AsyncSession = Depends(get_db),
                          ctx: dict = Depends(get_verified_tenant_context)):
    """Write-only. Seals the merchant's provider secrets and verifies them with the provider.
    The response never contains a secret."""
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    # Connecting a payment provider is core to every tier; the tier only bounds HOW MANY providers.
    from app.contexts.commerce.domain.presentation_rules import LIMIT_PAYMENT_PROVIDERS
    from app.kernel.access import entitlement_policy as ep
    from app.kernel.access.policy_loader import deny, load_policy_for_tenant
    tid = _tid(ctx)
    existing = (await db.execute(select(MerchantPaymentConnection.provider).where(MerchantPaymentConnection.tenant_id == tid))).scalars().all()
    if provider.lower() not in existing:  # re-submitting credentials for a provider already added is not a new provider
        policy, standing = await load_policy_for_tenant(db, tid)
        decision = ep.can_consume_limit(policy, standing, LIMIT_PAYMENT_PROVIDERS, current=len(existing))
        if not decision:
            raise deny(decision)
    try:
        result = await mp.connect_provider(db, _tid(ctx), provider, payload.model_dump(exclude_none=True))
    except rules.CredentialValidationError as exc:
        raise HTTPException(422, detail={"error": {"code": "INVALID_CREDENTIALS", "message": str(exc), "details": {}}})
    except VaultNotConfigured:
        logger.error("Credential vault is not configured; refusing to store merchant credentials")
        raise HTTPException(503, detail={"error": {"code": "CREDENTIAL_VAULT_NOT_CONFIGURED",
                                                    "message": "Secure credential storage is not available yet.", "details": {}}})
    return {"data": result}


@router.delete("/payment-connections/{provider}/credentials")
@limiter.limit("10/hour", key_func=key_ip_tenant)
@limiter.limit("60/hour", key_func=key_ip)
async def delete_credentials(request: Request, provider: str, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    outcome = await mp.remove_credentials(db, _tid(ctx), provider)
    return {"data": {"provider": provider.lower(), "status": "pending", "has_credentials": False, **outcome,
                     "note": ("Secrets were removed immediately." if not outcome["retained_for_unresolved_payments"] else
                              "The previous credential is retained, sealed, only until payments already started with it are resolved.")}}


# ---- per-merchant webhook ingestion (unauthenticated; authenticity = provider signature) ----------
@webhook_router.post("/{webhook_token}", include_in_schema=False)
@limiter.limit("300/minute", key_func=key_webhook_token)
@limiter.limit("3000/minute", key_func=key_ip)
async def merchant_payment_webhook(webhook_token: str, request: Request, db: AsyncSession = Depends(get_db)):
    raw_body = await request.body()
    headers = {k.lower(): v for k, v in request.headers.items()}

    route = (await db.execute(select(PaymentWebhookRoute).where(PaymentWebhookRoute.webhook_token == webhook_token))).scalar_one_or_none()
    if route is None:
        return Response(status_code=404)
    tenant_id, connection_id = route.tenant_id, route.connection_id
    await mp.bind_tenant_context(db, tenant_id)

    connection = (await db.execute(select(MerchantPaymentConnection).where(
        MerchantPaymentConnection.id == connection_id, MerchantPaymentConnection.tenant_id == tenant_id))).scalar_one_or_none()
    if connection is None or connection.status != "connected":
        # 404, not 200: an event for a non-connected account must not be acknowledged as handled.
        return Response(status_code=404)
    # Authenticate with the credential revision the payment was initiated with (it may be retired by now),
    # else the active one. The reference is read from the unauthenticated body ONLY to choose candidates.
    from app.contexts.commerce.domain.models import CommercePayment
    peeked = PaymentProviderAdapter.peek_reference(raw_body)
    payment_revision = None
    if peeked:
        payment_revision = await db.scalar(select(CommercePayment.credential_id).where(
            CommercePayment.tenant_id == tenant_id, CommercePayment.connection_id == connection_id,
            (CommercePayment.reference == peeked) | (CommercePayment.provider_reference == peeked)))
    active = await mp.active_credential(db, connection)
    candidates = rules.webhook_signature_candidates(
        payment_revision_id=payment_revision, active_revision_id=active.id if active is not None else None)
    result = None
    for credential_id in candidates:
        try:
            adapter = await mp.build_adapter(db, connection, credential_id)
        except (VaultNotConfigured, VaultDecryptionError):
            logger.error("Cannot load credentials for merchant payment connection %s", connection_id)
            return Response(status_code=503)  # provider retries; nothing is lost
        attempt = adapter.verify_webhook_signature(headers=headers, raw_body=raw_body)
        if attempt.signature_valid:
            result = attempt
            break
    if result is None:
        logger.warning("Rejected merchant webhook for connection %s: invalid signature", connection_id)
        return Response(status_code=401)
    if not result.event_id:
        return Response(status_code=422)

    event = MerchantPaymentEvent(
        tenant_id=tenant_id, connection_id=connection_id, event_id=result.event_id,
        event_type=result.event_type or "unknown", reference=result.provider_reference,
        raw_payload=result.normalized_payload or {})
    db.add(event)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        return Response(status_code=200)  # duplicate delivery: already persisted
    await mp.bind_tenant_context(db, tenant_id)
    event_pk = event.id

    await mp.process_merchant_event(db, tenant_id, event_pk)  # best effort; the worker sweeps leftovers
    return Response(status_code=200)
