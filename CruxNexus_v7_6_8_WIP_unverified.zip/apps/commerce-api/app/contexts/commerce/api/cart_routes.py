"""Commerce HTTP adapter."""
from __future__ import annotations

import secrets
from decimal import Decimal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.contexts.commerce.domain.models import Cart, CartItem, OrderItem, Product, StorefrontProfile
from app.contexts.commerce.api.schemas import CartItemInput
from app.contexts.commerce.domain.invariants import Order
from app.contexts.commerce.application.services.public_storefront import resolve_public_storefront

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/storefronts", tags=["public-storefront"])

@router.post("/{slug}/cart/items", status_code=201)
async def add_cart_item(slug: str, payload: CartItemInput, request: Request, db: AsyncSession = Depends(get_db)):
    tenant = (await resolve_public_storefront(db, slug)).tenant
    cart_token = request.headers.get("X-Cart-Token")
    if not cart_token:
        raise HTTPException(400, "X-Cart-Token header is required")
    cart = (await db.execute(select(Cart).where(Cart.token == cart_token, Cart.tenant_id == tenant.id, Cart.status == "open").with_for_update())).scalar_one_or_none()
    if cart is None:
        raise HTTPException(404, "Cart not found")
    product = (await db.execute(select(Product).where(Product.id == payload.product_id, Product.tenant_id == tenant.id, Product.published == True).with_for_update())).scalar_one_or_none()
    if product is None:
        raise HTTPException(404, "Product not found")
    available = product.stock - product.reserved_stock
    existing = (await db.execute(select(CartItem).where(CartItem.cart_id == cart.id, CartItem.product_id == product.id).with_for_update())).scalar_one_or_none()
    new_qty = payload.quantity + (existing.quantity if existing else 0)
    if new_qty > available:
        raise HTTPException(409, "Insufficient stock")
    if existing:
        existing.quantity = new_qty
        existing.unit_price = product.price
    else:
        db.add(CartItem(tenant_id=tenant.id, cart_id=cart.id, product_id=product.id, quantity=new_qty, unit_price=product.price))
    await db.commit()
    return {"data": {"cart_token": cart.token, "product_id": str(product.id), "quantity": new_qty}}

@router.get("/{slug}/cart")
async def get_cart(slug: str, request: Request, db: AsyncSession = Depends(get_db)):
    tenant = (await resolve_public_storefront(db, slug)).tenant
    cart_token = request.headers.get("X-Cart-Token")
    if not cart_token:
        raise HTTPException(400, "X-Cart-Token header is required")
    cart = (await db.execute(select(Cart).where(Cart.token == cart_token, Cart.tenant_id == tenant.id))).scalar_one_or_none()
    if cart is None:
        raise HTTPException(404, "Cart not found")
    rows = (await db.execute(select(CartItem, Product).join(Product, Product.id == CartItem.product_id).where(CartItem.cart_id == cart.id))).all()
    items = [{"product_id": str(p.id), "name": p.name, "quantity": ci.quantity, "unit_price": str(ci.unit_price), "line_total": str(ci.unit_price * ci.quantity)} for ci, p in rows]
    subtotal = sum((ci.unit_price * ci.quantity for ci, _ in rows), Decimal("0"))
    store_currency = await db.scalar(select(StorefrontProfile.currency).where(StorefrontProfile.tenant_id == tenant.id))
    if store_currency is None:
        raise HTTPException(409, "This store is not configured")
    return {"data": {"cart_token": cart.token, "status": cart.status, "subtotal": str(subtotal), "currency": store_currency, "items": items}}

@router.post("/{slug}/cart", status_code=201)
async def create_cart(slug: str, db: AsyncSession = Depends(get_db)):
    tenant = (await resolve_public_storefront(db, slug)).tenant
    cart = Cart(tenant_id=tenant.id, token=secrets.token_urlsafe(48))
    db.add(cart)
    await db.commit()
    return {"data": {"cart_token": cart.token, "tenant_id": str(tenant.id)}}

