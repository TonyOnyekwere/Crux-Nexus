"""Commerce HTTP adapter."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_verified_tenant_context
from app.auth.authorization import Permission, require_permission
from app.database import get_db
from app.contexts.commerce.domain.models import InventoryMovement, OrderItem, Product
from app.contexts.commerce.api.schemas import InventoryAdjustment
from app.contexts.commerce.domain.invariants import Order

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce"])

@router.post("/inventory/{product_id}/adjust")
async def adjust_inventory(product_id: UUID, payload: InventoryAdjustment, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_INVENTORY)
    tid = _tenant_id(ctx)
    product = (await db.execute(select(Product).where(Product.id == product_id, Product.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if product is None:
        raise HTTPException(404, "Product not found")
    new_stock = product.stock + payload.quantity_delta
    if new_stock < product.reserved_stock:
        raise HTTPException(409, "Stock cannot be reduced below currently reserved inventory")
    product.stock = new_stock
    db.add(InventoryMovement(tenant_id=tid, product_id=product.id, quantity_delta=payload.quantity_delta, reason=payload.reason))
    await db.commit()
    return {"data": {"product_id": str(product.id), "stock": product.stock, "reserved_stock": product.reserved_stock, "available_stock": product.stock - product.reserved_stock}}

