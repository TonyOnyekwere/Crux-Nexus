"""Commerce HTTP adapter."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.contexts.commerce.domain.models import OrderItem, Product, StorefrontProfile
from app.contexts.commerce.domain.invariants import Order
from app.contexts.commerce.application.services.public_storefront import resolve_public_storefront

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/storefronts", tags=["public-storefront"])

@router.get("/{slug}/products")
async def public_products(slug: str, db: AsyncSession = Depends(get_db)):
    tenant = (await resolve_public_storefront(db, slug)).tenant
    products = (await db.execute(select(Product).where(Product.tenant_id == tenant.id, Product.published == True).order_by(Product.name))).scalars().all()
    return {"data": [_product_dict(p) for p in products]}

@router.get("/{slug}")
async def storefront(slug: str, db: AsyncSession = Depends(get_db)):
    tenant = (await resolve_public_storefront(db, slug)).tenant
    profile = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tenant.id, StorefrontProfile.published == True))).scalar_one_or_none()
    if profile is None:
        raise HTTPException(404, "Storefront is not published")
    products = (await db.execute(select(Product).where(Product.tenant_id == tenant.id, Product.published == True).order_by(Product.name))).scalars().all()
    return {"data": {"tenant_id": str(tenant.id), "slug": tenant.slug, "business_name": profile.business_name, "description": profile.description, "category": profile.category, "currency": profile.currency, "products": [_product_dict(p) for p in products]}}

