"""Aggregate router for the Commerce bounded context."""
from fastapi import APIRouter

from .storefront_routes import router as storefront_router
from .catalog_routes import router as catalog_router
from .inventory_routes import router as inventory_router
from .order_routes import router as order_router
from .dashboard_routes import router as dashboard_router
from .presentation_routes import router as presentation_router
from .merchant_payment_routes import router as merchant_payment_router
from .payment_config_routes import router as payment_config_router

router = APIRouter()
router.include_router(storefront_router)
router.include_router(catalog_router)
router.include_router(inventory_router)
router.include_router(order_router)
router.include_router(dashboard_router)
router.include_router(presentation_router)
router.include_router(merchant_payment_router)
router.include_router(payment_config_router)
