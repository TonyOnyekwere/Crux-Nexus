"""Commerce HTTP adapter."""
from __future__ import annotations

import hashlib
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.contexts.commerce.domain.models import OrderItem, Product
from app.contexts.commerce.domain.invariants import Order
from app.contexts.commerce.application.services.public_storefront import resolve_public_storefront

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/storefronts", tags=["public-storefront"])

@router.get("/{slug}/orders/{order_number}")
async def public_order(slug: str, order_number: str, request: Request, db: AsyncSession = Depends(get_db)):
    redis_client = getattr(request.app.state, "redis_client", None)
    if redis_client is not None:
        key = f"order-lookup:{request.client.host if request.client else 'unknown'}:{order_number}"
        count = await redis_client.incr(key)
        if count == 1:
            await redis_client.expire(key, 60)
        if count > 10:
            raise HTTPException(429, "Too many order lookup attempts")
    token = request.headers.get("X-Order-Access-Token")
    if not token:
        raise HTTPException(401, "X-Order-Access-Token header is required")
    tenant = (await resolve_public_storefront(db, slug)).tenant
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    result = await db.execute(
        select(Order).where(Order.tenant_id == tenant.id, Order.order_number == order_number, Order.access_token_hash == token_hash)
    )
    order = result.scalar_one_or_none()
    if order is None:
        raise HTTPException(404, "Order not found")
    items = (await db.execute(select(OrderItem).where(OrderItem.order_id == order.id))).scalars().all()
    return {"data": _order_dict(order, items)}

