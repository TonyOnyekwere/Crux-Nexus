"""Aggregate router for the Commerce bounded context."""
from fastapi import APIRouter

from .storefront_public_routes import router as storefront_public_router
from .cart_routes import router as cart_router
from .checkout_routes import router as checkout_router
from .order_public_routes import router as order_public_router
from .payment_routes import router as payment_router
from .presentation_routes import public_router as presentation_public_router

router = APIRouter()
router.include_router(storefront_public_router)
router.include_router(cart_router)
router.include_router(checkout_router)
router.include_router(order_public_router)
router.include_router(payment_router)
router.include_router(presentation_public_router)
