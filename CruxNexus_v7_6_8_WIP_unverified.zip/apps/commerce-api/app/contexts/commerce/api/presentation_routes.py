"""Merchant-owned storefront presentation, custom domain and payment connections.

All tier behaviour comes from the Control Center-synchronized plan via
app.kernel.access (capabilities + limits). Downgrade rule: configuration is
PRESERVED, further use is blocked, and it restores automatically when the
entitlement returns; the merchant may always REMOVE or DISABLE what they set.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.authorization import Permission, require_permission
from app.auth.jwt_handler import get_verified_tenant_context
from app.config import get_settings
from app.contexts.commerce.domain import presentation_rules as pr
from app.contexts.commerce.domain.models import StorefrontConfiguration
from app.database import get_db
from app.kernel.access import entitlement_policy as ep
from app.kernel.access.policy_loader import deny, load_policy_for_tenant

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce-presentation"])
public_router = APIRouter(prefix="/api/v1/storefronts", tags=["public-storefront"])


def _tid(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))


def _bad(exc: Exception, status: int = 422) -> HTTPException:
    return HTTPException(status, detail={"error": {"code": "INVALID_PRESENTATION", "message": str(exc), "details": {}}})


class PresentationUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    theme: Optional[dict] = None
    fonts: Optional[dict] = None
    layout: Optional[dict] = None
    component_slots: Optional[dict] = None
    custom_css: Optional[str] = None


class CustomDomainRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    domain: str


async def _get_config(db: AsyncSession, tid: UUID, *, lock: bool = False) -> Optional[StorefrontConfiguration]:
    q = select(StorefrontConfiguration).where(StorefrontConfiguration.tenant_id == tid)
    return (await db.execute(q.with_for_update() if lock else q)).scalar_one_or_none()


def _features(cfg: Optional[StorefrontConfiguration], policy, standing) -> dict:
    cfg_theme = bool(cfg and (cfg.theme or cfg.fonts or cfg.layout))
    return {
        pr.CAP_THEME: ep.feature_state(policy, standing, pr.CAP_THEME, configured=cfg_theme),
        pr.CAP_SLOTS: ep.feature_state(policy, standing, pr.CAP_SLOTS, configured=bool(cfg and cfg.component_slots)),
        pr.CAP_CSS: ep.feature_state(policy, standing, pr.CAP_CSS, configured=bool(cfg and cfg.custom_css)),
        pr.CAP_DOMAIN: ep.feature_state(policy, standing, pr.CAP_DOMAIN, configured=bool(cfg and cfg.custom_domain)),
    }


def _present(cfg: Optional[StorefrontConfiguration]) -> dict:
    return {
        "theme": (cfg.theme if cfg else {}) or {}, "fonts": (cfg.fonts if cfg else {}) or {},
        "layout": (cfg.layout if cfg else {}) or {}, "component_slots": (cfg.component_slots if cfg else {}) or {},
        "custom_css": cfg.custom_css if cfg else None,
        "custom_domain": cfg.custom_domain if cfg else None,
        "custom_domain_status": cfg.custom_domain_status if cfg else "none",
    }


@router.get("/storefront/presentation")
async def get_presentation(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.VIEW_DASHBOARD)
    tid = _tid(ctx)
    cfg = await _get_config(db, tid)
    policy, standing = await load_policy_for_tenant(db, tid)
    return {"data": {**_present(cfg), "feature_states": _features(cfg, policy, standing),
                     "limits": {k: policy.limit(k) for k in (pr.LIMIT_SLOTS, pr.LIMIT_CSS_BYTES, pr.LIMIT_PRODUCTS)}}}


@router.put("/storefront/presentation")
async def update_presentation(payload: PresentationUpdate, db: AsyncSession = Depends(get_db),
                              ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tid(ctx)
    policy, standing = await load_policy_for_tenant(db, tid)
    cfg = await _get_config(db, tid, lock=True)
    sent = payload.model_dump(exclude_unset=True)

    try:
        clean: dict = {}
        if "theme" in sent: clean["theme"] = pr.validate_theme(sent["theme"])
        if "fonts" in sent: clean["fonts"] = pr.validate_fonts(sent["fonts"])
        if "layout" in sent: clean["layout"] = pr.validate_layout(sent["layout"])
        if "component_slots" in sent: clean["component_slots"] = pr.validate_slots(sent["component_slots"])
        if "custom_css" in sent:
            css_cap = policy.limit(pr.LIMIT_CSS_BYTES)
            clean["custom_css"] = pr.validate_css(sent["custom_css"], max_bytes=css_cap)
    except pr.PresentationError as exc:
        raise _bad(exc)

    # Only parts that actually CHANGE need entitlement: a downgraded merchant can still
    # save the rest of their settings (their preserved customization is simply not re-submitted
    # as a change), and can always clear a feature (removal needs no entitlement).
    current = _present(cfg)
    changed = {k: v for k, v in clean.items() if v != current.get(k) and v not in (None, {}, "")}
    need = pr.required_capabilities(
        theme=changed.get("theme"), fonts=changed.get("fonts"), layout=changed.get("layout"),
        slots=changed.get("component_slots"), css=changed.get("custom_css"),
    )
    for capability in sorted(need):
        decision = ep.can_use_capability(policy, standing, capability, new_use=True)
        if not decision:
            raise deny(decision)
    if "component_slots" in changed:
        depth = ep.check_absolute_limit(policy, standing, pr.LIMIT_SLOTS, requested_total=len(changed["component_slots"]))
        if not depth:
            raise deny(depth)

    if cfg is None:
        cfg = StorefrontConfiguration(tenant_id=tid)
        db.add(cfg)
    for key, value in clean.items():
        setattr(cfg, key, value)
    await db.commit()
    return {"data": {**_present(cfg), "feature_states": _features(cfg, policy, standing)}}


@router.post("/storefront/custom-domain")
async def request_custom_domain(payload: CustomDomainRequest, db: AsyncSession = Depends(get_db),
                                ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tid(ctx)
    policy, standing = await load_policy_for_tenant(db, tid)
    decision = ep.can_use_capability(policy, standing, pr.CAP_DOMAIN, new_use=True)
    if not decision:
        raise deny(decision)
    # Domain count is per MERCHANT (all of its storefronts), against the plan limit (+ purchased add-ons).
    from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
    from app.kernel.access.policy_loader import merchant_id_for_tenant
    merchant_id = await merchant_id_for_tenant(db, tid)
    in_use = await db.scalar(
        select(func.count()).select_from(StorefrontConfiguration)
        .join(MerchantAccountTenant, MerchantAccountTenant.tenant_id == StorefrontConfiguration.tenant_id)
        .where(MerchantAccountTenant.merchant_account_id == merchant_id,
               StorefrontConfiguration.custom_domain.is_not(None), StorefrontConfiguration.tenant_id != tid)
    )
    limit_decision = ep.can_consume_limit(policy, standing, pr.LIMIT_DOMAINS, current=int(in_use or 0))
    if not limit_decision:
        raise deny(limit_decision)
    platform = tuple(d for d in (getattr(get_settings(), "PLATFORM_DOMAIN", None),) if d)
    try:
        host = pr.normalize_hostname(payload.domain, platform_domains=platform)
    except pr.PresentationError as exc:
        raise _bad(exc)
    cfg = await _get_config(db, tid, lock=True)
    if cfg is None:
        cfg = StorefrontConfiguration(tenant_id=tid)
        db.add(cfg)
    cfg.custom_domain = host
    cfg.custom_domain_status = "pending"  # only the (not yet built) DNS verification flow may set 'verified'
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, detail={"error": {"code": "DOMAIN_IN_USE", "message": "That domain is already connected to another storefront.", "details": {}}})
    return {"data": {"custom_domain": host, "custom_domain_status": "pending",
                     "note": "Domain verification is not yet available; the domain will not serve traffic until verified."}}


@router.delete("/storefront/custom-domain")
async def remove_custom_domain(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    """Always allowed, whatever the tier: a merchant can always remove what they configured."""
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    cfg = await _get_config(db, _tid(ctx), lock=True)
    if cfg is not None:
        cfg.custom_domain, cfg.custom_domain_status = None, "none"
        await db.commit()
    return {"data": {"custom_domain": None, "custom_domain_status": "none"}}


# ---- retired payment-connection metadata routes
# These recorded provider "intent" without credentials and could set a connection state independently of
# the verified credential flow. Superseded by: PUT/DELETE /payment-connections/{provider}/credentials
# (verified connection), PUT /payment-connections/{provider}/availability (merchant switch) and
# GET/PUT /payment-methods/config (everything the merchant configures about payments).
def _retired(replacement: str) -> HTTPException:
    return HTTPException(410, detail={"error": {"code": "ROUTE_RETIRED",
        "message": "This endpoint has been retired and no longer does anything.", "details": {"use": replacement}}})


@router.get("/payment-connections")
async def retired_list_payment_connections(ctx: dict = Depends(get_verified_tenant_context)):
    raise _retired("/api/v1/commerce/payment-methods/config")


@router.put("/payment-connections/{provider}")
async def retired_upsert_payment_connection(provider: str, ctx: dict = Depends(get_verified_tenant_context)):
    raise _retired(f"/api/v1/commerce/payment-connections/{provider}/credentials")


@router.post("/payment-connections/{provider}/disable")
async def retired_disable_payment_connection(provider: str, ctx: dict = Depends(get_verified_tenant_context)):
    raise _retired(f"/api/v1/commerce/payment-connections/{provider}/availability")


# ---- public: only what the merchant is CURRENTLY entitled to render
@public_router.get("/{slug}/presentation")
async def public_presentation(slug: str, db: AsyncSession = Depends(get_db)):
    # Same single public boundary as every other storefront endpoint (active tenant, published, entitled).
    from app.contexts.commerce.application.services.public_storefront import resolve_public_storefront
    tenant = (await resolve_public_storefront(db, slug)).tenant
    cfg = await _get_config(db, tenant.id)
    policy, standing = await load_policy_for_tenant(db, tenant.id)
    states = _features(cfg, policy, standing)
    live = lambda cap: states[cap] in ep.RENDERING_STATES  # noqa: E731
    return {"data": {
        # Preserved-but-not-entitled customization stays in the database and is simply not rendered.
        "theme": (cfg.theme if cfg and live(pr.CAP_THEME) else {}) or {},
        "fonts": (cfg.fonts if cfg and live(pr.CAP_THEME) else {}) or {},
        "layout": (cfg.layout if cfg and live(pr.CAP_THEME) else {}) or {},
        "component_slots": (cfg.component_slots if cfg and live(pr.CAP_SLOTS) else {}) or {},
        "custom_css": cfg.custom_css if cfg and live(pr.CAP_CSS) else None,
    }}
