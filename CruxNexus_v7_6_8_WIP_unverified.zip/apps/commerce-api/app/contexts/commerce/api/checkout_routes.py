"""Commerce HTTP adapter."""
from __future__ import annotations
import logging

import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
import secrets
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.config import get_settings
from app.infrastructure.payments.adapter import ProviderOutcomeUnknownError, ProviderRejectedError
from app.contexts.billing.domain.provider_registry import ProviderRegistryEntry
from app.contexts.commerce.domain.models import (
    Cart,
    CartItem,
    CommerceCheckoutIdempotency,
    CommercePayment,
    Customer,
    Fulfillment,
    InventoryMovement,
    OrderItem,
    Product,
    StorefrontProfile,
)
from app.contexts.commerce.api.schemas import CheckoutRequest
from app.contexts.commerce.domain.invariants import Order, server_delivery_fee, transition_order
from app.contexts.commerce.application.services.payment import _release_order_reservation
logger=logging.getLogger(__name__)

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

from app.contexts.commerce.application.services.checkout_recovery import order_dict as _order_dict  # noqa: E402
from app.contexts.commerce.application.services.public_storefront import resolve_public_storefront
from app.infrastructure.rate_limiter import key_ip, key_ip_slug, limiter

router = APIRouter(prefix="/api/v1/storefronts", tags=["public-storefront"])

@router.post("/{slug}/checkout", status_code=201)
@limiter.limit("30/minute", key_func=key_ip_slug)
@limiter.limit("120/minute", key_func=key_ip)
async def checkout(slug: str, payload: CheckoutRequest, request: Request, db: AsyncSession = Depends(get_db)):
    tenant = (await resolve_public_storefront(db, slug)).tenant
    idempotency_key = request.headers.get("Idempotency-Key")
    if not idempotency_key:
        raise HTTPException(428, "Idempotency-Key header is required for checkout")
    fingerprint_payload = payload.model_dump(mode="json")
    fingerprint = hashlib.sha256(json.dumps(fingerprint_payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    idem = CommerceCheckoutIdempotency(tenant_id=tenant.id, idempotency_key=idempotency_key, request_fingerprint=fingerprint, status="processing", processing_since=datetime.now(timezone.utc))
    db.add(idem)
    try:
        await db.flush()
    except IntegrityError:
        # ONLY a duplicate key is an idempotent replay. Any other failure (RLS, permissions, schema) is a
        # real fault and must surface; the previous blanket `except Exception` hid those as "duplicates".
        await db.rollback()
        await db.execute(text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"), {"tenant_id": str(tenant.id)})
        idem = (await db.execute(select(CommerceCheckoutIdempotency).where(CommerceCheckoutIdempotency.tenant_id==tenant.id, CommerceCheckoutIdempotency.idempotency_key==idempotency_key).with_for_update())).scalar_one_or_none()
        if idem is None:
            raise HTTPException(409, "Checkout idempotency claim could not be established")
        if idem.request_fingerprint != fingerprint:
            raise HTTPException(409, "Idempotency-Key was already used with different checkout parameters")
        if idem.status == "completed" and idem.response_payload is not None:
            return {"data": idem.response_payload}
        if idem.status == "failed":
            raise HTTPException(409, "The previous attempt with this Idempotency-Key did not complete; retry with a new key")
        from app.contexts.commerce.application.services import checkout_recovery as _recovery
        if _recovery.lease_expired(idem.processing_since):
            # The original request died after committing the order. Rebuild its response from durable state.
            outcome = await _recovery.recover_expired_claim(db, idem)
            await db.commit()
            if outcome == "completed":
                return {"data": idem.response_payload}
            raise HTTPException(409, "The previous attempt with this Idempotency-Key did not complete; retry with a new key")
        raise HTTPException(409, "This checkout request is already being processed")
    cart_token = request.headers.get("X-Cart-Token")
    if not cart_token:
        raise HTTPException(400, "X-Cart-Token header is required")
    # Merchant-configured methods: the merchant decides what their storefront offers; platform governance may
    # additionally disable a provider. Online providers need the merchant's OWN verified connection (the
    # CruxNexus subscription channel is never a customer gateway). Checked before any stock is reserved.
    from app.contexts.commerce.application.services import merchant_payments as _mp
    from app.contexts.commerce.domain import payment_methods as pm
    profile = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tenant.id))).scalar_one_or_none()
    if profile is None:
        raise HTTPException(409, "This store is not configured")
    connected = await _mp.connected_providers(db, tenant.id)
    platform_enabled = set((await db.execute(select(ProviderRegistryEntry.provider_type).where(ProviderRegistryEntry.enabled.is_(True)))).scalars().all())
    allowed, why = pm.method_availability(
        method=payload.payment_method, pod_enabled=profile.pod_enabled, bank_transfer_enabled=profile.bank_transfer_enabled,
        bank_transfer_details=profile.bank_transfer_details, connected_providers=connected, platform_enabled_providers=platform_enabled)
    if not allowed:
        raise HTTPException(409, detail={"error": {"code": why, "message": "That payment method is not available at this store. Choose another.", "details": {}}})
    if payload.payment_method in ("paystack", "flutterwave") and not payload.customer_email:
        raise HTTPException(422, "An email address is required for online card payment")
    fulfillment_method = payload.fulfillment_method
    if fulfillment_method == "delivery" and not profile.delivery_enabled:
        raise HTTPException(409, detail={"error": {"code": "FULFILLMENT_METHOD_NOT_ENABLED", "message": "This store does not offer delivery.", "details": {}}})
    if fulfillment_method == "pickup" and not profile.pickup_enabled:
        raise HTTPException(409, detail={"error": {"code": "FULFILLMENT_METHOD_NOT_ENABLED", "message": "This store does not offer pickup.", "details": {}}})
    if fulfillment_method == "delivery" and not (payload.delivery_address or "").strip():
        raise HTTPException(422, "A delivery address is required for delivery")
    merchant_connection = merchant_credential = None
    if payload.payment_method in ("paystack", "flutterwave"):
        merchant_connection = await _mp.get_connected_connection(db, tenant.id, payload.payment_method)
        merchant_credential = await _mp.active_credential(db, merchant_connection) if merchant_connection is not None else None
        if merchant_connection is None or merchant_credential is None:
            raise HTTPException(409, detail={"error": {"code": "PAYMENT_PROVIDER_NOT_CONNECTED",
                "message": "This store has not connected that payment provider. Choose another payment method.", "details": {}}})
    cart = (await db.execute(select(Cart).where(Cart.token == cart_token, Cart.tenant_id == tenant.id, Cart.status == "open").with_for_update())).scalar_one_or_none()
    if cart is None:
        raise HTTPException(404, "Cart not found")
    rows = (await db.execute(select(CartItem, Product).join(Product, Product.id == CartItem.product_id).where(CartItem.cart_id == cart.id).order_by(Product.id).with_for_update(of=Product))).all()
    if not rows:
        raise HTTPException(400, "Cart is empty")
    # Currency authority (NGN/GHS/KES/ZAR, one per storefront): the storefront's currency prices the whole
    # order. A cart containing anything else is rejected, never converted or mixed.
    from app.contexts.commerce.domain.currency_rules import CurrencyError, assert_single_currency_cart
    store_currency = profile.currency
    try:
        assert_single_currency_cart(store_currency, [product.currency for _, product in rows])
    except CurrencyError as exc:
        raise HTTPException(409, detail={"error": {"code": exc.code, "message": exc.message, "details": {}}})
    subtotal = Decimal("0")
    for ci, product in rows:
        available = product.stock - product.reserved_stock
        if ci.quantity > available:
            raise HTTPException(409, f"Insufficient stock for {product.name}")
        subtotal += Decimal(product.price) * ci.quantity
    delivery_fee = server_delivery_fee(tenant, payload)
    total = subtotal + delivery_fee
    customer = (await db.execute(select(Customer).where(Customer.tenant_id == tenant.id, Customer.phone == payload.customer_phone).with_for_update())).scalar_one_or_none()
    if customer is None:
        customer = Customer(tenant_id=tenant.id, name=payload.customer_name, phone=payload.customer_phone, email=payload.customer_email)
        db.add(customer)
        await db.flush()
    else:
        customer.name = payload.customer_name
        customer.email = payload.customer_email
    initial_status, initial_payment_status = pm.initial_order_state(payload.payment_method)
    now = datetime.now(timezone.utc)
    deadline = pm.reservation_deadline(payload.payment_method, now, bank_window_hours=profile.bank_transfer_window_hours)
    order_access_token = secrets.token_urlsafe(32)
    order = Order(tenant_id=tenant.id, customer_id=customer.id, order_number="CNX-" + secrets.token_hex(5).upper(), status=initial_status, payment_status=initial_payment_status, subtotal=subtotal, delivery_fee=delivery_fee, total=total, currency=store_currency, fulfillment_method=fulfillment_method, delivery_address=(payload.delivery_address if fulfillment_method == "delivery" else None), notes=payload.notes, access_token_hash=hashlib.sha256(order_access_token.encode()).hexdigest(), reservation_expires_at=deadline)
    db.add(order)
    await db.flush()
    idem.order_id = order.id   # recovery link: lets a crashed request be completed from durable state
    for ci, product in rows:
        product.reserved_stock += ci.quantity
        db.add(InventoryMovement(tenant_id=tenant.id, product_id=product.id, reserved_delta=ci.quantity, reason="order_reserved", reference=order.order_number))
        db.add(OrderItem(tenant_id=tenant.id, order_id=order.id, product_id=product.id, product_name=product.name, sku=product.sku, quantity=ci.quantity, unit_price=product.price, line_total=Decimal(product.price) * ci.quantity))
    cart.status = "converted"
    db.add(Fulfillment(tenant_id=tenant.id, order_id=order.id, status="unfulfilled"))
    payment = None
    if payload.payment_method == "pay_on_delivery":
        order.payment_status = "pending"
        transition_order(order, "confirmed")
        payment = CommercePayment(tenant_id=tenant.id, order_id=order.id, reference="CNX-ORD-" + secrets.token_hex(8).upper(), provider="pay_on_delivery", amount=total, currency=store_currency, status="pending")
    elif payload.payment_method == "bank_transfer":
        order.status = "awaiting_transfer"
        payment = CommercePayment(tenant_id=tenant.id, order_id=order.id, reference="CNX-ORD-" + secrets.token_hex(8).upper(), provider="bank_transfer", amount=total, currency=store_currency, status="pending")
    else:
        # Provider initialization is intentionally a real adapter boundary. If
        # credentials are absent the order remains durable and payment pending.
        payment = CommercePayment(tenant_id=tenant.id, order_id=order.id, reference="CNX-ORD-" + secrets.token_hex(8).upper(), provider=payload.payment_method, amount=total, currency=store_currency, status="pending", connection_id=merchant_connection.id, credential_id=merchant_credential.id)
        order.status = "pending_payment"
    db.add(payment)
    await db.commit()
    # SET LOCAL RLS context expires at commit. Re-establish it for every
    # post-commit operation in this request before touching Commerce rows.
    await db.execute(text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"), {"tenant_id": str(tenant.id)})

    # Online providers are initialized only after the local order/payment
    # identity is durable. A provider timeout therefore leaves a recoverable
    # PENDING commerce payment rather than losing the order.
    if payload.payment_method in ("paystack", "flutterwave"):
        from app.contexts.commerce.application.services import merchant_payments as _mp
        from app.infrastructure.secrets.credential_vault import VaultDecryptionError, VaultNotConfigured
        try:
            try:
                adapter = await _mp.build_adapter(db, merchant_connection, merchant_credential.id)
            except (VaultNotConfigured, VaultDecryptionError):
                # Nothing was sent to any provider, so no charge can exist: a definitive failure.
                raise ProviderRejectedError("Merchant payment credentials are unavailable")
            settings = get_settings()
            redirect_url = f"{settings.PUBLIC_APP_URL.rstrip('/')}/storefront/{slug}/orders/{order.order_number}"
            initialized = await adapter.initialize_charge(
                reference=payment.reference,
                amount=total,
                currency=store_currency,
                merchant_email=payload.customer_email,
                redirect_url=redirect_url,
            )
            payment.provider_reference = initialized.provider_reference
            payment.authorization_url = initialized.redirect_url
            await db.commit()
            await db.execute(text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"), {"tenant_id": str(tenant.id)})
        except ProviderRejectedError:
            payment.status = "failed"
            order.payment_status = "failed"
            if order.status in {"pending_payment", "awaiting_transfer"}:
                transition_order(order, "payment_failed")
            await _release_order_reservation(db, order, "payment_rejected")
            await db.commit()
        except ProviderOutcomeUnknownError:
            # Leave payment/order pending. Reconciliation/webhook can resolve it.
            pass
        except Exception as exc:
            logger.exception("Commerce payment initialization outcome UNKNOWN for %s", payment.reference)
            # Once an external request may have left the process, a generic
            # exception cannot prove that the provider rejected the charge.
            # Keep the durable payment pending and let webhook/reconciliation
            # establish the terminal state.
            payment.status = "pending"
            order.payment_status = "pending"
            await db.commit()

    response_payload = {"order": _order_dict(order, [x for x, _ in rows]), "order_access_token": None, "payment": {"reference": payment.reference, "provider": payment.provider, "status": payment.status, "authorization_url": payment.authorization_url}}
    if payload.payment_method == "bank_transfer":
        response_payload["payment"]["bank_transfer"] = {**(profile.bank_transfer_details or {}), "pay_before": order.reservation_expires_at.isoformat() if order.reservation_expires_at else None, "reference": order.order_number}
    idem.response_payload = response_payload
    idem.status = "completed"
    idem.completed_at = datetime.now(timezone.utc)
    await db.commit()
    # The access token is a bearer credential: shown once, to this caller only, and never persisted.
    return {"data": {**response_payload, "order_access_token": order_access_token}}

