"""Commerce HTTP adapter."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_verified_tenant_context
from app.auth.authorization import Permission, require_permission
from app.database import get_db
from app.contexts.commerce.domain.models import InventoryMovement, OrderItem, Product, StorefrontProfile
from app.contexts.commerce.api.schemas import ProductCreate, ProductPatch
from app.contexts.commerce.domain.invariants import Order

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce"])

@router.post("/products", status_code=201)
async def create_product(payload: ProductCreate, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_PRODUCTS)
    tid = _tenant_id(ctx)
    exists = (await db.execute(select(Product).where(Product.tenant_id == tid, (Product.sku == payload.sku) | (Product.slug == payload.slug)))).scalar_one_or_none()
    if exists:
        raise HTTPException(409, "A product with this SKU or slug already exists")
    # Tier limit (Control Center data). Existing products are never touched by a downgrade;
    # being over the limit only blocks creating MORE.
    from app.kernel.access.entitlement_policy import can_consume_limit
    from app.kernel.access.policy_loader import deny, load_policy_for_tenant
    from app.contexts.commerce.domain.presentation_rules import LIMIT_PRODUCTS
    policy, standing = await load_policy_for_tenant(db, tid)
    current_products = await db.scalar(select(func.count()).select_from(Product).where(Product.tenant_id == tid))
    decision = can_consume_limit(policy, standing, LIMIT_PRODUCTS, current=int(current_products or 0))
    if not decision:
        raise deny(decision)
    # Currency authority: a product is priced in its storefront's single currency (set here, never by the client).
    profile = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tid))).scalar_one_or_none()
    if profile is None:
        raise HTTPException(409, detail={"error": {"code": "STOREFRONT_NOT_CONFIGURED", "message": "Set up your storefront (including its currency) before adding products.", "details": {}}})
    p = Product(tenant_id=tid, currency=profile.currency, **payload.model_dump())
    db.add(p)
    await db.flush()
    if p.stock:
        db.add(InventoryMovement(tenant_id=tid, product_id=p.id, quantity_delta=p.stock, reason="initial_stock"))
    await db.commit()
    await db.refresh(p)
    return {"data": _product_dict(p)}

@router.patch("/products/{product_id}")
async def patch_product(product_id: UUID, payload: ProductPatch, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_PRODUCTS)
    tid = _tenant_id(ctx)
    p = (await db.execute(select(Product).where(Product.id == product_id, Product.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if p is None:
        raise HTTPException(404, "Product not found")
    for k, v in payload.model_dump(exclude_unset=True).items():
        if k in {"stock"}:
            raise HTTPException(400, "Stock changes must use the inventory adjustment endpoint")
        setattr(p, k, v)
    await db.commit()
    return {"data": _product_dict(p)}

@router.get("/products")
async def list_products(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    tid = _tenant_id(ctx)
    rows = (await db.execute(select(Product).where(Product.tenant_id == tid).order_by(Product.created_at.desc()))).scalars().all()
    return {"data": [_product_dict(p) for p in rows]}

