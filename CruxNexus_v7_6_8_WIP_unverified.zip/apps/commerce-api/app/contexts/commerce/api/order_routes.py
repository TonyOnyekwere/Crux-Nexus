"""Commerce HTTP adapter."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_verified_tenant_context
from app.auth.authorization import Permission, require_permission
from app.database import get_db
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.commerce.domain.models import (
    CommercePayment,
    Fulfillment,
    InventoryMovement,
    OrderItem,
    Product,
)
from app.contexts.commerce.api.schemas import FulfillmentUpdate
from app.contexts.commerce.domain.invariants import Order, transition_order

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce"])

@router.get("/orders/{order_id}")
async def merchant_order(order_id: UUID, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    tid = _tenant_id(ctx)
    o = (await db.execute(select(Order).where(Order.id == order_id, Order.tenant_id == tid))).scalar_one_or_none()
    if o is None:
        raise HTTPException(404, "Order not found")
    items = (await db.execute(select(OrderItem).where(OrderItem.order_id == o.id))).scalars().all()
    return {"data": _order_dict(o, items)}

@router.post("/payments/{reference}/confirm-bank-transfer")
async def confirm_bank_transfer(reference: str, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_ORDERS)
    tid = _tenant_id(ctx)
    payment = (await db.execute(select(CommercePayment).where(CommercePayment.reference == reference, CommercePayment.tenant_id == tid, CommercePayment.provider == "bank_transfer").with_for_update())).scalar_one_or_none()
    if payment is None:
        raise HTTPException(404, "Bank-transfer payment not found")
    if payment.status == "successful":
        return {"data": {"reference": payment.reference, "status": payment.status}}
    order = (await db.execute(select(Order).where(Order.id == payment.order_id, Order.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if order is None:
        raise HTTPException(404, "Order not found")
    merchant_id = await db.scalar(
        select(MerchantAccountTenant.merchant_account_id).where(
            MerchantAccountTenant.tenant_id == tid
        )
    )
    if merchant_id is None:
        raise HTTPException(403, "Storefront is not owned by a merchant account")
    from app.kernel.access.resolver import MerchantAccessResolver
    access = await MerchantAccessResolver(db).can_process_orders(merchant_id, tid)
    if not access.allowed:
        raise HTTPException(403, access.reason)
    from app.contexts.commerce.application.services.payment import apply_late_bank_transfer
    result = await apply_late_bank_transfer(db, order, payment)
    await db.commit()
    return {"data": {"reference": payment.reference, "order_number": order.order_number, "payment_status": payment.status,
                     "order_status": order.status, "outcome": result["outcome"], "requires_refund": result["requires_refund"]}}

@router.get("/orders")
async def merchant_orders(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    tid = _tenant_id(ctx)
    orders = (await db.execute(select(Order).where(Order.tenant_id == tid).order_by(Order.created_at.desc()))).scalars().all()
    result = []
    for o in orders:
        items = (await db.execute(select(OrderItem).where(OrderItem.order_id == o.id))).scalars().all()
        result.append(_order_dict(o, items))
    return {"data": result}

@router.patch("/orders/{order_id}/fulfillment")
async def update_fulfillment(order_id: UUID, payload: FulfillmentUpdate, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_ORDERS)
    tid = _tenant_id(ctx)
    o = (await db.execute(select(Order).where(Order.id == order_id, Order.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if o is None:
        raise HTTPException(404, "Order not found")
    merchant_id = await db.scalar(select(MerchantAccountTenant.merchant_account_id).where(MerchantAccountTenant.tenant_id == tid))
    if merchant_id is None:
        raise HTTPException(403, "Storefront is not owned by a merchant account")
    from app.kernel.access.resolver import MerchantAccessResolver
    access = await MerchantAccessResolver(db).can_process_orders(merchant_id, tid)
    if not access.allowed:
        raise HTTPException(403, access.reason)

    f = (await db.execute(select(Fulfillment).where(Fulfillment.order_id == o.id, Fulfillment.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if f is None:
        f = Fulfillment(tenant_id=tid, order_id=o.id, status="unfulfilled")
        db.add(f)
        await db.flush()
    # Latest payment attempt decides the gate; an order can legitimately have several
    # (retries), so a single-row lookup would raise MultipleResultsFound.
    payment = (await db.execute(
        select(CommercePayment)
        .where(CommercePayment.order_id == o.id, CommercePayment.tenant_id == tid)
        .order_by(CommercePayment.created_at.desc()).limit(1).with_for_update()
    )).scalar_one_or_none()
    if payment is None:
        raise HTTPException(409, "Order has no payment record")

    from app.contexts.commerce.application.services.payment import (
        _release_order_reservation,
        outstanding_reservation,
    )
    from app.contexts.commerce.domain.fulfillment_rules import (
        STOCK_COMMIT,
        STOCK_RELEASE,
        FulfillmentRuleError,
        plan_fulfillment_change,
    )

    try:
        plan = plan_fulfillment_change(
            order_status=o.status, payment_status=o.payment_status, payment_provider=payment.provider,
            fulfillment_status=f.status, target=payload.status,
        )
    except FulfillmentRuleError as exc:
        raise HTTPException(409, str(exc))

    if not plan.noop:
        if plan.stock_effect == STOCK_COMMIT:
            held = await outstanding_reservation(db, o)
            items = (await db.execute(
                select(OrderItem, Product).join(Product, Product.id == OrderItem.product_id)
                .where(OrderItem.order_id == o.id, OrderItem.tenant_id == tid)
                .order_by(Product.id).with_for_update(of=Product)
            )).all()
            for item, product in items:
                # Verify against THIS order's own reservation, not just aggregate counters.
                if held.get(product.id, 0) < item.quantity or product.reserved_stock < item.quantity or product.stock < item.quantity:
                    raise HTTPException(409, "Inventory changed and this order can no longer be fulfilled")
            for item, product in items:
                product.reserved_stock -= item.quantity
                product.stock -= item.quantity
                db.add(InventoryMovement(tenant_id=tid, product_id=product.id, quantity_delta=-item.quantity, reserved_delta=-item.quantity, reason="order_fulfilled", reference=o.order_number))
        elif plan.stock_effect == STOCK_RELEASE:
            await _release_order_reservation(db, o, "order_cancelled")
        transition_order(o, plan.order_status)
        if plan.order_status == "cancelled":
            o.cancellation_reason = "merchant"
        f.status = plan.fulfillment_status
        o.fulfillment_status = plan.fulfillment_status
        o.reservation_expires_at = None
        if plan.mark_pod_paid:
            payment.status = "successful"
            o.payment_status = "paid"
        if plan.flag_refund:
            payment.requires_refund = True  # money was collected; refund is a provider-side action

    # Carrier / tracking / notes are details and apply on every call (including a same-status call).
    for k, v in payload.model_dump(exclude_unset=True, exclude={"status"}).items():
        setattr(f, k, v)
    await db.commit()
    return {"data": {"order_id": str(o.id), "order_status": o.status, "fulfillment_status": f.status, "payment_status": o.payment_status, "requires_refund": bool(payment.requires_refund), "carrier": f.carrier, "tracking_number": f.tracking_number}}


@router.post("/orders/{order_id}/complete")
async def complete_order(order_id: UUID, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_ORDERS)
    tid = _tenant_id(ctx)
    o = (await db.execute(select(Order).where(Order.id == order_id, Order.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if o is None:
        raise HTTPException(404, "Order not found")
    if o.status != "delivered" or o.fulfillment_status != "delivered":
        raise HTTPException(409, "Only a delivered order can be completed")
    transition_order(o, "completed")
    await db.commit()
    return {"data": {"order_id": str(o.id), "order_status": o.status, "fulfillment_status": o.fulfillment_status}}
