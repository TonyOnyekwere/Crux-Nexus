"""Commerce HTTP adapter."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_verified_tenant_context
from app.auth.authorization import Permission, require_permission
from app.database import get_db
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.commerce.domain.models import OrderItem, Product, StorefrontProfile
from app.contexts.commerce.api.schemas import StorefrontUpsert
from app.contexts.commerce.domain.invariants import Order

def _tenant_id(ctx: dict) -> UUID:
    return UUID(str(ctx["tenant_id"]))

def _product_dict(p: Product) -> dict:
    return {"id": str(p.id), "name": p.name, "slug": p.slug, "description": p.description, "sku": p.sku, "price": str(p.price), "currency": p.currency, "stock": p.stock, "available_stock": p.stock - p.reserved_stock, "published": p.published}

def _order_dict(o: Order, items: list[OrderItem]) -> dict:
    return {"id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status, "fulfillment_status": o.fulfillment_status, "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total), "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(), "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items]}

router = APIRouter(prefix="/api/v1/commerce", tags=["commerce"])

@router.put("/storefront")
async def upsert_storefront(payload: StorefrontUpsert, db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tenant_id(ctx)
    row = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tid).with_for_update())).scalar_one_or_none()
    from app.contexts.commerce.domain.currency_rules import CurrencyError, check_currency_change, normalize_currency
    sent = payload.model_dump(exclude_unset=True)
    if row is None:
        row = StorefrontProfile(tenant_id=tid, **{**payload.model_dump(exclude={"currency"}), "currency": normalize_currency(payload.currency)})
        db.add(row)
    else:
        requested = normalize_currency(sent["currency"]) if sent.get("currency") else row.currency
        product_count = await db.scalar(select(func.count()).select_from(Product).where(Product.tenant_id == tid))
        order_count = await db.scalar(select(func.count()).select_from(Order).where(Order.tenant_id == tid))
        try:
            check_currency_change(current=row.currency, requested=requested, product_count=int(product_count or 0), order_count=int(order_count or 0))
        except CurrencyError as exc:
            raise HTTPException(409, detail={"error": {"code": exc.code, "message": exc.message, "details": {}}})
        for key, value in sent.items():
            if key != "currency":
                setattr(row, key, value)
        row.currency = requested
    await db.commit()
    return {"data": {"id": str(row.id), "tenant_id": str(tid), "business_name": row.business_name, "published": row.published}}

@router.post("/storefront/publish")
async def publish_storefront(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tenant_id(ctx)
    row = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if row is None:
        raise HTTPException(404, "Storefront profile not configured")
    merchant_id = await db.scalar(
        select(MerchantAccountTenant.merchant_account_id).where(
            MerchantAccountTenant.tenant_id == tid
        )
    )
    if merchant_id is None:
        raise HTTPException(403, "Storefront is not owned by a merchant account")
    from app.kernel.access.resolver import MerchantAccessResolver
    access = await MerchantAccessResolver(db).can_publish_store(merchant_id, tid)
    if not access.allowed:
        raise HTTPException(409, access.reason)
    # Publication readiness is enforced here, once: the public boundary relies on `published` meaning "ready".
    from app.contexts.commerce.application.services.storefront_readiness import storefront_readiness
    problems = await storefront_readiness(db, tid, row)
    if problems:
        raise HTTPException(409, detail={"error": {"code": "STOREFRONT_NOT_READY", "message": "Your storefront is not ready to publish yet.", "details": {"problems": problems}}})
    row.published = True
    await db.commit()
    return {"data": {"published": True, "tenant_id": str(tid)}}


@router.post("/storefront/unpublish")
async def unpublish_storefront(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    """Taking a store offline is always allowed; nothing is deleted."""
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tenant_id(ctx)
    row = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tid).with_for_update())).scalar_one_or_none()
    if row is None:
        raise HTTPException(404, "Storefront profile not configured")
    row.published = False
    await db.commit()
    return {"data": {"published": False, "tenant_id": str(tid)}}


@router.get("/storefront/readiness")
async def storefront_publication_readiness(db: AsyncSession = Depends(get_db), ctx: dict = Depends(get_verified_tenant_context)):
    require_permission(ctx, Permission.MANAGE_STORE_SETTINGS)
    tid = _tenant_id(ctx)
    row = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tid))).scalar_one_or_none()
    if row is None:
        raise HTTPException(404, "Storefront profile not configured")
    from app.contexts.commerce.application.services.storefront_readiness import storefront_readiness
    problems = await storefront_readiness(db, tid, row)
    return {"data": {"ready": not problems, "published": row.published, "problems": problems}}



def _retired(replacement: str) -> HTTPException:
    return HTTPException(410, detail={"error": {"code": "ROUTE_RETIRED",
        "message": "This endpoint has been retired and no longer does anything.",
        "details": {"use": replacement}}})


@router.put("/storefront/configuration")
@router.get("/storefront/configuration")
async def retired_storefront_configuration(ctx: dict = Depends(get_verified_tenant_context)):
    """Retired: it wrote theme/fonts/layout/CSS/domain WITHOUT the tier entitlement checks. The single,
    policy-aware authority is PUT/GET /api/v1/commerce/storefront/presentation (custom domain:
    POST /api/v1/commerce/storefront/custom-domain)."""
    raise _retired("/api/v1/commerce/storefront/presentation")
