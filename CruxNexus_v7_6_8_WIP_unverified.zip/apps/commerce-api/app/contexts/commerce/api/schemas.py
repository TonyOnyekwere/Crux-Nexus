"""Commerce HTTP schemas."""
from __future__ import annotations
from decimal import Decimal
from uuid import UUID
from pydantic import field_validator, BaseModel, ConfigDict, Field

class StorefrontUpsert(BaseModel):
    model_config = ConfigDict(extra="forbid")
    business_name: str = Field(min_length=2, max_length=160)
    description: str | None = None
    category: str | None = None
    phone: str | None = None
    city: str | None = None
    address: str | None = None
    # Single currency per storefront (NGN, GHS, KES, ZAR). Unset means "leave as is" on update and the
    # default (NGN) on creation; it must never be silently reset by an unrelated profile edit.
    currency: str | None = Field(default=None, min_length=3, max_length=3)

    @field_validator("currency")
    @classmethod
    def _supported_currency(cls, value):
        if value is None:
            return value
        from app.contexts.commerce.domain.currency_rules import CurrencyError, normalize_currency
        try:
            return normalize_currency(value)
        except CurrencyError as exc:
            raise ValueError(exc.message)

class ProductCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1, max_length=180)
    slug: str = Field(min_length=1, max_length=180)
    description: str | None = None
    sku: str = Field(min_length=1, max_length=80)
    price: Decimal = Field(ge=0)
    # No currency field: a product is priced in its storefront's single currency, set by the server.
    stock: int = Field(default=0, ge=0)
    published: bool = False

class ProductPatch(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = Field(default=None, min_length=1, max_length=180)
    description: str | None = None
    price: Decimal | None = Field(default=None, ge=0)
    published: bool | None = None

class CartCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

class CartItemInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    product_id: UUID
    quantity: int = Field(gt=0, le=1000)

class CheckoutRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    customer_name: str = Field(min_length=2, max_length=160)
    customer_phone: str = Field(min_length=5, max_length=30)
    customer_email: str | None = None
    # How the customer receives the order. Which methods exist is the merchant's decision (see storefront
    # delivery_enabled / pickup_enabled); a delivery address is required only for delivery.
    fulfillment_method: str = Field(default="delivery", pattern="^(delivery|pickup)$")
    delivery_address: str | None = Field(default=None, min_length=5, max_length=1000)
    payment_method: str = Field(pattern="^(pay_on_delivery|bank_transfer|paystack|flutterwave)$")
    notes: str | None = None

class InventoryAdjustment(BaseModel):
    model_config = ConfigDict(extra="forbid")
    quantity_delta: int
    reason: str = Field(min_length=2, max_length=120)


class FulfillmentUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: str = Field(pattern="^(unfulfilled|processing|shipped|delivered|cancelled)$")
    carrier: str | None = None
    tracking_number: str | None = None
    notes: str | None = None


# ------------------------------- Helpers --------------------------------

