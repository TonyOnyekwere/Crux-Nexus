"""Merchant-owned payment connections: storing sealed credentials, verifying them with the
provider, and building a provider adapter FROM THE MERCHANT'S OWN credentials.

This module is the ONLY place a customer-checkout adapter is constructed. It never touches the
CruxNexus-owned (subscription) provider registry, so the subscription channel can never serve as
a customer gateway.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

import uuid

from sqlalchemy import delete, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.contexts.commerce.domain import merchant_payment_rules as rules
from app.contexts.commerce.domain.models import (
    MerchantPaymentConnection,
    MerchantPaymentCredential,
    PaymentWebhookRoute,
)
from app.contexts.commerce.application.services.payment import apply_commerce_payment_verification
from app.contexts.commerce.domain.models import CommercePayment, MerchantPaymentEvent
from app.infrastructure.payments.adapter import (
    PaymentProviderAdapter,
    ProviderOutcomeUnknownError,
    ProviderRejectedError,
    ProviderTransactionNotFoundError,
    is_in_flight,
)
from app.infrastructure.payments.flutterwave import FlutterwaveAdapter
from app.infrastructure.payments.paystack import PaystackAdapter
from app.infrastructure.secrets.credential_vault import (
    CredentialVault,
    SealedCredential,
    aad_for_revision,
    VaultDecryptionError,
    VaultNotConfigured,
    vault_from_settings,
)

logger = logging.getLogger(__name__)


def get_vault() -> CredentialVault:
    return vault_from_settings(get_settings())  # raises VaultNotConfigured -> callers fail closed


def adapter_from_secrets(provider: str, secrets: dict) -> PaymentProviderAdapter:
    if provider == "paystack":
        return PaystackAdapter(secrets["secret_key"])
    if provider == "flutterwave":
        return FlutterwaveAdapter(secrets["secret_key"], secrets.get("webhook_secret_hash"))
    raise ValueError(f"Unsupported merchant payment provider '{provider}'")


async def bind_tenant_context(db: AsyncSession, tenant_id: UUID) -> None:
    """Transaction-local RLS context; must be re-issued after every commit."""
    await db.execute(text("SELECT set_config('app.current_tenant_id', :t, true)"), {"t": str(tenant_id)})


async def connected_providers(db: AsyncSession, tenant_id: UUID) -> set:
    rows = (await db.execute(
        select(MerchantPaymentConnection.provider).where(
            MerchantPaymentConnection.tenant_id == tenant_id, MerchantPaymentConnection.status == "connected",
            MerchantPaymentConnection.enabled.is_(True))
    )).scalars().all()
    return set(rows)


async def get_connected_connection(db: AsyncSession, tenant_id: UUID, provider: str) -> Optional[MerchantPaymentConnection]:
    return (await db.execute(
        select(MerchantPaymentConnection).where(
            MerchantPaymentConnection.tenant_id == tenant_id,
            MerchantPaymentConnection.provider == provider,
            MerchantPaymentConnection.status == "connected",
            MerchantPaymentConnection.enabled.is_(True),
        )
    )).scalar_one_or_none()


async def active_credential(db: AsyncSession, connection: MerchantPaymentConnection) -> Optional[MerchantPaymentCredential]:
    return (await db.execute(select(MerchantPaymentCredential).where(
        MerchantPaymentCredential.connection_id == connection.id,
        MerchantPaymentCredential.tenant_id == connection.tenant_id,
        MerchantPaymentCredential.status == "active"))).scalar_one_or_none()


def _aad(credential: MerchantPaymentCredential, connection: MerchantPaymentConnection) -> bytes:
    if credential.aad_version == 1:  # rows sealed before revisions existed
        return CredentialVault.aad_for(connection.tenant_id, connection.id, connection.provider)
    return aad_for_revision(connection.tenant_id, connection.id, connection.provider, credential.id)


async def load_secrets(db: AsyncSession, connection: MerchantPaymentConnection, credential_id: Optional[UUID] = None,
                       vault: Optional[CredentialVault] = None) -> dict:
    """Decrypt ONE specific credential revision of this connection. With no id, the active revision.
    A payment must pass the revision it was initiated with; a purged revision cannot be opened."""
    vault = vault or get_vault()
    if credential_id is None:
        row = await active_credential(db, connection)
    else:
        row = (await db.execute(select(MerchantPaymentCredential).where(
            MerchantPaymentCredential.id == credential_id,
            MerchantPaymentCredential.connection_id == connection.id,
            MerchantPaymentCredential.tenant_id == connection.tenant_id))).scalar_one_or_none()
    if row is None:
        raise VaultDecryptionError("No such credential revision for this payment connection.")
    if row.status == "purged" or row.ciphertext is None or row.nonce is None:
        raise VaultDecryptionError("This credential revision has been purged.")
    return vault.open(SealedCredential(row.key_version, bytes(row.nonce), bytes(row.ciphertext)), aad=_aad(row, connection))


async def build_adapter(db: AsyncSession, connection: MerchantPaymentConnection, credential_id: Optional[UUID] = None,
                        vault: Optional[CredentialVault] = None) -> PaymentProviderAdapter:
    return adapter_from_secrets(connection.provider, await load_secrets(db, connection, credential_id, vault))


async def connect_provider(db: AsyncSession, tenant_id: UUID, provider: str, payload: dict, *, vault: Optional[CredentialVault] = None) -> dict:
    """Add a NEW credential revision, prove it against the provider, and only then make it active.

    Credentials are never mutated: the previous revision keeps serving payments already initiated with
    it. A failed or inconclusive replacement never breaks a working connection. Status never becomes
    'connected' unless the PROVIDER accepted the credentials. Returns a secret-free summary."""
    settings = get_settings()
    clean, mode = rules.validate_credentials(
        provider, payload, allow_test_keys=(settings.ENVIRONMENT or "").lower() != "production")
    vault = vault or get_vault()
    provider = provider.lower()

    connection = (await db.execute(select(MerchantPaymentConnection).where(
        MerchantPaymentConnection.tenant_id == tenant_id, MerchantPaymentConnection.provider == provider
    ).with_for_update())).scalar_one_or_none()
    if connection is None:
        connection = MerchantPaymentConnection(tenant_id=tenant_id, provider=provider, status="pending")
        db.add(connection)
        await db.flush()

    # An unverified earlier attempt is superseded; it was never referenced by any payment.
    await db.execute(delete(MerchantPaymentCredential).where(
        MerchantPaymentCredential.connection_id == connection.id, MerchantPaymentCredential.status == "pending"))
    revisions = (await db.execute(select(MerchantPaymentCredential.revision).where(
        MerchantPaymentCredential.connection_id == connection.id))).scalars().all()
    number = rules.next_revision_number(list(revisions))
    credential_id = uuid.uuid4()
    sealed = vault.seal(clean, aad=aad_for_revision(tenant_id, connection.id, provider, credential_id))
    db.add(MerchantPaymentCredential(
        id=credential_id, tenant_id=tenant_id, connection_id=connection.id, provider=provider, revision=number,
        status="pending", aad_version=2, key_version=sealed.key_version, nonce=sealed.nonce, ciphertext=sealed.ciphertext))

    route = (await db.execute(select(PaymentWebhookRoute).where(PaymentWebhookRoute.connection_id == connection.id))).scalar_one_or_none()
    if route is None:
        route = PaymentWebhookRoute(webhook_token=rules.generate_webhook_token(), tenant_id=tenant_id, connection_id=connection.id)
        db.add(route)
    token, connection_id = route.webhook_token, connection.id
    configuration = {**(connection.configuration or {}), "mode": mode}
    connection.configuration = configuration
    await db.commit()  # the new revision is durable BEFORE any network call
    await bind_tenant_context(db, tenant_id)

    outcome, error = "pending", None
    try:
        await adapter_from_secrets(provider, clean).verify_credentials()
        outcome = "verified"
    except ProviderRejectedError:
        outcome, error = "rejected", "The provider rejected these credentials."
    except ProviderOutcomeUnknownError:
        outcome, error = "inconclusive", "The provider could not be reached to verify these credentials; try again."
    except NotImplementedError:
        outcome, error = "rejected", "Credential verification is not available for this provider."

    connection = (await db.execute(select(MerchantPaymentConnection).where(
        MerchantPaymentConnection.id == connection_id).with_for_update())).scalar_one()
    candidate = (await db.execute(select(MerchantPaymentCredential).where(
        MerchantPaymentCredential.id == credential_id))).scalar_one_or_none()
    highest = (await db.execute(select(func.max(MerchantPaymentCredential.revision)).where(
        MerchantPaymentCredential.connection_id == connection_id))).scalar_one_or_none() or 0
    still_current = candidate is not None and rules.may_activate(
        candidate_revision=candidate.revision, highest_revision=highest, candidate_status=candidate.status)

    if not still_current:
        # A newer replacement or a delete ran while we were talking to the provider: it wins, nothing changes.
        await db.commit()
        return {"provider": provider, "status": connection.status, "mode": mode, "superseded": True,
                "error": "Another change to this connection happened while verifying; please review and retry.",
                "webhook_path": rules.webhook_path(token)}

    if outcome == "verified":
        previous = await active_credential(db, connection)
        if previous is not None:
            previous.status, previous.retired_at = "retired", datetime.now(timezone.utc)
            await db.flush()  # free the single "active" slot before activating the new revision
        candidate.status, candidate.rotated_at = "active", (datetime.now(timezone.utc) if previous is not None else None)
        connection.status, connection.last_error = "connected", None
        connection.verified_at = datetime.now(timezone.utc)
        connection.credential_reference = f"vault://merchant-payment-credential/{candidate.id}"
        connection.configuration = configuration
        if previous is not None:
            await db.flush()
            await purge_settled_revisions(db, tenant_id=tenant_id, connection_id=connection.id)  # nothing used it -> purge now
    elif outcome == "rejected":
        await db.delete(candidate)  # never referenced by a payment; do not retain rejected secrets
        has_active = await active_credential(db, connection) is not None
        connection.status = "connected" if has_active else "error"
        connection.last_error = error
    else:  # inconclusive: keep the pending revision for a retry; do not touch a working connection
        has_active = await active_credential(db, connection) is not None
        connection.status = "connected" if has_active else "pending"
        connection.last_error = error
    await db.commit()
    return {"provider": provider, "status": connection.status, "mode": mode, "error": error,
            "revision": number if outcome == "verified" else None,
            "webhook_path": rules.webhook_path(token),
            "setup": ("Set this webhook URL in your Paystack dashboard." if provider == "paystack" else
                      "Set this webhook URL and the same secret hash in your Flutterwave dashboard.")}


async def purge_settled_revisions(db: AsyncSession, tenant_id: Optional[UUID] = None, connection_id: Optional[UUID] = None) -> int:
    """Zero the secret of every RETIRED revision whose payments have all settled. The row stays as history
    (payments keep their credential_id). Safe to call repeatedly."""
    q = select(MerchantPaymentCredential).where(MerchantPaymentCredential.status == "retired")
    if tenant_id is not None:
        q = q.where(MerchantPaymentCredential.tenant_id == tenant_id)
    if connection_id is not None:
        q = q.where(MerchantPaymentCredential.connection_id == connection_id)
    purged = 0
    for cred in (await db.execute(q.with_for_update(skip_locked=True))).scalars().all():
        refs = (await db.execute(select(CommercePayment.status, CommercePayment.requires_refund).where(
            CommercePayment.credential_id == cred.id, CommercePayment.tenant_id == cred.tenant_id))).all()
        if rules.revision_purgeable(revision_status=cred.status, referencing_payments=[(s, bool(r)) for s, r in refs]):
            cred.status, cred.nonce, cred.ciphertext = "purged", None, None
            cred.purged_at = datetime.now(timezone.utc)
            purged += 1
    return purged


async def remove_credentials(db: AsyncSession, tenant_id: UUID, provider: str) -> dict:
    """Merchant disconnects. New payments stop immediately (connection -> pending, active revision
    retired). The sealed secret is kept ONLY while a payment that used it is unresolved or owed a refund,
    so those payments can still be verified against the right account; everything else is purged now."""
    connection = (await db.execute(select(MerchantPaymentConnection).where(
        MerchantPaymentConnection.tenant_id == tenant_id, MerchantPaymentConnection.provider == provider.lower()
    ).with_for_update())).scalar_one_or_none()
    if connection is None:
        return {"retained_for_unresolved_payments": 0, "purged": 0}
    await db.execute(delete(MerchantPaymentCredential).where(
        MerchantPaymentCredential.connection_id == connection.id, MerchantPaymentCredential.status == "pending"))
    active = await active_credential(db, connection)
    if active is not None:
        active.status, active.retired_at = "retired", datetime.now(timezone.utc)
    connection.credential_reference, connection.status, connection.verified_at = None, "pending", None
    await db.flush()
    purged = await purge_settled_revisions(db, tenant_id=tenant_id, connection_id=connection.id)
    retained = (await db.execute(select(func.count()).select_from(MerchantPaymentCredential).where(
        MerchantPaymentCredential.connection_id == connection.id, MerchantPaymentCredential.status == "retired"))).scalar_one()
    await db.commit()
    return {"retained_for_unresolved_payments": int(retained), "purged": purged}


async def process_merchant_event(db: AsyncSession, tenant_id: UUID, event_id: UUID) -> bool:
    """Verify with the MERCHANT's provider account, then apply. Leaves the event unprocessed when the
    provider cannot be reached, so the sweep retries it. Caller must have bound the tenant context."""
    event = (await db.execute(select(MerchantPaymentEvent).where(
        MerchantPaymentEvent.id == event_id, MerchantPaymentEvent.tenant_id == tenant_id).with_for_update())).scalar_one_or_none()
    if event is None or event.processed:
        return False
    reference = event.reference
    payment = None
    if reference:
        payment = (await db.execute(select(CommercePayment).where(
            CommercePayment.tenant_id == tenant_id, CommercePayment.connection_id == event.connection_id,
            (CommercePayment.reference == str(reference)) | (CommercePayment.provider_reference == str(reference))
        ).with_for_update())).scalar_one_or_none()
    if payment is None:
        event.processed, event.processed_at = True, datetime.now(timezone.utc)
        event.processing_error = "No payment for this reference on this connection."
        await db.commit()
        return True
    connection = (await db.execute(select(MerchantPaymentConnection).where(MerchantPaymentConnection.id == event.connection_id))).scalar_one()
    try:
        # Verify against the exact credential revision this payment was initiated with.
        adapter = await build_adapter(db, connection, payment.credential_id)
        verification = await adapter.verify_transaction(str(payment.provider_reference or payment.reference))
    except ProviderTransactionNotFoundError:
        # Not proof of "no charge" for a young payment (initialization may still be in flight): let the
        # sweep decide once the grace window has passed.
        return False
    except (ProviderOutcomeUnknownError, VaultNotConfigured, VaultDecryptionError):
        return False
    if is_in_flight(verification.status):
        return False
    await apply_commerce_payment_verification(db, payment, verification)
    event.processed, event.processed_at, event.processing_error = True, datetime.now(timezone.utc), None
    await db.flush()
    await purge_settled_revisions(db, tenant_id=tenant_id, connection_id=event.connection_id)  # this payment may have been the last user
    await db.commit()
    return True
