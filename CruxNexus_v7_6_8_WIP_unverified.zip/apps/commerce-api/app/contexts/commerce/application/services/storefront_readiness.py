"""Gathers the facts for publication readiness and evaluates them with domain/publication_rules."""
from __future__ import annotations

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.provider_registry import ProviderRegistryEntry
from app.contexts.commerce.application.services import merchant_payments as mp
from app.contexts.commerce.domain import payment_methods as pm
from app.contexts.commerce.domain.models import Product, StorefrontProfile
from app.contexts.commerce.domain.publication_rules import readiness_problems


async def storefront_readiness(db: AsyncSession, tenant_id: UUID, profile: StorefrontProfile) -> list:
    published_products = await db.scalar(select(func.count()).select_from(Product).where(
        Product.tenant_id == tenant_id, Product.published.is_(True)))
    connected = await mp.connected_providers(db, tenant_id)
    platform_enabled = set((await db.execute(select(ProviderRegistryEntry.provider_type).where(
        ProviderRegistryEntry.enabled.is_(True)))).scalars().all())
    methods = pm.enabled_methods(
        pod_enabled=profile.pod_enabled, bank_transfer_enabled=profile.bank_transfer_enabled,
        bank_transfer_details=profile.bank_transfer_details, connected_providers=connected,
        platform_enabled_providers=platform_enabled)
    return readiness_problems(
        business_name=profile.business_name, phone=profile.phone, contact_email=profile.contact_email,
        published_product_count=int(published_products or 0), enabled_payment_methods=methods,
        pickup_enabled=profile.pickup_enabled, delivery_enabled=profile.delivery_enabled)
