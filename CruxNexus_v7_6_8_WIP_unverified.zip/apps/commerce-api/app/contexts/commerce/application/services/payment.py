"""Commerce payment application service."""
from __future__ import annotations
from decimal import Decimal
from datetime import datetime, timezone
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from app.infrastructure.outbox.repository import OutboxRepository
from app.infrastructure.payments.adapter import is_in_flight
from app.kernel.events.types import DomainEvent, EventEnvelope
from app.contexts.commerce.domain.models import CommercePayment, InventoryMovement, Order, OrderItem, Product
from app.contexts.commerce.domain.invariants import transition_order

async def outstanding_reservation(db: AsyncSession, order: Order) -> dict:
    """Units this order still holds in reserved stock, from the movement ledger
    (sum of reserved_delta per product for the order reference). The ledger is
    the authority: an order status cannot distinguish a confirmed order that
    still holds stock from a failed one that already released it, and releasing
    twice would consume other orders' reservations."""
    rows = (await db.execute(
        select(InventoryMovement.product_id, func.coalesce(func.sum(InventoryMovement.reserved_delta), 0))
        .where(InventoryMovement.tenant_id == order.tenant_id, InventoryMovement.reference == order.order_number)
        .group_by(InventoryMovement.product_id)
    )).all()
    return {product_id: int(total) for product_id, total in rows if int(total) > 0}


async def _release_order_reservation(db: AsyncSession, order: Order, reason: str) -> None:
    held = await outstanding_reservation(db, order)
    if held:
        products = (await db.execute(
            select(Product).where(Product.id.in_(list(held)), Product.tenant_id == order.tenant_id)
            .order_by(Product.id).with_for_update()
        )).scalars().all()
        for product in products:
            qty = held[product.id]
            product.reserved_stock = max(0, product.reserved_stock - qty)
            db.add(InventoryMovement(tenant_id=order.tenant_id, product_id=product.id,
                                     reserved_delta=-qty, reason=reason, reference=order.order_number))
    order.reservation_expires_at = None

async def apply_commerce_payment_verification(db: AsyncSession, payment: CommercePayment, verification) -> str:
    """Apply a provider-independent commerce payment result.

    A successful payment can never resurrect a cancelled order. If the
    reservation already expired, the payment is recorded as successful and
    flagged for refund/manual reconciliation instead.
    """
    order = (await db.execute(select(Order).where(Order.id == payment.order_id).with_for_update())).scalar_one_or_none()
    if order is None:
        payment.status = "failed"
        return payment.status

    if is_in_flight(verification.status):
        return payment.status

    amount_matches = Decimal(str(verification.amount)) == Decimal(str(payment.amount))
    currency_matches = verification.currency.upper() == payment.currency.upper()
    if not (amount_matches and currency_matches):
        payment.status = "failed"
        if order.status in {"pending_payment", "awaiting_transfer"}:
            order.payment_status = "failed"
            transition_order(order, "payment_failed")
            await _release_order_reservation(db, order, "payment_failed")
        return payment.status

    if verification.successful:
        payment.status = "successful"
        payment.provider_reference = verification.provider_reference
        if order.status == "cancelled" or order.reservation_expires_at is None or order.fulfillment_status == "cancelled":
            payment.requires_refund = True
            order.payment_status = "paid"
            await OutboxRepository(db).append(EventEnvelope(
                event_type=DomainEvent.PAYMENT_SUCCESSFUL_ON_CANCELLED_ORDER,
                aggregate_type="Order", aggregate_id=order.id, tenant_id=order.tenant_id,
                payload={"order_number": order.order_number, "payment_reference": payment.reference, "reason": "reservation_expired_or_order_cancelled"},
            ))
            return payment.status
        order.payment_status = "paid"
        if order.status in {"pending_payment", "awaiting_transfer", "payment_failed"}:
            transition_order(order, "confirmed")
        order.reservation_expires_at = None
        return payment.status

    payment.status = "failed"
    if order.status in {"pending_payment", "awaiting_transfer"}:
        order.payment_status = "failed"
        transition_order(order, "payment_failed")
        await _release_order_reservation(db, order, "payment_failed")
    return payment.status



async def try_rereserve_order(db: AsyncSession, order: Order) -> bool:
    """Re-check stock and, if EVERY line is still available, reserve it again for this order. All or
    nothing, with product rows locked in a fixed order (deadlock-free). The caller commits."""
    items = (await db.execute(
        select(OrderItem, Product).join(Product, Product.id == OrderItem.product_id)
        .where(OrderItem.order_id == order.id, OrderItem.tenant_id == order.tenant_id)
        .order_by(Product.id).with_for_update(of=Product)
    )).all()
    if not items:
        return False
    for item, product in items:
        if product.stock - product.reserved_stock < item.quantity:
            return False
    for item, product in items:
        product.reserved_stock += item.quantity
        db.add(InventoryMovement(tenant_id=order.tenant_id, product_id=product.id, reserved_delta=item.quantity,
                                 reason="order_re_reserved", reference=order.order_number))
    return True


async def apply_late_bank_transfer(db: AsyncSession, order: Order, payment: CommercePayment) -> dict:
    """Merchant confirms a bank transfer. Money received NEVER revives an order by itself: the outcome is
    decided by domain/payment_methods.plan_late_bank_transfer from the reservation state and stock."""
    from datetime import datetime, timezone
    from app.contexts.commerce.domain import payment_methods as pm

    now = datetime.now(timezone.utc)
    held = await outstanding_reservation(db, order)
    live = pm.reservation_is_live(
        order_status=order.status, reserved_units_held=bool(held), deadline=order.reservation_expires_at,
        now=now, method=pm.BANK)
    can_rereserve = False
    needs_stock_check = (order.status == "awaiting_transfer" and not live) or (
        order.status == "cancelled" and order.cancellation_reason == pm.EXPIRED_REASON)
    if needs_stock_check:
        can_rereserve = await try_rereserve_order(db, order)
    plan = pm.plan_late_bank_transfer(
        order_status=order.status, cancellation_reason=order.cancellation_reason,
        reservation_live=live, can_rereserve=can_rereserve)

    if plan == pm.ALREADY_CONFIRMED:
        return {"outcome": plan, "requires_refund": bool(payment.requires_refund)}
    payment.status = "successful"
    order.payment_status = "paid"
    if plan == pm.REFUND_REQUIRED:
        payment.requires_refund = True   # the money is real; the order stays as it is and is NOT revived
        return {"outcome": plan, "requires_refund": True}
    if plan == pm.REOPEN_AND_CONFIRM:
        order.status = "confirmed"       # only a worker-EXPIRED order may reopen, and only with stock re-reserved
        order.cancellation_reason = None
    else:
        transition_order(order, "confirmed")
    order.reservation_expires_at = None
    return {"outcome": plan, "requires_refund": False}
