"""THE public storefront boundary.

Every public (unauthenticated) storefront endpoint resolves its store here and nowhere else. A store is
reachable only if its tenant is active, a profile exists and is explicitly published, and the merchant is
commercially entitled to operate (subscription not blocked/suspended). Anything else is a uniform 404, so
the public cannot tell a draft, suspended or lapsed store from one that does not exist.
"""
from __future__ import annotations

from dataclasses import dataclass

from fastapi import HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.commerce.domain.models import StorefrontProfile
from app.contexts.commerce.domain.publication_rules import public_access
from app.contexts.tenant_management.domain.entities import Tenant
from app.kernel.access.entitlement_policy import Standing
from app.kernel.access.policy_loader import load_policy_for_tenant


@dataclass
class PublicStorefront:
    tenant: Tenant
    profile: StorefrontProfile


async def resolve_public_storefront(db: AsyncSession, slug: str) -> PublicStorefront:
    await db.execute(text("SELECT set_config('app.public_storefront', '1', true)"))
    tenant = (await db.execute(select(Tenant).where(Tenant.slug == slug))).scalar_one_or_none()
    if tenant is None or tenant.status != "active":
        raise HTTPException(status_code=404, detail="Storefront not found")
    await db.execute(text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"), {"tenant_id": str(tenant.id)})
    profile = (await db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tenant.id))).scalar_one_or_none()
    _policy, standing = await load_policy_for_tenant(db, tenant.id)
    if not public_access(
        tenant_status=tenant.status, profile_exists=profile is not None,
        profile_published=bool(profile and profile.published), commercially_blocked=standing is Standing.BLOCKED,
    ):
        raise HTTPException(status_code=404, detail="Storefront not found")
    return PublicStorefront(tenant=tenant, profile=profile)
