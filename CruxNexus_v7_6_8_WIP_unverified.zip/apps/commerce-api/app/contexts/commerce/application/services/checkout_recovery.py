"""Checkout idempotency recovery.

Checkout commits the order + payment first, and only then talks to the payment provider and records the
final response, so a crash in between would leave an idempotency row in 'processing' forever. Every row
is therefore linked to its order (order_id) and carries a lease (processing_since). Once the lease has
passed, a replay of the same key - or the recovery worker - rebuilds the response from durable state
and completes the row. The order access token is NEVER stored: it is a bearer credential shown once, to
the original caller; a recovered or replayed response omits it.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.commerce.domain.models import (
    CommerceCheckoutIdempotency, CommercePayment, Order, OrderItem,
)

# Provider calls time out well inside this; after it a still-'processing' row means the request died.
CHECKOUT_LEASE = timedelta(minutes=2)


def order_dict(o: Order, items: list) -> dict:
    return {
        "id": str(o.id), "order_number": o.order_number, "status": o.status, "payment_status": o.payment_status,
        "fulfillment_status": o.fulfillment_status, "fulfillment_method": o.fulfillment_method,
        "subtotal": str(o.subtotal), "delivery_fee": str(o.delivery_fee), "total": str(o.total),
        "currency": o.currency, "delivery_address": o.delivery_address, "created_at": o.created_at.isoformat(),
        "items": [{"product_id": str(i.product_id), "name": i.product_name, "sku": i.sku, "quantity": i.quantity,
                   "unit_price": str(i.unit_price), "line_total": str(i.line_total)} for i in items],
    }


def lease_expired(processing_since: datetime, now: Optional[datetime] = None) -> bool:
    return (now or datetime.now(timezone.utc)) - processing_since >= CHECKOUT_LEASE


async def reconstruct_response(db: AsyncSession, idem: CommerceCheckoutIdempotency) -> Optional[dict]:
    """Rebuild the checkout response from the order the request created, or None if it created none."""
    if idem.order_id is None:
        return None
    order = (await db.execute(select(Order).where(Order.id == idem.order_id, Order.tenant_id == idem.tenant_id))).scalar_one_or_none()
    if order is None:
        return None
    items = (await db.execute(select(OrderItem).where(OrderItem.order_id == order.id, OrderItem.tenant_id == idem.tenant_id))).scalars().all()
    payment = (await db.execute(
        select(CommercePayment).where(CommercePayment.order_id == order.id, CommercePayment.tenant_id == idem.tenant_id)
        .order_by(CommercePayment.created_at.desc()).limit(1))).scalar_one_or_none()
    return {
        "order": order_dict(order, list(items)),
        "order_access_token": None,
        "access_token_note": "The order access token is shown once at checkout and is never stored; use order number + phone to look the order up.",
        "payment": None if payment is None else {
            "reference": payment.reference, "provider": payment.provider, "status": payment.status,
            "authorization_url": payment.authorization_url},
    }


async def recover_expired_claim(db: AsyncSession, idem: CommerceCheckoutIdempotency) -> str:
    """Resolve ONE stuck 'processing' row whose lease has passed. Returns 'completed' or 'failed'.
    Caller holds the row lock and commits."""
    response = await reconstruct_response(db, idem)
    if response is None:
        idem.status = "failed"       # nothing durable was created; the client may retry with a NEW key
        idem.completed_at = datetime.now(timezone.utc)
        return "failed"
    idem.response_payload = response
    idem.status = "completed"
    idem.completed_at = datetime.now(timezone.utc)
    return "completed"


async def recover_stuck_checkouts(db: AsyncSession, now: Optional[datetime] = None, limit: int = 50) -> int:
    """Worker pass (worker role, cross-tenant by policy): finalize 'processing' rows past their lease."""
    from sqlalchemy import text

    await db.execute(text("SELECT set_config('app.worker_context', '1', true)"))
    cutoff = (now or datetime.now(timezone.utc)) - CHECKOUT_LEASE
    rows = (await db.execute(
        select(CommerceCheckoutIdempotency).where(
            CommerceCheckoutIdempotency.status == "processing", CommerceCheckoutIdempotency.processing_since < cutoff)
        .order_by(CommerceCheckoutIdempotency.processing_since).limit(limit).with_for_update(skip_locked=True)
    )).scalars().all()
    for idem in rows:
        await recover_expired_claim(db, idem)
    if rows:
        await db.commit()
    return len(rows)
