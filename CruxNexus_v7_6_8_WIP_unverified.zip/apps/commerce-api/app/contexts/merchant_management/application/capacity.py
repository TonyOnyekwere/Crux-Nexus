from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text, or_
from uuid import UUID
import logging

from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.merchant_entitlement import (
    EntitlementStatus,
    EntitlementType,
    MerchantEntitlement,
)
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.merchant_management.domain.entities import MerchantAccount
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus
from app.contexts.tenant_management.domain.membership import TenantMembership, TenantRole, MembershipStatus
from app.exceptions import CapacityExceededError, NotFoundError, SubscriptionRequiredError

logger = logging.getLogger(__name__)


class CapacityService:
    """Single authority for all capacity calculations.
    
    This service enforces the commercial rules:
    - STARTER: 1 storefront, 0 staff/base, 0 extra storefronts, 0 extra staff
    - BUSINESS: 1 storefront, 3 staff/base, +1 extra storefronts max, +2 extra staff max
    - ENTERPRISE: 1 storefront, 8 staff/base, +2 extra storefronts max, +4 extra staff max
    
    Owner does NOT consume staff capacity.
    """
    
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_storefront_capacity(
        self,
        merchant_account_id: UUID,
    ) -> int:
        """Calculate effective storefront capacity for a merchant.
        
        Formula: plan.included_storefronts + active_extra_storefront_entitlements
        
        The capacity includes:
        1. Base included storefronts from the plan (e.g., 1 for all plans)
        2. Extra storefront capacity from entitlement records (purchased or plan-granted)
        
        IMPORTANT: plan.max_extra_storefronts is a LIMIT, not automatic capacity.
        It controls how many extra storefronts can be purchased/granted, but the actual
        capacity comes from entitlement records only.
        """
        # Get merchant's active subscription
        subscription_result = await self.db.execute(
            select(MerchantSubscription).where(
                MerchantSubscription.merchant_account_id == merchant_account_id,
                MerchantSubscription.status.in_([
                    SubscriptionStatus.TRIALING.value,
                    SubscriptionStatus.ACTIVE.value,
                ])
            )
        )
        subscription = subscription_result.scalar_one_or_none()
        if not subscription:
            raise SubscriptionRequiredError(
                "This merchant does not have an active or trialing subscription. "
                "Resubscribe to a plan to regain storefront entitlement."
            )
        
        # Get subscription plan
        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == subscription.subscription_plan_id)
        )
        plan = plan_result.scalar_one_or_none()
        if not plan:
            raise NotFoundError("subscription_plan")
        
        # Get active extra storefront entitlements (these provide actual capacity)
        extra_result = await self.db.execute(
            select(func.sum(MerchantEntitlement.quantity)).where(
                MerchantEntitlement.merchant_account_id == merchant_account_id,
                MerchantEntitlement.entitlement_type == EntitlementType.EXTRA_STOREFRONT.value,
                MerchantEntitlement.status == EntitlementStatus.ACTIVE.value,
                # Fixed a real gap (external review): status=ACTIVE alone
                # was being treated as sufficient - an entitlement whose
                # starts_at is still in the future, or whose ends_at has
                # already passed, was still counted toward capacity.
                MerchantEntitlement.starts_at <= func.now(),
                or_(MerchantEntitlement.ends_at.is_(None), MerchantEntitlement.ends_at > func.now()),
            )
        )
        extra_quantity = extra_result.scalar() or 0
        
        # Effective capacity = included + actual entitlement capacity
        return plan.included_storefronts + extra_quantity

    async def grant_extra_storefront_entitlement(
        self,
        *,
        merchant_account_id: UUID,
        quantity: int,
        source: str,
    ) -> MerchantEntitlement:
        """Grant additional storefront capacity beyond plan.included_storefronts.

        This is the entitlement layer the commerce-tier model describes:
        SubscriptionPlan.max_extra_storefronts is the *ceiling* on how much
        extra storefront capacity a merchant on that plan could ever hold —
        it does not itself grant anything. Actually granting capacity
        (via purchase, admin grant, or promotion — see EntitlementSource)
        is a separate, explicit act, and this is the one place that should
        ever create an extra_storefront MerchantEntitlement row, so the
        ceiling is enforced in exactly one place.

        Before this method existed, there was no code path anywhere that
        created an extra_storefront entitlement — meaning no merchant,
        regardless of plan, could ever actually exercise the "extra
        storefronts" their plan nominally allowed.
        """
        if quantity <= 0:
            raise ValueError("Grant quantity must be positive")

        # Row lock (external review fix): without this, two concurrent
        # grant calls can both read the same existing_quantity below
        # before either commits, both pass the ceiling check, and the
        # combined total exceeds plan.max_extra_storefronts. Same lock
        # pattern already used by create_storefront_with_capacity_check
        # for exactly this class of race.
        await self.db.execute(
            text("SELECT id FROM merchant_accounts WHERE id = :merchant_id FOR UPDATE"),
            {"merchant_id": str(merchant_account_id)},
        )

        subscription_result = await self.db.execute(
            select(MerchantSubscription).where(
                MerchantSubscription.merchant_account_id == merchant_account_id,
                MerchantSubscription.status.in_([
                    SubscriptionStatus.TRIALING.value,
                    SubscriptionStatus.ACTIVE.value,
                ])
            )
        )
        subscription = subscription_result.scalar_one_or_none()
        if not subscription:
            raise SubscriptionRequiredError(
                "This merchant does not have an active or trialing subscription. "
                "Extra storefront capacity cannot be granted without one."
            )

        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == subscription.subscription_plan_id)
        )
        plan = plan_result.scalar_one_or_none()
        if not plan:
            raise NotFoundError("subscription_plan")

        # Check plan limits before granting
        # For plan-based grants (source=admin_grant for plan capacity), allow up to plan.max_extra_*
        # For additional purchases, also check against plan.max_extra_* but allow up to the limit
        existing_result = await self.db.execute(
            select(func.sum(MerchantEntitlement.quantity)).where(
                MerchantEntitlement.merchant_account_id == merchant_account_id,
                MerchantEntitlement.entitlement_type == EntitlementType.EXTRA_STOREFRONT.value,
                MerchantEntitlement.status == EntitlementStatus.ACTIVE.value,
                MerchantEntitlement.starts_at <= func.now(),
                or_(MerchantEntitlement.ends_at.is_(None), MerchantEntitlement.ends_at > func.now()),
            )
        )
        existing_quantity = existing_result.scalar() or 0
        
        if existing_quantity + quantity > plan.max_extra_storefronts:
            raise CapacityExceededError(
                "extra_storefront_entitlement",
                plan.max_extra_storefronts,
                existing_quantity,
            )

        entitlement = MerchantEntitlement(
            merchant_account_id=merchant_account_id,
            entitlement_type=EntitlementType.EXTRA_STOREFRONT.value,
            quantity=quantity,
            source=source,
            status=EntitlementStatus.ACTIVE.value,
        )
        self.db.add(entitlement)
        await self.db.flush()
        return entitlement

    async def get_active_storefront_count(
        self,
        merchant_account_id: UUID,
    ) -> int:
        """Count active storefronts for a merchant.
        
        Counts: PROVISIONING, ONBOARDING, ACTIVE, SUSPENDED
        Does NOT count: ARCHIVED

        Fixed a real bug (flagged across three separate external reviews
        before finally being fixed here): this previously counted every
        MerchantAccountTenant ownership row with no join to Tenant at
        all, so an ARCHIVED storefront kept consuming capacity forever -
        a merchant who archived a store could never create a replacement
        once at their plan's storefront limit.
        """
        result = await self.db.execute(
            select(func.count(MerchantAccountTenant.id))
            .join(Tenant, Tenant.id == MerchantAccountTenant.tenant_id)
            .where(
                MerchantAccountTenant.merchant_account_id == merchant_account_id,
                Tenant.status != TenantStatus.ARCHIVED,
            )
        )
        return result.scalar() or 0

    async def get_available_storefront_slots(
        self,
        merchant_account_id: UUID,
    ) -> int:
        """Calculate available storefront slots.
        
        Formula: effective_capacity - active_count
        """
        capacity = await self.get_storefront_capacity(merchant_account_id)
        active_count = await self.get_active_storefront_count(merchant_account_id)
        return max(0, capacity - active_count)

    async def can_create_storefront(
        self,
        merchant_account_id: UUID,
    ) -> bool:
        """Check if merchant can create another storefront."""
        available = await self.get_available_storefront_slots(merchant_account_id)
        return available > 0

    async def get_storefront_staff_capacity(
        self,
        merchant_account_id: UUID,
        tenant_id: UUID,
    ) -> int:
        """Calculate effective staff capacity for a specific storefront.

        Formula: plan.base_staff_per_storefront + this storefront's
        allocated share of the merchant's extra staff entitlement.
        Owner does NOT consume staff capacity.

        IMPORTANT: plan.max_extra_staff is a LIMIT, not automatic capacity.
        The actual capacity comes from entitlement records only.

        Fixed a real P0 bug (external review): this previously added the
        merchant's FULL total extra-staff entitlement to EVERY storefront
        independently — a merchant with 2 extra staff and 2 storefronts
        effectively got 2+2=4 usable extra slots instead of 2 total, since
        both storefronts separately "saw" the full merchant-wide sum. The
        StaffCapacityAllocation model already existed specifically to
        represent "this much of the merchant's extra staff entitlement is
        allocated to this specific storefront" — it just wasn't being
        read here. Now the extra-staff contribution to a given
        storefront's capacity is calculated from ITS allocation only.
        """
        ownership_result = await self.db.execute(
            select(MerchantAccountTenant).where(
                MerchantAccountTenant.merchant_account_id == merchant_account_id,
                MerchantAccountTenant.tenant_id == tenant_id,
            )
        )
        if ownership_result.scalar_one_or_none() is None:
            raise ValueError("Tenant is not owned by this merchant account")

        # Get merchant's active subscription
        subscription_result = await self.db.execute(
            select(MerchantSubscription).where(
                MerchantSubscription.merchant_account_id == merchant_account_id,
                MerchantSubscription.status.in_([
                    SubscriptionStatus.TRIALING.value,
                    SubscriptionStatus.ACTIVE.value,
                ])
            )
        )
        subscription = subscription_result.scalar_one_or_none()
        if not subscription:
            raise SubscriptionRequiredError(
                "This merchant does not have an active or trialing subscription. "
                "Resubscribe to a plan to regain staff entitlement."
            )
        
        # Get subscription plan
        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == subscription.subscription_plan_id)
        )
        plan = plan_result.scalar_one_or_none()
        if not plan:
            raise NotFoundError("subscription_plan")
        
        # This storefront's share of the merchant's extra staff
        # entitlement — not the merchant-wide total (see docstring above
        # for why that was a real bug). Allocation-time enforcement
        # (EntitlementAllocationService.allocate_staff_to_storefront)
        # is what already prevents allocating more than the merchant's
        # actual granted entitlement across all storefronts combined;
        # this read-time calculation just needs this storefront's slice.
        from app.contexts.billing.application.entitlement_allocation import (
            EntitlementAllocationService,
        )

        allocation_service = EntitlementAllocationService(self.db)
        allocated_staff = await allocation_service.get_storefront_allocated_staff(tenant_id)

        # Total capacity = base staff + this storefront's allocated extra staff
        return plan.base_staff_per_storefront + allocated_staff

    async def get_current_staff_count(
        self,
        tenant_id: UUID,
    ) -> int:
        """Count current staff members for a storefront.
        
        Does NOT count OWNER.
        Counts: MANAGER, STAFF with ACTIVE membership status.

        Fixed a real bug (flagged across three separate external reviews):
        this previously counted every membership row matching the role,
        with no status filter - a REMOVED or SUSPENDED staff member kept
        consuming staff capacity indefinitely.
        """
        result = await self.db.execute(
            select(func.count(TenantMembership.id)).where(
                TenantMembership.tenant_id == tenant_id,
                TenantMembership.role.in_([TenantRole.MANAGER.value, TenantRole.STAFF.value]),
                TenantMembership.status == MembershipStatus.ACTIVE.value,
            )
        )
        return result.scalar() or 0

    async def can_add_staff(
        self,
        merchant_account_id: UUID,
        tenant_id: UUID,
    ) -> bool:
        """Check if storefront can add another staff member."""
        ownership_result = await self.db.execute(
            select(MerchantAccountTenant).where(
                MerchantAccountTenant.merchant_account_id == merchant_account_id,
                MerchantAccountTenant.tenant_id == tenant_id,
            )
        )
        if ownership_result.scalar_one_or_none() is None:
            raise ValueError("Tenant is not owned by this merchant account")

        capacity = await self.get_storefront_staff_capacity(merchant_account_id, tenant_id)
        current = await self.get_current_staff_count(tenant_id)
        return current < capacity

    async def create_storefront_with_capacity_check(
        self,
        *,
        merchant_account_id: UUID,
        owner_user_id: UUID,
        slug: str,
    ) -> Tenant:
        """
        Create storefront with capacity enforcement and concurrency safety.
        
        This method uses transactional locking to prevent race conditions:
        BEGIN
        ↓
        SELECT merchant_account FOR UPDATE (locks merchant)
        ↓
        calculate capacity
        ↓
        count active storefronts
        ↓
        reject if full
        ↓
        create tenant
        ↓
        create ownership
        ↓
        create owner membership
        ↓
        COMMIT
        """
        # Lock the merchant account to prevent concurrent storefront creation
        await self.db.execute(
            text("SELECT id FROM merchant_accounts WHERE id = :merchant_id FOR UPDATE"),
            {"merchant_id": str(merchant_account_id)}
        )
        
        # Check capacity
        if not await self.can_create_storefront(merchant_account_id):
            capacity = await self.get_storefront_capacity(merchant_account_id)
            active_count = await self.get_active_storefront_count(merchant_account_id)
            raise CapacityExceededError("storefront", capacity, active_count)
        
        # Create tenant. Reaching this point already proves the merchant has
        # a valid TRIALING/ACTIVE subscription (can_create_storefront ->
        # get_storefront_capacity raises SubscriptionRequiredError
        # otherwise), so the storefront can go straight to ACTIVE rather
        # than sitting in PROVISIONING with no path out of it. Nothing in
        # this codebase ever promotes PROVISIONING -> ACTIVE automatically
        # (the only endpoint that could, PATCH /tenants/{id}/status, is
        # deliberately stubbed to always 403 pending real platform-admin
        # auth) — so setting the terminal status here, once, at the moment
        # we already have proof of commercial entitlement, is the correct
        # place to do it rather than leaving every storefront permanently
        # stuck.
        tenant = Tenant(
            slug=slug,
            status=TenantStatus.ACTIVE,
        )
        self.db.add(tenant)
        await self.db.flush()
        
        # Create ownership
        ownership = MerchantAccountTenant(
            merchant_account_id=merchant_account_id,
            tenant_id=tenant.id,
        )
        self.db.add(ownership)
        await self.db.flush()
        
        # Create owner membership
        membership = TenantMembership(
            tenant_id=tenant.id,
            user_id=owner_user_id,
            role=TenantRole.OWNER.value,
            status=MembershipStatus.ACTIVE.value,
        )
        self.db.add(membership)
        await self.db.flush()
        
        return tenant