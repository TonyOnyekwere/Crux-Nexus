"""Canonical merchant-facing API routes."""

from app.contexts.identity.api.routes import list_accessible_storefronts
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/merchant", tags=["merchant"])

# Storefront routes consolidated to canonical endpoints:
# - POST /api/v1/storefronts (for creation)
# - GET /api/v1/storefronts/{tenant_id} (for retrieval) 
# - GET /api/v1/identity/storefronts (for listing accessible storefronts)

# Only list endpoint remains in merchant namespace for convenience
router.add_api_route(
    "/storefronts",
    list_accessible_storefronts,
    methods=["GET"],
    name="merchant_list_storefronts",
)

__all__ = ["router"]
