from datetime import datetime, timezone
import enum
import uuid
from sqlalchemy import Column, DateTime, String, Boolean, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base

class SuspensionSource(str, enum.Enum):
    SUBSCRIPTION = "subscription"
    CONTROL_CENTER = "control_center"
    MERCHANT = "merchant"
    SYSTEM = "system"

class TenantSuspension(Base):
    __tablename__ = "tenant_suspensions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    reason = Column(String(120), nullable=False)
    source = Column(String(40), nullable=False)
    suspended_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    suspended_by = Column(UUID(as_uuid=True), nullable=True)
    restorable_by_subscription = Column(Boolean, nullable=False, default=False)
    governance_override = Column(Boolean, nullable=False, default=False)
    restored_at = Column(DateTime(timezone=True), nullable=True)
    notes = Column(Text, nullable=True)
