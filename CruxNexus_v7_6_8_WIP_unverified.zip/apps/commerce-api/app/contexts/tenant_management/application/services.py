from datetime import datetime, timezone
import uuid
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.merchant_management.application.capacity import CapacityService
from app.contexts.merchant_management.domain.merchant_account_tenant import (
    MerchantAccountTenant,
)
from app.contexts.merchant_management.domain.merchant_account_user import (
    MerchantAccountUser,
)
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus
from app.contexts.tenant_management.domain.suspension import TenantSuspension, SuspensionSource
from app.contexts.tenant_management.domain.membership import (
    TenantMembership,
    TenantRole,
    MembershipStatus,
)
from app.exceptions import CapacityExceededError
from app.utils.slug import normalize_storefront_slug


class TenantService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_storefront(
        self,
        *,
        merchant_account_id: UUID,
        owner_user_id: UUID,
        slug: str,
    ) -> Tenant:
        """Create storefront with capacity enforcement and concurrency safety.
        
        This is the authoritative storefront creation operation that replaces
        the old generic tenant creation. It enforces merchant capacity and
        creates the complete ownership structure atomically.
        """
        normalized_slug = normalize_storefront_slug(slug)
        capacity_service = CapacityService(self.db)

        async def _create_in_current_transaction() -> Tenant:
            from app.kernel.access.resolver import MerchantAccessResolver

            access = await MerchantAccessResolver(self.db).can_create_storefront(merchant_account_id)
            if not access.allowed:
                raise ValueError(access.reason)

            # The merchant_account_id must be authorized for the owner user before any
            # storefront creation can proceed. This prevents arbitrary merchant context
            # drift and ensures merchant-scoped lifecycle enforcement.
            user_membership_result = await self.db.execute(
                select(MerchantAccountUser).where(
                    MerchantAccountUser.merchant_account_id == merchant_account_id,
                    MerchantAccountUser.user_id == owner_user_id,
                )
            )
            if user_membership_result.scalar_one_or_none() is None:
                raise ValueError("Owner is not authorized for this merchant account")

            # Check for slug uniqueness
            existing = await self.db.execute(
                select(Tenant).where(Tenant.slug == normalized_slug)
            )
            if existing.scalar_one_or_none():
                raise ValueError("Slug already taken")

            # Create storefront with capacity check and concurrency safety
            tenant = await capacity_service.create_storefront_with_capacity_check(
                merchant_account_id=merchant_account_id,
                owner_user_id=owner_user_id,
                slug=normalized_slug,
            )
            return tenant

        if self.db.in_transaction():
            return await _create_in_current_transaction()

        async with self.db.begin():
            return await _create_in_current_transaction()

    async def get_tenant_by_slug(self, slug: str) -> Tenant | None:
        result = await self.db.execute(
            select(Tenant).where(Tenant.slug == slug)
        )
        return result.scalar_one_or_none()

    async def get_tenant_by_id(self, tenant_id: UUID) -> Tenant | None:
        result = await self.db.execute(
            select(Tenant).where(Tenant.id == tenant_id)
        )
        return result.scalar_one_or_none()

    async def user_has_membership(
        self,
        user_id: UUID,
        tenant_id: UUID,
    ) -> TenantMembership | None:
        result = await self.db.execute(
            select(TenantMembership).where(
                TenantMembership.user_id == user_id,
                TenantMembership.tenant_id == tenant_id,
                TenantMembership.status == MembershipStatus.ACTIVE.value,
            )
        )
        return result.scalar_one_or_none()

    async def validate_tenant_ready_for_access(
        self,
        tenant_id: UUID,
    ) -> Tenant:
        tenant = await self.get_tenant_by_id(tenant_id)
        if tenant is None:
            raise ValueError("Tenant not found")
        if tenant.status == TenantStatus.ARCHIVED:
            raise ValueError("This storefront is archived and no longer accessible.")
        if tenant.status == TenantStatus.SUSPENDED:
            raise ValueError("This storefront is suspended and not accessible.")
        return tenant

    async def merchant_has_staff_capability(
        self,
        merchant_account_id: UUID,
        tenant_id: UUID,
    ) -> bool:
        """Return true only when the merchant plan explicitly supports staff features."""
        result = await self.db.execute(
            select(MerchantSubscription).where(
                MerchantSubscription.merchant_account_id == merchant_account_id,
                MerchantSubscription.status.in_([
                    SubscriptionStatus.TRIALING.value,
                    SubscriptionStatus.ACTIVE.value,
                ]),
            )
        )
        subscription = result.scalar_one_or_none()
        if subscription is None:
            return False

        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(
                SubscriptionPlan.id == subscription.subscription_plan_id,
                SubscriptionPlan.active.is_(True),
            )
        )
        plan = plan_result.scalar_one_or_none()
        if plan is None:
            return False

        return plan.base_staff_per_storefront > 0

    async def can_manage_staff_or_raise(
        self,
        merchant_account_id: UUID,
        tenant_id: UUID,
    ) -> bool:
        """Compatibility wrapper around the canonical capability resolver."""
        from app.kernel.access.resolver import MerchantAccessResolver

        access = await MerchantAccessResolver(self.db).can_add_staff(
            merchant_account_id, tenant_id
        )
        if not access.allowed:
            raise ValueError(access.reason)
        return True

    async def add_staff_member(
        self,
        *,
        merchant_account_id: UUID,
        tenant_id: UUID,
        user_id: UUID,
        role: TenantRole,
    ) -> TenantMembership:
        """Add a staff member to a storefront with capacity enforcement."""
        if role == TenantRole.OWNER:
            raise ValueError("Cannot invite additional owners via staff endpoint.")

        capacity_service = CapacityService(self.db)

        async def _add_in_current_transaction() -> TenantMembership:
            ownership_result = await self.db.execute(
                select(MerchantAccountTenant)
                .where(
                    MerchantAccountTenant.merchant_account_id == merchant_account_id,
                    MerchantAccountTenant.tenant_id == tenant_id,
                )
                .with_for_update()
            )
            if ownership_result.scalar_one_or_none() is None:
                raise ValueError("Tenant is not owned by this merchant account")

            # MerchantAccessResolver is the capability authority. CapacityService
            # remains the arithmetic/concurrency implementation underneath it.
            from app.kernel.access.resolver import MerchantAccessResolver

            access = await MerchantAccessResolver(self.db).can_add_staff(
                merchant_account_id, tenant_id
            )
            if not access.allowed:
                raise ValueError(access.reason)

            # Check for existing membership
            existing = await self.user_has_membership(user_id, tenant_id)
            if existing:
                raise ValueError("User already has membership for this storefront.")

            membership = TenantMembership(
                tenant_id=tenant_id,
                user_id=user_id,
                role=role.value,
                status=MembershipStatus.ACTIVE.value,
            )
            self.db.add(membership)
            await self.db.flush()
            return membership

        if self.db.in_transaction():
            return await _add_in_current_transaction()

        async with self.db.begin():
            return await _add_in_current_transaction()

    async def update_tenant_status(
        self, tenant_id: UUID, new_status: TenantStatus, *,
        source: str = SuspensionSource.CONTROL_CENTER.value,
        reason: str = "Administrative status change",
        actor_id: UUID | None = None,
    ) -> Tenant:
        """Update tenant status with state machine validation.
        
        This should only be called by Control Center or authorized platform roles.
        Merchant owners should not be able to change platform lifecycle states.
        """
        tenant = await self.get_tenant_by_id(tenant_id)
        if not tenant:
            raise ValueError("Tenant not found")

        valid_transitions = {
            TenantStatus.ACTIVE: [TenantStatus.SUSPENDED, TenantStatus.OFFBOARDING],
            TenantStatus.SUSPENDED: [TenantStatus.ACTIVE, TenantStatus.OFFBOARDING],
            TenantStatus.OFFBOARDING: [TenantStatus.ARCHIVED],
            TenantStatus.ARCHIVED: [],
            # PROVISIONING and ONBOARDING are kept in enum for future platform-admin use
            # but are not used in merchant-initiated storefront creation
        }

        if new_status not in valid_transitions.get(tenant.status, []):
            raise ValueError(
                f"Invalid status transition from {tenant.status} to {new_status}"
            )

        tenant.status = new_status
        if new_status == TenantStatus.SUSPENDED:
            self.db.add(TenantSuspension(
                tenant_id=tenant.id, reason=reason, source=source,
                suspended_by=actor_id,
                restorable_by_subscription=(source == SuspensionSource.SUBSCRIPTION.value),
                governance_override=(source == SuspensionSource.CONTROL_CENTER.value),
            ))
        elif new_status == TenantStatus.ACTIVE:
            if source == SuspensionSource.CONTROL_CENTER.value:
                active_governance = (await self.db.execute(
                    select(TenantSuspension).where(
                        TenantSuspension.tenant_id == tenant.id,
                        TenantSuspension.restored_at.is_(None),
                        TenantSuspension.governance_override.is_(True),
                    ).with_for_update()
                )).scalars().all()
                for suspension in active_governance:
                    suspension.restored_at = datetime.now(timezone.utc)
            active = (await self.db.execute(
                select(TenantSuspension).where(
                    TenantSuspension.tenant_id == tenant.id,
                    TenantSuspension.restored_at.is_(None),
                    TenantSuspension.restorable_by_subscription.is_(True),
                ).with_for_update()
            )).scalars().all()
            for suspension in active:
                suspension.restored_at = datetime.now(timezone.utc)
        from app.infrastructure.audit import SecurityEvent, SecurityEventType, record_durable_audit
        if new_status == TenantStatus.SUSPENDED:
            await record_durable_audit(self.db, SecurityEvent(event_type=SecurityEventType.TENANT_SUSPENDED, user_id=str(actor_id) if actor_id else None, tenant_id=str(tenant.id), success=True, reason=reason, metadata={"source": source}), actor_type=source)
        await self.db.commit()
        await self.db.refresh(tenant)
        return tenant
