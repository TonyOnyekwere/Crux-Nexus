import logging
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.authorization import Permission, has_permission
from app.auth.control_center_auth import verify_control_center_service
from app.auth.jwt_handler import (
    get_current_merchant_context,
    get_current_tenant_context,
    get_current_user_id,
)
from app.contexts.identity.application.services import IdentityService
from app.contexts.merchant_management.application.services import MerchantService
from app.contexts.tenant_management.application.services import TenantService
from app.database import get_db
from app.exceptions import CapacityExceededError, CruxNexusError
from app.kernel.errors.responses import error_response

from .schemas import (
    StaffInviteRequest,
    StorefrontCreate,
    TenantResponse,
    TenantStatusUpdate,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["storefronts"])


@router.post("/storefronts", status_code=status.HTTP_201_CREATED)
async def create_storefront(
    payload: StorefrontCreate,
    db: AsyncSession = Depends(get_db),
    merchant_context: dict = Depends(get_current_merchant_context),
):
    user_id = merchant_context["user_id"]

    merchant_service = MerchantService(db)
    merchant_account_id = await merchant_service.get_merchant_account_id_for_user(
        user_id
    )
    if merchant_account_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "MERCHANT_REQUIRED",
                    "message": "No merchant account found for this user.",
                    "details": {},
                }
            },
        )

    # MerchantAccessResolver convergence (external review fix — P0):
    # this route previously went straight to TenantService/CapacityService,
    # which check subscription/capacity but never MerchantAccount.status —
    # a SUSPENDED merchant with an ACTIVE subscription and available
    # capacity could still create a storefront. TenantService's own
    # internal row-locked capacity check (create_storefront_with_capacity_check)
    # remains the authoritative, concurrency-safe capacity gate below;
    # this adds the merchant/subscription status check that was missing
    # entirely, as an upfront rejection before attempting the transaction.
    from app.kernel.access.resolver import MerchantAccessResolver

    resolver = MerchantAccessResolver(db)
    access = await resolver.can_create_storefront(merchant_account_id)
    if not access.allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "ACCESS_DENIED", "message": access.reason, "details": {}}},
        )

    try:
        service = TenantService(db)
        tenant = await service.create_storefront(
            merchant_account_id=merchant_account_id,
            owner_user_id=user_id,
            slug=payload.slug,
        )
        return {"data": TenantResponse.model_validate(tenant).model_dump()}
    except CapacityExceededError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": {"code": exc.code, "message": exc.message, "details": exc.details}},
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "VALIDATION_ERROR", "message": str(exc), "details": {}}},
        )
    except IntegrityError:
        await db.rollback()
        logger.exception("Database integrity error while creating storefront")
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": {
                    "code": "STOREFRONT_CONFLICT",
                    "message": "Storefront could not be created because of a data conflict.",
                    "details": {},
                }
            },
        )


@router.get("/storefronts/{tenant_id}")
async def get_storefront(
    tenant_id: UUID,
    db: AsyncSession = Depends(get_db),
    user_id: UUID = Depends(get_current_user_id),
):
    service = TenantService(db)
    membership = await service.user_has_membership(user_id, tenant_id)
    if membership is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "MEMBERSHIP_REQUIRED",
                    "message": "Not authorized to access this storefront.",
                    "details": {},
                }
            },
        )

    try:
        tenant = await service.validate_tenant_ready_for_access(tenant_id)
    except ValueError as exc:
        message = str(exc)
        if "not found" in message.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error": {
                        "code": "TENANT_NOT_FOUND",
                        "message": message,
                        "details": {},
                    }
                },
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "TENANT_NOT_READY",
                    "message": message,
                    "details": {},
                }
            },
        ) from exc

    return {"data": TenantResponse.model_validate(tenant).model_dump()}


@router.post("/tenants/{tenant_id}/members", status_code=status.HTTP_410_GONE, include_in_schema=False)
async def invite_staff_member_deprecated(tenant_id: UUID):
    """Retired compatibility boundary. Use POST /api/v1/invitations."""
    raise HTTPException(status_code=status.HTTP_410_GONE, detail={"error":{"code":"STAFF_ENDPOINT_RETIRED","message":"Use POST /api/v1/invitations.","details":{"new_endpoint":"/api/v1/invitations"}}})

@router.patch("/tenants/{tenant_id}/status")
async def update_tenant_status(
    tenant_id: UUID,
    status_update: TenantStatusUpdate,
    db: AsyncSession = Depends(get_db),
    _cc_context=Depends(verify_control_center_service),
):
    """Transition a tenant's lifecycle status.

    Previously hard-stubbed to always 403 because there was no
    authorization model to gate it on - the state-machine logic in
    TenantService.update_tenant_status has been correct and fully tested
    since it was written. Callable only by Control Center, authenticated
    as a service (not as an individual admin user - Control Center owns
    admin identity/RBAC entirely in its own database and asserts which
    admin triggered this via X-Acting-Admin-Id/X-Acting-Admin-Email,
    logged here for audit but not independently re-verified).
    """
    tenant_service = TenantService(db)
    try:
        tenant = await tenant_service.update_tenant_status(
            tenant_id, status_update.status,
            source="control_center",
            reason=status_update.reason or "Control Center governance action",
            actor_id=UUID(_cc_context.acting_admin_id) if _cc_context.acting_admin_id else None,
        )
    except ValueError as exc:
        message = str(exc)
        if message == "Tenant not found":
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=error_response(code="TENANT_NOT_FOUND", message=message),
            )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=error_response(code="INVALID_STATUS_TRANSITION", message=message),
        )

    logger.info(
        "Tenant %s status changed to %s by Control Center (acting admin: %s)",
        tenant_id,
        status_update.status,
        _cc_context.acting_admin_id or "unspecified",
    )

    return {
        "data": {
            "tenant_id": str(tenant.id),
            "status": tenant.status.value
            if hasattr(tenant.status, "value")
            else tenant.status,
        }
    }
