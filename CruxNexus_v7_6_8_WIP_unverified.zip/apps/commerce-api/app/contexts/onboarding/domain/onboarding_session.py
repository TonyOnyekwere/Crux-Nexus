"""Onboarding session domain models.

Per the locked CruxNexus Merchant Onboarding & Activation Architecture
(2026-09-17). See migrations/versions/021_create_onboarding_sessions.py
for the schema this maps to, and that migration's docstring for how this
relates to the pre-existing merchant_onboarding_requests idempotency
ledger (migration 015) — that ledger is unchanged and still owns
provisioning idempotency; this is the journey/session layer above it.

This file defines the schema and status vocabulary only. The
application-layer session service (create/resume/advance/version-check/
expire, and the launch transaction that finally calls
OnboardingService.onboard_merchant) is deliberately not included in this
pass — see CRX-P0-022 for why that's staged as Phase 2 rather than built
in the same pass as the schema.
"""

from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import CheckConstraint, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID

from app.database import Base


class OnboardingSessionStatus(str, enum.Enum):
    """Onboarding's own status authority (locked architecture section 14)
    — independent of subscription/merchant/tenant status. A session can be
    IN_PROGRESS while its subscription is PAYMENT_PENDING, for example."""

    IN_PROGRESS = "in_progress"
    LAUNCHING = "launching"
    COMPLETED = "completed"
    ABANDONED = "abandoned"
    EXPIRED = "expired"
    RECOVERY_REQUIRED = "recovery_required"


class OnboardingStepEventType(str, enum.Enum):
    """Append-only funnel-analytics event types (locked architecture
    section 51)."""

    STEP_ENTERED = "step_entered"
    STEP_COMPLETED = "step_completed"
    STEP_FAILED = "step_failed"
    ABANDONED_FROM = "abandoned_from"


class OnboardingStep(str, enum.Enum):
    """Canonical step names for `current_step`/`completed_steps`, matching
    the locked journey order (architecture section 16 / 56). This is the
    application's vocabulary for steps, not a DB constraint — `current_step`
    is a plain string column so a future flow_version can introduce new
    step names without a migration."""

    WELCOME = "welcome"
    COMMERCIAL_CONTEXT = "commercial_context"  # "where/what do you sell"
    BUSINESS_INFO = "business_info"
    ACCOUNT_CREATED = "account_created"
    VERIFIED = "verified"
    CONTACT_INFO = "contact_info"
    PLAN_SELECTED = "plan_selected"
    ACTIVATION_MODE_SELECTED = "activation_mode_selected"  # trial vs pay-now
    PAYMENT_PENDING = "payment_pending"
    SUBSCRIPTION_ACTIVE = "subscription_active"
    DELIVERY_SETUP = "delivery_setup"
    FIRST_PRODUCT = "first_product"
    BRANDING = "branding"
    REVIEW = "review"
    LAUNCHING = "launching"
    LIVE = "live"


class OnboardingSession(Base):
    """A resumable merchant onboarding journey. See migration 021."""

    __tablename__ = "onboarding_sessions"
    __table_args__ = (
        CheckConstraint(
            "status IN ('in_progress', 'launching', 'completed', 'abandoned', 'expired', 'recovery_required')",
            name="chk_onboarding_session_status",
        ),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    device_session_token = Column(String(255), nullable=False, unique=True)

    owner_email = Column(String(320), nullable=True)

    owner_user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    flow_version = Column(String(20), nullable=False, default="v1")

    current_step = Column(String(50), nullable=False, default=OnboardingStep.WELCOME.value)

    completed_steps = Column(JSONB, nullable=False, default=list)

    payload = Column(JSONB, nullable=False, default=dict)

    status = Column(String(30), nullable=False, default=OnboardingSessionStatus.IN_PROGRESS.value)

    # Optimistic concurrency (section 50) — every mutation must read this,
    # send it back as If-Match, and the service must check-and-increment
    # it in the same statement (WHERE version = :expected), rejecting a
    # mismatch with 409 rather than blindly overwriting.
    version = Column(Integer, nullable=False, default=1)

    tenant_id = Column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="SET NULL"),
        nullable=True,
    )

    launch_attempt_count = Column(Integer, nullable=False, default=0)

    last_launch_error = Column(Text, nullable=True)

    expires_at = Column(DateTime(timezone=True), nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class OnboardingStepEvent(Base):
    """Append-only funnel event. Never updated or deleted once written —
    aggregation (onboarding_funnel_daily, section 51) reads from this."""

    __tablename__ = "onboarding_step_events"
    __table_args__ = (
        CheckConstraint(
            "event_type IN ('step_entered', 'step_completed', 'step_failed', 'abandoned_from')",
            name="chk_onboarding_step_event_type",
        ),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    session_id = Column(
        UUID(as_uuid=True),
        ForeignKey("onboarding_sessions.id", ondelete="CASCADE"),
        nullable=False,
    )

    step = Column(String(50), nullable=False)

    event_type = Column(String(30), nullable=False)

    event_metadata = Column(JSONB, nullable=False, default=dict)

    occurred_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
