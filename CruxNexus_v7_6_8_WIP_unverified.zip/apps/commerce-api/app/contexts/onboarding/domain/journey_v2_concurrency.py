"""Optimistic concurrency and idempotency decisions for the v2 journey (CRX-FE-003 WP4 core).

Pure, standard library only. The service performs the I/O; this module decides, in a fixed and tested
order, what a request is allowed to do:

  1. caller authenticated and authorised for the session   (before anything stored can be revealed)
  2. idempotency key present and well-formed               (only for operations that require one)
  3. If-Match present and well-formed                      (for every state-changing request)
  4. stored key record: replay / conflict / in progress    (replay wins over a stale version so a
                                                            lost response can be retried safely)
  5. version staleness check against the current version
"""

from __future__ import annotations

import enum
import hashlib
import hmac
import json
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping, Optional

MAX_VERSION = 2**31 - 1
_KEY_PATTERN = re.compile(r"^[A-Za-z0-9._:\-]{16,128}$")
_IF_MATCH_PATTERN = re.compile(r'^(?:W/)?"?([0-9]{1,10})"?$')

# Operations that must carry an Idempotency-Key (CRX-FE-003 §7).
IDEMPOTENT_OPERATIONS = frozenset({"register", "select_plan", "start_trial", "start_payment", "launch"})


class RequestOutcome(str, enum.Enum):
    FORBIDDEN = "forbidden"
    IDEMPOTENCY_KEY_REQUIRED = "idempotency_key_required"
    IDEMPOTENCY_KEY_INVALID = "idempotency_key_invalid"
    IF_MATCH_REQUIRED = "if_match_required"
    IF_MATCH_INVALID = "if_match_invalid"
    IDEMPOTENCY_KEY_REUSED = "idempotency_key_reused"
    IDEMPOTENCY_IN_PROGRESS = "idempotency_in_progress"
    VERSION_CONFLICT = "version_conflict"
    REPLAY = "replay"
    EXECUTE = "execute"


HTTP_STATUS: dict[RequestOutcome, int] = {
    RequestOutcome.FORBIDDEN: 403,
    RequestOutcome.IDEMPOTENCY_KEY_REQUIRED: 400,
    RequestOutcome.IDEMPOTENCY_KEY_INVALID: 400,
    RequestOutcome.IF_MATCH_REQUIRED: 428,
    RequestOutcome.IF_MATCH_INVALID: 400,
    RequestOutcome.IDEMPOTENCY_KEY_REUSED: 422,
    RequestOutcome.IDEMPOTENCY_IN_PROGRESS: 409,
    RequestOutcome.VERSION_CONFLICT: 409,
    RequestOutcome.REPLAY: 200,
    RequestOutcome.EXECUTE: 200,
}

ERROR_CODE: dict[RequestOutcome, str] = {
    RequestOutcome.IDEMPOTENCY_KEY_REQUIRED: "IDEMPOTENCY_KEY_REQUIRED",
    RequestOutcome.IDEMPOTENCY_KEY_INVALID: "IDEMPOTENCY_KEY_INVALID",
    RequestOutcome.IF_MATCH_REQUIRED: "IF_MATCH_REQUIRED",
    RequestOutcome.IF_MATCH_INVALID: "IF_MATCH_INVALID",
    RequestOutcome.IDEMPOTENCY_KEY_REUSED: "IDEMPOTENCY_KEY_REUSED",
    RequestOutcome.IDEMPOTENCY_IN_PROGRESS: "IDEMPOTENCY_IN_PROGRESS",
    RequestOutcome.VERSION_CONFLICT: "JOURNEY_VERSION_CONFLICT",
}


def etag(version: int) -> str:
    return f'"{version}"'


def parse_if_match(header: Optional[str]) -> Optional[int]:
    """Returns the version, or None when the header is absent. Raises ValueError when malformed.

    Accepts ``"3"``, ``W/"3"`` and ``3``. Rejects ``*``, lists, zero, signs and absurd values so a
    wildcard can never switch the check off.
    """
    if header is None or not header.strip():
        return None
    match = _IF_MATCH_PATTERN.match(header.strip())
    if not match:
        raise ValueError("If-Match must be the journey version, e.g. \"3\".")
    version = int(match.group(1))
    if version < 1 or version > MAX_VERSION:
        raise ValueError("If-Match version is out of range.")
    return version


def key_is_valid(key: str) -> bool:
    return bool(_KEY_PATTERN.match(key))


def canonical_request_hash(operation: str, body: Optional[Mapping[str, Any]], *, secret: Optional[bytes] = None) -> str:
    """SHA-256 (HMAC when ``secret`` is supplied) of the canonical operation + request body.

    Use the keyed form when the body carries credentials (e.g. a password) so the stored hash cannot
    be used to test guesses offline.
    """
    canonical = json.dumps({"op": operation, "body": body}, sort_keys=True, separators=(",", ":"), default=str).encode()
    if secret is not None:
        return hmac.new(secret, canonical, hashlib.sha256).hexdigest()
    return hashlib.sha256(canonical).hexdigest()


@dataclass(frozen=True)
class StoredKey:
    operation: str
    actor: str
    request_hash: str
    status: str            # 'in_progress' | 'completed'
    expires_at: datetime


@dataclass(frozen=True)
class RequestPlan:
    outcome: RequestOutcome
    parsed_version: Optional[int] = None

    @property
    def http_status(self) -> int:
        return HTTP_STATUS[self.outcome]

    @property
    def error_code(self) -> Optional[str]:
        return ERROR_CODE.get(self.outcome)

    @property
    def proceeds(self) -> bool:
        return self.outcome is RequestOutcome.EXECUTE


def plan_mutation(
    *,
    operation: str,
    actor: str,
    authorized: bool,
    idempotency_key: Optional[str],
    if_match: Optional[str],
    request_hash: str,
    stored_key: Optional[StoredKey],
    current_version: int,
    now: datetime,
) -> RequestPlan:
    """Decide what a state-changing v2 request may do. ``stored_key`` must be looked up by the caller
    only AFTER ``authorized`` is established (the lookup is scoped to the session)."""
    if not authorized:
        return RequestPlan(RequestOutcome.FORBIDDEN)

    key_required = operation in IDEMPOTENT_OPERATIONS
    if key_required:
        if idempotency_key is None or not idempotency_key.strip():
            return RequestPlan(RequestOutcome.IDEMPOTENCY_KEY_REQUIRED)
        if not key_is_valid(idempotency_key):
            return RequestPlan(RequestOutcome.IDEMPOTENCY_KEY_INVALID)

    try:
        expected = parse_if_match(if_match)
    except ValueError:
        return RequestPlan(RequestOutcome.IF_MATCH_INVALID)
    if expected is None:
        return RequestPlan(RequestOutcome.IF_MATCH_REQUIRED)

    if key_required and stored_key is not None and stored_key.expires_at > now:
        if (
            stored_key.operation != operation
            or stored_key.actor != actor
            or not hmac.compare_digest(stored_key.request_hash, request_hash)
        ):
            return RequestPlan(RequestOutcome.IDEMPOTENCY_KEY_REUSED, expected)
        if stored_key.status == "completed":
            return RequestPlan(RequestOutcome.REPLAY, expected)
        return RequestPlan(RequestOutcome.IDEMPOTENCY_IN_PROGRESS, expected)

    if expected != current_version:
        return RequestPlan(RequestOutcome.VERSION_CONFLICT, expected)
    return RequestPlan(RequestOutcome.EXECUTE, expected)
