"""Typed, validated draft data for each v2 journey step (CRX-FE-003 WP2).

Every model forbids unknown fields. Existing commerce validators are reused so onboarding drafts obey
exactly the rules the merchant-operations endpoints apply after launch.
"""

from __future__ import annotations

import enum
import re
from decimal import Decimal
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator

from app.contexts.commerce.domain import payment_methods as pm
from app.contexts.commerce.domain.currency_rules import normalize_currency
from app.contexts.commerce.domain.merchant_payment_rules import CONNECTABLE_PROVIDERS
from app.contexts.onboarding.domain.journey_v2 import V2Step
from app.utils.slug import normalize_storefront_slug

_EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,189}\.[^@\s]{2,}$")
_E164 = re.compile(r"^\+[1-9][0-9]{6,14}$")
_ACCENT = re.compile(r"^#[0-9a-fA-F]{6}$")


def _normalize(value: str) -> str:
    return " ".join(value.split())


def _blank_to_none(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    value = _normalize(value)
    return value or None


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class SalesChannel(str, enum.Enum):
    WHATSAPP = "whatsapp"
    INSTAGRAM = "instagram"
    FACEBOOK = "facebook"
    PHYSICAL_STORE = "physical_store"
    MARKETPLACE = "marketplace"
    WEBSITE = "website"
    OTHER = "other"


class SalesChannelsData(_Strict):
    channels: list[SalesChannel] = Field(max_length=8)

    @field_validator("channels")
    @classmethod
    def _unique(cls, value):
        if len(set(value)) != len(value):
            raise ValueError("Each sales channel can be listed once.")
        return value


class CategoryData(_Strict):
    """INTERIM: free text until a Control Center-governed category catalogue exists (CRX-FE-003 D5).
    Kept as a plain normalised string so existing merchant records migrate without change."""

    category: str = Field(min_length=1, max_length=60)

    @field_validator("category")
    @classmethod
    def _clean(cls, value: str) -> str:
        value = _normalize(value)
        if len(value) < 2:
            raise ValueError("Enter a category of at least 2 characters.")
        return value


class BusinessInfoData(_Strict):
    business_name: str = Field(min_length=1, max_length=120)
    country: Literal["NG", "GH", "KE", "ZA"]
    currency: str = Field(min_length=3, max_length=3)

    @field_validator("business_name")
    @classmethod
    def _name(cls, value: str) -> str:
        value = _normalize(value)
        if len(value) < 2:
            raise ValueError("Enter your business name (at least 2 characters).")
        return value

    @field_validator("currency")
    @classmethod
    def _currency(cls, value: str) -> str:
        return normalize_currency(value)  # NGN / GHS / KES / ZAR only


class ContactData(_Strict):
    support_email: str = Field(max_length=254)
    phone: Optional[str] = Field(default=None, max_length=20)
    address: Optional[str] = Field(default=None, max_length=300)
    city: Optional[str] = Field(default=None, max_length=100)

    @field_validator("support_email")
    @classmethod
    def _email(cls, value: str) -> str:
        value = value.strip().lower()
        if not _EMAIL.match(value):
            raise ValueError("Enter a valid support email address.")
        return value

    @field_validator("phone")
    @classmethod
    def _phone(cls, value: Optional[str]) -> Optional[str]:
        value = _blank_to_none(value)
        if value is None:
            return None
        compact = value.replace(" ", "")
        if not _E164.match(compact):
            raise ValueError("Enter the phone number in international format, e.g. +2348012345678.")
        return compact

    @field_validator("address", "city")
    @classmethod
    def _optional_text(cls, value: Optional[str]) -> Optional[str]:
        return _blank_to_none(value)


class PaymentSetupData(_Strict):
    """Step 08: the merchant's OWN customer-payment setup. Not the CruxNexus subscription payment.

    ``offline_only`` is a real configuration (validated bank-transfer details and/or pay on delivery)
    and never counts as a connected online provider.
    """

    decision: Literal["connect", "offline_only", "skip"]
    provider: Optional[str] = None
    credentials: Optional[dict[str, SecretStr]] = Field(default=None, repr=False)
    offline_methods: list[Literal["bank_transfer", "pay_on_delivery"]] = Field(default_factory=list)
    bank_transfer_details: Optional[dict] = None
    bank_transfer_window_hours: Optional[int] = None

    @model_validator(mode="after")
    def _consistent(self):
        d = self.decision
        has_online = self.provider is not None or self.credentials is not None
        has_offline = bool(self.offline_methods) or self.bank_transfer_details is not None or self.bank_transfer_window_hours is not None
        if d == "skip":
            if has_online or has_offline:
                raise ValueError("A skipped payment setup cannot carry provider or offline settings.")
        elif d == "connect":
            if self.provider not in CONNECTABLE_PROVIDERS:
                raise ValueError(f"provider must be one of {', '.join(CONNECTABLE_PROVIDERS)}.")
            if not self.credentials:
                raise ValueError("credentials are required to connect a provider.")
            if has_offline:
                raise ValueError("Offline settings belong to the offline_only decision.")
        else:  # offline_only
            if has_online:
                raise ValueError("offline_only cannot carry provider credentials.")
            if not self.offline_methods:
                raise ValueError("Choose at least one offline payment method.")
            if len(set(self.offline_methods)) != len(self.offline_methods):
                raise ValueError("Each offline method can be listed once.")
            if "bank_transfer" in self.offline_methods:
                if not self.bank_transfer_details:
                    raise ValueError("Bank transfer requires complete bank details.")
                self.bank_transfer_details = pm.validate_bank_transfer_details(self.bank_transfer_details)
                self.bank_transfer_window_hours = pm.validate_bank_window_hours(
                    self.bank_transfer_window_hours if self.bank_transfer_window_hours is not None else pm.DEFAULT_BANK_WINDOW_HOURS
                )
            elif self.bank_transfer_details is not None or self.bank_transfer_window_hours is not None:
                raise ValueError("Bank details were supplied but bank transfer was not selected.")
        return self

    @property
    def counts_as_online_provider(self) -> bool:
        return self.decision == "connect"

    def public_data(self) -> dict:
        """Everything that may be stored in the session payload. Credentials are excluded: they are
        encrypted separately on receipt and never appear in payload, logs or responses."""
        data = self.model_dump(mode="json", exclude={"credentials"})
        data["has_credentials"] = self.credentials is not None
        return data


class DeliverySetupData(_Strict):
    pickup_enabled: bool
    delivery_enabled: bool

    @model_validator(mode="after")
    def _at_least_one(self):
        if not (self.pickup_enabled or self.delivery_enabled):
            raise ValueError("Enable pickup or delivery, or skip this step.")
        return self


class FirstProductData(_Strict):
    title: str = Field(min_length=1, max_length=160)
    price: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    starting_stock: int = Field(ge=0, le=1_000_000)
    # D4: no upload/storage exists, so no image reference is accepted. No placeholder values.
    image_ref: None = None

    @field_validator("title")
    @classmethod
    def _title(cls, value: str) -> str:
        value = _normalize(value)
        if len(value) < 2:
            raise ValueError("Enter a product title (at least 2 characters).")
        return value


class BrandingData(_Strict):
    display_name: str = Field(min_length=1, max_length=120)
    slug: Optional[str] = Field(default=None, max_length=80)
    accent: Optional[str] = None
    logo_ref: None = None  # D4: no storage yet

    @field_validator("display_name")
    @classmethod
    def _display(cls, value: str) -> str:
        value = _normalize(value)
        if len(value) < 2:
            raise ValueError("Enter a storefront name (at least 2 characters).")
        return value

    @field_validator("slug")
    @classmethod
    def _slug(cls, value: Optional[str]) -> Optional[str]:
        if value is None or not value.strip():
            return None
        normalized = normalize_storefront_slug(value)
        if len(normalized) < 3:
            raise ValueError("The storefront address must have at least 3 letters or numbers.")
        return normalized

    @field_validator("accent")
    @classmethod
    def _accent(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        if not _ACCENT.match(value):
            raise ValueError("Accent colour must be a hex value like #1D7F48.")
        return value.lower()


STEP_SCHEMAS: dict[V2Step, type[BaseModel]] = {
    V2Step.SALES_CHANNELS: SalesChannelsData,
    V2Step.CATEGORY: CategoryData,
    V2Step.BUSINESS_INFO: BusinessInfoData,
    V2Step.CONTACT: ContactData,
    V2Step.PAYMENT_SETUP: PaymentSetupData,
    V2Step.DELIVERY_SETUP: DeliverySetupData,
    V2Step.FIRST_PRODUCT: FirstProductData,
    V2Step.BRANDING: BrandingData,
}
