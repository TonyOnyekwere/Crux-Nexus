"""Persistence for the v2 onboarding journey (CRX-FE-003 WP1). See migration 049."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, Column, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID

from app.database import Base


class OnboardingIdempotencyKey(Base):
    """Replay record bound to session + operation + actor + request hash.

    Written in the same transaction as the operation it protects (status 'in_progress'), finalised
    with the result in that same transaction. Never stores credentials or tokens.
    """

    __tablename__ = "onboarding_idempotency_keys"
    __table_args__ = (
        UniqueConstraint("session_id", "key", name="uq_onboarding_idempotency_session_key"),
        CheckConstraint("status IN ('in_progress', 'completed')", name="ck_onboarding_idempotency_status"),
        CheckConstraint("char_length(key) BETWEEN 16 AND 128", name="ck_onboarding_idempotency_key_length"),
        CheckConstraint("char_length(request_hash) = 64", name="ck_onboarding_idempotency_hash_length"),
        CheckConstraint(
            "(status = 'completed') = (response_status IS NOT NULL)", name="ck_onboarding_idempotency_completed_result"
        ),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = Column(UUID(as_uuid=True), ForeignKey("onboarding_sessions.id", ondelete="CASCADE"), nullable=False)
    key = Column(String(128), nullable=False)
    operation = Column(String(60), nullable=False)
    actor = Column(String(80), nullable=False)
    request_hash = Column(String(64), nullable=False)
    status = Column(String(20), nullable=False, default="in_progress")
    response_status = Column(Integer, nullable=True)
    response_body = Column(JSONB, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    expires_at = Column(DateTime(timezone=True), nullable=False)


class OnboardingSlugReservation(Base):
    """Short-lived hold on a storefront slug. Expired rows never block: claims replace them."""

    __tablename__ = "onboarding_slug_reservations"
    __table_args__ = (
        UniqueConstraint("slug_normalized", name="uq_onboarding_slug_reservations_slug"),
        UniqueConstraint("session_id", name="uq_onboarding_slug_reservations_session"),
        CheckConstraint("slug_normalized = lower(slug_normalized)", name="ck_onboarding_slug_reservations_lower"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    slug_normalized = Column(String(64), nullable=False)
    session_id = Column(UUID(as_uuid=True), ForeignKey("onboarding_sessions.id", ondelete="CASCADE"), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
