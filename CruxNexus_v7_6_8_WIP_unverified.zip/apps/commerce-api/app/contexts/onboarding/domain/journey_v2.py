"""v2 onboarding journey: stages, steps and the server-owned transition rules (CRX-FE-003 WP2).

Pure domain, standard library only. Nothing here reads a client-supplied stage or step *completion*:
the client names the step it is submitting; whether that is legal, and what stage results, is decided
here from the stage the server already holds plus server-computed facts.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Optional

FLOW_VERSION = "v2"


class V2Stage(str, enum.Enum):
    SALES_CHANNELS = "SALES_CHANNELS"
    CATEGORY = "CATEGORY"
    BUSINESS_INFO = "BUSINESS_INFO"
    ACCOUNT = "ACCOUNT"
    VERIFICATION = "VERIFICATION"
    CONTACT = "CONTACT"
    PAYMENT_SETUP = "PAYMENT_SETUP"
    DELIVERY_SETUP = "DELIVERY_SETUP"
    FIRST_PRODUCT = "FIRST_PRODUCT"
    BRANDING = "BRANDING"
    REVIEW = "REVIEW"
    TIER_SELECTION = "TIER_SELECTION"
    SUBSCRIPTION_CHOICE = "SUBSCRIPTION_CHOICE"
    PAYMENT_PENDING = "PAYMENT_PENDING"
    READY_TO_LAUNCH = "READY_TO_LAUNCH"
    LAUNCHING = "LAUNCHING"
    COMPLETED = "COMPLETED"


STAGE_ORDER: tuple[V2Stage, ...] = tuple(V2Stage)


def stage_index(stage: V2Stage) -> int:
    return STAGE_ORDER.index(stage)


class V2Step(str, enum.Enum):
    """Typed draft-data steps. Each is written through its own validated endpoint."""

    SALES_CHANNELS = "sales_channels"
    CATEGORY = "category"
    BUSINESS_INFO = "business_info"
    CONTACT = "contact"
    PAYMENT_SETUP = "payment_setup"
    DELIVERY_SETUP = "delivery_setup"
    FIRST_PRODUCT = "first_product"
    BRANDING = "branding"


STEP_STAGE: dict[V2Step, V2Stage] = {
    V2Step.SALES_CHANNELS: V2Stage.SALES_CHANNELS,
    V2Step.CATEGORY: V2Stage.CATEGORY,
    V2Step.BUSINESS_INFO: V2Stage.BUSINESS_INFO,
    V2Step.CONTACT: V2Stage.CONTACT,
    V2Step.PAYMENT_SETUP: V2Stage.PAYMENT_SETUP,
    V2Step.DELIVERY_SETUP: V2Stage.DELIVERY_SETUP,
    V2Step.FIRST_PRODUCT: V2Stage.FIRST_PRODUCT,
    V2Step.BRANDING: V2Stage.BRANDING,
}

# Only these may be skipped through the skip endpoint. Payment setup records an explicit
# "skip" decision inside its own typed payload instead.
OPTIONAL_STEPS = frozenset({V2Step.SALES_CHANNELS, V2Step.DELIVERY_SETUP})

# Steps writable before an account exists (device-token custody). Nothing commercial or sensitive.
ANONYMOUS_STEPS = frozenset({V2Step.SALES_CHANNELS, V2Step.CATEGORY, V2Step.BUSINESS_INFO})

# Draft steps may be re-submitted until launch is claimed.
_LAST_EDITABLE_STAGE = V2Stage.READY_TO_LAUNCH


class V2Action(str, enum.Enum):
    SUBMIT_STEP = "submit_step"
    SKIP_STEP = "skip_step"
    REGISTER = "register"
    REQUEST_OTP = "request_otp"
    VERIFY_OTP = "verify_otp"
    CHECK_SLUG = "check_slug"
    RUN_REVIEW = "run_review"
    CONFIRM_REVIEW = "confirm_review"
    SELECT_PLAN = "select_plan"
    START_TRIAL = "start_trial"
    START_PAYMENT = "start_payment"
    LAUNCH = "launch"


class V2Event(str, enum.Enum):
    """Server-originated facts. No client endpoint can raise these."""

    PAYMENT_CONFIRMED = "payment_confirmed"
    LAUNCH_SUCCEEDED = "launch_succeeded"
    LAUNCH_FAILED = "launch_failed"
    LAUNCH_LEASE_EXPIRED = "launch_lease_expired"


@dataclass(frozen=True)
class Facts:
    """Server-computed inputs to the rules. The client can influence none of them directly."""

    review_clean: bool = False          # last server review found no issues and no edit happened since
    trial_available: bool = False       # plan.trial_days > 0 and no trial ever used by this merchant
    payment_retry_allowed: bool = True  # no unresolved pending provider attempt blocks a new one
    launch_lease_live: bool = False     # another launch attempt holds an unexpired lease
    completed_steps: frozenset[V2Step] = field(default_factory=frozenset)


class InvalidV2TransitionError(ValueError):
    def __init__(self, stage: V2Stage, action: "V2Action | V2Event", allowed: list[V2Action]):
        self.stage = stage
        self.action = action
        self.allowed_actions = allowed
        super().__init__(
            f"'{action.value}' is not allowed from stage {stage.value}. "
            f"Allowed: {[a.value for a in allowed] or 'none'}."
        )


class StepNotAllowedError(ValueError):
    def __init__(self, stage: V2Stage, step: V2Step, allowed_steps: list[V2Step], reason: str):
        self.stage = stage
        self.step = step
        self.allowed_steps = allowed_steps
        self.reason = reason
        super().__init__(f"Step '{step.value}' cannot be written at stage {stage.value}: {reason}.")


class StepNotOptionalError(ValueError):
    def __init__(self, step: V2Step):
        self.step = step
        super().__init__(f"Step '{step.value}' is required and cannot be skipped.")


@dataclass(frozen=True)
class StepOutcome:
    stage: V2Stage
    review_invalidated: bool
    kind: str  # "advance" (current step) or "edit" (earlier step re-submitted)


def _next_stage(stage: V2Stage) -> V2Stage:
    return STAGE_ORDER[stage_index(stage) + 1]


# ----------------------------------------------------------------------------- steps

def step_access(stage: V2Stage, step: V2Step) -> str:
    """'current' | 'edit' | 'denied:<reason>' for writing ``step`` while the session is at ``stage``."""
    target = STEP_STAGE[step]
    if stage_index(stage) < stage_index(target):
        return "denied:future_step"
    if stage is target:
        return "current"
    if stage_index(stage) > stage_index(_LAST_EDITABLE_STAGE):
        return "denied:launch_started"
    return "edit"


def allowed_steps(stage: V2Stage, *, authenticated: bool) -> list[V2Step]:
    out = [s for s in V2Step if step_access(stage, s) in ("current", "edit")]
    if not authenticated:
        # Device-token custody ends at registration and covers only non-sensitive pre-account steps.
        if stage_index(stage) > stage_index(V2Stage.ACCOUNT):
            return []
        out = [s for s in out if s in ANONYMOUS_STEPS]
    return out


def plan_step_submit(stage: V2Stage, step: V2Step, *, authenticated: bool) -> StepOutcome:
    allowed = allowed_steps(stage, authenticated=authenticated)
    if step not in allowed:
        access = step_access(stage, step)
        if not authenticated and step not in ANONYMOUS_STEPS:
            reason = "requires_account"
        elif not authenticated and stage_index(stage) > stage_index(V2Stage.ACCOUNT):
            reason = "device_session_retired"
        else:
            reason = access.split(":", 1)[1] if access.startswith("denied:") else "not_allowed"
        raise StepNotAllowedError(stage, step, allowed, reason)

    review_invalidated = stage_index(stage) >= stage_index(V2Stage.REVIEW)
    if step_access(stage, step) == "current":
        return StepOutcome(_next_stage(stage), review_invalidated=False, kind="advance")

    # Edit of an earlier step. Before payment is in flight the plan decision is re-opened by returning
    # to REVIEW; once a payment is pending or the subscription is entitled the stage is not regressed
    # (launch re-runs the review validation).
    if stage in (V2Stage.TIER_SELECTION, V2Stage.SUBSCRIPTION_CHOICE):
        return StepOutcome(V2Stage.REVIEW, review_invalidated=True, kind="edit")
    return StepOutcome(stage, review_invalidated=review_invalidated, kind="edit")


def plan_step_skip(stage: V2Stage, step: V2Step, *, authenticated: bool) -> StepOutcome:
    if step not in OPTIONAL_STEPS:
        raise StepNotOptionalError(step)
    return plan_step_submit(stage, step, authenticated=authenticated)


# --------------------------------------------------------------------------- actions

def allowed_actions(stage: V2Stage, facts: Facts = Facts(), *, authenticated: bool = True) -> list[V2Action]:
    actions: list[V2Action] = []
    if allowed_steps(stage, authenticated=authenticated):
        actions.append(V2Action.SUBMIT_STEP)
        if any(s in OPTIONAL_STEPS for s in allowed_steps(stage, authenticated=authenticated)):
            actions.append(V2Action.SKIP_STEP)

    if stage is V2Stage.ACCOUNT:
        actions.append(V2Action.REGISTER)
    elif stage is V2Stage.VERIFICATION:
        actions += [V2Action.REQUEST_OTP, V2Action.VERIFY_OTP]
    elif stage is V2Stage.REVIEW:
        actions.append(V2Action.RUN_REVIEW)
        if facts.review_clean:
            actions.append(V2Action.CONFIRM_REVIEW)
    elif stage is V2Stage.TIER_SELECTION:
        actions.append(V2Action.SELECT_PLAN)
    elif stage is V2Stage.SUBSCRIPTION_CHOICE:
        actions += [V2Action.SELECT_PLAN, V2Action.START_PAYMENT]
        if facts.trial_available:
            actions.append(V2Action.START_TRIAL)
    elif stage is V2Stage.PAYMENT_PENDING:
        if facts.payment_retry_allowed:
            actions.append(V2Action.START_PAYMENT)
    elif stage is V2Stage.READY_TO_LAUNCH:
        actions.append(V2Action.LAUNCH)
    elif stage is V2Stage.LAUNCHING:
        if not facts.launch_lease_live:
            actions.append(V2Action.LAUNCH)

    if stage_index(V2Stage.BRANDING) <= stage_index(stage) <= stage_index(_LAST_EDITABLE_STAGE) and authenticated:
        actions.append(V2Action.CHECK_SLUG)
    return actions


def plan_action(stage: V2Stage, action: V2Action, facts: Facts = Facts()) -> V2Stage:
    """Stage that results from a non-step client action, or raise. Step writes use plan_step_*."""
    if action in (V2Action.SUBMIT_STEP, V2Action.SKIP_STEP):
        raise ValueError("Step writes are planned with plan_step_submit / plan_step_skip.")
    allowed = allowed_actions(stage, facts)
    if action not in allowed:
        raise InvalidV2TransitionError(stage, action, allowed)

    return {
        V2Action.REGISTER: V2Stage.VERIFICATION,
        V2Action.REQUEST_OTP: stage,
        V2Action.VERIFY_OTP: V2Stage.CONTACT,
        V2Action.CHECK_SLUG: stage,
        V2Action.RUN_REVIEW: stage,
        V2Action.CONFIRM_REVIEW: V2Stage.TIER_SELECTION,
        V2Action.SELECT_PLAN: V2Stage.SUBSCRIPTION_CHOICE,
        V2Action.START_TRIAL: V2Stage.READY_TO_LAUNCH,
        V2Action.START_PAYMENT: V2Stage.PAYMENT_PENDING,
        V2Action.LAUNCH: V2Stage.LAUNCHING,
    }[action]


_EVENT_FROM: dict[V2Event, tuple[frozenset[V2Stage], V2Stage]] = {
    V2Event.PAYMENT_CONFIRMED: (frozenset({V2Stage.PAYMENT_PENDING}), V2Stage.READY_TO_LAUNCH),
    V2Event.LAUNCH_SUCCEEDED: (frozenset({V2Stage.LAUNCHING}), V2Stage.COMPLETED),
    V2Event.LAUNCH_FAILED: (frozenset({V2Stage.LAUNCHING}), V2Stage.READY_TO_LAUNCH),
    V2Event.LAUNCH_LEASE_EXPIRED: (frozenset({V2Stage.LAUNCHING}), V2Stage.READY_TO_LAUNCH),
}


def apply_event(stage: V2Stage, event: V2Event) -> V2Stage:
    sources, target = _EVENT_FROM[event]
    if stage not in sources:
        raise InvalidV2TransitionError(stage, event, allowed_actions(stage))
    return target


_NEXT_ACTION: dict[V2Stage, Optional[str]] = {
    V2Stage.SALES_CHANNELS: "submit_step",
    V2Stage.CATEGORY: "submit_step",
    V2Stage.BUSINESS_INFO: "submit_step",
    V2Stage.ACCOUNT: "register",
    V2Stage.VERIFICATION: "verify_otp",
    V2Stage.CONTACT: "submit_step",
    V2Stage.PAYMENT_SETUP: "submit_step",
    V2Stage.DELIVERY_SETUP: "submit_step",
    V2Stage.FIRST_PRODUCT: "submit_step",
    V2Stage.BRANDING: "submit_step",
    V2Stage.REVIEW: "run_review",
    V2Stage.TIER_SELECTION: "select_plan",
    V2Stage.SUBSCRIPTION_CHOICE: "choose_subscription",
    V2Stage.PAYMENT_PENDING: "await_payment_confirmation",
    V2Stage.READY_TO_LAUNCH: "launch",
    V2Stage.LAUNCHING: "await_launch",
    V2Stage.COMPLETED: None,
}


def next_action(stage: V2Stage, facts: Facts = Facts()) -> Optional[str]:
    if stage is V2Stage.REVIEW and facts.review_clean:
        return "confirm_review"
    return _NEXT_ACTION[stage]


def next_step(stage: V2Stage) -> Optional[V2Step]:
    for step, target in STEP_STAGE.items():
        if target is stage:
            return step
    return None


def is_entitled_stage(stage: V2Stage) -> bool:
    """Stages reached only after verified payment evidence or an authorised trial."""
    return stage in (V2Stage.READY_TO_LAUNCH, V2Stage.LAUNCHING, V2Stage.COMPLETED)
