"""Merchant onboarding journey state machine (CRX-P0-030).

Kratos-approved MVP journey (supersedes the generic client-driven step
advance for flow_version "mvp1"; the locked architecture's trial/delivery/
first-product/branding steps are intentionally out of this MVP slice):

    REGISTERED -> OTP_VERIFIED -> MERCHANT_CREATED -> BUSINESS_CONFIGURED
      -> PLAN_SELECTED -> PAYMENT_PENDING -> PAYMENT_CONFIRMED
      -> STOREFRONT_READY -> COMPLETED

The client never names a stage. It performs an ACTION; this module is the
only place that decides whether that action is legal from the current
stage and what stage results. Pure functions, no I/O, so the rules are
unit-testable without a database. Preconditions that depend on real facts
(user verified, subscription active, ...) are enforced by JourneyService
against the database - the stored stage is never itself evidence.
"""

from __future__ import annotations

import enum
from typing import Optional

JOURNEY_FLOW_VERSION = "mvp1"


class JourneyStage(str, enum.Enum):
    REGISTERED = "REGISTERED"
    OTP_VERIFIED = "OTP_VERIFIED"
    MERCHANT_CREATED = "MERCHANT_CREATED"
    BUSINESS_CONFIGURED = "BUSINESS_CONFIGURED"
    PLAN_SELECTED = "PLAN_SELECTED"
    PAYMENT_PENDING = "PAYMENT_PENDING"
    PAYMENT_CONFIRMED = "PAYMENT_CONFIRMED"
    STOREFRONT_READY = "STOREFRONT_READY"
    COMPLETED = "COMPLETED"


STAGE_ORDER = list(JourneyStage)


def stage_index(stage: JourneyStage) -> int:
    return STAGE_ORDER.index(stage)


class JourneyAction(str, enum.Enum):
    VERIFY_OTP = "verify_otp"
    CREATE_MERCHANT = "create_merchant"
    CONFIGURE_BUSINESS = "configure_business"
    SELECT_PLAN = "select_plan"
    START_PAYMENT = "start_payment"
    CONFIRM_PAYMENT = "confirm_payment"  # system-derived only, no client endpoint
    CREATE_STOREFRONT = "create_storefront"
    COMPLETE = "complete"


# action -> stages it may be performed from
_ALLOWED_FROM: dict[JourneyAction, frozenset[JourneyStage]] = {
    JourneyAction.VERIFY_OTP: frozenset({JourneyStage.REGISTERED}),
    JourneyAction.CREATE_MERCHANT: frozenset({JourneyStage.OTP_VERIFIED}),
    JourneyAction.CONFIGURE_BUSINESS: frozenset(
        {
            JourneyStage.MERCHANT_CREATED,
            JourneyStage.BUSINESS_CONFIGURED,
            JourneyStage.PLAN_SELECTED,
            JourneyStage.PAYMENT_PENDING,
            JourneyStage.PAYMENT_CONFIRMED,  # e.g. slug taken at launch
        }
    ),
    # Not allowed from PAYMENT_PENDING: a charge for the old plan may be
    # live, and a late success would then activate a different plan than
    # was paid for.
    JourneyAction.SELECT_PLAN: frozenset({JourneyStage.BUSINESS_CONFIGURED, JourneyStage.PLAN_SELECTED}),
    JourneyAction.START_PAYMENT: frozenset({JourneyStage.PLAN_SELECTED, JourneyStage.PAYMENT_PENDING}),
    JourneyAction.CONFIRM_PAYMENT: frozenset({JourneyStage.PLAN_SELECTED, JourneyStage.PAYMENT_PENDING}),
    JourneyAction.CREATE_STOREFRONT: frozenset({JourneyStage.PAYMENT_CONFIRMED}),
    JourneyAction.COMPLETE: frozenset({JourneyStage.STOREFRONT_READY}),
}

_FIXED_TARGET: dict[JourneyAction, JourneyStage] = {
    JourneyAction.VERIFY_OTP: JourneyStage.OTP_VERIFIED,
    JourneyAction.CREATE_MERCHANT: JourneyStage.MERCHANT_CREATED,
    JourneyAction.SELECT_PLAN: JourneyStage.PLAN_SELECTED,
    JourneyAction.START_PAYMENT: JourneyStage.PAYMENT_PENDING,
    JourneyAction.CONFIRM_PAYMENT: JourneyStage.PAYMENT_CONFIRMED,
    JourneyAction.CREATE_STOREFRONT: JourneyStage.STOREFRONT_READY,
    JourneyAction.COMPLETE: JourneyStage.COMPLETED,
}

_NEXT_ACTION: dict[JourneyStage, Optional[str]] = {
    JourneyStage.REGISTERED: "verify_otp",
    JourneyStage.OTP_VERIFIED: "create_merchant",
    JourneyStage.MERCHANT_CREATED: "configure_business",
    JourneyStage.BUSINESS_CONFIGURED: "select_plan",
    JourneyStage.PLAN_SELECTED: "start_payment",
    JourneyStage.PAYMENT_PENDING: "await_payment_confirmation",
    JourneyStage.PAYMENT_CONFIRMED: "create_storefront",
    JourneyStage.STOREFRONT_READY: "complete",
    JourneyStage.COMPLETED: None,
}


class InvalidJourneyTransitionError(ValueError):
    def __init__(self, current: JourneyStage, action: JourneyAction):
        self.current = current
        self.action = action
        self.allowed_actions = allowed_actions(current)
        super().__init__(
            f"Action '{action.value}' is not allowed from stage {current.value}. "
            f"Allowed: {[a.value for a in self.allowed_actions] or 'none'}."
        )


def allowed_actions(current: JourneyStage) -> list[JourneyAction]:
    """Client-invocable actions from `current` (CONFIRM_PAYMENT is system-only)."""
    return [
        a
        for a, stages in _ALLOWED_FROM.items()
        if current in stages and a is not JourneyAction.CONFIRM_PAYMENT
    ]


def next_action(current: JourneyStage) -> Optional[str]:
    return _NEXT_ACTION[current]


def plan_transition(current: JourneyStage, action: JourneyAction) -> JourneyStage:
    """Stage that results from performing `action` at `current`, or raise."""
    if current not in _ALLOWED_FROM[action]:
        raise InvalidJourneyTransitionError(current, action)
    if action is JourneyAction.CONFIGURE_BUSINESS:
        # First configuration advances; later edits don't move the stage.
        return JourneyStage.BUSINESS_CONFIGURED if current is JourneyStage.MERCHANT_CREATED else current
    return _FIXED_TARGET[action]


def is_at_or_past(current: JourneyStage, target: JourneyStage) -> bool:
    return stage_index(current) >= stage_index(target)
