from datetime import datetime, timezone
import uuid

from sqlalchemy import Column, DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class MerchantOnboardingRequestRecord(Base):
    """Idempotency ledger for POST /api/v1/onboarding/journey/merchant.

    Migration 015 created this table ("merchant_onboarding_requests") with
    the stated goal of making onboarding idempotent, but no ORM model or
    application code ever referenced it — the idempotency_key column
    existed in the schema and nothing else. This model, together with the
    idempotency handling added to OnboardingService.onboard_merchant, is
    what actually makes retries safe: a client that retries a request with
    the same Idempotency-Key gets the original result replayed instead of
    either a duplicate merchant account or a confusing 409.

    Named *Record* to avoid colliding with the unrelated Pydantic request
    schema of the same base name in
    app.contexts.onboarding.api.schemas.MerchantOnboardingRequest.
    """

    __tablename__ = "merchant_onboarding_requests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    idempotency_key = Column(String(255), nullable=False, unique=True)

    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )

    plan_code = Column(String(50), nullable=False)

    # Migration 026: without this, the idempotency fingerprint comparison
    # in OnboardingService.onboard_merchant couldn't detect the same key
    # being reused with a different merchant_name - a real gap found in
    # external review.
    merchant_name = Column(String(255), nullable=True)

    storefront_slug = Column(String(100), nullable=False)

    merchant_account_id = Column(
        UUID(as_uuid=True),
        ForeignKey("merchant_accounts.id", ondelete="SET NULL"),
        nullable=True,
    )

    # pending -> completed, or pending -> failed. A failed request may be
    # retried with the same idempotency_key, which resets it to pending.
    status = Column(String(50), nullable=False, default="pending")

    completed_at = Column(DateTime(timezone=True), nullable=True)

    error_message = Column(Text, nullable=True)

    lease_owner = Column(String(120), nullable=True)
    lease_expires_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
