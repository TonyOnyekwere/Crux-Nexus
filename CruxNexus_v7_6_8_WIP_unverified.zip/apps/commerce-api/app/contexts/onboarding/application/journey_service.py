"""Merchant onboarding journey service (CRX-P0-030).

Every public method is one client ACTION. The client never supplies a
stage: stage legality comes from domain/journey.py, and every precondition
that matters is re-checked against real rows (user status, subscription
status, tenant ownership) - the stored stage is a cursor, not evidence.

Concurrency: each mutating action first takes a row lock on the caller's
onboarding session (SELECT ... FOR UPDATE), so two concurrent actions for
one journey serialise instead of racing.
"""

from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import create_global_access_token
from app.config import get_settings
from app.contexts.billing.application.subscription_payment_service import SubscriptionPaymentService
from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.financial_transaction import PaymentProvider
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.identity.application.services import IdentityService
from app.contexts.identity.domain.entities import User, UserStatus
from app.contexts.merchant_management.domain.entities import MerchantAccount
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.merchant_management.domain.merchant_account_user import MerchantAccountUser, MerchantUserRole
from app.contexts.onboarding.domain.journey import (
    JOURNEY_FLOW_VERSION,
    JourneyAction,
    JourneyStage,
    InvalidJourneyTransitionError,
    allowed_actions,
    is_at_or_past,
    next_action,
    plan_transition,
)
from app.contexts.onboarding.domain.onboarding_session import (
    OnboardingSession,
    OnboardingSessionStatus,
)
from app.contexts.tenant_management.application.services import TenantService
from app.contexts.tenant_management.domain.entities import Tenant
from app.contexts.tenant_management.domain.membership import MembershipStatus, TenantMembership, TenantRole
from app.contexts.commerce import StorefrontProfile
from app.kernel.events.publisher import publish_to_outbox
from app.kernel.events.types import DomainEvent, EventEnvelope
from app.utils.slug import normalize_storefront_slug

logger = logging.getLogger(__name__)

SESSION_TTL = timedelta(days=7)

class JourneyError(ValueError):
    """Business-rule failure with a machine-readable code."""

    def __init__(self, code: str, message: str, status_hint: int = 400):
        super().__init__(message)
        self.code = code
        self.status_hint = status_hint


class JourneyService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ session
    async def _lock_session(self, user_id: UUID) -> OnboardingSession:
        result = await self.db.execute(
            select(OnboardingSession)
            .where(
                OnboardingSession.owner_user_id == user_id,
                OnboardingSession.flow_version == JOURNEY_FLOW_VERSION,
                OnboardingSession.status.in_(
                    [OnboardingSessionStatus.IN_PROGRESS.value, OnboardingSessionStatus.COMPLETED.value]
                ),
            )
            .order_by(OnboardingSession.created_at.desc())
            .limit(1)
            .with_for_update()
        )
        session = result.scalar_one_or_none()
        if session is not None:
            return session
        return await self._create_session_for_existing_user(user_id)

    async def _create_session_for_existing_user(self, user_id: UUID) -> OnboardingSession:
        user = await self._get_user(user_id)
        stage = JourneyStage.OTP_VERIFIED if user.status == UserStatus.ACTIVE else JourneyStage.REGISTERED
        return await self._new_session(user, stage)

    async def _new_session(self, user: User, stage: JourneyStage) -> OnboardingSession:
        session = OnboardingSession(
            device_session_token=secrets.token_urlsafe(32),
            owner_email=user.email,
            owner_user_id=user.id,
            flow_version=JOURNEY_FLOW_VERSION,
            current_step=stage.value,
            completed_steps=[],
            payload={},
            status=OnboardingSessionStatus.IN_PROGRESS.value,
            version=1,
            expires_at=datetime.now(timezone.utc) + SESSION_TTL,
        )
        self.db.add(session)
        try:
            await self.db.flush()
        except IntegrityError:
            # uq_one_open_onboarding_session_per_owner: a concurrent request
            # created it first - use that one.
            await self.db.rollback()
            result = await self.db.execute(
                select(OnboardingSession)
                .where(
                    OnboardingSession.owner_user_id == user.id,
                    OnboardingSession.flow_version == JOURNEY_FLOW_VERSION,
                )
                .order_by(OnboardingSession.created_at.desc())
                .limit(1)
                .with_for_update()
            )
            return result.scalar_one()
        return session

    async def _get_user(self, user_id: UUID) -> User:
        user = (await self.db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
        if user is None:
            raise JourneyError("USER_NOT_FOUND", "User not found.", 404)
        return user

    def _stage(self, session: OnboardingSession) -> JourneyStage:
        return JourneyStage(session.current_step)

    def _apply(self, session: OnboardingSession, action: JourneyAction, **payload_updates) -> JourneyStage:
        """Validate `action` against the machine and move the cursor."""
        current = self._stage(session)
        try:
            target = plan_transition(current, action)
        except InvalidJourneyTransitionError as exc:
            raise JourneyError("INVALID_JOURNEY_TRANSITION", str(exc), 409) from exc
        if target != current:
            completed = list(session.completed_steps or [])
            if current.value not in completed:
                completed.append(current.value)
            session.completed_steps = completed
        session.current_step = target.value
        session.payload = {**(session.payload or {}), **payload_updates}
        session.version = (session.version or 1) + 1
        session.updated_at = datetime.now(timezone.utc)
        return target

    def _snapshot(self, session: OnboardingSession) -> dict:
        stage = self._stage(session)
        payload = session.payload or {}
        return {
            "session_id": str(session.id),
            "stage": stage.value,
            "next_action": next_action(stage),
            "allowed_actions": [a.value for a in allowed_actions(stage)],
            "completed_stages": session.completed_steps or [],
            "business": payload.get("business"),
            "plan_code": payload.get("plan_code"),
            "merchant_account_id": payload.get("merchant_account_id"),
            "tenant_id": str(session.tenant_id) if session.tenant_id else None,
            "payment_reference": payload.get("payment_reference"),
            "version": session.version,
        }

    # -------------------------------------------------------------- 1. register
    async def register(self, *, email: str, password: str) -> dict:
        try:
            user = await IdentityService(self.db).create_user(email=email, password=password)
        except ValueError as exc:
            raise JourneyError("EMAIL_ALREADY_REGISTERED", str(exc), 409) from exc
        session = await self._new_session(user, JourneyStage.REGISTERED)
        await self.db.commit()
        return {
            "access_token": create_global_access_token(user_id=user.id, email=user.email),
            "token_type": "bearer",
            "journey": self._snapshot(session),
        }

    async def state(self, user_id: UUID) -> dict:
        session = await self._lock_session(user_id)
        await self._sync_payment_stage(session)
        await self.db.commit()
        return self._snapshot(session)

    # ------------------------------------------------------------------- 2. OTP
    async def confirm_otp(self, user_id: UUID, code: str) -> dict:
        """The OTP code itself is checked by OTPService (route layer maps its
        errors). This advances the journey only if the user row is really
        ACTIVE afterwards."""
        from app.contexts.identity.application.otp_service import OTPService

        session = await self._lock_session(user_id)
        stage = self._stage(session)
        if stage is not JourneyStage.REGISTERED:
            raise JourneyError(
                "INVALID_JOURNEY_TRANSITION",
                f"OTP verification is not applicable at stage {stage.value}.",
                409,
            )
        await OTPService(self.db).verify_code(user_id=user_id, submitted_code=code)
        # verify_code commits and releases the session lock; take it again.
        session = await self._lock_session(user_id)
        user = await self._get_user(user_id)
        if user.status != UserStatus.ACTIVE:
            raise JourneyError("USER_NOT_VERIFIED", "Verification did not complete.", 409)
        if self._stage(session) is JourneyStage.REGISTERED:
            self._apply(session, JourneyAction.VERIFY_OTP)
        await self.db.commit()
        return self._snapshot(session)

    async def _require_verified(self, user_id: UUID) -> None:
        user = await self._get_user(user_id)
        if user.status != UserStatus.ACTIVE:
            raise JourneyError("USER_NOT_VERIFIED", "Verify your account with the one-time code first.", 403)

    # ------------------------------------------------------ 3. merchant account
    async def create_merchant(self, user_id: UUID, business_name: str) -> dict:
        await self._require_verified(user_id)
        session = await self._lock_session(user_id)
        stage = self._stage(session)

        existing = await self._owned_merchant(user_id)
        if existing is not None and stage is JourneyStage.OTP_VERIFIED:
            # Crash/retry between provisioning and cursor update: reconcile.
            self._apply(session, JourneyAction.CREATE_MERCHANT, merchant_account_id=str(existing.id))
            await self.db.commit()
            return self._snapshot(session)
        if existing is not None:
            raise JourneyError("MERCHANT_ALREADY_EXISTS", "A merchant account already exists for this user.", 409)

        self._apply(session, JourneyAction.CREATE_MERCHANT)  # validates stage first
        name = business_name.strip()
        if not name:
            raise JourneyError("VALIDATION", "Business name is required.", 422)
        try:
            merchant = MerchantAccount(name=name, status="active")
            self.db.add(merchant)
            await self.db.flush()
            self.db.add(
                MerchantAccountUser(
                    merchant_account_id=merchant.id, user_id=user_id, role=MerchantUserRole.OWNER.value
                )
            )
            await self.db.flush()
            session.payload = {**session.payload, "merchant_account_id": str(merchant.id), "business_name": name}
            await publish_to_outbox(
                self.db,
                EventEnvelope(
                    event_type=DomainEvent.MERCHANT_CREATED,
                    aggregate_type="MerchantAccount",
                    aggregate_id=merchant.id,
                    payload={"merchant_name": name, "user_id": str(user_id)},
                ),
            )
            await self.db.commit()
        except IntegrityError as exc:
            await self.db.rollback()
            raise JourneyError("MERCHANT_ALREADY_EXISTS", "A merchant account already exists for this user.", 409) from exc
        return self._snapshot(session)

    async def _owned_merchant(self, user_id: UUID) -> Optional[MerchantAccount]:
        return (
            await self.db.execute(
                select(MerchantAccount)
                .join(MerchantAccountUser, MerchantAccountUser.merchant_account_id == MerchantAccount.id)
                .where(
                    MerchantAccountUser.user_id == user_id,
                    MerchantAccountUser.role == MerchantUserRole.OWNER.value,
                )
                .limit(1)
            )
        ).scalar_one_or_none()

    async def _require_merchant(self, user_id: UUID, session: OnboardingSession) -> MerchantAccount:
        merchant = await self._owned_merchant(user_id)
        if merchant is None or str((session.payload or {}).get("merchant_account_id")) != str(merchant.id):
            raise JourneyError("MERCHANT_REQUIRED", "Create your merchant account first.", 409)
        return merchant

    # --------------------------------------------------------- 4. business/store
    async def configure_business(
        self,
        user_id: UUID,
        *,
        storefront_slug: Optional[str],
        category: Optional[str],
        contact_phone: Optional[str],
        city: Optional[str],
        address: Optional[str],
    ) -> dict:
        await self._require_verified(user_id)
        session = await self._lock_session(user_id)
        merchant = await self._require_merchant(user_id, session)
        requested_slug = storefront_slug or merchant.name
        try:
            slug = normalize_storefront_slug(requested_slug)
        except ValueError as exc:
            raise JourneyError("INVALID_SLUG", str(exc), 422) from exc
        # Friendly early check only; tenants.slug UNIQUE is the real guard
        # and is enforced again when the storefront is created.
        taken = (
            await self.db.execute(select(Tenant.id).where(func.lower(Tenant.slug) == slug))
        ).scalar_one_or_none()
        if taken is not None and str(taken) != str(session.tenant_id or ""):
            raise JourneyError("SLUG_TAKEN", f"Storefront address '{slug}' is already in use.", 409)

        self._apply(
            session,
            JourneyAction.CONFIGURE_BUSINESS,
            business={
                "storefront_slug": slug,
                "category": category,
                "contact_phone": contact_phone,
                "city": city,
                "address": address,
            },
        )
        await self.db.commit()
        return self._snapshot(session)

    # ----------------------------------------------------------- 5. plan select
    async def select_plan(self, user_id: UUID, plan_code: str) -> dict:
        await self._require_verified(user_id)
        session = await self._lock_session(user_id)
        merchant = await self._require_merchant(user_id, session)
        stage = self._stage(session)

        plan = (
            await self.db.execute(
                select(SubscriptionPlan).where(
                    func.lower(SubscriptionPlan.code) == plan_code.strip().lower(),
                    SubscriptionPlan.active.is_(True),
                )
            )
        ).scalar_one_or_none()
        if plan is None:
            raise JourneyError("PLAN_NOT_FOUND", f"Plan '{plan_code}' not found or inactive.", 404)

        # Changing plan is only legal while nothing has been paid.
        subscription = await self._current_subscription(merchant.id)
        if subscription is not None and subscription.status in (
            SubscriptionStatus.ACTIVE.value,
            SubscriptionStatus.TRIALING.value,
        ):
            raise JourneyError("PLAN_LOCKED", "A subscription is already active for this account.", 409)

        self._apply(session, JourneyAction.SELECT_PLAN, plan_code=plan.code)  # stage check

        if subscription is None:
            subscription = MerchantSubscription(
                merchant_account_id=merchant.id,
                subscription_plan_id=plan.id,
                status=SubscriptionStatus.PENDING_SELECTION.value,
            )
            self.db.add(subscription)
        else:
            subscription.subscription_plan_id = plan.id
            subscription.status = SubscriptionStatus.PENDING_SELECTION.value
        await self.db.flush()
        session.payload = {**session.payload, "subscription_id": str(subscription.id)}
        await self.db.commit()
        return self._snapshot(session)

    async def _current_subscription(self, merchant_account_id: UUID) -> Optional[MerchantSubscription]:
        return (
            await self.db.execute(
                select(MerchantSubscription)
                .where(MerchantSubscription.merchant_account_id == merchant_account_id)
                .order_by(MerchantSubscription.created_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()

    # --------------------------------------------------------------- 6. payment
    async def start_payment(self, user_id: UUID, *, provider: PaymentProvider) -> dict:
        await self._require_verified(user_id)
        session = await self._lock_session(user_id)
        merchant = await self._require_merchant(user_id, session)
        user = await self._get_user(user_id)

        stage = self._stage(session)
        if stage not in (JourneyStage.PLAN_SELECTED, JourneyStage.PAYMENT_PENDING):
            raise JourneyError(
                "INVALID_JOURNEY_TRANSITION", f"Payment cannot start from stage {stage.value}.", 409
            )

        from app.infrastructure.payments.adapter import get_payment_provider_registry

        if provider not in get_payment_provider_registry().available_providers():
            raise JourneyError("PROVIDER_NOT_AVAILABLE", "That payment provider is not available.", 400)

        subscription = await self._current_subscription(merchant.id)
        if subscription is None:
            raise JourneyError("PLAN_REQUIRED", "Select a plan first.", 409)

        # Release the session lock while talking to the provider: the
        # payment service commits internally and has its own row lock.
        session_id = session.id
        await self.db.commit()
        settings = get_settings()
        redirect_url = f"{settings.PUBLIC_APP_URL.rstrip('/')}/onboarding/payment/callback"
        result = await SubscriptionPaymentService(self.db).initiate_payment(
            merchant_account_id=merchant.id,
            subscription_id=subscription.id,
            merchant_email=user.email,
            provider=provider,
            redirect_url=redirect_url,
        )
        session = (
            await self.db.execute(
                select(OnboardingSession).where(OnboardingSession.id == session_id).with_for_update()
            )
        ).scalar_one()
        if self._stage(session) in (JourneyStage.PLAN_SELECTED, JourneyStage.PAYMENT_PENDING):
            self._apply(
                session,
                JourneyAction.START_PAYMENT,
                payment_reference=result["reference"],
                payment_provider=provider.value,
            )
        await self.db.commit()
        return {**self._snapshot(session), "checkout": result}

    async def _sync_payment_stage(self, session: OnboardingSession) -> None:
        """PAYMENT_PENDING -> PAYMENT_CONFIRMED, derived purely from the
        subscription row, which only a verified webhook/reconciliation can
        set to ACTIVE. No client action can cause this."""
        if self._stage(session) not in (JourneyStage.PLAN_SELECTED, JourneyStage.PAYMENT_PENDING):
            return
        merchant_id = (session.payload or {}).get("merchant_account_id")
        if not merchant_id:
            return
        subscription = await self._current_subscription(UUID(merchant_id))
        if subscription is not None and subscription.status == SubscriptionStatus.ACTIVE.value:
            self._apply(session, JourneyAction.CONFIRM_PAYMENT)

    # ------------------------------------------------------------- 7. storefront
    async def create_storefront(self, user_id: UUID) -> dict:
        await self._require_verified(user_id)
        session = await self._lock_session(user_id)
        merchant = await self._require_merchant(user_id, session)
        await self._sync_payment_stage(session)

        stage = self._stage(session)
        if stage is JourneyStage.STOREFRONT_READY:
            return self._snapshot(session)  # idempotent
        if stage is not JourneyStage.PAYMENT_CONFIRMED:
            raise JourneyError(
                "PAYMENT_NOT_CONFIRMED",
                "The storefront can only be created after payment is confirmed.",
                409,
            )
        # Re-prove the commercial precondition from the database itself.
        subscription = await self._current_subscription(merchant.id)
        if subscription is None or subscription.status not in (
            SubscriptionStatus.ACTIVE.value,
            SubscriptionStatus.TRIALING.value,
        ):
            raise JourneyError("SUBSCRIPTION_NOT_ACTIVE", "No active subscription.", 409)

        business = (session.payload or {}).get("business")
        if not business:
            raise JourneyError("BUSINESS_REQUIRED", "Business details are missing.", 409)
        slug = business["storefront_slug"]

        try:
            # Storefront provisioning is owned by TenantService. Onboarding
            # supplies the journey-specific business profile, but it does not
            # reimplement capacity, ownership, membership, or concurrency
            # rules. This keeps the onboarding path identical to the normal
            # storefront-provisioning path.
            tenant = await TenantService(self.db).create_storefront(
                merchant_account_id=merchant.id,
                owner_user_id=user_id,
                slug=slug,
            )
            self.db.add(
                StorefrontProfile(
                    tenant_id=tenant.id,
                    business_name=(session.payload or {}).get("business_name") or merchant.name,
                    category=business.get("category"),
                    phone=business.get("contact_phone"),
                    city=business.get("city"),
                    address=business.get("address"),
                    currency="NGN",
                    published=False,
                )
            )
            await self.db.flush()
            self._apply(session, JourneyAction.CREATE_STOREFRONT)
            session.tenant_id = tenant.id
            await publish_to_outbox(
                self.db,
                EventEnvelope(
                    event_type=DomainEvent.STOREFRONT_CREATED,
                    aggregate_type="Tenant",
                    aggregate_id=tenant.id,
                    payload={"merchant_account_id": str(merchant.id), "slug": slug},
                ),
            )
            await self.db.commit()
        except IntegrityError as exc:
            await self.db.rollback()
            raise JourneyError(
                "SLUG_TAKEN",
                f"Storefront address '{slug}' was taken. Choose another and try again.",
                409,
            ) from exc
        return self._snapshot(session)

    # ------------------------------------------------------------- 8. complete
    async def complete(self, user_id: UUID) -> dict:
        await self._require_verified(user_id)
        session = await self._lock_session(user_id)
        merchant = await self._require_merchant(user_id, session)
        if self._stage(session) is JourneyStage.COMPLETED:
            return {**self._snapshot(session), "tenant_id": str(session.tenant_id)}

        # Final cross-check of everything the "live" claim rests on.
        subscription = await self._current_subscription(merchant.id)
        owns_tenant = (
            await self.db.execute(
                select(TenantMembership.id)
                .join(MerchantAccountTenant, MerchantAccountTenant.tenant_id == TenantMembership.tenant_id)
                .where(
                    MerchantAccountTenant.merchant_account_id == merchant.id,
                    TenantMembership.user_id == user_id,
                    TenantMembership.role == TenantRole.OWNER.value,
                    TenantMembership.status == MembershipStatus.ACTIVE.value,
                )
                .limit(1)
            )
        ).scalar_one_or_none()
        if (
            subscription is None
            or subscription.status not in (SubscriptionStatus.ACTIVE.value, SubscriptionStatus.TRIALING.value)
            or owns_tenant is None
            or session.tenant_id is None
        ):
            raise JourneyError("ACTIVATION_PROOF_MISSING", "Activation requirements are not all satisfied.", 409)

        self._apply(session, JourneyAction.COMPLETE)
        session.status = OnboardingSessionStatus.COMPLETED.value
        await self.db.commit()
        return self._snapshot(session)
