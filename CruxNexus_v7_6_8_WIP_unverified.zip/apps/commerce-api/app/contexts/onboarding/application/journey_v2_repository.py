"""Race-safe persistence primitives for the v2 onboarding journey (CRX-FE-003 WP1)."""

from __future__ import annotations

import enum
from datetime import timedelta
from uuid import UUID

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.tenant_management.domain.entities import Tenant

SLUG_RESERVATION_TTL = timedelta(minutes=15)


class SlugClaim(str, enum.Enum):
    CLAIMED = "claimed"
    RESERVED_BY_OTHER = "reserved_by_other"
    TAKEN = "taken"


async def claim_slug(
    db: AsyncSession,
    *,
    session_id: UUID,
    slug: str,
    ttl: timedelta = SLUG_RESERVATION_TTL,
) -> SlugClaim:
    """Hold ``slug`` for an onboarding session, or report why it cannot be held.

    * An existing storefront slug (case-insensitive) is TAKEN.
    * A live reservation by another session is RESERVED_BY_OTHER.
    * An *expired* reservation never blocks: the upsert replaces it in one statement.
    * The owning session may renew its own reservation; a session holds at most one slug, so
      claiming a different slug first releases its previous one.
    The claim is a single INSERT ... ON CONFLICT, so concurrent claimants serialise on the unique
    index and exactly one wins. ``tenants.slug UNIQUE`` remains the final arbiter at launch.
    The caller owns the transaction.
    """
    normalized = slug.strip().lower()
    if not normalized:
        raise ValueError("slug must not be blank")

    existing_tenant = (
        await db.execute(select(Tenant.id).where(func.lower(Tenant.slug) == normalized))
    ).scalar_one_or_none()
    if existing_tenant is not None:
        return SlugClaim.TAKEN

    await db.execute(
        text("DELETE FROM onboarding_slug_reservations WHERE session_id = :sid AND slug_normalized <> :slug"),
        {"sid": session_id, "slug": normalized},
    )
    # Opportunistic cleanup; correctness does not depend on it because the upsert replaces expired rows.
    await db.execute(text("DELETE FROM onboarding_slug_reservations WHERE expires_at <= now()"))

    claimed = (
        await db.execute(
            text(
                """
                INSERT INTO onboarding_slug_reservations (slug_normalized, session_id, expires_at)
                VALUES (:slug, :sid, now() + (CAST(:ttl AS integer) * interval '1 second'))
                ON CONFLICT (slug_normalized) DO UPDATE
                    SET session_id = EXCLUDED.session_id, expires_at = EXCLUDED.expires_at
                    WHERE onboarding_slug_reservations.expires_at <= now()
                       OR onboarding_slug_reservations.session_id = EXCLUDED.session_id
                RETURNING id
                """
            ),
            {"slug": normalized, "sid": session_id, "ttl": int(ttl.total_seconds())},
        )
    ).first()
    return SlugClaim.CLAIMED if claimed is not None else SlugClaim.RESERVED_BY_OTHER
