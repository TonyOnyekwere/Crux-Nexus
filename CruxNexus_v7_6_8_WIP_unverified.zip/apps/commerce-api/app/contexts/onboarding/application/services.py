from datetime import datetime, timedelta, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from typing import Optional
from uuid import UUID
import logging
import socket

from app.config import get_settings
from app.contexts.identity.domain.entities import User
from app.contexts.merchant_management.domain.entities import MerchantAccount
from app.contexts.merchant_management.domain.merchant_account_user import MerchantAccountUser, MerchantUserRole
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus
from app.contexts.tenant_management.domain.membership import TenantMembership, TenantRole, MembershipStatus
from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.billing.domain.merchant_trial_history import MerchantTrialHistory
from app.contexts.onboarding.domain.onboarding_request import MerchantOnboardingRequestRecord
from app.exceptions import IdempotencyKeyConflictError, OnboardingInProgressError
from app.utils.slug import normalize_storefront_slug

logger = logging.getLogger(__name__)

IDEMPOTENCY_LEASE_TIMEOUT_MINUTES = 5


class OnboardingService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def _build_response_from_merchant_account(
        self, merchant_account_id: UUID, user_id: UUID
    ) -> dict:
        """Re-derive the onboarding response for an already-completed
        request, without new columns on merchant_onboarding_requests
        to store the full payload — everything needed is reachable from
        merchant_account_id."""
        tenant_row = await self.db.execute(
            select(MerchantAccountTenant.tenant_id)
            .where(MerchantAccountTenant.merchant_account_id == merchant_account_id)
            .order_by(MerchantAccountTenant.tenant_id)
            .limit(1)
        )
        tenant_id = tenant_row.scalar_one()

        subscription_row = await self.db.execute(
            select(MerchantSubscription.id)
            .where(MerchantSubscription.merchant_account_id == merchant_account_id)
            .order_by(MerchantSubscription.created_at.desc())
            .limit(1)
        )
        subscription_id = subscription_row.scalar_one()

        membership_row = await self.db.execute(
            select(TenantMembership.id)
            .where(
                TenantMembership.tenant_id == tenant_id,
                TenantMembership.user_id == user_id,
            )
            .limit(1)
        )
        membership_id = membership_row.scalar_one()

        return {
            "merchant_account_id": merchant_account_id,
            "tenant_id": tenant_id,
            "subscription_id": subscription_id,
            "membership_id": membership_id,
        }

    async def _claim_ledger_row(
        self, record: MerchantOnboardingRequestRecord
    ) -> None:
        """Atomically take over a failed / lease-expired ledger row.

        Idempotency-lease fix (external review): reclaiming was a plain
        read-then-write, so two retries could both observe the same
        expired-pending (or failed) row and both proceed to provision.
        This is a compare-and-swap: the UPDATE only matches if status and
        created_at (which doubles as the lease start and is refreshed on
        every claim) are still exactly what this caller read, so exactly
        one concurrent claimant wins; the loser gets rowcount 0 and is
        told the request is in progress.
        """
        record_id = record.id
        seen_status = record.status
        seen_created_at = record.created_at
        result = await self.db.execute(
            update(MerchantOnboardingRequestRecord)
            .where(
                MerchantOnboardingRequestRecord.id == record_id,
                MerchantOnboardingRequestRecord.status == seen_status,
                MerchantOnboardingRequestRecord.created_at == seen_created_at,
            )
            .values(
                status="pending",
                error_message=None,
                created_at=datetime.now(timezone.utc),
                lease_owner=f"{socket.gethostname()}:{id(self)}",
                lease_expires_at=datetime.now(timezone.utc) + timedelta(minutes=IDEMPOTENCY_LEASE_TIMEOUT_MINUTES),
            )
        )
        if result.rowcount == 0:
            await self.db.rollback()
            raise OnboardingInProgressError()
        await self.db.commit()
        await self.db.refresh(record)

    async def onboard_merchant(
        self,
        *,
        user_id: UUID,
        merchant_name: str,
        storefront_slug: str,
        plan_code: str,
        idempotency_key: Optional[str] = None,
    ) -> dict:
        """
        Complete merchant onboarding transaction.
        
        This creates the complete foundation in one atomic transaction:
        - Merchant Account
        - Merchant Account User relationship
        - Subscription
        - Tenant (Storefront)
        - Merchant Account Tenant ownership
        - Tenant Membership (OWNER)
        
        Transaction flow:
        BEGIN
        ↓
        Verify User exists
        ↓
        Create Merchant Account
        ↓
        Create Merchant Account User
        ↓
        Resolve Subscription Plan
        ↓
        Create Merchant Subscription
        ↓
        Create Tenant
        ↓
        Create Merchant Account Tenant ownership
        ↓
        Create Tenant Membership (OWNER)
        ↓
        COMMIT

        If idempotency_key is provided (migration 015 + this method are what
        actually implement it — the table existed for a while with nothing
        reading or writing it), a retried request with the same key returns
        the original result instead of creating a second merchant account or
        raising a confusing uniqueness error.
        """
        onboarding_record: Optional[MerchantOnboardingRequestRecord] = None

        if idempotency_key:
            existing = await self.db.execute(
                select(MerchantOnboardingRequestRecord).where(
                    MerchantOnboardingRequestRecord.idempotency_key == idempotency_key
                )
            )
            onboarding_record = existing.scalar_one_or_none()

            if onboarding_record is not None:
                same_request = (
                    onboarding_record.user_id == user_id
                    and onboarding_record.plan_code == plan_code
                    and onboarding_record.storefront_slug == storefront_slug
                    and onboarding_record.merchant_name == merchant_name
                )
                if not same_request:
                    raise IdempotencyKeyConflictError()

                if onboarding_record.status == "completed":
                    return await self._build_response_from_merchant_account(
                        onboarding_record.merchant_account_id, user_id
                    )
                if onboarding_record.status == "pending":
                    # Lease timeout (external review fix): without this, a
                    # request that crashes after committing this pending
                    # row but before completing the provisioning
                    # transaction below leaves the row pending forever -
                    # every future retry with the same key would get
                    # OnboardingInProgressError permanently, with no way
                    # out short of manual DB intervention. A pending row
                    # older than the lease window is presumed abandoned
                    # (the original request is not still legitimately
                    # in-flight after this long) and is safe to reclaim -
                    # reused exactly like an explicitly failed row.
                    now = datetime.now(timezone.utc)
                    lease_expired = onboarding_record.lease_expires_at is not None and onboarding_record.lease_expires_at <= now
                    if not lease_expired and onboarding_record.lease_expires_at is None:
                        lease_expired = onboarding_record.created_at + timedelta(minutes=IDEMPOTENCY_LEASE_TIMEOUT_MINUTES) <= now
                    if not lease_expired:
                        raise OnboardingInProgressError()
                    logger.warning(
                        "Reclaiming onboarding idempotency key %s - pending lease "
                        "expired after %s (likely an earlier request crashed mid-flight).",
                        idempotency_key,
                        now - (onboarding_record.lease_expires_at or onboarding_record.created_at),
                    )
                    # Fall through and retry, same as an explicitly failed row.
                elif onboarding_record.status == "failed":
                    pass  # fall through and retry below
                # (any other unexpected status also falls through rather
                # than getting stuck - "pending" and "failed" are the only
                # two non-terminal-for-retry states this ledger uses)
                await self._claim_ledger_row(onboarding_record)
            else:
                onboarding_record = MerchantOnboardingRequestRecord(
                    idempotency_key=idempotency_key,
                    user_id=user_id,
                    plan_code=plan_code,
                    storefront_slug=storefront_slug,
                    merchant_name=merchant_name,
                    status="pending",
                    lease_owner=f"{socket.gethostname()}:{id(self)}",
                    lease_expires_at=datetime.now(timezone.utc) + timedelta(minutes=IDEMPOTENCY_LEASE_TIMEOUT_MINUTES),
                )
                self.db.add(onboarding_record)
                # Committed on its own, ahead of the main transaction below,
                # so a concurrent retry with the same key reliably sees
                # "pending" (and is rejected as in-progress) rather than
                # racing to insert two ledger rows for the same key.
                #
                # Fixed a real race (external review): two concurrent
                # requests with the same never-before-seen key can both
                # complete the SELECT above with no match, then both reach
                # this INSERT. The unique constraint on idempotency_key
                # correctly stops the second one at the database, but
                # without this try/except that surfaced as an unhandled
                # IntegrityError (a raw 500) instead of the same clean
                # "already in progress" response a request arriving a
                # moment later would have gotten.
                try:
                    await self.db.commit()
                except IntegrityError:
                    await self.db.rollback()
                    existing = await self.db.execute(
                        select(MerchantOnboardingRequestRecord).where(
                            MerchantOnboardingRequestRecord.idempotency_key == idempotency_key
                        )
                    )
                    onboarding_record = existing.scalar_one()
                    if onboarding_record.status == "pending":
                        raise OnboardingInProgressError()
                    if onboarding_record.status == "completed":
                        return await self._build_response_from_merchant_account(
                            onboarding_record.merchant_account_id, user_id
                        )
                    # "failed" - the loser of the race can safely retry
                    # using the winner's now-failed row (atomic claim).
                    await self._claim_ledger_row(onboarding_record)

        try:
            return await self._onboard_merchant_inner(
                user_id=user_id,
                merchant_name=merchant_name,
                storefront_slug=storefront_slug,
                plan_code=plan_code,
                onboarding_record=onboarding_record,
            )
        except Exception as exc:
            if idempotency_key:
                # Look up by the plain idempotency_key argument, not an
                # attribute on onboarding_record: that object may already
                # be expired from an earlier commit in this same session
                # (expire_on_commit=True), and reading an expired attribute
                # here would attempt an implicit lazy-load that AsyncSession
                # cannot perform outside an explicit await, raising
                # MissingGreenlet instead of the error we actually want to
                # report.
                await self.db.rollback()
                refreshed = await self.db.execute(
                    select(MerchantOnboardingRequestRecord).where(
                        MerchantOnboardingRequestRecord.idempotency_key
                        == idempotency_key
                    )
                )
                row = refreshed.scalar_one_or_none()
                if row is not None:
                    row.status = "failed"
                    row.error_message = str(exc)[:2000]
                    await self.db.commit()
            raise

    async def _onboard_merchant_inner(
        self,
        *,
        user_id: UUID,
        merchant_name: str,
        storefront_slug: str,
        plan_code: str,
        onboarding_record: Optional[MerchantOnboardingRequestRecord],
    ) -> dict:
        # Verify user exists
        user_result = await self.db.execute(
            select(User).where(User.id == user_id)
        )
        user = user_result.scalar_one_or_none()
        if not user:
            raise ValueError("User not found")

        existing_merchant_result = await self.db.execute(
            select(MerchantAccount)
            .join(
                MerchantAccountUser,
                MerchantAccountUser.merchant_account_id == MerchantAccount.id,
            )
            .where(MerchantAccountUser.user_id == user_id)
            .order_by(MerchantAccount.created_at.desc(), MerchantAccount.id.desc())
            .limit(1)
        )
        if existing_merchant_result.scalar_one_or_none() is not None:
            raise ValueError(
                "This user already has a merchant account. Use the existing account to upgrade or renew the plan instead of creating a second one."
            )

        normalized_slug = normalize_storefront_slug(storefront_slug)

        existing_tenant = await self.db.execute(
            select(Tenant).where(func.lower(Tenant.slug) == normalized_slug)
        )
        if existing_tenant.scalar_one_or_none() is not None:
            raise ValueError(f"Storefront slug '{storefront_slug}' is already in use")

        # Resolve subscription plan in a case-insensitive way to match the
        # seeded values ('starter', 'business', 'enterprise') and the API contract.
        # Outside production, recover from a missing seed by creating the
        # canonical plans before rejecting the onboarding request — this is a
        # development/staging convenience only. In production, a missing
        # plan is treated as a hard operational error (see below) rather
        # than something onboarding silently repairs.
        normalized_plan_code = plan_code.strip().lower()
        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(
                func.lower(SubscriptionPlan.code) == normalized_plan_code,
                SubscriptionPlan.active.is_(True),
            )
        )
        plan = plan_result.scalar_one_or_none()
        if not plan:
            raise ValueError(
                f"Subscription plan '{plan_code}' not found or inactive. "
                "Platform configuration must be provisioned by Control Center."
            )


        # From here on, every insert is protected by a real database
        # constraint (uq_one_owner_merchant_per_user,
        # uq_one_live_subscription_per_merchant, tenants.slug UNIQUE — see
        # migration 008 and the Tenant model). The SELECT-based checks above
        # are an early, friendly rejection for the common case; concurrent
        # requests that race past them are caught here as an IntegrityError
        # and turned into the same clean domain error, rather than an
        # unhandled 500.
        try:
            # Create merchant account
            merchant_account = MerchantAccount(
                name=merchant_name,
                status="active",
            )
            self.db.add(merchant_account)
            await self.db.flush()

            # Create merchant account user relationship
            merchant_account_user = MerchantAccountUser(
                merchant_account_id=merchant_account.id,
                user_id=user_id,
                role=MerchantUserRole.OWNER.value,
            )
            self.db.add(merchant_account_user)
            await self.db.flush()

            # Create merchant subscription
            #
            # Trial length is plan-configured (SubscriptionPlan.trial_days) —
            # never a hardcoded constant here. Every plan is required to carry
            # an explicit trial_days value (see migration 010), so a missing
            # value indicates a data problem rather than something to silently
            # default around.
            if plan.trial_days is None:
                raise ValueError(
                    f"Subscription plan '{plan.code}' is missing a configured trial_days value"
                )

            trial_started_at = datetime.now(timezone.utc)
            trial_ends_at = trial_started_at + timedelta(days=plan.trial_days)

            merchant_subscription = MerchantSubscription(
                merchant_account_id=merchant_account.id,
                subscription_plan_id=plan.id,
                status=SubscriptionStatus.TRIALING.value,
                trial_started_at=trial_started_at,
                trial_ends_at=trial_ends_at,
            )
            self.db.add(merchant_subscription)
            await self.db.flush()

            # Audit trail: record the start of the trial. This is the write path
            # that keeps merchant_trial_history populated going forward — the
            # one-time migration 004 backfill only ever covered historical rows.
            # subscription_id (migration 011) is what expiration matches on —
            # never re-derive the open trial via merchant/plan correlation when
            # a direct reference is available.
            trial_history_entry = MerchantTrialHistory(
                merchant_account_id=merchant_account.id,
                subscription_plan_id=plan.id,
                subscription_id=merchant_subscription.id,
                status=SubscriptionStatus.TRIALING.value,
                started_at=trial_started_at,
            )
            self.db.add(trial_history_entry)
            await self.db.flush()

            # Deliberately NOT auto-granting max_extra_storefronts/
            # max_extra_staff here. Fixed a real regression (flagged
            # across three separate external reviews): this used to
            # create a MerchantEntitlement for the FULL max_extra_* value
            # unconditionally at onboarding, treating a documented ceiling
            # ("up to 1 extra storefront", "up to 2 extra staff") as
            # automatically-included capacity instead. The existing,
            # separately-tested grant path
            # (CapacityService.grant_extra_storefront_entitlement /
            # the staff equivalent) already enforces max_extra_* as a
            # hard ceiling on explicit grants — see
            # test_grant_extra_storefront_entitlement_enforces_plan_ceiling
            # in tests/unit/test_merchant_db_compatibility.py, which only
            # makes sense if max_extra_* is a cap on grants that don't
            # happen automatically. A merchant now starts with exactly
            # their plan's included_storefronts/base_staff_per_storefront;
            # any extra capacity comes from an explicit grant (admin grant
            # today, a self-service purchase flow later), capped at
            # max_extra_*, never both included and independently
            # grantable up to the same ceiling.

            # Storefront provisioning is delegated to the canonical TenantService.
            # Onboarding must never maintain a second capacity/ownership implementation.
            from app.contexts.tenant_management.application.services import TenantService
            tenant = await TenantService(self.db).create_storefront(
                merchant_account_id=merchant_account.id,
                owner_user_id=user_id,
                slug=normalized_slug,
            )

            from app.kernel.events.publisher import publish_to_outbox
            from app.kernel.events.types import DomainEvent, EventEnvelope

            await publish_to_outbox(
                self.db,
                EventEnvelope(
                    event_type=DomainEvent.MERCHANT_CREATED,
                    aggregate_type="MerchantAccount",
                    aggregate_id=merchant_account.id,
                    payload={
                        "merchant_name": merchant_name,
                        "user_id": str(user_id),
                        "plan_code": plan_code,
                    },
                ),
            )
            await publish_to_outbox(
                self.db,
                EventEnvelope(
                    event_type=DomainEvent.STOREFRONT_CREATED,
                    aggregate_type="Tenant",
                    aggregate_id=tenant.id,
                    tenant_id=tenant.id,
                    payload={"slug": normalized_slug, "merchant_account_id": str(merchant_account.id)},
                ),
            )

            if onboarding_record is not None:
                onboarding_record.status = "completed"
                onboarding_record.merchant_account_id = merchant_account.id
                onboarding_record.completed_at = datetime.now(timezone.utc)
                await self.db.flush()

            await self.db.commit()
        except IntegrityError:
            await self.db.rollback()
            logger.warning(
                "Onboarding lost a uniqueness race for user_id=%s slug=%s",
                user_id,
                normalized_slug,
            )
            raise ValueError(
                "This user already has a merchant account, or the storefront "
                "slug was just taken by a concurrent request. Please retry."
            )

        membership_id = await self.db.scalar(
            select(TenantMembership.id).where(
                TenantMembership.tenant_id == tenant.id,
                TenantMembership.user_id == user_id,
            )
        )
        if membership_id is None:
            raise RuntimeError("Storefront owner membership was not created")
        return {
            "merchant_account_id": merchant_account.id,
            "tenant_id": tenant.id,
            "subscription_id": merchant_subscription.id,
            "membership_id": membership_id,
        }