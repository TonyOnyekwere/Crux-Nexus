"""Onboarding session service — Phase 2 of CRX-P0-022.

Implements the actual behavior the onboarding_sessions/onboarding_step_events
schema (migration 021) was built for: create, resume by device token,
advance a step under optimistic concurrency, and emit funnel events.

This does NOT yet implement the step-specific journey endpoints (welcome,
business info, plan selection, etc. — Gate 4 / sections 16-34 of the
locked architecture). Those all become thin callers of `advance_step`
below with a step-specific payload shape; building the generic mechanism
correctly first, then the ~12 thin endpoints on top of it, is less risky
than building all of them at once against a half-proven mechanism.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.onboarding.domain.onboarding_session import (
    OnboardingSession,
    OnboardingSessionStatus,
    OnboardingStepEvent,
    OnboardingStepEventType,
)

SESSION_EXPIRY_DAYS = 7  # locked architecture section 48


class OnboardingVersionConflictError(ValueError):
    """Raised when an advance_step call's expected_version doesn't match
    the row's current version — the caller is working from stale state
    (locked architecture section 50: concurrent-device protection)."""


class OnboardingStepNotAllowedError(ValueError):
    """A client tried to set a step only the server may set."""


# Steps whose entry implies server-verified facts (payment, activation,
# launch) or that belong to the server-driven journey. Never client-settable.
CLIENT_FORBIDDEN_STEPS = frozenset(
    {
        "payment_pending",
        "subscription_active",
        "launching",
        "live",
        "OTP_VERIFIED",
        "MERCHANT_CREATED",
        "BUSINESS_CONFIGURED",
        "PLAN_SELECTED",
        "PAYMENT_PENDING",
        "PAYMENT_CONFIRMED",
        "STOREFRONT_READY",
        "COMPLETED",
    }
)


class OnboardingSessionNotFoundError(ValueError):
    pass


class OnboardingSessionService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_session(
        self,
        *,
        device_session_token: str,
        owner_email: Optional[str] = None,
        owner_user_id: Optional[UUID] = None,
        flow_version: str = "v1",
    ) -> OnboardingSession:
        session = OnboardingSession(
            device_session_token=device_session_token,
            owner_email=owner_email,
            owner_user_id=owner_user_id,
            flow_version=flow_version,
            expires_at=datetime.now(timezone.utc) + timedelta(days=SESSION_EXPIRY_DAYS),
        )
        self.db.add(session)
        await self.db.flush()

        await self._emit_event(session.id, session.current_step, OnboardingStepEventType.STEP_ENTERED)
        await self.db.commit()
        await self.db.refresh(session)
        return session

    async def get_by_device_token(self, device_session_token: str) -> Optional[OnboardingSession]:
        result = await self.db.execute(
            select(OnboardingSession).where(
                OnboardingSession.device_session_token == device_session_token
            )
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, session_id: UUID) -> Optional[OnboardingSession]:
        result = await self.db.execute(
            select(OnboardingSession).where(OnboardingSession.id == session_id)
        )
        return result.scalar_one_or_none()

    async def link_owner(
        self, session_id: UUID, *, owner_user_id: UUID, owner_email: str
    ) -> None:
        """Attach an authenticated identity to a session that started
        anonymously (locked architecture: Welcome/business-context steps
        precede account creation)."""
        session = await self.get_by_id(session_id)
        if session is None:
            raise OnboardingSessionNotFoundError(str(session_id))
        session.owner_user_id = owner_user_id
        session.owner_email = owner_email
        await self.db.commit()

    async def advance_step(
        self,
        *,
        session_id: UUID,
        expected_version: int,
        new_step: str,
        payload_update: dict[str, Any],
        trusted: bool = False,
    ) -> OnboardingSession:
        """Move the session to `new_step`, merging `payload_update` into
        the accumulated payload, under optimistic concurrency.

        The UPDATE's WHERE clause checks version in the same statement as
        the increment — this is what makes two concurrent devices safe:
        whichever commits first wins and bumps the version; the second
        one's WHERE matches zero rows, and rowcount==0 is how we detect
        the conflict rather than a read-then-write race.
        """
        session = await self.get_by_id(session_id)
        if session is None:
            raise OnboardingSessionNotFoundError(str(session_id))

        # Client-reachable callers (trusted=False) may only move through
        # steps that carry no commercial authority. Without this a client
        # could PATCH new_step="live" and skip payment entirely. Journey
        # (mvp1) sessions are driven solely by JourneyService.
        if not trusted:
            if session.flow_version == "mvp1":
                raise OnboardingStepNotAllowedError(
                    "This session is driven by the server-side journey; steps cannot be set directly."
                )
            if new_step in CLIENT_FORBIDDEN_STEPS:
                raise OnboardingStepNotAllowedError(
                    f"Step '{new_step}' is set by the server and cannot be requested by a client."
                )

        merged_payload = {**(session.payload or {}), **payload_update}
        completed = list(session.completed_steps or [])
        if session.current_step not in completed:
            completed.append(session.current_step)

        result = await self.db.execute(
            update(OnboardingSession)
            .where(
                OnboardingSession.id == session_id,
                OnboardingSession.version == expected_version,
            )
            .values(
                current_step=new_step,
                completed_steps=completed,
                payload=merged_payload,
                version=OnboardingSession.version + 1,
                updated_at=datetime.now(timezone.utc),
            )
        )

        if result.rowcount == 0:
            await self.db.rollback()
            raise OnboardingVersionConflictError(
                f"Session {session_id} was modified elsewhere (expected version "
                f"{expected_version}). Reload and retry."
            )

        await self._emit_event(
            session_id, completed[-1] if completed else session.current_step,
            OnboardingStepEventType.STEP_COMPLETED,
        )
        await self._emit_event(session_id, new_step, OnboardingStepEventType.STEP_ENTERED)

        await self.db.commit()
        return await self.get_by_id(session_id)

    async def mark_launching(self, session_id: UUID) -> None:
        session = await self.get_by_id(session_id)
        if session is None:
            raise OnboardingSessionNotFoundError(str(session_id))
        session.status = OnboardingSessionStatus.LAUNCHING.value
        session.launch_attempt_count += 1
        await self.db.commit()

    async def mark_launch_failed(self, session_id: UUID, error: str) -> None:
        session = await self.get_by_id(session_id)
        if session is None:
            raise OnboardingSessionNotFoundError(str(session_id))
        session.status = OnboardingSessionStatus.IN_PROGRESS.value
        session.last_launch_error = error[:2000]
        await self.db.commit()

    async def mark_completed(self, session_id: UUID, tenant_id: UUID) -> None:
        session = await self.get_by_id(session_id)
        if session is None:
            raise OnboardingSessionNotFoundError(str(session_id))
        session.status = OnboardingSessionStatus.COMPLETED.value
        session.tenant_id = tenant_id
        await self._emit_event(session_id, "live", OnboardingStepEventType.STEP_COMPLETED)
        await self.db.commit()

    async def _emit_event(
        self,
        session_id: UUID,
        step: str,
        event_type: OnboardingStepEventType,
        metadata: Optional[dict] = None,
    ) -> None:
        event = OnboardingStepEvent(
            session_id=session_id,
            step=step,
            event_type=event_type.value,
            event_metadata=metadata or {},
        )
        self.db.add(event)
        await self.db.flush()
