"""Merchant onboarding journey API (CRX-P0-030).

Action endpoints only - there is deliberately NO endpoint that accepts a
stage / step name from the client. All routes except /register require a
Bearer token; every route resolves the caller's own journey from the token.
"""

import logging
from typing import Optional
from uuid import UUID

from fastapi import Request, APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_current_user_id
from app.auth.password_policy import validate_password_strength
from app.contexts.billing.application.subscription_payment_service import (
    PaymentAlreadyCompletedError,
    PaymentOutcomeUnknownError,
    PlanPricingNotConfiguredError,
    PriorPaymentUnverifiableError,
)
from app.contexts.billing.domain.financial_transaction import PaymentProvider
from app.contexts.identity.application.otp_service import (
    OTPRateLimitExceededError,
    OTPResendTooSoonError,
    OTPService,
    OTPVerificationError,
)
from app.contexts.onboarding.application.journey_service import JourneyError, JourneyService
from app.database import get_db
from app.infrastructure.payments.adapter import ProviderRejectedError
from app.infrastructure.rate_limiter import key_ip, key_ip_tenant, limiter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/onboarding/journey", tags=["onboarding-journey"])


def _err(code: str, message: str, http: int, **details) -> HTTPException:
    return HTTPException(http, detail={"error": {"code": code, "message": message, "details": details}})


class RegisterRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    email: EmailStr
    password: str

    @field_validator("password")
    @classmethod
    def _strong(cls, v: str) -> str:
        return validate_password_strength(v)


class OTPRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    channel: str = Field(default="email", pattern="^(email|sms)$")


class OTPConfirm(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str = Field(min_length=4, max_length=12)


class MerchantRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    business_name: str = Field(min_length=2, max_length=120)


class BusinessRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    storefront_slug: Optional[str] = Field(default=None, min_length=3, max_length=50)
    category: Optional[str] = Field(default=None, max_length=80)
    contact_phone: Optional[str] = Field(default=None, max_length=30)
    city: Optional[str] = Field(default=None, max_length=80)
    address: Optional[str] = Field(default=None, max_length=255)


class PlanRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    plan_code: str = Field(min_length=2, max_length=50)


class PaymentRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    provider: PaymentProvider


def _journey_error(exc: JourneyError) -> HTTPException:
    return _err(exc.code, str(exc), exc.status_hint)


@router.post("/register", status_code=status.HTTP_201_CREATED)
@limiter.limit("20/hour", key_func=key_ip)
async def register(request: Request, body: RegisterRequest, db: AsyncSession = Depends(get_db)):
    try:
        return {"data": await JourneyService(db).register(email=body.email, password=body.password)}
    except JourneyError as exc:
        raise _journey_error(exc)


@router.get("/state")
async def get_state(db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)):
    try:
        return {"data": await JourneyService(db).state(user_id)}
    except JourneyError as exc:
        raise _journey_error(exc)


@router.post("/otp/request")
@limiter.limit("10/hour", key_func=key_ip_tenant)
@limiter.limit("30/hour", key_func=key_ip)
async def request_otp(
    request: Request,
    body: OTPRequest, db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)
):
    try:
        _otp, delivery = await OTPService(db).request_code(user_id=user_id, channel=body.channel)
    except OTPResendTooSoonError as exc:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            detail={"error": {"code": "OTP_RESEND_TOO_SOON", "message": str(exc),
                              "details": {"retry_after_seconds": exc.retry_after_seconds}}},
            headers={"Retry-After": str(exc.retry_after_seconds)},
        )
    except OTPRateLimitExceededError as exc:
        raise _err("OTP_RATE_LIMIT_EXCEEDED", str(exc), 429)
    except ValueError as exc:
        raise _err("OTP_REQUEST_FAILED", str(exc), 400)
    if not delivery.sent:
        # Never let the client advance into an OTP step that has no usable
        # code. The provider result is authoritative for delivery status.
        raise _err(
            "OTP_DELIVERY_FAILED",
            delivery.detail or "The verification code could not be delivered.",
            503,
            provider=delivery.provider,
            channel=body.channel,
        )
    return {"data": {"delivered": True, "channel": body.channel, "provider": delivery.provider}}


@router.post("/otp/verify")
@limiter.limit("30/hour", key_func=key_ip_tenant)
@limiter.limit("100/hour", key_func=key_ip)
async def verify_otp(
    request: Request,
    body: OTPConfirm, db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)
):
    try:
        return {"data": await JourneyService(db).confirm_otp(user_id, body.code)}
    except OTPVerificationError as exc:
        raise _err(exc.code, str(exc), 429 if exc.code == "TOO_MANY_ATTEMPTS" else 400)
    except JourneyError as exc:
        raise _journey_error(exc)


@router.post("/merchant", status_code=status.HTTP_201_CREATED)
async def create_merchant(
    body: MerchantRequest, db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)
):
    try:
        return {"data": await JourneyService(db).create_merchant(user_id, body.business_name)}
    except JourneyError as exc:
        raise _journey_error(exc)


@router.put("/business")
async def configure_business(
    body: BusinessRequest, db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)
):
    try:
        return {"data": await JourneyService(db).configure_business(user_id, **body.model_dump())}
    except JourneyError as exc:
        raise _journey_error(exc)


@router.post("/plan")
async def select_plan(
    body: PlanRequest, db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)
):
    try:
        return {"data": await JourneyService(db).select_plan(user_id, body.plan_code)}
    except JourneyError as exc:
        raise _journey_error(exc)


@router.post("/payment")
async def start_payment(
    body: PaymentRequest, db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)
):
    try:
        return {"data": await JourneyService(db).start_payment(
            user_id, provider=body.provider)}
    except JourneyError as exc:
        raise _journey_error(exc)
    except PaymentOutcomeUnknownError as exc:
        raise _err("PAYMENT_OUTCOME_UNKNOWN",
                   "We could not confirm your payment request. If you were charged, your "
                   "subscription will activate automatically; please do not pay again for a few minutes.",
                   202, reference=exc.reference)
    except PaymentAlreadyCompletedError as exc:
        raise _err("PAYMENT_ALREADY_COMPLETED", str(exc), 409)
    except PriorPaymentUnverifiableError as exc:
        raise HTTPException(503, detail={"error": {"code": "PRIOR_PAYMENT_UNVERIFIED", "message": str(exc), "details": {}}},
                            headers={"Retry-After": "60"})
    except ProviderRejectedError:
        raise _err("PROVIDER_REJECTED", "The payment provider declined to start this payment.", 502)
    except PlanPricingNotConfiguredError as exc:
        raise _err("PLAN_PRICING_NOT_CONFIGURED", str(exc), 503)


@router.post("/storefront", status_code=status.HTTP_201_CREATED)
async def create_storefront(db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)):
    try:
        return {"data": await JourneyService(db).create_storefront(user_id)}
    except JourneyError as exc:
        raise _journey_error(exc)


@router.post("/complete")
async def complete(db: AsyncSession = Depends(get_db), user_id: UUID = Depends(get_current_user_id)):
    """Finish onboarding. The response carries tenant_id: the client then
    calls /api/v1/identity/switch-tenant to enter the Commerce OS."""
    try:
        return {"data": await JourneyService(db).complete(user_id)}
    except JourneyError as exc:
        raise _journey_error(exc)
