import hmac
import logging
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.auth.jwt_handler import get_current_merchant_context
from app.contexts.onboarding.application.services import OnboardingService
from app.exceptions import IdempotencyKeyConflictError, OnboardingInProgressError
from .schemas import (
    MerchantOnboardingRequest,
    MerchantOnboardingResponse,
    OnboardingSessionAdvanceRequest,
    OnboardingSessionCreateRequest,
    OnboardingSessionResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/onboarding", tags=["onboarding"])


@router.post("/merchant", status_code=status.HTTP_410_GONE)
async def deprecated_merchant_onboarding():
    """The old one-call bootstrap is retired. Merchant creation now belongs
    to the server-validated onboarding journey so OTP, plan, payment and
    storefront readiness cannot be bypassed by calling a legacy endpoint."""
    raise HTTPException(
        status_code=status.HTTP_410_GONE,
        detail={
            "error": {
                "code": "ONBOARDING_FLOW_RETIRED",
                "message": "Use /api/v1/onboarding/journey for merchant onboarding.",
                "details": {},
            }
        },
    )


@router.post("/sessions", status_code=status.HTTP_201_CREATED)
async def create_or_resume_session(
    request_data: OnboardingSessionCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create a new onboarding session (server-generated token), or
    resume an existing one if device_session_token is supplied and
    matches.

    Fixed a real security weakness (external review): the token used to
    be accepted verbatim from the client even when creating a brand new
    session, meaning a client could choose a predictable value like
    "123456" for the one piece of data that proves possession/access to
    that session. The server now always generates the token for a new
    session (secrets.token_urlsafe) - a client-supplied value is only
    ever used to look up an existing session, never to seed a new one.

    Deliberately unauthenticated: the locked journey's Welcome/commercial-
    context/business-info steps precede account creation (section 18),
    so a session must be able to exist before any identity does.
    Possession of device_session_token is what proves access to an
    anonymous session — once a session is linked to an owner_user_id
    (via link_owner, called from the account-creation step in Phase 4,
    not yet built), stronger auth-based checks should additionally apply
    there. This endpoint predates that linkage and can't require it.
    """
    import secrets as _secrets

    from app.contexts.onboarding.application.session_service import OnboardingSessionService

    service = OnboardingSessionService(db)

    if request_data.device_session_token:
        existing = await service.get_by_device_token(request_data.device_session_token)
        if existing is not None:
            return {"data": OnboardingSessionResponse.from_session(existing).model_dump()}
        # A supplied token that matches nothing is not license to create
        # a new session under that client-chosen value - that would just
        # move the same vulnerability from "create" to "resume-that-
        # silently-creates". Treat it as not found instead.
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "SESSION_NOT_FOUND", "message": "No session found for this token.", "details": {}}},
        )

    generated_token = _secrets.token_urlsafe(32)
    session = await service.create_session(
        device_session_token=generated_token,
        owner_email=request_data.owner_email,
    )
    return {"data": OnboardingSessionResponse.from_session(session).model_dump()}


@router.get("/sessions/{session_id}")
async def get_session(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
    x_device_session_token: str = Header(..., alias="X-Device-Session-Token"),
):
    """Fetch session state. Requires possession of the session's own
    device_session_token via header — a session UUID alone is not proof
    of access (this was a real vulnerability found in external review: the
    original version had no possession check at all, so anyone who
    obtained/guessed a session UUID could read or, worse, mutate another
    merchant's in-progress onboarding data via PATCH).

    Once a session is linked to an authenticated owner (Phase 4's
    account-creation step, not yet built), an authenticated-owner path
    should be added as an alternative to the device token — this check
    is the baseline that closes the vulnerability today, not the final
    authorization model.
    """
    from app.contexts.onboarding.application.session_service import OnboardingSessionService

    service = OnboardingSessionService(db)
    session = await service.get_by_id(session_id)
    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "SESSION_NOT_FOUND", "message": "Onboarding session not found.", "details": {}}},
        )
    if not hmac.compare_digest(x_device_session_token, session.device_session_token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "SESSION_ACCESS_DENIED", "message": "Invalid device session token.", "details": {}}},
        )
    return {"data": OnboardingSessionResponse.from_session(session).model_dump()}


@router.patch("/sessions/{session_id}")
async def advance_session(
    session_id: UUID,
    request_data: OnboardingSessionAdvanceRequest,
    db: AsyncSession = Depends(get_db),
    x_device_session_token: str = Header(..., alias="X-Device-Session-Token"),
):
    """Advance a session to a new step. This is the generic mechanism
    every step-specific endpoint (Phase 4 - welcome, business info, plan
    selection, etc.) will call with a step-specific payload_update shape;
    those thin, validated endpoints don't exist yet, so for now the
    caller supplies new_step/payload_update directly. expected_version
    must match the session's current version (optimistic concurrency,
    locked architecture section 50) or this returns 409.
    """
    from app.contexts.onboarding.application.session_service import (
        OnboardingSessionNotFoundError,
        OnboardingSessionService,
        OnboardingStepNotAllowedError,
        OnboardingVersionConflictError,
    )

    service = OnboardingSessionService(db)

    existing = await service.get_by_id(session_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "SESSION_NOT_FOUND", "message": "Onboarding session not found.", "details": {}}},
        )
    if not hmac.compare_digest(x_device_session_token, existing.device_session_token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "SESSION_ACCESS_DENIED", "message": "Invalid device session token.", "details": {}}},
        )

    try:
        session = await service.advance_step(
            session_id=session_id,
            expected_version=request_data.expected_version,
            new_step=request_data.new_step,
            payload_update=request_data.payload_update,
        )
    except OnboardingSessionNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "SESSION_NOT_FOUND", "message": "Onboarding session not found.", "details": {}}},
        )
    except OnboardingStepNotAllowedError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "STEP_NOT_ALLOWED", "message": str(exc), "details": {}}},
        )
    except OnboardingVersionConflictError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": {"code": "STALE_VERSION", "message": str(exc), "details": {}}},
        )

    return {"data": OnboardingSessionResponse.from_session(session).model_dump()}
