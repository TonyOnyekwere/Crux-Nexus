from uuid import UUID
from pydantic import BaseModel


class MerchantOnboardingRequest(BaseModel):
    merchant_name: str
    storefront_slug: str
    plan: str  # STARTER, BUSINESS, ENTERPRISE


class MerchantOnboardingResponse(BaseModel):
    merchant_account_id: UUID
    tenant_id: UUID
    subscription_id: UUID
    membership_id: UUID
class OnboardingSessionCreateRequest(BaseModel):
    # Optional: omit entirely to create a brand new session (the server
    # always generates the actual token — see the route). Include only to
    # resume an existing session by a token the client was previously
    # given. A client can no longer invent its own token value for a new
    # session — that was a real security weakness (external review):
    # since possession of this token is the sole access-control mechanism
    # for an anonymous session, a client-chosen value (e.g. "123456")
    # made that mechanism guessable instead of cryptographically random.
    device_session_token: str | None = None
    owner_email: str | None = None


class OnboardingSessionAdvanceRequest(BaseModel):
    expected_version: int
    new_step: str
    payload_update: dict = {}


class OnboardingSessionResponse(BaseModel):
    id: UUID
    device_session_token: str
    owner_email: str | None
    current_step: str
    completed_steps: list
    payload: dict
    status: str
    version: int
    expires_at: str

    model_config = {"from_attributes": True}

    @classmethod
    def from_session(cls, session) -> "OnboardingSessionResponse":
        return cls(
            id=session.id,
            device_session_token=session.device_session_token,
            owner_email=session.owner_email,
            current_step=session.current_step,
            completed_steps=session.completed_steps or [],
            payload=session.payload or {},
            status=session.status,
            version=session.version,
            expires_at=session.expires_at.isoformat(),
        )
