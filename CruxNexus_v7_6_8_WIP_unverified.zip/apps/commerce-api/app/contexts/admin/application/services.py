from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from uuid import UUID
import logging

from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.billing.domain.merchant_entitlement import MerchantEntitlement, EntitlementType, EntitlementSource, EntitlementStatus
from app.exceptions import NotFoundError

logger = logging.getLogger(__name__)


class AdminEntitlementService:
    """Service for administrative operations on merchant entitlements."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def grant_plan_based_entitlements(
        self,
        merchant_account_id: UUID,
    ) -> dict:
        """
        Grant plan-based entitlements to an existing merchant.
        
        This is useful for fixing merchants who were onboarded before the
        automatic entitlement granting was implemented.
        """
        # Get merchant's active subscription
        subscription_result = await self.db.execute(
            select(MerchantSubscription).where(
                MerchantSubscription.merchant_account_id == merchant_account_id,
                MerchantSubscription.status.in_([
                    SubscriptionStatus.TRIALING.value,
                    SubscriptionStatus.ACTIVE.value,
                ])
            )
        )
        subscription = subscription_result.scalar_one_or_none()
        if not subscription:
            raise NotFoundError("subscription", "No active subscription found for this merchant")
        
        # Get subscription plan
        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == subscription.subscription_plan_id)
        )
        plan = plan_result.scalar_one_or_none()
        if not plan:
            raise NotFoundError("subscription_plan", "Subscription plan not found")
        
        entitlements_created = []
        
        # Grant extra storefront entitlements if plan allows
        if plan.max_extra_storefronts > 0:
            existing_result = await self.db.execute(
                select(MerchantEntitlement).where(
                    MerchantEntitlement.merchant_account_id == merchant_account_id,
                    MerchantEntitlement.entitlement_type == EntitlementType.EXTRA_STOREFRONT.value,
                    MerchantEntitlement.source == EntitlementSource.PLAN_GRANT.value,
                )
            )
            existing = existing_result.scalar_one_or_none()

            if not existing:
                storefront_entitlement = MerchantEntitlement(
                    merchant_account_id=merchant_account_id,
                    entitlement_type=EntitlementType.EXTRA_STOREFRONT.value,
                    quantity=plan.max_extra_storefronts,
                    source=EntitlementSource.PLAN_GRANT.value,
                    status=EntitlementStatus.ACTIVE.value,
                )
                self.db.add(storefront_entitlement)
                await self.db.flush()
                entitlements_created.append({
                    "type": "extra_storefront",
                    "quantity": plan.max_extra_storefronts,
                })

        # Grant extra staff entitlements if plan allows
        if plan.max_extra_staff > 0:
            existing_result = await self.db.execute(
                select(MerchantEntitlement).where(
                    MerchantEntitlement.merchant_account_id == merchant_account_id,
                    MerchantEntitlement.entitlement_type == EntitlementType.EXTRA_STAFF.value,
                    MerchantEntitlement.source == EntitlementSource.PLAN_GRANT.value,
                )
            )
            existing = existing_result.scalar_one_or_none()

            if not existing:
                staff_entitlement = MerchantEntitlement(
                    merchant_account_id=merchant_account_id,
                    entitlement_type=EntitlementType.EXTRA_STAFF.value,
                    quantity=plan.max_extra_staff,
                    source=EntitlementSource.PLAN_GRANT.value,
                    status=EntitlementStatus.ACTIVE.value,
                )
                self.db.add(staff_entitlement)
                await self.db.flush()
                entitlements_created.append({
                    "type": "extra_staff",
                    "quantity": plan.max_extra_staff,
                })
        
        await self.db.commit()
        
        return {
            "merchant_account_id": str(merchant_account_id),
            "plan_code": plan.code,
            "entitlements_created": entitlements_created,
        }