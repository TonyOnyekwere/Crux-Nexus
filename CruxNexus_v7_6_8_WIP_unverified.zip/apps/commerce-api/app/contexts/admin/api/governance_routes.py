from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from pydantic import field_validator, BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.auth.control_center_auth import verify_control_center_service
from app.contexts.billing.domain.governance_policy import CommerceGovernancePolicy
from app.contexts.billing.domain.provider_registry import ProviderRegistryEntry
from app.contexts.billing.domain.entities import SubscriptionPlan
from app.database import get_db
from app.infrastructure.audit import SecurityEvent, SecurityEventType, record_durable_audit

def _is_newer_version(incoming: str, current: str) -> bool:
    if current == "initial": return True
    try: return int(incoming) > int(current)
    except (TypeError, ValueError): return incoming != current

router=APIRouter(prefix="/api/v1/admin/governance",tags=["admin-governance"])

class PolicyPayload(BaseModel):
    governance_version: str = Field(min_length=1, max_length=80)
    model_config=ConfigDict(extra="forbid")
    grace_period_days: int=Field(ge=0,le=90)
    monthly_period_days: int=Field(ge=1,le=366)
    yearly_period_days: int=Field(ge=1,le=1000)
    allow_early_renewal: bool=False

class ProviderPayload(BaseModel):
    model_config=ConfigDict(extra="forbid")
    provider_type: str
    enabled: bool
    priority: int=Field(ge=0,le=10000)
    governance_version: str

class PlanPayload(BaseModel):
    model_config=ConfigDict(extra="forbid")
    governance_version: str = "initial"
    code: str
    name: str
    included_storefronts: int=Field(ge=0)
    base_staff_per_storefront: int=Field(ge=0)
    max_extra_storefronts: int=Field(ge=0)
    max_extra_staff: int=Field(ge=0)
    trial_days: int=Field(ge=0,le=365)
    price_amount: str | None=None
    price_currency: str | None=None
    billing_interval: str | None=None
    active: bool=True
    capabilities: dict = Field(default_factory=dict)
    resource_limits: dict = Field(default_factory=dict)

    # Defense in depth: the Control Center validates the same shapes before syncing, but Commerce must
    # never store policy its own engine would have to fail closed on.
    @field_validator("capabilities")
    @classmethod
    def _valid_capabilities(cls, value):
        import re
        if len(value) > 300:
            raise ValueError("too many capabilities")
        for key, granted in value.items():
            if not isinstance(key, str) or not re.match(r"^[a-z][a-z0-9_.]{1,60}$", key) or not isinstance(granted, bool):
                raise ValueError(f"invalid capability {key!r}")
        return value

    @field_validator("resource_limits")
    @classmethod
    def _valid_limits(cls, value):
        import re
        if len(value) > 300:
            raise ValueError("too many limits")
        for key, limit in value.items():
            if not isinstance(key, str) or not re.match(r"^[a-z][a-z0-9_.]{1,60}$", key):
                raise ValueError(f"invalid limit key {key!r}")
            if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 0 or limit > 10**15):
                raise ValueError(f"invalid limit value for {key!r}")
        return value

@router.put("/policy")
async def sync_policy(payload: PolicyPayload, db: AsyncSession=Depends(get_db), _cc=Depends(verify_control_center_service)):
    row=await db.scalar(select(CommerceGovernancePolicy).where(CommerceGovernancePolicy.policy_key=="default").with_for_update())
    if row is None: raise HTTPException(500,"Governance policy is not initialized")
    if not _is_newer_version(payload.governance_version, row.governance_version):
        return {"data": {"ignored_stale_version": True, "governance_version": row.governance_version}}
    for key,value in payload.model_dump().items(): setattr(row,key,value)
    await record_durable_audit(db, SecurityEvent(event_type=SecurityEventType.GOVERNANCE_POLICY_CHANGED, success=True, reason="Control Center policy synchronization", metadata=payload.model_dump()), actor_type="control_center")
    await db.commit(); return {"data":payload.model_dump()}

@router.put("/providers/{provider_type}")
async def sync_provider(provider_type: str, payload: ProviderPayload, db: AsyncSession=Depends(get_db), _cc=Depends(verify_control_center_service)):
    if payload.provider_type != provider_type: raise HTTPException(400,"provider_type mismatch")
    row=await db.scalar(select(ProviderRegistryEntry).where(ProviderRegistryEntry.provider_type==provider_type).with_for_update())
    if row is None:
        row=ProviderRegistryEntry(provider_type=provider_type); db.add(row)
    elif not _is_newer_version(payload.governance_version, row.governance_version):
        return {"data": {"ignored_stale_version": True, "governance_version": row.governance_version}}
    row.enabled=payload.enabled; row.priority=payload.priority; row.governance_version=payload.governance_version
    await record_durable_audit(db, SecurityEvent(event_type=SecurityEventType.PROVIDER_GOVERNANCE_CHANGED, success=True, reason="Control Center provider synchronization", metadata=payload.model_dump()), actor_type="control_center")
    await db.commit(); return {"data": {"provider_type":row.provider_type,"enabled":row.enabled,"priority":row.priority,"governance_version":row.governance_version}}

@router.put("/plans/{code}")
async def sync_plan(code: str, payload: PlanPayload, db: AsyncSession=Depends(get_db), _cc=Depends(verify_control_center_service)):
    if payload.code != code: raise HTTPException(400,"plan code mismatch")
    row=await db.scalar(select(SubscriptionPlan).where(SubscriptionPlan.code==code).with_for_update())
    if row is None:
        row=SubscriptionPlan(code=code); db.add(row)
    elif not _is_newer_version(payload.governance_version, row.governance_version):
        return {"data": {"ignored_stale_version": True, "governance_version": row.governance_version}}
    for key,value in payload.model_dump().items():
        if key != "code" and value is not None: setattr(row,key,value)
    await record_durable_audit(db, SecurityEvent(event_type=SecurityEventType.PLAN_GOVERNANCE_CHANGED, success=True, reason="Control Center plan synchronization", metadata=payload.model_dump()), actor_type="control_center")
    await db.commit(); return {"data": {"code":row.code,"active":row.active}}
