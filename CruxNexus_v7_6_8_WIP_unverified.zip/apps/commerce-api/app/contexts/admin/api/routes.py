import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.control_center_auth import verify_control_center_service
from app.contexts.admin.application.services import AdminEntitlementService
from app.contexts.admin.api.schemas import GrantPlanEntitlementsRequest, GrantPlanEntitlementsResponse
from app.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


@router.post("/entitlements/grant-plan-based", status_code=status.HTTP_200_OK)
async def grant_plan_based_entitlements(
    request_data: GrantPlanEntitlementsRequest,
    db: AsyncSession = Depends(get_db),
    _cc_context=Depends(verify_control_center_service),
):
    """
    Grant plan-based entitlements to an existing merchant.
    
    This is useful for fixing merchants who were onboarded before the
    automatic entitlement granting was implemented.

    Callable only by Control Center, authenticated as a service (see
    app/auth/control_center_auth.py). Previously had NO authorization
    dependency at all — any caller who could reach this route could grant
    arbitrary extra storefront/staff capacity to any merchant_account_id,
    unauthenticated. That was the single most severe issue found across
    both remediation passes on this repository.
    """
    try:
        service = AdminEntitlementService(db)
        result = await service.grant_plan_based_entitlements(
            merchant_account_id=request_data.merchant_account_id,
        )
        logger.info(
            "Plan-based entitlements granted for merchant_account_id=%s by "
            "Control Center (acting admin: %s)",
            request_data.merchant_account_id,
            _cc_context.acting_admin_id or "unspecified",
        )
        return {"data": GrantPlanEntitlementsResponse(**result).model_dump()}
    except Exception as e:
        await db.rollback()
        logger.exception("Failed to grant plan-based entitlements")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": {
                    "code": "ENTITLEMENT_GRANT_FAILED",
                    "message": "Failed to grant plan-based entitlements",
                    "details": {}
                }
            }
        )