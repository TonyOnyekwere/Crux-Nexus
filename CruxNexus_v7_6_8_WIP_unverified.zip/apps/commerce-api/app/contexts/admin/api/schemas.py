from uuid import UUID
from pydantic import BaseModel


class GrantPlanEntitlementsRequest(BaseModel):
    merchant_account_id: UUID


class GrantPlanEntitlementsResponse(BaseModel):
    merchant_account_id: UUID
    plan_code: str
    entitlements_created: list