"""Read-only merchant plan catalogue (CRX-FE-001).

Server-owned, database-backed view of the plans a merchant may select. It
mirrors the eligibility rule enforced by ``JourneyService.select_plan``
(plan is ``active``) so the list can never offer something selection would
reject. It never exposes Control Center policy (``capabilities``), the
governance version, provider configuration, or any administrative field.

``subscription_plans`` carries exactly one (price, currency, interval) per
plan, so the response carries exactly that - it does not invent a currency or
interval list. Pricing is reported as configured only when the same fields
payment initiation needs are present and the interval is one the period
calculation supports; otherwise price fields are ``None`` and
``pricing_configured`` is ``False`` (selecting such a plan is permitted by the
backend, but paying for it would be rejected with PLAN_PRICING_NOT_CONFIGURED).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Mapping, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.entities import SubscriptionPlan

# Intervals ``subscription_period_end`` can compute a period for.
SUPPORTED_BILLING_INTERVALS = frozenset({"monthly", "annual", "yearly"})


def serialize_resource_limits(raw: Any) -> dict[str, Optional[int]]:
    """Merchant-visible numeric limits from ``resource_limits``.

    Mirrors the entitlement engine: ``None`` means no limit configured;
    a malformed value (negative, non-integer, bool) is treated as 0
    (fail closed) rather than displayed as something more generous.
    """
    if not isinstance(raw, Mapping):
        return {}
    out: dict[str, Optional[int]] = {}
    for key in sorted(k for k in raw if isinstance(k, str)):
        value = raw[key]
        if value is None:
            out[key] = None
        elif isinstance(value, bool) or not isinstance(value, int) or value < 0:
            out[key] = 0
        else:
            out[key] = value
    return out


def serialize_plan(plan: Any) -> dict[str, Any]:
    amount = plan.price_amount
    currency = (plan.price_currency or "").strip().upper() or None
    interval = (plan.billing_interval or "").strip().lower() or None
    configured = (
        amount is not None
        and Decimal(amount) >= 0
        and currency is not None
        and interval in SUPPORTED_BILLING_INTERVALS
    )
    return {
        "code": plan.code,
        "name": plan.name,
        "pricing_configured": configured,
        "price": format(Decimal(amount), "f") if configured else None,
        "currency": currency if configured else None,
        "interval": interval if configured else None,
        "trial_days": plan.trial_days,
        "limits": {
            "included_storefronts": plan.included_storefronts,
            "base_staff_per_storefront": plan.base_staff_per_storefront,
            "max_extra_storefronts": plan.max_extra_storefronts,
            "max_extra_staff": plan.max_extra_staff,
            "resources": serialize_resource_limits(plan.resource_limits),
        },
    }


async def list_selectable_plans(db: AsyncSession) -> list[dict[str, Any]]:
    rows = (
        await db.execute(
            select(SubscriptionPlan)
            .where(SubscriptionPlan.active.is_(True))
            .order_by(
                SubscriptionPlan.price_amount.asc().nulls_last(),
                SubscriptionPlan.code.asc(),
            )
        )
    ).scalars().all()
    return [serialize_plan(row) for row in rows]
