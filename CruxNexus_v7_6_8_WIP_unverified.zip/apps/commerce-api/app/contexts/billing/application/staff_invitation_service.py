"""Staff invitation application service."""

import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
import hashlib

from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.contexts.billing.domain.staff_invitation import StaffInvitation, InvitationStatus
from app.contexts.identity.domain.entities import User, UserStatus
from app.contexts.tenant_management.domain.membership import TenantMembership, TenantRole, MembershipStatus
from app.exceptions import NotFoundError, ValidationError
from app.infrastructure.notifications import get_notification_provider

# Same hashing convention as IdentityService (app/contexts/identity/application/services.py)
pwd_context = CryptContext(schemes=["bcrypt"], bcrypt__rounds=12, deprecated="auto")


class StaffInvitationService:
    """Service for managing staff invitations."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_invitation(
        self,
        *,
        tenant_id: str,
        invited_email: str,
        role: str = "staff",
        invited_by: str,
        expires_in_hours: int = 168,  # 7 days default
        notification_channel: Optional[str] = "email",
    ) -> StaffInvitation:
        """Create a staff invitation.
        
        Args:
            tenant_id: The tenant to invite staff to
            invited_email: Email address of the staff member
            role: Role to assign (staff, manager)
            invited_by: User ID of the inviter
            expires_in_hours: How long the invitation is valid
            notification_channel: Channel to send notification (email, whatsapp, sms)
        
        Returns:
            The created StaffInvitation record (without the raw token)
        
        Raises:
            ValidationError: If email is invalid or already has pending invitation
        """
        # Normalize (external review fix — same case-sensitivity gap as
        # user accounts): without this, "Tony@x.com" and "tony@x.com"
        # could both get pending invitations, and matching an existing
        # User by invited_email (accept_invitation) could miss a
        # differently-cased account.
        invited_email = invited_email.strip().lower()

        # Check for existing pending invitation for this email
        existing = await self.db.execute(
            select(StaffInvitation).where(
                StaffInvitation.tenant_id == tenant_id,
                StaffInvitation.invited_email == invited_email,
                StaffInvitation.status == InvitationStatus.PENDING,
            )
        )
        if existing.scalar_one_or_none():
            raise ValidationError(
                f"A pending invitation already exists for {invited_email} in this tenant"
            )

        # Generate secure token
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode()).hexdigest()

        # Calculate expiration
        expires_at = datetime.now(timezone.utc) + timedelta(hours=expires_in_hours)

        # Create invitation
        invitation = StaffInvitation(
            tenant_id=tenant_id,
            invited_email=invited_email,
            role=role,
            token_hash=token_hash,
            status=InvitationStatus.PENDING,
            invited_by=invited_by,
            expires_at=expires_at,
            notification_channel=notification_channel,
        )
        self.db.add(invitation)
        await self.db.flush()

        # The raw token exists only in this local variable and in the
        # invitee's notification — only its hash is ever persisted. It
        # must be used here, before it goes out of scope, or nowhere: this
        # method previously discarded it right after hashing, which meant
        # no notification (real or otherwise) could ever have delivered a
        # usable invitation link even after a real provider was wired in.
        provider = get_notification_provider()
        result = await provider.send(
            channel=notification_channel or "email",
            recipient=invited_email,
            template="staff_invitation",
            context={
                "tenant_id": str(tenant_id),
                "role": role,
                "expires_at": expires_at.isoformat(),
                "invitation_token": token,
            },
        )
        if result.sent:
            invitation.notification_sent_at = result.sent_at

        # This was a real bug found in external review: every method in
        # this service previously only called flush(), never commit().
        # app/database/session.py's get_db() closes the session without
        # committing on the way out, so every "successful" invitation
        # create/accept/cancel response was actually rolled back the
        # moment the request finished — nothing was ever durably
        # persisted.
        await self.db.commit()

        return invitation

    async def accept_invitation(
        self,
        *,
        token: str,
        authenticated_user_id: Optional[str] = None,
        new_account_password: Optional[str] = None,
    ) -> TenantMembership:
        """Accept a staff invitation.

        Identity binding, fixed: this previously accepted a client-supplied
        `user_id` directly with no verification that the caller's actual
        authenticated identity corresponded to it — anyone holding a valid
        invitation token could assign the resulting membership to an
        arbitrary user_id of their choosing. Now:
        - if a user already exists for the invited email, the caller MUST
          be authenticated as that exact user (authenticated_user_id must
          match) - there is no other way to accept on an existing
          account's behalf.
        - if no user exists yet, one is created from the invitation with a
          real password (new_account_password, required in that case) -
          not the previous password_hash="" dead-end account.

        Double-accept race, fixed: the invitation row is now selected
        with FOR UPDATE before its status is checked, so two concurrent
        accept requests for the same token serialize instead of both
        observing PENDING and both proceeding.
        """
        token_hash = hashlib.sha256(token.encode()).hexdigest()

        result = await self.db.execute(
            select(StaffInvitation)
            .where(StaffInvitation.token_hash == token_hash)
            .with_for_update()
        )
        invitation = result.scalar_one_or_none()
        if not invitation:
            raise NotFoundError("invitation")

        if invitation.status != InvitationStatus.PENDING:
            raise ValidationError(f"Invitation is {invitation.status}, not pending.")

        if datetime.now(timezone.utc) > invitation.expires_at:
            invitation.status = InvitationStatus.EXPIRED
            await self.db.commit()
            raise ValidationError("Invitation has expired")

        user_result = await self.db.execute(
            select(User).where(User.email == invitation.invited_email)
        )
        existing_user = user_result.scalar_one_or_none()

        if existing_user:
            if not authenticated_user_id or str(authenticated_user_id) != str(existing_user.id):
                raise ValidationError(
                    "An account already exists for this invitation's email. "
                    "Log in as that account before accepting."
                )
            final_user_id = str(existing_user.id)
        else:
            if not new_account_password:
                raise ValidationError(
                    "A password is required to create an account for this invitation."
                )
            new_user = User(
                email=invitation.invited_email,
                password_hash=pwd_context.hash(new_account_password),
                status=UserStatus.UNVERIFIED,
            )
            self.db.add(new_user)
            await self.db.flush()
            final_user_id = str(new_user.id)

        existing_membership = await self.db.execute(
            select(TenantMembership).where(
                TenantMembership.tenant_id == invitation.tenant_id,
                TenantMembership.user_id == final_user_id,
            )
        )
        if existing_membership.scalar_one_or_none():
            raise ValidationError("User already has membership in this tenant")

        # Staff capacity enforcement (external review fix — P0): this
        # acceptance path previously created a TenantMembership directly,
        # never checking MerchantAccessResolver/CapacityService at all.
        # A Starter merchant with zero staff capacity could invite and
        # accept unlimited staff — a direct commercial entitlement
        # bypass, not just a missing nice-to-have. The deprecated
        # POST /tenants/{id}/members endpoint already enforced this; its
        # replacement (this invitation flow) did not.
        from app.contexts.merchant_management.domain.merchant_account_tenant import (
            MerchantAccountTenant,
        )
        from app.kernel.access.resolver import MerchantAccessResolver

        owner_result = await self.db.execute(
            select(MerchantAccountTenant.merchant_account_id).where(
                MerchantAccountTenant.tenant_id == invitation.tenant_id
            )
        )
        merchant_account_id = owner_result.scalar_one_or_none()
        if merchant_account_id is None:
            raise ValidationError("This storefront has no owning merchant account.")

        # MerchantAccount is the canonical serialization boundary for staff
        # capacity. Every concurrent membership admission for this merchant
        # locks the same row before counting active staff.
        from app.contexts.merchant_management.domain.entities import MerchantAccount
        merchant_row = (await self.db.execute(select(MerchantAccount).where(MerchantAccount.id == merchant_account_id).with_for_update())).scalar_one_or_none()
        if merchant_row is None:
            raise ValidationError("Merchant account not found.")
        resolver = MerchantAccessResolver(self.db)
        access = await resolver.can_add_staff(merchant_account_id, invitation.tenant_id)
        if not access.allowed:
            raise ValidationError(f"Cannot add staff: {access.reason}")

        membership = TenantMembership(
            tenant_id=invitation.tenant_id,
            user_id=final_user_id,
            role=invitation.role,
            status=MembershipStatus.ACTIVE.value,
        )
        self.db.add(membership)

        invitation.status = InvitationStatus.ACCEPTED
        invitation.accepted_at = datetime.now(timezone.utc)
        invitation.accepted_by = final_user_id

        await self.db.commit()
        return membership

    async def cancel_invitation(
        self,
        *,
        invitation_id: str,
        tenant_id: str,
        cancelled_by: str,
    ) -> StaffInvitation:
        """Cancel a pending invitation.

        tenant_id is now required and filtered in the same query that
        looks up the invitation — fixed a real authorization-ordering bug
        (external review): the previous version looked up the invitation
        by ID alone, mutated its status to CANCELLED, and only checked
        whether it belonged to the caller's tenant afterward in the route.
        By the time that check failed, the cross-tenant cancellation had
        already happened and committed. Filtering by tenant_id here means
        an invitation belonging to a different tenant simply doesn't
        match the query — the route can no longer accidentally mutate it
        before finding out it shouldn't have.
        """
        result = await self.db.execute(
            select(StaffInvitation).where(
                StaffInvitation.id == invitation_id,
                StaffInvitation.tenant_id == tenant_id,
            )
        )
        invitation = result.scalar_one_or_none()
        if not invitation:
            raise NotFoundError("invitation")

        if invitation.status != InvitationStatus.PENDING:
            raise ValidationError(
                f"Cannot cancel invitation with status {invitation.status}"
            )

        invitation.status = InvitationStatus.CANCELLED
        await self.db.commit()

        return invitation

    async def get_invitation_by_token(self, token: str) -> Optional[StaffInvitation]:
        """Get invitation by token (for validation before acceptance).
        
        Args:
            token: The invitation token
        
        Returns:
            The invitation if found and valid, None otherwise
        """
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        result = await self.db.execute(
            select(StaffInvitation).where(
                StaffInvitation.token_hash == token_hash,
                StaffInvitation.status == InvitationStatus.PENDING,
            )
        )
        return result.scalar_one_or_none()

    async def list_pending_invitations(
        self,
        tenant_id: str,
    ) -> list[StaffInvitation]:
        """List all pending invitations for a tenant.
        
        Args:
            tenant_id: The tenant to list invitations for
        
        Returns:
            List of pending invitations
        """
        result = await self.db.execute(
            select(StaffInvitation).where(
                StaffInvitation.tenant_id == tenant_id,
                StaffInvitation.status == InvitationStatus.PENDING,
            )
        )
        return result.scalars().all()
