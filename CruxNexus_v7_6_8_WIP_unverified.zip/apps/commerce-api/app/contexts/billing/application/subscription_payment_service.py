"""Subscription payment orchestration.

Locked Onboarding & Activation Architecture, section 8, and the full
chain external review has repeatedly required before this can be called
done:

    Payment initiated -> Provider -> Webhook -> Signature verification
    -> Webhook deduplication -> Financial transaction -> Provider
    verification/reconciliation -> Subscription transition ->
    Merchant/storefront activation -> Audit/outbox event

Two halves, deliberately asymmetric in how complete they are:

1. initiate_payment: creates the FinancialTransaction and calls the
   provider adapter to start a charge. Explicitly REFUSES to run if the
   plan has no configured price (migration 027 added price_amount/
   price_currency/billing_interval as nullable, unpopulated columns —
   real production pricing is a business decision that has not been
   supplied, and this method will not invent one or accept one from a
   caller). This is what makes the missing parameter visible rather than
   worked around.

2. process_webhook_event: the reconciliation logic. This is the half
   that actually closes the long-standing "webhook says paid, does
   nothing happen" gap. Critically, per explicit external review
   warning: this NEVER sets subscription.status = ACTIVE just because a
   webhook payload claims success. It always re-verifies with the
   provider directly (adapter.verify_transaction), and only acts on a
   FinancialTransaction it can identify unambiguously via
   provider_reference — an event that doesn't resolve to a known
   transaction, or whose verified amount/currency don't match what that
   transaction was created for, is treated as an anomaly and does NOT
   activate anything, rather than being force-fit into the closest
   guess.

What this does NOT do, and why that's not a gap:
- Does not separately "activate entitlements" as a distinct step.
  Effective capacity is already computed dynamically from current
  subscription status (see MerchantAccessResolver and CapacityService) —
  there are no discrete entitlement rows to flip on. The subscription
  status transition IS the entitlement activation.
- Does not separately "activate the storefront/tenant". Tenant/
  MerchantAccount status are independent authorities (suspend/offboard
  are explicit actions) that were never coupled to subscription payment
  success in this architecture — access is gated by checking subscription
  status at the point of use, not by cascading a status write onto Tenant.
"""

from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Optional
from uuid import UUID

from sqlalchemy import select, and_, exists
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.financial_transaction import (
    FinancialTransaction,
    FinancialTransactionStatus,
    PaymentProvider,
    ProviderWebhookEvent,
)
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.billing.domain.governance_policy import CommerceGovernancePolicy
from app.infrastructure.outbox.repository import OutboxRepository
from app.infrastructure.worker_jobs import enqueue_job
from app.infrastructure.payments.adapter import (
    is_in_flight,
    ProviderRejectedError,
    ProviderTransactionNotFoundError,
    get_payment_provider_registry,
)
from app.kernel.events.types import DomainEvent, EventEnvelope

logger = logging.getLogger(__name__)


class PlanPricingNotConfiguredError(ValueError):
    """Raised instead of inventing or accepting a client-supplied amount
    when a plan has no price configured yet."""


class PaymentOutcomeUnknownError(RuntimeError):
    """Provider initiation timed out / returned 5xx: a charge MAY exist.
    The transaction stays PENDING and is resolved by the webhook path or
    the stale-pending sweeper. Callers must tell the merchant to wait and
    must NOT retry with a new charge."""

    def __init__(self, reference: str, message: str = ""):
        super().__init__(message or f"Payment outcome unknown for {reference}")
        self.reference = reference


class PaymentAlreadyCompletedError(RuntimeError):
    """A previous attempt for this subscription turned out to be paid."""


class SubscriptionAlreadyActiveError(RuntimeError):
    """An already-active subscription cannot start another pay-now charge."""


class PriorPaymentUnverifiableError(RuntimeError):
    """A previous attempt for this subscription is still pending and the
    provider could not be asked about it right now; starting a second
    charge could double-bill the merchant."""


# Pending transactions younger than this are left to the webhook path by
# the sweeper; older ones are verified directly with the provider.
STALE_PENDING_AFTER = timedelta(minutes=15)


def subscription_period_end(start: datetime, billing_interval: str | None, *, monthly_days: int = 30, yearly_days: int = 365) -> datetime:
    if billing_interval == "monthly":
        return start + timedelta(days=monthly_days)
    if billing_interval in {"annual", "yearly"}:
        return start + timedelta(days=yearly_days)
    raise ValueError(f"Unsupported billing interval: {billing_interval}")


class SubscriptionPaymentService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def initiate_payment(
        self,
        *,
        merchant_account_id: UUID,
        subscription_id: UUID,
        merchant_email: str,
        provider: PaymentProvider,
        redirect_url: str,
    ) -> dict:
        """Start a pay-now subscription charge. Returns the checkout
        redirect URL the merchant's browser is sent to.

        Duplicate-charge safety (external review P1): the pending
        transaction is COMMITTED before the provider is called, so a crash
        can never leave a provider charge with no local record; a provider
        timeout / 5xx leaves the transaction PENDING (outcome unknown)
        instead of FAILED; and any earlier pending attempt for the same
        subscription is verified with the provider before a new charge is
        allowed.
        """
        # Row lock serialises concurrent initiations for one subscription.
        subscription_result = await self.db.execute(
            select(MerchantSubscription)
            .where(MerchantSubscription.id == subscription_id)
            .with_for_update()
        )
        subscription = subscription_result.scalar_one_or_none()
        if subscription is None:
            raise ValueError("Subscription not found.")
        if subscription.merchant_account_id != merchant_account_id:
            raise ValueError("Subscription does not belong to this merchant.")
        if subscription.status == SubscriptionStatus.ACTIVE.value:
            raise SubscriptionAlreadyActiveError(
                "This subscription is already active. A new subscription payment cannot be started while the current period is active."
            )

        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == subscription.subscription_plan_id)
        )
        plan = plan_result.scalar_one_or_none()
        if plan is None:
            raise ValueError("Plan not found.")

        if plan.price_amount is None or plan.price_currency is None:
            raise PlanPricingNotConfiguredError(
                f"Plan '{plan.code}' has no configured price yet — pay-now activation "
                "cannot proceed until real pricing is supplied (see migration 027)."
            )

        # Resolve the adapter before creating anything: an unconfigured
        # provider is a config error, not a payment attempt.
        adapter = get_payment_provider_registry().get(provider)

        await self._resolve_prior_pending(subscription_id)

        reference = f"CNX-{secrets.token_hex(12)}"

        transaction = FinancialTransaction(
            reference=reference,
            merchant_account_id=merchant_account_id,
            subscription_id=subscription_id,
            subscription_plan_id=plan.id,
            provider=provider.value,
            # Both adapters use our reference as the provider-side
            # reference (see PaymentProviderAdapter.verify_transaction), so
            # a webhook can resolve this row even if initiation's outcome
            # was never observed.
            provider_reference=reference,
            amount=plan.price_amount,
            currency=plan.price_currency,
            status=FinancialTransactionStatus.PENDING.value,
        )
        self.db.add(transaction)
        subscription.status = SubscriptionStatus.PAYMENT_PENDING.value
        await self.db.commit()  # durable record + subscription claim BEFORE any provider call

        try:
            charge = await adapter.initialize_charge(
                reference=reference,
                amount=plan.price_amount,
                currency=plan.price_currency,
                merchant_email=merchant_email,
                redirect_url=redirect_url,
            )
        except ProviderRejectedError as exc:
            # Definitive refusal / request never sent: no charge can exist.
            # Close the subscription claim in the same lifecycle transition
            # so PAYMENT_PENDING cannot strand the merchant after a provider
            # rejection.
            await self._close_unpaid(transaction, FinancialTransactionStatus.FAILED)
            logger.error("Payment initiation rejected for %s: %s", reference, exc)
            raise
        except Exception as exc:
            # Timeout, 5xx, unparseable response, or anything unexpected
            # after the request may have been sent: a charge MAY exist.
            # Keep PENDING; webhook / sweeper resolves it.
            if subscription.status != SubscriptionStatus.PAYMENT_PENDING.value:
                subscription.status = SubscriptionStatus.PAYMENT_PENDING.value
            await self.db.commit()
            logger.error(
                "Payment initiation outcome UNKNOWN for %s (left PENDING): %r", reference, exc
            )
            raise PaymentOutcomeUnknownError(reference) from exc

        transaction.provider_reference = charge.provider_reference
        transaction.payment_method = None
        transaction.authorization_type = charge.authorization_type.value

        subscription.status = SubscriptionStatus.PAYMENT_PENDING.value

        await self.db.commit()

        return {
            "reference": reference,
            "redirect_url": charge.redirect_url,
            "provider": provider.value,
        }

    async def _resolve_prior_pending(self, subscription_id: UUID) -> None:
        """Charge lock. Before a NEW charge, every earlier PENDING attempt for this subscription must have
        reached a terminal state: paid (-> refuse, already paid), or failed / abandoned / provider
        not-found with strong evidence (-> safe). A provider that still says PENDING or UNKNOWN, an
        unreachable provider, or a young or inconclusive not-found all BLOCK the new charge. Age alone
        never authorizes a second charge (see domain/charge_lock.py)."""
        result = await self.db.execute(
            select(FinancialTransaction.id).where(
                FinancialTransaction.subscription_id == subscription_id,
                FinancialTransaction.status == FinancialTransactionStatus.PENDING.value,
            ).order_by(FinancialTransaction.created_at)
        )
        for transaction_id in result.scalars().all():
            try:
                outcome = await self.reconcile_transaction(transaction_id)
            except Exception as exc:
                await self.db.rollback()
                raise PriorPaymentUnverifiableError(
                    "An earlier payment attempt could not be verified with the provider; "
                    "do not pay again yet. It will be resolved automatically."
                ) from exc
            if outcome == FinancialTransactionStatus.SUCCESSFUL.value:
                raise PaymentAlreadyCompletedError(
                    "A previous payment attempt for this subscription has succeeded."
                )
            if outcome == FinancialTransactionStatus.PENDING.value:
                raise PriorPaymentUnverifiableError(
                    "An earlier payment attempt is still unresolved at the payment provider. "
                    "Do not pay again; it will be confirmed or closed automatically."
                )

    async def reconcile_transaction(self, transaction_id: UUID) -> str:
        """Resolve one PENDING transaction by asking the provider directly (no webhook needed) and return
        its resulting status. The decision comes from domain/charge_lock.py: only SUCCESS, FAILED,
        ABANDONED or a provider not-found that is strong evidence end a transaction; everything else
        leaves it PENDING. Provider-unreachable errors propagate so the caller can retry."""
        from app.contexts.billing.domain.charge_lock import (
            PAID, TERMINAL_ABANDONED, TERMINAL_FAILED, classify_prior_attempt,
        )

        result = await self.db.execute(
            select(FinancialTransaction)
            .where(FinancialTransaction.id == transaction_id)
            .with_for_update()
        )
        transaction = result.scalar_one_or_none()
        if transaction is None:
            raise ValueError("Transaction not found.")
        if transaction.status != FinancialTransactionStatus.PENDING.value:
            return transaction.status

        adapter = get_payment_provider_registry().get(PaymentProvider(transaction.provider))
        verification = None
        try:
            verification = await adapter.verify_transaction(
                transaction.provider_reference or transaction.reference
            )
            provider_state = verification.status
        except ProviderTransactionNotFoundError:
            provider_state = "NOT_FOUND"

        created = transaction.created_at
        age = (datetime.now(timezone.utc) - created) if created is not None else timedelta(0)
        decision = classify_prior_attempt(
            provider_state=provider_state, age=age,
            not_found_conclusive_after=getattr(adapter, "not_found_conclusive_after", None),
        )
        if decision == PAID:
            await self._apply_verification(transaction, verification)
            await self.db.commit()
        elif decision == TERMINAL_FAILED:
            await self._close_unpaid(transaction, FinancialTransactionStatus.FAILED)
        elif decision == TERMINAL_ABANDONED:
            await self._close_unpaid(transaction, FinancialTransactionStatus.ABANDONED)
        else:
            await self.db.commit()  # still unresolved: release the row lock, keep PENDING
        return transaction.status

    async def _close_unpaid(
        self, transaction: FinancialTransaction, status: FinancialTransactionStatus
    ) -> None:
        transaction.status = status.value
        subscription_result = await self.db.execute(
            select(MerchantSubscription).where(MerchantSubscription.id == transaction.subscription_id)
        )
        subscription = subscription_result.scalar_one_or_none()
        if subscription is not None and subscription.status == SubscriptionStatus.PAYMENT_PENDING.value:
            subscription.status = SubscriptionStatus.PAYMENT_FAILED.value
            await OutboxRepository(self.db).append(
                EventEnvelope(
                    event_type=DomainEvent.PAYMENT_FAILED,
                    aggregate_type="FinancialTransaction",
                    aggregate_id=transaction.id,
                    payload={"reference": transaction.reference, "provider": transaction.provider},
                )
            )
        await self.db.commit()

    async def process_webhook_event(self, webhook_event_id: UUID) -> None:
        """Reconcile one verified-but-unprocessed webhook event into a
        subscription state transition. Idempotent — safe to call twice
        for the same event (a duplicate delivery, or a retry after a
        transient failure)."""
        event_result = await self.db.execute(
            select(ProviderWebhookEvent).where(ProviderWebhookEvent.id == webhook_event_id)
        )
        event = event_result.scalar_one_or_none()
        if event is None:
            logger.error("process_webhook_event called with unknown event_id=%s", webhook_event_id)
            return

        if event.processed:
            return  # already handled - idempotent no-op

        if not event.signature_verified:
            # Should be unreachable (webhook_routes.py never persists an
            # unverified event), but never act on one if it somehow exists.
            event.processing_error = "Refused to process: signature not verified."
            event.processed = True
            event.processed_at = datetime.now(timezone.utc)
            await self.db.commit()
            return

        provider_reference = (event.raw_payload or {}).get("data", {}).get("reference") or (
            event.raw_payload or {}
        ).get("data", {}).get("tx_ref")

        if not provider_reference:
            event.processing_error = "No provider_reference extractable from payload."
            event.processed = True
            event.processed_at = datetime.now(timezone.utc)
            await self.db.commit()
            logger.error("Webhook event %s has no extractable provider_reference.", event.id)
            return

        transaction_result = await self.db.execute(
            select(FinancialTransaction).where(
                FinancialTransaction.provider == event.provider_code,
                FinancialTransaction.provider_reference == provider_reference,
            ).with_for_update()
        )
        transaction = transaction_result.scalar_one_or_none()

        if transaction is None:
            # An event that doesn't resolve to a transaction WE created is
            # an anomaly, not something to guess about — never activate
            # anything on the strength of a webhook alone (external
            # review's explicit warning). Mark processed so it doesn't
            # loop forever, but flag loudly for investigation.
            event.processing_error = (
                f"No FinancialTransaction found for provider={event.provider_code} "
                f"provider_reference={provider_reference}."
            )
            event.processed = True
            event.processed_at = datetime.now(timezone.utc)
            await self.db.commit()
            logger.error(event.processing_error)
            return

        if transaction.status == FinancialTransactionStatus.SUCCESSFUL.value:
            # Already reconciled by an earlier delivery of this or another
            # event referencing the same transaction - idempotent no-op.
            event.processed = True
            event.processed_at = datetime.now(timezone.utc)
            await self.db.commit()
            return

        registry = get_payment_provider_registry()
        try:
            provider_enum = PaymentProvider(event.provider_code)
            adapter = registry.get(provider_enum)
            verification = await adapter.verify_transaction(transaction.provider_reference)
        except ProviderTransactionNotFoundError as exc:
            # Definitive provider absence is not a transient worker failure.
            # Close the local transaction and consume the webhook so it does
            # not retry forever.
            await self._close_unpaid(transaction, FinancialTransactionStatus.FAILED)
            event.processing_error = str(exc)
            event.processed = True
            event.processed_at = datetime.now(timezone.utc)
            await self.db.commit()
            return
        except Exception as exc:
            # Outcome unknown/network/provider failure remains retryable.
            logger.error("verify_transaction failed for event %s: %s", event.id, exc)
            return

        if is_in_flight(verification.status):
            event.processing_error = "Provider reports transaction still in flight; retry later."
            await self.db.commit()
            return

        outcome, error = await self._apply_verification(transaction, verification)
        if error:
            event.processing_error = error
        event.processed = True
        event.processed_at = datetime.now(timezone.utc)
        await self.db.commit()

    async def _apply_verification(
        self, transaction: FinancialTransaction, verification
    ) -> tuple[str, Optional[str]]:
        """Apply an independently re-verified provider result to a
        transaction and its subscription. Shared by the webhook path and
        the stale-pending sweeper so both enforce identical rules.
        Never commits: the caller commits, together with whatever else it
        is marking processed, so state and bookkeeping land atomically.
        Returns (outcome, error) where outcome is one of
        "mismatch" | "successful" | "failed"."""
        # Never trust the webhook payload's amount/status directly - only
        # the independently re-verified result, cross-checked against
        # what this specific transaction was actually created for.
        amount_matches = Decimal(str(verification.amount)) == Decimal(str(transaction.amount))
        currency_matches = verification.currency == transaction.currency

        if not (amount_matches and currency_matches):
            transaction.status = FinancialTransactionStatus.FAILED.value
            subscription_result = await self.db.execute(select(MerchantSubscription).where(MerchantSubscription.id == transaction.subscription_id).with_for_update())
            subscription = subscription_result.scalar_one_or_none()
            if subscription is not None and subscription.status == SubscriptionStatus.PAYMENT_PENDING.value:
                subscription.status = SubscriptionStatus.PAYMENT_FAILED.value
                await OutboxRepository(self.db).append(EventEnvelope(event_type=DomainEvent.PAYMENT_FAILED, aggregate_type="FinancialTransaction", aggregate_id=transaction.id, tenant_id=None, payload={"reference":transaction.reference,"reason":"amount_or_currency_mismatch"}))
            error = (
                f"Verified amount/currency ({verification.amount} {verification.currency}) "
                f"does not match transaction {transaction.reference} "
                f"({transaction.amount} {transaction.currency}) - possible tampering or "
                "a provider-side data issue. NOT activating."
            )
            logger.critical(error)
            return "mismatch", error

        if verification.successful:
            transaction.status = FinancialTransactionStatus.SUCCESSFUL.value
            transaction.completed_at = datetime.now(timezone.utc)

            await enqueue_job(self.db, "billing.activate_subscription", {"transaction_id": str(transaction.id)}, max_attempts=8)
            outbox = OutboxRepository(self.db)
            await outbox.append(
                EventEnvelope(
                    event_type=DomainEvent.PAYMENT_SUCCESSFUL,
                    aggregate_type="FinancialTransaction",
                    aggregate_id=transaction.id,
                    payload={"reference": transaction.reference, "provider": transaction.provider},
                )
            )
        elif verification.status in ("FAILED", "ABANDONED", "NOT_FOUND"):
            transaction.status = (
                FinancialTransactionStatus.ABANDONED.value if verification.status == "ABANDONED"
                else FinancialTransactionStatus.FAILED.value
            )

            subscription_result = await self.db.execute(
                select(MerchantSubscription).where(MerchantSubscription.id == transaction.subscription_id)
            )
            subscription = subscription_result.scalar_one_or_none()
            if subscription is not None and subscription.status == SubscriptionStatus.PAYMENT_PENDING.value:
                subscription.status = SubscriptionStatus.PAYMENT_FAILED.value

            outbox = OutboxRepository(self.db)
            await outbox.append(
                EventEnvelope(
                    event_type=DomainEvent.PAYMENT_FAILED,
                    aggregate_type="FinancialTransaction",
                    aggregate_id=transaction.id,
                    payload={"reference": transaction.reference, "provider": transaction.provider},
                )
            )


        return ("successful" if verification.successful else "failed"), None

    async def activate_verified_subscription(self, transaction_id: UUID) -> None:
        transaction=(await self.db.execute(select(FinancialTransaction).where(FinancialTransaction.id==transaction_id).with_for_update())).scalar_one_or_none()
        if transaction is None or transaction.status != FinancialTransactionStatus.SUCCESSFUL.value or transaction.subscription_activation_applied:
            return
        subscription=(await self.db.execute(select(MerchantSubscription).where(MerchantSubscription.id==transaction.subscription_id).with_for_update())).scalar_one_or_none()
        if subscription is None:
            transaction.subscription_activation_applied=True; return
        states={SubscriptionStatus.ACTIVE.value,SubscriptionStatus.PAYMENT_PENDING.value,SubscriptionStatus.PAYMENT_FAILED.value,SubscriptionStatus.PAST_DUE.value,SubscriptionStatus.TRIAL_EXPIRED.value,SubscriptionStatus.SUSPENDED.value}
        if subscription.status not in states:
            transaction.subscription_activation_applied=True; return
        was_lapsed=subscription.status in {SubscriptionStatus.TRIAL_EXPIRED.value,SubscriptionStatus.SUSPENDED.value}
        was_active=subscription.status==SubscriptionStatus.ACTIVE.value
        now=datetime.now(timezone.utc)
        plan=await self.db.scalar(select(SubscriptionPlan).where(SubscriptionPlan.id==subscription.subscription_plan_id))
        policy=await self.db.scalar(select(CommerceGovernancePolicy).where(CommerceGovernancePolicy.policy_key=="default"))
        if plan is None or not plan.billing_interval or policy is None: raise ValueError("Subscription governance is not configured")
        if was_active:
            anchor=max(subscription.ends_at or now,now)
            subscription.ends_at=subscription_period_end(anchor,plan.billing_interval,monthly_days=policy.monthly_period_days,yearly_days=policy.yearly_period_days)
        else:
            subscription.starts_at=now
            subscription.ends_at=subscription_period_end(now,plan.billing_interval,monthly_days=policy.monthly_period_days,yearly_days=policy.yearly_period_days)
            subscription.trial_ends_at=None
        subscription.status=SubscriptionStatus.ACTIVE.value
        if was_lapsed: await self._restore_suspended_storefronts(transaction.merchant_account_id)
        await OutboxRepository(self.db).append(EventEnvelope(event_type=DomainEvent.SUBSCRIPTION_ACTIVATED,aggregate_type="MerchantSubscription",aggregate_id=subscription.id,payload={"merchant_account_id":str(transaction.merchant_account_id),"financial_transaction_reference":transaction.reference}))
        transaction.subscription_activation_applied=True

    async def _restore_suspended_storefronts(self, merchant_account_id: UUID) -> int:
        """Flip every SUSPENDED storefront owned by this merchant back to
        ACTIVE. Only SUSPENDED - never touches ARCHIVED/OFFBOARDING/
        PROVISIONING/ONBOARDING, which are unrelated, more final states
        this reactivation has no business overriding.
        """
        from sqlalchemy import update

        from app.contexts.merchant_management.domain.merchant_account_tenant import (
            MerchantAccountTenant,
        )
        from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus

        owned_tenant_ids_result = await self.db.execute(
            select(MerchantAccountTenant.tenant_id).where(
                MerchantAccountTenant.merchant_account_id == merchant_account_id
            )
        )
        owned_tenant_ids = [row[0] for row in owned_tenant_ids_result.all()]
        if not owned_tenant_ids:
            return 0

        from app.contexts.tenant_management.domain.suspension import TenantSuspension
        governance_override = TenantSuspension.__table__.alias("governance_override")
        restorable = (await self.db.execute(
            select(TenantSuspension.tenant_id).where(
                TenantSuspension.tenant_id.in_(owned_tenant_ids),
                TenantSuspension.restored_at.is_(None),
                TenantSuspension.restorable_by_subscription.is_(True),
                TenantSuspension.governance_override.is_(False),
                ~exists(select(1).select_from(governance_override).where(
                    governance_override.c.tenant_id == TenantSuspension.tenant_id,
                    governance_override.c.restored_at.is_(None),
                    governance_override.c.governance_override.is_(True),
                )),
            )
        )).scalars().all()
        if not restorable:
            return 0
        result = await self.db.execute(
            update(Tenant)
            .where(Tenant.id.in_(restorable), Tenant.status == TenantStatus.SUSPENDED)
            .values(status=TenantStatus.ACTIVE)
        )
        await self.db.execute(
            update(TenantSuspension)
            .where(TenantSuspension.tenant_id.in_(restorable), TenantSuspension.restored_at.is_(None), TenantSuspension.restorable_by_subscription.is_(True))
            .values(restored_at=datetime.now(timezone.utc))
        )
        return result.rowcount or 0
