import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, DateTime, ForeignKey, String, Integer, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base

class AllocationAnomaly(Base):
    __tablename__ = "allocation_anomalies"
    __table_args__ = (UniqueConstraint("merchant_entitlement_id", "anomaly_type", name="uq_allocation_anomaly"),)
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_entitlement_id = Column(UUID(as_uuid=True), ForeignKey("merchant_entitlements.id", ondelete="CASCADE"), nullable=False, index=True)
    anomaly_type = Column(String(80), nullable=False)
    status = Column(String(20), nullable=False, default="open")
    granted_quantity = Column(Integer, nullable=False)
    allocated_quantity = Column(Integer, nullable=False)
    opened_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    resolved_at = Column(DateTime(timezone=True), nullable=True)
