"""Canonical subscription payment transaction and webhook inbox.

Locked Onboarding & Activation Architecture, sections 9-11. See migration
022 for the schema. FinancialTransaction is the CNX-TXN identity that
exists independently of whichever provider processed it (section 10) —
domain code and reporting query this table, never a provider's own
reference as the source of truth. ProviderWebhookEvent is the immutable
inbox every webhook lands in before being normalized (section 11).

PaystackAdapter and FlutterwaveAdapter implement the provider boundary.
Sandbox credentials are required for runtime verification before production.
"""

from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID

from app.database import Base


class PaymentProvider(str, enum.Enum):
    PAYSTACK = "paystack"
    FLUTTERWAVE = "flutterwave"


class PaymentAuthorizationType(str, enum.Enum):
    """Locked architecture section 4: not every payment method can renew a
    subscription automatically, so the authorization type is modeled
    separately from both `provider` and `status`. A merchant paying via a
    non-recurring method still activates the subscription; renewal may
    require a fresh payment rather than an automatic charge."""

    ONE_TIME_PAYMENT = "one_time_payment"
    RECURRING_AUTHORIZATION = "recurring_authorization"
    BANK_TRANSFER_RENEWAL = "bank_transfer_renewal"
    DIRECT_DEBIT_MANDATE = "direct_debit_mandate"
    CARD_AUTHORIZATION = "card_authorization"


class FinancialTransactionStatus(str, enum.Enum):
    PENDING = "pending"
    SUCCESSFUL = "successful"
    FAILED = "failed"
    REVERSED = "reversed"
    ABANDONED = "abandoned"


class FinancialTransaction(Base):
    """A single subscription-payment attempt. `reference` is the
    externally-shareable CNX-TXN identity; `provider_reference` is that
    provider's own transaction/reference ID, kept only for reconciliation
    — never used as the primary lookup key elsewhere in the app."""

    __tablename__ = "financial_transactions"
    __table_args__ = (
        CheckConstraint(
            "provider IN ('paystack', 'flutterwave')",
            name="chk_financial_transaction_provider",
        ),
        CheckConstraint(
            "status IN ('pending', 'successful', 'failed', 'reversed', 'abandoned')",
            name="chk_financial_transaction_status",
        ),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    reference = Column(String(64), nullable=False, unique=True)

    merchant_account_id = Column(
        UUID(as_uuid=True),
        ForeignKey("merchant_accounts.id", ondelete="CASCADE"),
        nullable=False,
    )

    subscription_id = Column(
        UUID(as_uuid=True),
        ForeignKey("merchant_subscriptions.id", ondelete="SET NULL"),
        nullable=True,
    )

    subscription_plan_id = Column(
        UUID(as_uuid=True),
        ForeignKey("subscription_plans.id", ondelete="RESTRICT"),
        nullable=False,
    )

    provider = Column(String(30), nullable=False)

    provider_reference = Column(String(255), nullable=True)

    amount = Column(Numeric(14, 2), nullable=False)

    currency = Column(String(3), nullable=False, default="NGN")

    payment_method = Column(String(30), nullable=True)

    authorization_type = Column(String(30), nullable=True)

    status = Column(String(20), nullable=False, default=FinancialTransactionStatus.PENDING.value)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    subscription_activation_applied = Column(Boolean, nullable=False, default=False)

    completed_at = Column(DateTime(timezone=True), nullable=True)


class ProviderWebhookEvent(Base):
    """Immutable webhook inbox. A row is only ever inserted once (enforced
    by uk_provider_webhook_event) and only has `processed`/`processed_at`/
    `processing_error` updated after — `raw_payload` itself is never
    edited, so the original provider event is always reconstructable."""

    __tablename__ = "provider_webhook_events"
    __table_args__ = (
        UniqueConstraint("provider_code", "provider_event_id", name="uk_provider_webhook_event"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    provider_code = Column(String(30), nullable=False)

    provider_event_id = Column(String(255), nullable=False)

    event_type = Column(String(100), nullable=True)

    raw_payload = Column(JSONB, nullable=False)

    signature_verified = Column(Boolean, nullable=False, default=False)

    processed = Column(Boolean, nullable=False, default=False)

    processed_at = Column(DateTime(timezone=True), nullable=True)

    processing_error = Column(Text, nullable=True)

    received_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
