"""Staff invitation domain model."""

from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import Column, DateTime, String, ForeignKey, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class InvitationStatus(str, enum.Enum):
    PENDING = "PENDING"
    ACCEPTED = "ACCEPTED"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"


class StaffInvitation(Base):
    """Staff invitation for secure tenant membership invitation.
    
    This table implements the secure invitation flow:
    - Owner/Admin creates invitation with email and role
    - Invitation is stored with hashed token for security
    - Notification is sent via configured channel (email, WhatsApp, SMS)
    - Staff member accepts invitation using token
    - If staff member has no account, one is created
    - If staff member has account, it is linked
    - TenantMembership is created with ACTIVE status
    - Staff member receives tenant access
    
    Security model:
    - PENDING: Invitation created, awaiting acceptance
    - ACCEPTED: Invitation accepted, membership activated
    - EXPIRED: Invitation expired, no longer valid
    - CANCELLED: Invitation cancelled by inviter
    
    The invitation token establishes tenant context, so staff members
    do not need to know the tenant ID in advance.
    """
    __tablename__ = "staff_invitations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    tenant_id = Column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
    )

    invited_email = Column(
        String(255),
        nullable=False,
    )

    role = Column(
        String(50),
        nullable=False,
        default="staff",
    )

    token_hash = Column(
        String(255),
        nullable=False,
        unique=True,
    )

    status = Column(
        SQLEnum(
            InvitationStatus,
            name="invitation_status",
            create_type=False,
            values_callable=lambda enum_cls: [member.value for member in enum_cls],
        ),
        nullable=False,
        default=InvitationStatus.PENDING,
    )

    invited_by = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    accepted_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    accepted_by = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    expires_at = Column(
        DateTime(timezone=True),
        nullable=False,
    )

    notification_channel = Column(
        String(50),
        nullable=True,
    )

    notification_sent_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Invariants:
    # - expires_at > created_at
    # - token_hash is non-empty
    # - invited_email must be valid email format
    # - status transitions: PENDING → ACCEPTED/EXPIRED/CANCELLED
    # - accepted_at and accepted_by are set when status → ACCEPTED
    # - Only PENDING invitations can be accepted
    # - Expiration is checked before acceptance