import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, DateTime, Integer, Boolean, String
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base

class CommerceGovernancePolicy(Base):
    __tablename__ = "commerce_governance_policy"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    policy_key = Column(String(80), nullable=False, unique=True, default="default")
    grace_period_days = Column(Integer, nullable=False, default=3)
    monthly_period_days = Column(Integer, nullable=False, default=30)
    yearly_period_days = Column(Integer, nullable=False, default=365)
    allow_early_renewal = Column(Boolean, nullable=False, default=False)
    governance_version = Column(String(80), nullable=False, default="initial")

    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
