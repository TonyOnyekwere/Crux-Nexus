"""Subscription charge lock (pure, no I/O).

Invariant (locked by Kratos): an earlier provider transaction that is still PENDING blocks any new
charge for the same subscription until it reaches a TERMINAL state:

    SUCCESS (the subscription is paid)   FAILED   ABANDONED
    NOT_FOUND, but ONLY where the provider gives sufficiently strong evidence

No timeout may authorize a second charge. Age is used for exactly one thing: deciding whether a
provider "not found" is strong evidence (the originating initialization can no longer be in flight AND
the provider is known to create the transaction record at initialization). PENDING and UNKNOWN never
become terminal by waiting; they block, and reconciliation keeps asking the provider.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Optional

PAID = "paid"
TERMINAL_FAILED = "terminal_failed"
TERMINAL_ABANDONED = "terminal_abandoned"
BLOCK = "block"

IN_FLIGHT_STATES = frozenset({"PENDING", "UNKNOWN"})


def classify_prior_attempt(
    *, provider_state: str, age: timedelta, not_found_conclusive_after: Optional[timedelta]
) -> str:
    """Decide what an earlier attempt means for a NEW charge. `provider_state` is the normalized provider
    answer: SUCCESS | PENDING | FAILED | ABANDONED | UNKNOWN | NOT_FOUND."""
    if provider_state == "SUCCESS":
        return PAID
    if provider_state == "FAILED":
        return TERMINAL_FAILED
    if provider_state == "ABANDONED":
        return TERMINAL_ABANDONED
    if provider_state == "NOT_FOUND":
        if not_found_conclusive_after is not None and age >= not_found_conclusive_after:
            return TERMINAL_FAILED
        return BLOCK  # not strong evidence (too young, or this provider's "not found" is not conclusive)
    return BLOCK  # PENDING, UNKNOWN, or anything unrecognized: never safe to charge again


def allows_new_charge(decision: str) -> bool:
    return decision in (TERMINAL_FAILED, TERMINAL_ABANDONED)
