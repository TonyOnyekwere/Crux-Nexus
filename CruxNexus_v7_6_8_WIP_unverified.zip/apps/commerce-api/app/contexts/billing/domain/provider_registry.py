import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, DateTime, String, Boolean, Integer
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base

class ProviderRegistryEntry(Base):
    __tablename__ = "provider_registry_cache"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    provider_type = Column(String(40), nullable=False, unique=True)
    enabled = Column(Boolean, nullable=False, default=True)
    priority = Column(Integer, nullable=False, default=100)
    governance_version = Column(String(80), nullable=False, default="initial")
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
