from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import Column, DateTime, Integer, String, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB, UUID

from app.database import Base


class EntitlementType(str, enum.Enum):
    EXTRA_STOREFRONT = "extra_storefront"
    EXTRA_STAFF = "extra_staff"


class EntitlementSource(str, enum.Enum):
    PURCHASE = "purchase"
    ADMIN_GRANT = "admin_grant"
    PROMOTION = "promotion"
    PLAN_GRANT = "plan_grant"


class EntitlementStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    REVOKED = "revoked"


class MerchantEntitlement(Base):
    """Additional capability granted to a specific merchant.
    
    Entitlements represent additional capacity or capabilities beyond the base subscription plan.
    Examples include extra storefront slots, extra staff slots, premium features, etc.
    """
    __tablename__ = "merchant_entitlements"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    merchant_account_id = Column(
        UUID(as_uuid=True),
        ForeignKey("merchant_accounts.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Opaque entitlement KEY (extra_staff, extra_storefront, custom_domain, ...). Not an enum: new
    # purchasable add-ons are introduced by the Control Center without a schema or code change.
    entitlement_type = Column(
        String(50),
        nullable=False,
    )

    # capability | resource | add_on
    kind = Column(String(20), nullable=False, default="add_on")

    # What the grant gives, stated by the Control Center when it issues the entitlement, e.g.
    #   {"capabilities": ["storefront.custom_domain"], "limits": {"storefront.custom_domains": 1}}
    # Limit values are PER UNIT and are multiplied by `quantity`.
    grant_metadata = Column(JSONB, nullable=False, default=dict)

    quantity = Column(Integer, nullable=False, default=1)

    source = Column(
        String(50),
        nullable=False,
    )

    status = Column(
        String(50),
        nullable=False,
        default=EntitlementStatus.ACTIVE.value,
    )

    starts_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    ends_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Invariants:
    # - ACTIVE entitlements count toward effective capacity
    # - EXPIRED/CANCELLED/REVOKED do not count
    # - starts_at <= ends_at for time-limited entitlements
    # - source tracks origin (purchase, admin grant, promotion, etc.)
    # - quantity may be >1 for bulk grants