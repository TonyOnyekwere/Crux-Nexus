from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import Column, DateTime, String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class SubscriptionStatus(str, enum.Enum):
    """Locked state machine (CruxNexus Merchant Onboarding & Activation
    Architecture, 2026-09-17, section 6). Trial is a state on the selected
    plan, never a separate plan — capacity always derives from `plan`,
    independent of `status`.

    PENDING_SELECTION -> TRIAL_ACTIVE (trial) | PAYMENT_PENDING (pay-now)
    TRIAL_ACTIVE -> ACTIVE (payment) | TRIAL_EXPIRED (expiry)
    PAYMENT_PENDING -> ACTIVE (success) | PAYMENT_FAILED (failure)
    ACTIVE -> PAST_DUE (renewal failure) | CANCELLED | SUSPENDED
    PAST_DUE -> ACTIVE (payment) | SUSPENDED (policy threshold)
    TRIAL_EXPIRED -> ACTIVE (reactivation)
    SUSPENDED -> ACTIVE (authorized recovery)
    PAYMENT_FAILED -> PAYMENT_PENDING (retry) | ACTIVE (retry succeeds directly)
    """

    PENDING_SELECTION = "pending_selection"
    TRIALING = "trialing"  # == TRIAL_ACTIVE in the locked architecture's naming
    PAYMENT_PENDING = "payment_pending"
    PAYMENT_FAILED = "payment_failed"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    TRIAL_EXPIRED = "trial_expired"
    SUSPENDED = "suspended"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


class MerchantSubscription(Base):
    """A merchant's actual subscription to a subscription plan.
    
    This represents the business relationship between a merchant and their subscription plan.
    This is separate from the plan definition (subscription_plans).
    """
    __tablename__ = "merchant_subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    merchant_account_id = Column(
        UUID(as_uuid=True),
        ForeignKey("merchant_accounts.id", ondelete="CASCADE"),
        nullable=False,
    )

    subscription_plan_id = Column(
        UUID(as_uuid=True),
        ForeignKey("subscription_plans.id", ondelete="RESTRICT"),
        nullable=False,
    )

    status = Column(
        String(50),
        nullable=False,
        default=SubscriptionStatus.TRIALING.value,
    )

    starts_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    ends_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    trial_started_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    trial_ends_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Invariants:
    # - Each merchant has one active subscription at a time
    # - Status lifecycle: TRIALING → ACTIVE → PAST_DUE → SUSPENDED → CANCELLED/EXPIRED
    # - ACTIVE/TRIALING allows storefront creation
    # - CANCELLED/EXPIRED/SUSPENDED denies storefront creation