from datetime import datetime, timezone
import enum
import uuid

from sqlalchemy import Column, DateTime, Integer, Numeric, String, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB

from app.database import Base

from .merchant_entitlement import EntitlementStatus, MerchantEntitlement


class SubscriptionPlan(Base):
    """Platform-defined subscription plan configuration.
    
    This table defines the available subscription tiers (STARTER, BUSINESS, ENTERPRISE)
    and their capacity limits. This is platform-level configuration, not merchant-specific data.
    """
    __tablename__ = "subscription_plans"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    code = Column(String(30), nullable=False, unique=True)

    name = Column(String(100), nullable=False)

    included_storefronts = Column(
        Integer,
        nullable=False,
    )

    base_staff_per_storefront = Column(
        Integer,
        nullable=False,
    )

    max_extra_storefronts = Column(
        Integer,
        nullable=False,
    )

    max_extra_staff = Column(
        Integer,
        nullable=False,
    )

    trial_days = Column(
        Integer,
        nullable=False,
    )

    # MVP pricing is persisted in platform configuration by migration 031.
    price_amount = Column(Numeric(14, 2), nullable=True)
    price_currency = Column(String(3), nullable=True)
    billing_interval = Column(String(20), nullable=True)

    active = Column(
        Boolean,
        nullable=False,
        default=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    governance_version = Column(String(80), nullable=False, default="initial")

    # Control Center-owned, dynamically configurable capability and resource policy.
    # Existing numeric fields remain canonical for capacity enforcement; these JSON
    # documents extend the plan without schema rewrites for every new capability.
    capabilities = Column(JSONB, nullable=False, default=dict)
    resource_limits = Column(JSONB, nullable=False, default=dict)

    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Invariants:
    # - code is unique (enforced by database)
    # - Commerce tier capacity (storefronts/staff):
    #   STARTER: 1 storefront, 0 staff/base, 0 extra storefronts, 0 extra staff
    #   BUSINESS: 1 storefront, 3 staff/base, 1 extra storefronts max, 2 extra staff max
    #   ENTERPRISE: 1 storefront, 8 staff/base, 2 extra storefronts max, 4 extra staff max
    # - INACTIVE plans cannot be used for new subscriptions
    # - trial_days is a separate billing/trial policy, not part of commerce
    #   tier capacity above — every plan still requires an explicit value.
    #   OnboardingService must never hardcode a trial length; it always
    #   reads SubscriptionPlan.trial_days.