"""Staff invitation API schemas."""

from pydantic import BaseModel, EmailStr, Field, ConfigDict, field_validator
from datetime import datetime
from typing import Literal, Optional
from uuid import UUID

from app.auth.password_policy import validate_password_strength


class StaffInvitationCreate(BaseModel):
    """Request to create a staff invitation."""

    invited_email: EmailStr = Field(..., description="Email address of the staff member to invite")
    # Literal["staff", "manager"], not str: a bare `str` field was a real
    # privilege-escalation bug (external review) - anyone with
    # MANAGE_STAFF permission (owners AND managers) could submit
    # role="owner" and create an invitation granting full ownership
    # membership, since nothing constrained the value. "owner" is
    # deliberately excluded from the allowed set - ownership isn't
    # something staff-management permission should ever be able to grant.
    role: Literal["staff", "manager"] = Field(default="staff", description="Role to assign (staff or manager)")
    expires_in_hours: int = Field(default=168, ge=1, le=720, description="Hours until invitation expires (1-720)")
    notification_channel: Optional[str] = Field(default="email", description="Notification channel (email, whatsapp, sms)")


class StaffInvitationAccept(BaseModel):
    """Request to accept a staff invitation.

    `user_id` deliberately does not exist as a field here — accepting on
    behalf of an existing account is proven by being authenticated as
    that account (the route reads the caller's identity from their bearer
    token, if present), never by a client-supplied ID. `new_account_password`
    is required only when the invited email has no existing account yet.
    """

    token: str = Field(..., description="Invitation token")
    new_account_password: Optional[str] = Field(
        None, description="Required only if no account exists yet for the invited email"
    )

    @field_validator("new_account_password")
    @classmethod
    def _validate_password(cls, v: Optional[str]) -> Optional[str]:
        # Fixed a real gap (external review): invitation-created accounts
        # previously bypassed the same strength policy ordinary signup
        # enforces (length/complexity/common-password checks) - a
        # one-character password would have been hashed and accepted.
        if v is None:
            return v
        return validate_password_strength(v)


class StaffInvitationResponse(BaseModel):
    """Response with staff invitation details."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    tenant_id: UUID
    invited_email: str
    role: str
    status: str
    invited_by: Optional[UUID] = None
    accepted_at: Optional[datetime] = None
    accepted_by: Optional[UUID] = None
    expires_at: datetime
    notification_channel: Optional[str] = None
    notification_sent_at: Optional[datetime] = None
    created_at: datetime


class StaffInvitationAcceptResponse(BaseModel):
    """Response after accepting an invitation."""

    membership_id: UUID
    tenant_id: UUID
    user_id: UUID
    role: str
    status: str
    message: str = Field(default="Invitation accepted successfully")


class InvitationValidationResponse(BaseModel):
    """Response when validating an invitation token."""

    valid: bool
    tenant_id: Optional[str] = None
    invited_email: Optional[str] = None
    role: Optional[str] = None
    expires_at: Optional[datetime] = None
    message: Optional[str] = None