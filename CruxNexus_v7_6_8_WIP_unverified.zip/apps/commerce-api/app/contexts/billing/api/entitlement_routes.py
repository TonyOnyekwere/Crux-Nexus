from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_verified_tenant_context
from app.auth.authorization import Permission, require_permission
from app.contexts.billing.application.entitlement_allocation import EntitlementAllocationService
from app.contexts.merchant_management.application.services import MerchantService
from app.database import get_db

router = APIRouter(prefix="/api/v1/billing/entitlements", tags=["entitlements"])

class AllocateStaffRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    entitlement_id: UUID
    quantity: int = Field(gt=0, le=1000)

@router.post("/staff/allocate", status_code=status.HTTP_200_OK)
async def allocate_staff(
    body: AllocateStaffRequest,
    db: AsyncSession = Depends(get_db),
    ctx: dict = Depends(get_verified_tenant_context),
):
    require_permission(ctx, Permission.MANAGE_STAFF)
    tenant_id = UUID(str(ctx["tenant_id"]))
    user_id = UUID(str(ctx["user_id"]))
    merchant_id = await MerchantService(db).get_merchant_account_id_for_tenant_user(user_id, tenant_id)
    if merchant_id is None:
        raise HTTPException(403, "Merchant account required")
    try:
        allocation = await EntitlementAllocationService(db).allocate_staff_to_storefront(
            merchant_account_id=merchant_id,
            entitlement_id=body.entitlement_id,
            tenant_id=tenant_id,
            quantity=body.quantity,
        )
        from app.infrastructure.audit import SecurityEvent, SecurityEventType, record_durable_audit
        await record_durable_audit(db, SecurityEvent(event_type=SecurityEventType.STAFF_ALLOCATION_CHANGED, user_id=str(user_id), tenant_id=str(tenant_id), success=True, reason="Staff entitlement allocation", metadata={"allocation_id": str(allocation.id), "quantity": allocation.quantity}), actor_type="merchant")
        await db.commit()
        return {"data": {"allocation_id": str(allocation.id), "tenant_id": str(tenant_id), "quantity": allocation.quantity}}
    except ValueError as exc:
        await db.rollback()
        raise HTTPException(409, str(exc))

@router.delete("/staff/allocations/{allocation_id}")
async def deallocate_staff(
    allocation_id: UUID,
    quantity: int = 1,
    db: AsyncSession = Depends(get_db),
    ctx: dict = Depends(get_verified_tenant_context),
):
    if quantity <= 0:
        raise HTTPException(422, "quantity must be positive")
    require_permission(ctx, Permission.MANAGE_STAFF)
    user_id = UUID(str(ctx["user_id"]))
    merchant_id = await MerchantService(db).get_merchant_account_id_for_tenant_user(user_id, UUID(str(ctx["tenant_id"])))
    if merchant_id is None:
        raise HTTPException(403, "Merchant account required")
    try:
        allocation = await EntitlementAllocationService(db).deallocate_staff_from_storefront(
            merchant_account_id=merchant_id, allocation_id=allocation_id, quantity=quantity
        )
        from app.infrastructure.audit import SecurityEvent, SecurityEventType, record_durable_audit
        await record_durable_audit(db, SecurityEvent(event_type=SecurityEventType.STAFF_ALLOCATION_CHANGED, user_id=str(user_id), tenant_id=str(ctx["tenant_id"]), success=True, reason="Staff entitlement deallocation", metadata={"allocation_id": str(allocation.id), "quantity": getattr(allocation, "quantity", 0)}), actor_type="merchant")
        await db.commit()
        return {"data": {"allocation_id": str(allocation.id), "quantity": getattr(allocation, "quantity", 0)}}
    except ValueError as exc:
        await db.rollback()
        raise HTTPException(404, str(exc))
