"""Read-only plan catalogue for merchant plan selection (CRX-FE-001).

Plan selection itself stays server-authoritative: the client submits a
``plan_code`` to ``POST /api/v1/onboarding/journey/plan`` and the backend
re-validates eligibility. This route only lets the client display what the
backend will accept. Administration of plans stays in the Control Center.
"""

from uuid import UUID

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_current_user_id
from app.contexts.billing.application.plan_catalogue import list_selectable_plans
from app.database import get_db
from app.infrastructure.rate_limiter import key_ip, limiter

router = APIRouter(prefix="/api/v1/billing", tags=["billing"])


@router.get("/plans")
@limiter.limit("60/minute", key_func=key_ip)
async def list_plans(
    request: Request,
    db: AsyncSession = Depends(get_db),
    _user_id: UUID = Depends(get_current_user_id),
):
    return {"data": {"plans": await list_selectable_plans(db)}}
