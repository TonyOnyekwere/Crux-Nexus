"""Subscription pay-now payment initiation.

Fixed a real gap found in external review: SubscriptionPaymentService.
initiate_payment (CRX-P0-025) existed with no HTTP route ever calling
it — the payment-initiation logic was real but had no way for a merchant
to actually reach it. This is that entry point.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt_handler import get_current_merchant_context
from app.contexts.billing.api.subscription_payment_schemas import SubscriptionPaymentInitiateRequest
from app.contexts.billing.domain.financial_transaction import PaymentProvider
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription
from app.contexts.billing.domain.provider_registry import ProviderRegistryEntry
from app.contexts.merchant_management.application.services import MerchantService
from app.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/billing/subscription", tags=["billing"])


@router.post("/payment", status_code=status.HTTP_200_OK)
async def initiate_subscription_payment(
    payload: SubscriptionPaymentInitiateRequest,
    db: AsyncSession = Depends(get_db),
    merchant_context: dict = Depends(get_current_merchant_context),
):
    """Start a pay-now charge for the caller's own subscription.

    Requires the caller to already be OTP-verified (get_current_merchant_context
    enforces this — see CRX-P0-024) since this is exactly the kind of
    payment-adjacent operation the locked architecture's verification
    gate exists to block for unverified accounts.
    """
    from sqlalchemy import select

    from app.contexts.billing.application.subscription_payment_service import (
        PaymentAlreadyCompletedError,
        PaymentOutcomeUnknownError,
        PlanPricingNotConfiguredError,
        PriorPaymentUnverifiableError,
        SubscriptionPaymentService,
    SubscriptionAlreadyActiveError,
    )
    from app.infrastructure.payments.adapter import (
        ProviderRejectedError,
        get_payment_provider_registry,
    )

    user_id = merchant_context["user_id"]
    merchant_email = merchant_context.get("email")

    merchant_service = MerchantService(db)
    merchant_account_id = await merchant_service.get_merchant_account_id_for_user(user_id)
    if merchant_account_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "MERCHANT_REQUIRED", "message": "No merchant account found for this user.", "details": {}}},
        )

    try:
        provider = PaymentProvider(payload.provider)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": {
                    "code": "UNSUPPORTED_PROVIDER",
                    "message": f"'{payload.provider}' is not a supported payment provider.",
                    "details": {"supported": [p.value for p in PaymentProvider]},
                }
            },
        )

    # Control Center governance can disable a provider without redeploying Commerce.
    provider_policy = await db.scalar(select(ProviderRegistryEntry).where(ProviderRegistryEntry.provider_type == provider.value))
    if provider_policy is not None and not provider_policy.enabled:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail={"error": {"code": "PROVIDER_DISABLED", "message": "This payment provider is currently disabled by platform governance.", "details": {}}})

    # Fail fast and specifically if this provider isn't configured, rather
    # than letting the service raise a generic error deeper in.
    registry = get_payment_provider_registry()
    try:
        registry.get(provider)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"error": {"code": "PROVIDER_UNAVAILABLE", "message": str(exc), "details": {}}},
        )

    subscription_result = await db.execute(
        select(MerchantSubscription)
        .where(MerchantSubscription.merchant_account_id == merchant_account_id)
        .order_by(MerchantSubscription.created_at.desc())
        .limit(1)
    )
    subscription = subscription_result.scalar_one_or_none()
    if subscription is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "SUBSCRIPTION_NOT_FOUND", "message": "No subscription found for this merchant.", "details": {}}},
        )

    from app.config import get_settings
    settings = get_settings()
    redirect_url = f"{settings.PUBLIC_APP_URL.rstrip('/')}/billing/payment/callback"

    service = SubscriptionPaymentService(db)
    try:
        result = await service.initiate_payment(
            merchant_account_id=merchant_account_id,
            subscription_id=subscription.id,
            merchant_email=merchant_email,
            provider=provider,
            redirect_url=redirect_url,
        )
    except PaymentOutcomeUnknownError as exc:
        # 202: do NOT tell the merchant it failed and do NOT let the client
        # blindly retry a new charge - the first attempt may be live.
        raise HTTPException(
            status_code=status.HTTP_202_ACCEPTED,
            detail={"error": {"code": "PAYMENT_OUTCOME_UNKNOWN", "message": "We could not confirm your payment request with the provider. If you were charged, your subscription will activate automatically; please do not pay again for a few minutes.", "details": {"reference": exc.reference}}},
        )
    except SubscriptionAlreadyActiveError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": {"code": "SUBSCRIPTION_ALREADY_ACTIVE", "message": str(exc), "details": {}}},
        )
    except PaymentAlreadyCompletedError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": {"code": "PAYMENT_ALREADY_COMPLETED", "message": str(exc), "details": {}}},
        )
    except PriorPaymentUnverifiableError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"error": {"code": "PRIOR_PAYMENT_UNVERIFIED", "message": str(exc), "details": {}}},
            headers={"Retry-After": "60"},
        )
    except ProviderRejectedError as exc:
        logger.error("Payment initiation rejected: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": {"code": "PROVIDER_REJECTED", "message": "The payment provider declined to start this payment.", "details": {}}},
        )
    except PlanPricingNotConfiguredError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": {"code": "PLAN_PRICING_NOT_CONFIGURED", "message": str(exc), "details": {}}},
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "VALIDATION_ERROR", "message": str(exc), "details": {}}},
        )
    except Exception as exc:
        logger.error("Payment initiation failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": {"code": "PROVIDER_ERROR", "message": "The payment provider could not be reached.", "details": {}}},
        )

    return {"data": result}
