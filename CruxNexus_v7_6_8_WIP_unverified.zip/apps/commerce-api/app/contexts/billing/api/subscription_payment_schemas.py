from pydantic import BaseModel


class SubscriptionPaymentInitiateRequest(BaseModel):
    provider: str  # "paystack" or "flutterwave" - merchant's choice, never hardcoded
