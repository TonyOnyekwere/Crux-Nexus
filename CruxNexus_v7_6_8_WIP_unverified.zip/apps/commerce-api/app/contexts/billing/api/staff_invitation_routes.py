"""Staff invitation API routes."""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.auth.authorization import Permission, has_permission
from app.auth.jwt_handler import decode_access_token, get_verified_tenant_context
from app.contexts.billing.application.staff_invitation_service import StaffInvitationService
from app.contexts.billing.api.staff_invitation_schemas import (
    StaffInvitationCreate,
    StaffInvitationAccept,
    StaffInvitationResponse,
    StaffInvitationAcceptResponse,
    InvitationValidationResponse,
)
from app.exceptions import NotFoundError, ValidationError

router = APIRouter(prefix="/api/v1/invitations", tags=["invitations"])

_optional_bearer = HTTPBearer(auto_error=False)


async def _optional_authenticated_user_id(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_optional_bearer),
) -> Optional[str]:
    """Best-effort caller identity for the accept endpoint, which must
    remain reachable by someone with no account yet (invitation-based
    signup) — so unlike every other authenticated route in this app, a
    missing/invalid token here is not itself an error. It only matters
    when the invitation's email already has an account: in that case
    the service requires this to match, and rejects the request if it
    doesn't or is absent, rather than trusting a client-supplied ID."""
    if credentials is None or not credentials.credentials:
        return None
    try:
        payload = decode_access_token(credentials.credentials)
        return payload.get("sub")
    except HTTPException:
        return None


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_staff_invitation(
    payload: StaffInvitationCreate,
    db: AsyncSession = Depends(get_db),
    tenant_context: dict = Depends(get_verified_tenant_context),
):
    """Create a staff invitation for the current tenant.
    
    This endpoint creates a secure invitation that can be sent to a staff member.
    The invitation is stored with a hashed token and can be accepted later.
    
    Only users with admin/owner roles in the tenant should be able to create invitations.
    """
    tenant_id = tenant_context["tenant_id"]
    user_id = tenant_context["user_id"]

    if not has_permission(tenant_context["role"], Permission.MANAGE_STAFF):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "FORBIDDEN", "message": "Only owners/managers can invite staff.", "details": {}}},
        )

    service = StaffInvitationService(db)
    
    try:
        invitation = await service.create_invitation(
            tenant_id=tenant_id,
            invited_email=payload.invited_email,
            role=payload.role,
            invited_by=user_id,
            expires_in_hours=payload.expires_in_hours,
            notification_channel=payload.notification_channel,
        )
        return {
            "data": StaffInvitationResponse.model_validate(invitation).model_dump(),
            "message": (
                "Invitation created successfully."
                if invitation.notification_sent_at
                else "Invitation created successfully. No notification transport is "
                "configured yet, so the invitee has not been notified — share the "
                "invitation link with them directly for now."
            ),
        }
    except ValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "VALIDATION_ERROR", "message": str(exc), "details": {}}},
        )


@router.post("/accept", status_code=status.HTTP_200_OK)
async def accept_staff_invitation(
    payload: StaffInvitationAccept,
    db: AsyncSession = Depends(get_db),
    authenticated_user_id: Optional[str] = Depends(_optional_authenticated_user_id),
):
    """Accept a staff invitation.

    If the invited email already has an account, the caller must be
    authenticated as that account (bearer token) — there is no
    client-supplied user_id path anymore; that was a real vulnerability
    (see StaffInvitationService.accept_invitation's docstring). If no
    account exists yet, one is created using new_account_password.
    """
    service = StaffInvitationService(db)
    
    try:
        membership = await service.accept_invitation(
            token=payload.token,
            authenticated_user_id=authenticated_user_id,
            new_account_password=payload.new_account_password,
        )
        return {
            "data": StaffInvitationAcceptResponse(
                membership_id=membership.id,
                tenant_id=membership.tenant_id,
                user_id=membership.user_id,
                role=membership.role,
                status=membership.status,
            ).model_dump(),
            "message": "Invitation accepted successfully. You now have access to the tenant.",
        }
    except NotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "INVITATION_NOT_FOUND", "message": str(exc), "details": {}}},
        )
    except ValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "VALIDATION_ERROR", "message": str(exc), "details": {}}},
        )


@router.get("/validate/{token}", status_code=status.HTTP_200_OK)
async def validate_invitation(
    token: str,
    db: AsyncSession = Depends(get_db),
):
    """Validate an invitation token without accepting it.
    
    This endpoint checks if an invitation token is valid and returns
    the invitation details. This is useful for showing the invitation
    details to the user before they accept it.
    """
    service = StaffInvitationService(db)
    
    invitation = await service.get_invitation_by_token(token)
    
    if not invitation:
        return {
            "data": InvitationValidationResponse(
                valid=False,
                message="Invalid or expired invitation token",
            ).model_dump()
        }
    
    return {
        "data": InvitationValidationResponse(
            valid=True,
            tenant_id=str(invitation.tenant_id),
            invited_email=invitation.invited_email,
            role=invitation.role,
            expires_at=invitation.expires_at,
        ).model_dump()
    }


@router.delete("/{invitation_id}", status_code=status.HTTP_200_OK)
async def cancel_invitation(
    invitation_id: str,
    db: AsyncSession = Depends(get_db),
    tenant_context: dict = Depends(get_verified_tenant_context),
):
    """Cancel a pending staff invitation.
    
    Only the inviter or an admin can cancel an invitation.
    """
    tenant_id = tenant_context["tenant_id"]
    user_id = tenant_context["user_id"]

    if not has_permission(tenant_context["role"], Permission.MANAGE_STAFF):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "FORBIDDEN", "message": "Only owners/managers can cancel invitations.", "details": {}}},
        )

    service = StaffInvitationService(db)
    
    try:
        invitation = await service.cancel_invitation(
            invitation_id=invitation_id,
            tenant_id=tenant_id,
            cancelled_by=user_id,
        )
        
        return {
            "data": StaffInvitationResponse.model_validate(invitation).model_dump(),
            "message": "Invitation cancelled successfully",
        }
    except NotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "INVITATION_NOT_FOUND", "message": str(exc), "details": {}}},
        )
    except ValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "VALIDATION_ERROR", "message": str(exc), "details": {}}},
        )


@router.get("/pending", status_code=status.HTTP_200_OK)
async def list_pending_invitations(
    db: AsyncSession = Depends(get_db),
    tenant_context: dict = Depends(get_verified_tenant_context),
):
    """List all pending invitations for the current tenant.
    
    This endpoint returns all pending invitations for the tenant,
    allowing admins to see who has been invited and their status.
    """
    tenant_id = tenant_context["tenant_id"]

    if not has_permission(tenant_context["role"], Permission.MANAGE_STAFF):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": {"code": "FORBIDDEN", "message": "Only owners/managers can view pending invitations.", "details": {}}},
        )

    service = StaffInvitationService(db)
    
    invitations = await service.list_pending_invitations(tenant_id)
    
    return {
        "data": [StaffInvitationResponse.model_validate(inv).model_dump() for inv in invitations],
    }