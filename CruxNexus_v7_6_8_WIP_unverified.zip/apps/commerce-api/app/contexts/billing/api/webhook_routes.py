"""Payment provider webhook ingestion.

Locked Onboarding & Activation Architecture, section 11. This module
implements exactly the "Webhook Inbox" stage of that pipeline:

    Provider -> Signature Validation -> Persist Raw Event -> Deduplicate

and leaves the durable event for the webhook reconciliation worker.
The reconciliation service performs provider verification, normalization,
and the subscription state transition before marking the event processed.

Every event that passes signature verification AND has a valid, non-empty
normalized event identity is persisted verbatim to provider_webhook_events
and returns 200 immediately — reconciliation happens by a separate
process reading unprocessed rows, not inline in the webhook handler, so
a slow or temporarily-broken reconciliation step can never cause a
webhook timeout/retry storm from the provider's side.

Two hardening fixes from external review:
- An unconfigured provider (no adapter registered) now returns 503, not
  200. Returning 200 for "we can't actually process this" risks the
  provider interpreting it as successfully delivered and never retrying
  once the adapter IS configured — silently losing the event for good.
  503 is Paystack/Flutterwave's own documented signal to retry.
- A signature that verifies but wraps unparseable JSON, or JSON with no
  extractable event_id, is now rejected (422) rather than persisted with
  an empty event_id. A row with no real identity can't be deduplicated
  correctly and shouldn't occupy space in the canonical inbox.
"""

import logging

from fastapi import APIRouter, Request, Response, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import Depends

from app.contexts.billing.domain.financial_transaction import PaymentProvider, ProviderWebhookEvent
from app.database import get_db
from app.infrastructure.payments.adapter import get_payment_provider_registry
from app.infrastructure.rate_limiter import key_static, limiter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/billing/webhooks", tags=["billing-webhooks"])


async def _ingest(
    *, provider: PaymentProvider, request: Request, db: AsyncSession
) -> Response:
    raw_body = await request.body()
    headers = {k.lower(): v for k, v in request.headers.items()}

    registry = get_payment_provider_registry()
    try:
        adapter = registry.get(provider)
    except ValueError:
        logger.error("Webhook received for %s but no adapter is registered.", provider.value)
        # 503, not 200: a 200 here would tell the provider "delivered
        # successfully" for an event we did nothing with, and both
        # Paystack and Flutterwave stop retrying once they see a 2xx.
        # 503 is the documented signal to retry - once the adapter is
        # actually configured, the retried delivery gets processed for
        # real instead of being lost.
        return Response(status_code=status.HTTP_503_SERVICE_UNAVAILABLE)

    result = adapter.verify_webhook_signature(headers=headers, raw_body=raw_body)

    if not result.signature_valid:
        logger.warning("Rejected a %s webhook with an invalid signature.", provider.value)
        # Genuinely reject, not a 200 - an invalid signature means this
        # is not a verified event, and it is not persisted at all.
        return Response(status_code=status.HTTP_401_UNAUTHORIZED)

    if not result.event_id:
        # A valid signature over unparseable/unidentifiable content is
        # unusual but not impossible - don't let it into the canonical
        # inbox with an empty identity, since that can't be deduplicated
        # correctly and would corrupt the "one row per real event"
        # guarantee the uk_provider_webhook_event constraint exists for.
        logger.error(
            "Rejected a signature-valid %s webhook with no extractable event_id.",
            provider.value,
        )
        return Response(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY)

    event = ProviderWebhookEvent(
        provider_code=provider.value,
        provider_event_id=result.event_id,
        event_type=result.event_type,
        raw_payload=result.normalized_payload,
        signature_verified=True,
        processed=False,
    )
    db.add(event)
    try:
        await db.commit()
    except IntegrityError:
        # uk_provider_webhook_event fired - this exact event was already
        # received (provider retry, or a genuine duplicate delivery).
        # Safe no-op: the original row is untouched, nothing reprocesses.
        await db.rollback()
        logger.info(
            "Duplicate webhook for %s event_id=%s - ignored.",
            provider.value,
            result.event_id,
        )

    return Response(status_code=status.HTTP_200_OK)


@router.post("/paystack")
@limiter.limit("2000/minute", key_func=key_static("platform-webhook-paystack"))
async def paystack_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    return await _ingest(provider=PaymentProvider.PAYSTACK, request=request, db=db)


@router.post("/flutterwave")
@limiter.limit("2000/minute", key_func=key_static("platform-webhook-flutterwave"))
async def flutterwave_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    return await _ingest(provider=PaymentProvider.FLUTTERWAVE, request=request, db=db)
