"""Canonical registry of tenant-scoped database tables.

Merchant-owned Commerce tables must contain tenant_id, have RLS enabled and
FORCE ROW LEVEL SECURITY enabled, with tenant isolation policies. Control-plane
tables are classified separately. The Commerce data-plane registry is active
and is enforced by the CI RLS and tenant-index gates.

The tenants table is platform-owned registry state. Production application and
worker connections use a dedicated non-superuser runtime role; migration 034
creates/updates that role from DATABASE_RUNTIME_URL and grants registry access
without granting BYPASSRLS.
"""

TENANT_SCOPED_TABLES: tuple[str, ...] = (
    "storefront_profiles",
    "products",
    "inventory_movements",
    "customers",
    "carts",
    "cart_items",
    "orders",
    "order_items",
    "commerce_payments",
    "fulfillments",
    "storefront_configurations",
    "merchant_payment_connections",
    "commerce_checkout_idempotency",
    "merchant_payment_credentials",
    "merchant_payment_events",
)

# Every table that exists in the codebase today (verified by inspection,
# 2026-09-19 — 20 tables, `grep -rh '__tablename__' app/`), classified as
# control-plane: platform-owned governance/state, not merchant-owned
# commerce data. This list exists so the control-plane/data-plane boundary
# is an explicit, checkable fact rather than an implicit assumption — and
# so a future PR adding a genuinely tenant-owned table has an obvious place
# to move it out of this list and into TENANT_SCOPED_TABLES instead of
# leaving it uncategorized in neither.
CONTROL_PLANE_TABLES: tuple[str, ...] = (
    # Non-secret webhook routing (token -> tenant/connection); a merchant webhook has no tenant context yet.
    "payment_webhook_routes",
    # Platform-owned governance/operations tables (not merchant data). audit_events and
    # tenant_suspensions carry a tenant_id as a SUBJECT reference for platform actions; they are
    # written/read by platform and worker roles and must not be merchant-editable.
    "audit_events",
    "tenant_suspensions",
    "commerce_governance_policy",
    "provider_registry_cache",
    "worker_jobs",
    "users",
    "otp_codes",
    "merchant_accounts",
    "merchant_account_users",
    "merchant_account_tenants",
    "merchant_subscriptions",
    "merchant_entitlements",
    "merchant_trial_history",
    "merchant_onboarding_requests",
    "subscription_plans",
    "financial_transactions",
    "provider_webhook_events",
    "outbox_events",
    "onboarding_sessions",
    "onboarding_step_events",
    # v2 onboarding (pre-tenant, keyed by onboarding session): replay records and slug holds.
    "onboarding_idempotency_keys",
    "onboarding_slug_reservations",
    "staff_invitations",
    "tenant_memberships",
    "staff_capacity_allocations",
    "allocation_anomalies",
    # storefront_entitlement_allocations and storefront_staff_capacity
    # were retired in migration 028 - both were dead duplicate models of
    # what staff_capacity_allocations already does; see that migration's
    # docstring for the full reasoning.
    # tenants itself is control-plane data (the tenant *registry*, owned by
    # the platform) despite the name resembling the tenant-scoped concept —
    # see ADR-0009. It already has its own deny-all RLS policy
    # (migration 017), which is a different mechanism serving a different
    # purpose than TENANT_SCOPED_TABLES' per-tenant isolation.
    "tenants",
)


def classify_table(table_name: str) -> str:
    """Returns "tenant_scoped", "control_plane", or "unclassified" — a
    table in neither list is a signal to classify it, not to assume
    either default."""
    if table_name in TENANT_SCOPED_TABLES:
        return "tenant_scoped"
    if table_name in CONTROL_PLANE_TABLES:
        return "control_plane"
    return "unclassified"

