"""
Central model registration for Alembic migration discovery.

This module imports all SQLAlchemy models to ensure they are registered
with the Base metadata before Alembic autogenerate runs. This prevents
empty metadata and incorrect migration generation.

All domain entities must be imported here to be discovered by migrations.
"""

from sqlalchemy.orm import relationship
from app.database import Base

# Import all domain entities to register them with Base.metadata
from app.contexts.identity.domain.entities import User
from app.contexts.identity.domain.otp_code import OTPCode
from app.contexts.tenant_management.domain.entities import Tenant
from app.contexts.tenant_management.domain.suspension import TenantSuspension
from app.contexts.tenant_management.domain.membership import TenantMembership
from app.contexts.merchant_management.domain.entities import MerchantAccount
from app.contexts.merchant_management.domain.merchant_account_user import MerchantAccountUser
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.governance_policy import CommerceGovernancePolicy
from app.contexts.billing.domain.provider_registry import ProviderRegistryEntry
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription
from app.contexts.billing.domain.merchant_entitlement import MerchantEntitlement
from app.contexts.billing.domain.merchant_trial_history import MerchantTrialHistory
from app.contexts.billing.domain.staff_capacity_allocation import StaffCapacityAllocation
from app.contexts.billing.domain.staff_invitation import StaffInvitation
from app.contexts.billing.domain.allocation_anomaly import AllocationAnomaly
from app.contexts.billing.domain.financial_transaction import FinancialTransaction, ProviderWebhookEvent
from app.contexts.onboarding.domain.onboarding_request import MerchantOnboardingRequestRecord
from app.contexts.onboarding.domain.onboarding_session import OnboardingSession, OnboardingStepEvent
from app.contexts.onboarding.domain.journey_v2_models import OnboardingIdempotencyKey, OnboardingSlugReservation
from app.infrastructure.outbox.repository import OutboxEvent
from app.infrastructure.audit_model import AuditEvent
from app.infrastructure.worker_jobs import WorkerJob

# Establish relationships after all models are imported
# Note: relationships are established here to avoid circular import issues
# The actual ORM relationships would be defined in the domain entities
# but we use string references to avoid circular dependencies

# Export Base for Alembic target_metadata
from app.contexts.commerce import StorefrontProfile, StorefrontConfiguration, MerchantPaymentConnection, Product, InventoryMovement, Customer, Cart, CartItem, Order, OrderItem, CommercePayment, CommerceCheckoutIdempotency, Fulfillment

__all__ = ["Base"]
