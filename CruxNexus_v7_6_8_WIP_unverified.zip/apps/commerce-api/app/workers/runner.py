"""Unified CruxNexus worker runtime."""
from __future__ import annotations

import asyncio
import logging

from app.workers.runtime import create_worker_runtime
from app.workers.entitlement_reconciliation import run_entitlement_reconciliation_loop
from app.workers.commerce_reconciliation import run_commerce_reconciliation_loop
from app.workers.event_relay import run_relay_loop
from app.workers.onboarding_expiry import run_onboarding_expiry_loop
from app.workers.trial_expiration import run_trial_expiration_loop
from app.workers.webhook_reconciliation import run_webhook_reconciliation_loop
from app.workers.subscription_lifecycle import run_subscription_lifecycle_loop
from app.workers.job_executor import run_job_executor_loop

logger = logging.getLogger(__name__)


async def run_all() -> None:
    engine, session_factory = create_worker_runtime()
    loops = (
        run_relay_loop,
        run_trial_expiration_loop,
        run_onboarding_expiry_loop,
        run_webhook_reconciliation_loop,
        run_entitlement_reconciliation_loop,
        run_commerce_reconciliation_loop,
        run_subscription_lifecycle_loop,
        run_job_executor_loop,
    )
    logger.info("Starting background worker process (%d loop(s))", len(loops))
    try:
        await asyncio.gather(*(loop(session_factory=session_factory) for loop in loops))
    finally:
        await engine.dispose()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run_all())
