"""Shared worker database runtime with a dedicated non-superuser role."""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy import text
from contextlib import asynccontextmanager
from app.config import get_settings
from app.database.url import normalize_async_database_url


def create_worker_runtime():
    settings = get_settings()
    url = settings.DATABASE_WORKER_URL or settings.DATABASE_RUNTIME_URL or settings.DATABASE_URL
    engine = create_async_engine(normalize_async_database_url(url), pool_pre_ping=True)
    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    return engine, session_factory


@asynccontextmanager
async def worker_transaction(session: AsyncSession):
    """Bind the PostgreSQL worker execution context for one transaction."""
    async with session.begin():
        await session.execute(text("SELECT set_config('app.worker_context', '1', true)"))
        yield session
