"""Outbox relay worker — publishes pending events asynchronously."""

import asyncio
import logging
from datetime import datetime, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.workers.runtime import create_worker_runtime
from app.infrastructure.outbox.repository import OutboxEvent
from app.infrastructure.event_transport import create_event_transport

from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger = logging.getLogger(__name__)


async def relay_pending_events(db: AsyncSession, batch_size: int = 50, transport=None) -> int:
    """Mark pending outbox events as published. Transport wiring is Phase 1."""
    # FOR UPDATE SKIP LOCKED (external review fix): without this, two
    # concurrent relay workers could select and "publish" the same
    # pending event, which will matter the moment a real transport exists
    # (double delivery) and is already wasted/confusing work today.
    result = await db.execute(
        select(OutboxEvent)
        .where(OutboxEvent.status == "pending")
        .order_by(OutboxEvent.created_at)
        .limit(batch_size)
        .with_for_update(skip_locked=True)
    )
    events = result.scalars().all()
    if not events:
        return 0

    now = datetime.now(timezone.utc)
    owned_transport = transport is None
    transport = transport or create_event_transport()
    published_count = 0
    failed_count = 0
    for event in events:
        try:
            transport_id = await transport.publish(event_id=str(event.id), event_type=event.event_type, aggregate_type=event.aggregate_type, aggregate_id=str(event.aggregate_id), tenant_id=str(event.tenant_id) if event.tenant_id else None, payload=event.payload)
        except Exception as exc:
            event.attempt_count += 1
            event.last_error = str(exc)[:4000]
            failed_count += 1
            logger.exception("Event transport failed for %s", event.id)
            continue
        published_count += 1
        logger.info("Published event %s to transport id=%s", event.id, transport_id)
        await db.execute(update(OutboxEvent).where(OutboxEvent.id == event.id).values(status="published", published_at=now, transport_id=transport_id, last_error=None))
    await db.commit()
    if owned_transport:
        await transport.close()
    logger.info("Outbox relay sweep: selected=%d published=%d failed=%d", len(events), published_count, failed_count)
    if failed_count:
        raise RuntimeError(f"Outbox relay partially failed: {published_count} published, {failed_count} failed")
    return published_count


async def run_relay_loop(interval_seconds: int = 5, session_factory=None) -> None:
    if session_factory is None:
        _engine, session_factory = create_worker_runtime()
    transport = create_event_transport()
    try:
        while True:
            async with session_factory() as session:
                started_at = worker_started()
                try:
                    count = await relay_pending_events(session, transport=transport)
                    record_worker_success("event_relay", items=count, started_at=started_at)
                    if count:
                        logger.info("Relayed %d event(s)", count)
                except Exception:
                    WORKER_FAILURES.labels("event_relay").inc()
                    logger.exception("Event relay failed")
                    await session.rollback()
            await asyncio.sleep(interval_seconds)
    finally:
        await transport.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run_relay_loop())
