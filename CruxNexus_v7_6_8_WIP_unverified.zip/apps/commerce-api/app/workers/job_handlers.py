from uuid import UUID
from sqlalchemy import text
from app.contexts.billing.application.subscription_payment_service import SubscriptionPaymentService
from app.workers.job_executor import register_job_handler
async def activate_subscription(db,payload):
    await db.execute(text("SELECT set_config('app.worker_context','1',true)"))
    await SubscriptionPaymentService(db).activate_verified_subscription(UUID(payload["transaction_id"]))
register_job_handler("billing.activate_subscription",activate_subscription)
