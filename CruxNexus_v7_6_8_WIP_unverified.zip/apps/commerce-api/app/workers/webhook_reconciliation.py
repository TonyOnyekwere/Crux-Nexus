"""Webhook reconciliation worker.

Drains provider_webhook_events rows that passed signature verification
(webhook_routes.py's job) but haven't been reconciled into a subscription
state transition yet (SubscriptionPaymentService.process_webhook_event's
job) — this worker is what connects the two, on a poll loop rather than
inline in the webhook HTTP handler, matching the design already stated in
webhook_routes.py's module docstring ("reconciliation happens by a
separate process reading unprocessed rows, not inline in the webhook
handler, so a slow or temporarily-broken reconciliation step can never
cause a webhook timeout/retry storm from the provider's side").

FOR UPDATE SKIP LOCKED — but claimed and processed ONE ROW AT A TIME, not
as a batch. This fixes a real concurrency bug found in external review:
the original version SELECT'd a whole batch under one FOR UPDATE, but
SubscriptionPaymentService.process_webhook_event commits internally for
each event it processes — the first commit ends that transaction and
releases every lock in the batch, including the ones for events not yet
processed. A second worker could then claim and double-process the
"still locked, supposedly" remainder. Locking and processing exactly one
row per transaction means the lock's lifetime always matches the
commit boundary that actually needs it.
"""

import asyncio
import logging
from typing import Optional
from uuid import UUID

from sqlalchemy import select

from app.contexts.billing.domain.financial_transaction import ProviderWebhookEvent
from app.workers.runtime import create_worker_runtime

from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 30
BATCH_SIZE = 20


async def _claim_one_event_id(db) -> Optional[UUID]:
    result = await db.execute(
        select(ProviderWebhookEvent.id)
        .where(
            ProviderWebhookEvent.signature_verified.is_(True),
            ProviderWebhookEvent.processed.is_(False),
        )
        .order_by(ProviderWebhookEvent.received_at)
        .limit(1)
        .with_for_update(skip_locked=True)
    )
    row = result.first()
    return row[0] if row else None




async def reconcile_pending_webhooks(db) -> int:
    from app.contexts.billing.application.subscription_payment_service import (
        SubscriptionPaymentService,
    )

    service = SubscriptionPaymentService(db)
    processed_count = 0

    for _ in range(BATCH_SIZE):
        # Each iteration's SELECT...FOR UPDATE SKIP LOCKED and the
        # process_webhook_event call it guards happen back-to-back with
        # no commit in between except the one process_webhook_event
        # itself performs — so the lock this SELECT takes is held for
        # exactly as long as it needs to be, no longer and no less.
        event_id = await _claim_one_event_id(db)
        if event_id is None:
            break

        try:
            # The platform inbox carries SUBSCRIPTION events only (CruxNexus-owned provider
            # accounts). Customer payments arrive on each merchant's own webhook route.
            await service.process_webhook_event(event_id)
            processed_count += 1
        except Exception:
            logger.exception("Failed to reconcile webhook event %s", event_id)
            await db.rollback()
            break  # don't keep looping in an uncertain transaction state

    return processed_count


async def reconcile_stale_pending_transactions(db) -> int:
    """Resolve stale PENDING subscription transactions one at a time.

    The reconciliation service commits internally, so a batch-level
    FOR UPDATE SKIP LOCKED claim would release every unprocessed lock after
    the first transaction commits. Claim exactly one row per transaction
    instead, matching the lock lifetime to the commit boundary.
    """
    from datetime import datetime, timezone

    from app.contexts.billing.application.subscription_payment_service import (
        STALE_PENDING_AFTER,
        SubscriptionPaymentService,
    )
    from app.contexts.billing.domain.financial_transaction import (
        FinancialTransaction,
        FinancialTransactionStatus,
    )

    cutoff = datetime.now(timezone.utc) - STALE_PENDING_AFTER
    service = SubscriptionPaymentService(db)
    resolved = 0

    for _ in range(BATCH_SIZE):
        result = await db.execute(
            select(FinancialTransaction.id)
            .where(
                FinancialTransaction.status == FinancialTransactionStatus.PENDING.value,
                FinancialTransaction.created_at < cutoff,
            )
            .order_by(FinancialTransaction.created_at)
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        row = result.first()
        if row is None:
            break
        transaction_id = row[0]
        try:
            await service.reconcile_transaction(transaction_id)
            resolved += 1
        except Exception:
            logger.exception("Could not reconcile stale transaction %s", transaction_id)
            await db.rollback()
            # The failed provider operation remains pending and can be
            # retried by a later sweep. Continue with another claim rather
            # than holding a stale transaction lock.
            continue
    return resolved


async def run_webhook_reconciliation_loop(interval_seconds: int = POLL_INTERVAL_SECONDS, session_factory=None) -> None:
    if session_factory is None:
        _engine, session_factory = create_worker_runtime()

    logger.info("Webhook reconciliation loop started (interval=%ds)", interval_seconds)
    while True:
        async with session_factory() as session:
            started_at = worker_started()
            try:
                count = await reconcile_pending_webhooks(session)
                if count:
                    logger.info("Reconciled %d webhook event(s).", count)
                stale = await reconcile_stale_pending_transactions(session)
                record_worker_success("webhook_reconciliation", items=count + stale, started_at=started_at)
                if stale:
                    logger.info("Resolved %d stale pending transaction(s).", stale)
            except Exception:
                WORKER_FAILURES.labels("webhook_reconciliation" ).inc()
                logger.exception("Webhook reconciliation sweep failed")
                await session.rollback()
        await asyncio.sleep(interval_seconds)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run_webhook_reconciliation_loop())
