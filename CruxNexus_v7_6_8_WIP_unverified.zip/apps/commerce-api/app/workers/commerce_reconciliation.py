"""Commerce reservation expiry worker.

Releases stock held by abandoned or timed-out guest checkouts. This is a real
inventory lifecycle, not a mock payment timeout: the order, reservation and
inventory ledger are changed atomically under row locks.
"""
import asyncio
import logging
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.commerce import CommercePayment, Order, apply_commerce_payment_verification
from app.contexts.commerce.application.services.payment import _release_order_reservation
from app.workers.runtime import create_worker_runtime

from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger = logging.getLogger(__name__)
POLL_INTERVAL_SECONDS = 60
BATCH_SIZE = 50


async def reconcile_stale_commerce_payments(db: AsyncSession) -> int:
    """Re-query stale online customer payments with the MERCHANT's own provider credentials, so lost
    webhooks do not strand legitimate orders. The CruxNexus-owned (subscription) provider registry is
    never used here. Each payment is processed under its own tenant binding, so sealed credentials
    are only ever read for the payment's own merchant."""
    from datetime import timedelta
    from sqlalchemy import text
    from app.contexts.commerce.application.services import merchant_payments as mp
    from app.contexts.commerce.domain.invariants import transition_order
    from app.contexts.commerce.domain.models import MerchantPaymentConnection
    from app.infrastructure.payments.adapter import ProviderOutcomeUnknownError, ProviderTransactionNotFoundError, is_in_flight
    from app.infrastructure.secrets.credential_vault import VaultDecryptionError, VaultNotConfigured

    await db.execute(text("SELECT set_config('app.worker_context', '1', true)"))
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=15)
    stale = (await db.execute(
        select(CommercePayment.id, CommercePayment.tenant_id)
        .where(CommercePayment.connection_id.is_not(None), CommercePayment.status == "pending", CommercePayment.created_at < cutoff)
        .order_by(CommercePayment.created_at).limit(BATCH_SIZE)
    )).all()
    await db.rollback()  # end the read transaction; each payment below is its own transaction
    resolved = 0
    for payment_id, tenant_id in stale:
        try:
            await db.execute(text("SELECT set_config('app.worker_context', '1', true)"))
            await mp.bind_tenant_context(db, tenant_id)
            payment = (await db.execute(select(CommercePayment).where(
                CommercePayment.id == payment_id, CommercePayment.status == "pending").with_for_update(skip_locked=True))).scalar_one_or_none()
            if payment is None:
                await db.rollback()
                continue
            connection = (await db.execute(select(MerchantPaymentConnection).where(
                MerchantPaymentConnection.id == payment.connection_id, MerchantPaymentConnection.tenant_id == tenant_id))).scalar_one_or_none()
            if connection is None:
                await db.rollback()
                continue
            # The payment is verified against the credential revision it was INITIATED with. The merchant
            # disconnecting or replacing the account does not matter: that revision is retained while the
            # payment is unresolved. Only a purged revision (a payment that wrongly settled without
            # verification) cannot be checked, and then the payment stays pending for a human.
            try:
                adapter = await mp.build_adapter(db, connection, payment.credential_id)
                verification = await adapter.verify_transaction(payment.provider_reference or payment.reference)
            except ProviderTransactionNotFoundError:
                payment.status = "failed"
                order = (await db.execute(select(Order).where(Order.id == payment.order_id).with_for_update())).scalar_one_or_none()
                if order is not None and order.status in {"pending_payment", "awaiting_transfer"}:
                    order.payment_status = "failed"
                    transition_order(order, "payment_failed")
                    await _release_order_reservation(db, order, "provider_not_found")
                await db.flush()
                await mp.purge_settled_revisions(db, tenant_id=tenant_id, connection_id=connection.id)
                await db.commit()
                resolved += 1
                continue
            except (ProviderOutcomeUnknownError, VaultNotConfigured, VaultDecryptionError):
                await db.rollback()
                continue
            if is_in_flight(verification.status):
                await db.rollback()
                continue
            await apply_commerce_payment_verification(db, payment, verification)
            await db.flush()
            await mp.purge_settled_revisions(db, tenant_id=tenant_id, connection_id=connection.id)
            await db.commit()
            resolved += 1
        except Exception:
            logger.exception("Commerce payment reconciliation failed for payment %s", payment_id)
            await db.rollback()
    return resolved


async def sweep_merchant_payment_events(db: AsyncSession) -> int:
    """Retry merchant webhook events whose inline processing could not finish (provider unreachable...)."""
    from sqlalchemy import text
    from app.contexts.commerce.application.services import merchant_payments as mp
    from app.contexts.commerce.domain.models import MerchantPaymentEvent

    await db.execute(text("SELECT set_config('app.worker_context', '1', true)"))
    pending = (await db.execute(
        select(MerchantPaymentEvent.id, MerchantPaymentEvent.tenant_id)
        .where(MerchantPaymentEvent.processed.is_(False)).order_by(MerchantPaymentEvent.received_at).limit(BATCH_SIZE)
    )).all()
    await db.rollback()
    done = 0
    for event_id, tenant_id in pending:
        try:
            await mp.bind_tenant_context(db, tenant_id)
            if await mp.process_merchant_event(db, tenant_id, event_id):
                done += 1
            else:
                await db.rollback()
        except Exception:
            logger.exception("Merchant payment event %s sweep failed", event_id)
            await db.rollback()
    return done


async def expire_commerce_reservations(db: AsyncSession) -> int:
    from sqlalchemy import text
    from app.contexts.commerce.domain.invariants import transition_order

    await db.execute(text("SELECT set_config('app.worker_context', '1', true)"))
    now = datetime.now(timezone.utc)
    result = await db.execute(
        select(Order).where(
            Order.reservation_expires_at.is_not(None),
            Order.reservation_expires_at < now,
            Order.status.in_(("pending_payment", "payment_failed", "awaiting_transfer")),
        ).order_by(Order.reservation_expires_at).limit(BATCH_SIZE).with_for_update(skip_locked=True)
    )
    orders = result.scalars().all()
    count = 0
    for order in orders:
        # Ledger-based release: only what this order still holds, never a blind decrement.
        await _release_order_reservation(db, order, "reservation_expired")
        # An order can have several payment attempts (retries); consider all of them.
        payments = (await db.execute(select(CommercePayment).where(CommercePayment.order_id == order.id).with_for_update())).scalars().all()
        for payment in payments:
            if payment.status == "pending":
                payment.status = "abandoned"
        transition_order(order, "cancelled")
        order.cancellation_reason = "reservation_expired"   # distinguishes expiry from a deliberate cancel
        if payments:
            order.payment_status = "failed"
        order.reservation_expires_at = None
        count += 1
    if count:
        await db.commit()
    return count


async def run_commerce_reconciliation_loop(interval_seconds: int = POLL_INTERVAL_SECONDS, session_factory=None) -> None:
    if session_factory is None:
        _engine, session_factory = create_worker_runtime()
    logger.info("Commerce reservation reconciliation loop started (interval=%ds)", interval_seconds)
    while True:
        async with session_factory() as session:
            started_at = worker_started()
            try:
                await session.execute(__import__("sqlalchemy").text("SELECT set_config('app.worker_context', '1', true)"))
                payments = await reconcile_stale_commerce_payments(session)
                payments += await sweep_merchant_payment_events(session)
                from app.contexts.commerce.application.services.checkout_recovery import recover_stuck_checkouts
                await recover_stuck_checkouts(session)
                await session.execute(__import__("sqlalchemy").text("SELECT set_config('app.worker_context', '1', true)"))
                count = await expire_commerce_reservations(session)
                record_worker_success("commerce_reconciliation", items=payments + count, started_at=started_at)
                if payments:
                    logger.info("Reconciled %d stale commerce payment(s).", payments)
                if count:
                    logger.info("Expired %d commerce stock reservation(s).", count)
            except Exception:
                WORKER_FAILURES.labels("commerce_reconciliation" ).inc()
                logger.exception("Commerce reservation sweep failed")
                await session.rollback()
        await asyncio.sleep(interval_seconds)
