"""Onboarding session expiry worker.

FOR UPDATE SKIP LOCKED on both queries below (external review fix): this
worker previously had no row claiming at all, unlike trial_expiration.py
and event_relay.py which already did — two horizontally-scaled worker
replicas could select and bulk-update the same session rows. Safe to add
here without the batch/commit-boundary issue webhook_reconciliation.py
had, since each function here does exactly one SELECT, one bulk UPDATE,
and one commit — no per-row commits inside the loop that would release
the lock early.

Locked architecture section 48: sessions past their 7-day expires_at
window (set at creation — see OnboardingSessionService.create_session)
move to EXPIRED. This worker only flips the status; it does not delete
the row or its payload — section 48 also specifies the payload is
retained a further 30 days for recovery, which is a separate cleanup
job, not built here (nothing yet reads or purges based on that second
window, so building it now would be speculative).

Also recovers sessions stuck in LAUNCHING (external review fix): if the
process crashes mid-launch-transaction, a session can be left in
LAUNCHING indefinitely with no path back — nothing was watching for
that. Any session in LAUNCHING for longer than LAUNCHING_TIMEOUT_MINUTES
moves to RECOVERY_REQUIRED, an existing but previously-unreachable status
value on the model. This does NOT attempt the actual recovery/retry
itself - that needs to know whether the launch transaction's side effects
(if any partially committed before the crash) are safe to retry, which
depends on Phase 4's launch implementation (not yet built - see
CRX-P0-023). Flipping to RECOVERY_REQUIRED at least stops a stuck session
from silently pretending to still be in progress forever, and makes it
visible to whoever/whatever eventually implements that recovery.

Reminders at 1hr/24hr inactivity thresholds (also section 48) are not
implemented here either — that requires the notification seam
(app/infrastructure/notifications.py) to actually deliver something,
which it doesn't yet (logging-only, same standing note as everywhere
else this seam is referenced).
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.contexts.onboarding.domain.onboarding_session import (
    OnboardingSession,
    OnboardingSessionStatus,
)
from app.workers.runtime import create_worker_runtime

from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 300
LAUNCHING_TIMEOUT_MINUTES = 15


async def expire_stale_sessions(db) -> int:
    now = datetime.now(timezone.utc)

    result = await db.execute(
        select(OnboardingSession)
        .where(
            OnboardingSession.status == OnboardingSessionStatus.IN_PROGRESS.value,
            OnboardingSession.expires_at < now,
        )
        .with_for_update(skip_locked=True)
    )
    sessions = result.scalars().all()
    if sessions:
        session_ids = [s.id for s in sessions]
        await db.execute(
            update(OnboardingSession)
            .where(OnboardingSession.id.in_(session_ids))
            .values(status=OnboardingSessionStatus.EXPIRED.value)
        )
        await db.commit()
        logger.info("Expired %d stale onboarding session(s).", len(session_ids))

    return len(sessions) + await _recover_stuck_launches(db, now)


async def _recover_stuck_launches(db, now: datetime) -> int:
    timeout_cutoff = now - timedelta(minutes=LAUNCHING_TIMEOUT_MINUTES)

    result = await db.execute(
        select(OnboardingSession)
        .where(
            OnboardingSession.status == OnboardingSessionStatus.LAUNCHING.value,
            OnboardingSession.updated_at < timeout_cutoff,
        )
        .with_for_update(skip_locked=True)
    )
    stuck_sessions = result.scalars().all()
    if not stuck_sessions:
        return 0

    stuck_ids = [s.id for s in stuck_sessions]
    await db.execute(
        update(OnboardingSession)
        .where(OnboardingSession.id.in_(stuck_ids))
        .values(
            status=OnboardingSessionStatus.RECOVERY_REQUIRED.value,
            last_launch_error="Launch did not complete within the expected time and requires manual recovery.",
        )
    )
    await db.commit()

    logger.warning("Marked %d stuck LAUNCHING session(s) as RECOVERY_REQUIRED.", len(stuck_ids))
    return len(stuck_ids)


async def run_onboarding_expiry_loop(interval_seconds: int = POLL_INTERVAL_SECONDS, session_factory=None) -> None:
    """Run expire_stale_sessions() on a fixed interval, forever.

    Mirrors run_trial_expiration_loop's setup exactly (own engine/session
    factory, broad except-and-retry-next-tick so a not-yet-migrated
    database on worker startup doesn't crash-loop the process) — see that
    function's docstring in app/workers/trial_expiration.py for the full
    reasoning, which applies identically here.
    """
    if session_factory is None:
        _engine, session_factory = create_worker_runtime()

    logger.info("Onboarding session expiry loop started (interval=%ds)", interval_seconds)
    while True:
        async with session_factory() as session:
            started_at = worker_started()
            try:
                count = await expire_stale_sessions(session)
                record_worker_success("onboarding_expiry", items=count, started_at=started_at)
            except Exception:
                WORKER_FAILURES.labels("onboarding_expiry" ).inc()
                logger.exception("Onboarding session expiry sweep failed")
                await session.rollback()
        await asyncio.sleep(interval_seconds)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run_onboarding_expiry_loop())
