"""Paid subscription lifecycle worker.

ACTIVE subscriptions are driven by ends_at. At the period boundary they enter
PAST_DUE; after the governance-configured grace period they become SUSPENDED and owned storefront
tenants are suspended. Successful provider verification moves PAST_DUE/SUSPENDED
back to ACTIVE and establishes the next billing period.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.billing.domain.governance_policy import CommerceGovernancePolicy
from app.contexts.tenant_management.domain.suspension import TenantSuspension, SuspensionSource
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus
from app.infrastructure.outbox.repository import OutboxRepository
from app.kernel.events.types import DomainEvent, EventEnvelope

from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger = logging.getLogger(__name__)
POLL_INTERVAL_SECONDS = 300
BATCH_SIZE = 50


async def _suspend_subscription(db: AsyncSession, subscription: MerchantSubscription) -> None:
    subscription.status = SubscriptionStatus.SUSPENDED.value
    tenant_ids = [
        row[0]
        for row in (await db.execute(
            select(MerchantAccountTenant.tenant_id).where(
                MerchantAccountTenant.merchant_account_id == subscription.merchant_account_id
            )
        )).all()
    ]
    if tenant_ids:
        active_tenants = (await db.execute(select(Tenant.id).where(Tenant.id.in_(tenant_ids), Tenant.status == TenantStatus.ACTIVE.value))).scalars().all()
        if active_tenants:
            await db.execute(
                update(Tenant)
                .where(Tenant.id.in_(active_tenants), Tenant.status == TenantStatus.ACTIVE.value)
                .values(status=TenantStatus.SUSPENDED.value)
            )
            for tenant_id in active_tenants:
                db.add(TenantSuspension(tenant_id=tenant_id, reason="Subscription expired after grace period", source=SuspensionSource.SUBSCRIPTION.value, restorable_by_subscription=True, governance_override=False))
                from app.infrastructure.audit import SecurityEvent, SecurityEventType, record_durable_audit
                await record_durable_audit(db, SecurityEvent(event_type=SecurityEventType.TENANT_SUSPENDED, tenant_id=str(tenant_id), success=True, reason="Subscription expired after grace period", metadata={"source": SuspensionSource.SUBSCRIPTION.value}), actor_type=SuspensionSource.SUBSCRIPTION.value)
    await OutboxRepository(db).append(
        EventEnvelope(
            event_type=DomainEvent.SUBSCRIPTION_SUSPENDED,
            aggregate_type="MerchantSubscription",
            aggregate_id=subscription.id,
            payload={
                "merchant_account_id": str(subscription.merchant_account_id),
                "ends_at": subscription.ends_at.isoformat() if subscription.ends_at else None,
                "suspended_tenant_ids": [str(tid) for tid in tenant_ids],
            },
        )
    )


async def reconcile_subscription_lifecycle(db: AsyncSession) -> dict:
    now = datetime.now(timezone.utc)
    policy = await db.scalar(select(CommerceGovernancePolicy).where(CommerceGovernancePolicy.policy_key == "default"))
    if policy is None:
        raise RuntimeError("Commerce governance policy is not configured")
    grace_period = timedelta(days=policy.grace_period_days)
    past_due = 0
    suspended = 0

    result = await db.execute(
        select(MerchantSubscription)
        .where(
            MerchantSubscription.status == SubscriptionStatus.ACTIVE.value,
            MerchantSubscription.ends_at.is_not(None),
            MerchantSubscription.ends_at <= now,
        )
        .order_by(MerchantSubscription.ends_at)
        .limit(BATCH_SIZE)
        .with_for_update(skip_locked=True)
    )
    for subscription in result.scalars().all():
        subscription.status = SubscriptionStatus.PAST_DUE.value
        await OutboxRepository(db).append(
            EventEnvelope(
                event_type=DomainEvent.SUBSCRIPTION_PAST_DUE,
                aggregate_type="MerchantSubscription",
                aggregate_id=subscription.id,
                payload={"merchant_account_id": str(subscription.merchant_account_id), "ends_at": subscription.ends_at.isoformat()},
            )
        )
        past_due += 1
    if past_due:
        await db.commit()

    result = await db.execute(
        select(MerchantSubscription)
        .where(
            MerchantSubscription.status == SubscriptionStatus.PAST_DUE.value,
            MerchantSubscription.ends_at.is_not(None),
            MerchantSubscription.ends_at + grace_period <= now,
        )
        .order_by(MerchantSubscription.ends_at)
        .limit(BATCH_SIZE)
        .with_for_update(skip_locked=True)
    )
    for subscription in result.scalars().all():
        await _suspend_subscription(db, subscription)
        suspended += 1
    if suspended:
        await db.commit()
    return {"past_due": past_due, "suspended": suspended}


async def run_subscription_lifecycle_loop(session_factory, interval_seconds: int = POLL_INTERVAL_SECONDS) -> None:
    logger.info("Subscription lifecycle loop started (interval=%ds)", interval_seconds)
    while True:
        async with session_factory() as session:
            started_at = worker_started()
            try:
                result = await reconcile_subscription_lifecycle(session)
                record_worker_success("subscription_lifecycle", items=sum(result.values()), started_at=started_at)
                if any(result.values()):
                    logger.info("Subscription lifecycle sweep: %s", result)
            except Exception:
                WORKER_FAILURES.labels("subscription_lifecycle" ).inc()
                logger.exception("Subscription lifecycle sweep failed")
                await session.rollback()
        await asyncio.sleep(interval_seconds)
