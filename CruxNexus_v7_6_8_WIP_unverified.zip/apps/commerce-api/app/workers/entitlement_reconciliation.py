"""Entitlement lifecycle reconciliation worker.

This worker exists to keep entitlement/allocation state *healthy*, never
to decide whether a synchronous request is *allowed*. That distinction is
the whole point of this file, per the explicit architectural principle
locked for CruxNexus:

    Synchronous API ("Can I do this?")
        -> MerchantAccessResolver + CapacityService + transaction lock

    Asynchronous worker ("Is state healthy?")
        -> this file: reconciliation, expiry, anomaly detection

A merchant's POST /storefronts or invitation-accept request is answered
by MerchantAccessResolver in that same request, synchronously — this
worker never sits in that path and never will. If a future change makes
this worker responsible for an authorization decision, that's a
regression of this principle, not a feature.

Built only after the canonical allocation model was established
(migration 028 retired the two dead competing tables — see that
migration's docstring) — reconciling against multiple disagreeing models
would have formalized the confusion rather than resolved it.

Three deterministic/safe operations in this first version. Deliberately
does NOT attempt to auto-repair over-allocation (see
detect_allocation_anomalies below) — deciding which of several
allocations to reduce when they exceed a since-changed entitlement is a
governance/policy decision, not something to guess silently. Per the
locked direction, that kind of decision belongs to Control Center, not
to this worker inventing a resolution.
"""

import asyncio
import logging
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.contexts.billing.domain.allocation_anomaly import AllocationAnomaly
from app.contexts.billing.domain.merchant_entitlement import (
    EntitlementStatus,
    EntitlementType,
    MerchantEntitlement,
)
from app.contexts.billing.domain.staff_capacity_allocation import StaffCapacityAllocation
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus
from app.workers.runtime import create_worker_runtime
from app.infrastructure.outbox.repository import OutboxRepository
from app.kernel.events.types import DomainEvent, EventEnvelope

from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 600  # entitlement health is not urgent the way payment webhooks are


async def expire_lapsed_entitlements(db: AsyncSession) -> int:
    """ACTIVE entitlements past their ends_at move to EXPIRED.

    One row per transaction (FOR UPDATE SKIP LOCKED), matching the
    lesson already learned the hard way in webhook_reconciliation.py:
    a batch claim doesn't survive per-row commits, so don't batch-claim
    when each row gets its own commit.
    """
    expired_count = 0
    now = datetime.now(timezone.utc)

    for _ in range(100):  # bounded per sweep, matches other workers' batch ceilings
        result = await db.execute(
            select(MerchantEntitlement)
            .where(
                MerchantEntitlement.status == EntitlementStatus.ACTIVE.value,
                MerchantEntitlement.ends_at.is_not(None),
                MerchantEntitlement.ends_at < now,
            )
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        entitlement = result.scalar_one_or_none()
        if entitlement is None:
            break

        entitlement.status = EntitlementStatus.EXPIRED.value

        outbox = OutboxRepository(db)
        await outbox.append(
            EventEnvelope(
                event_type=DomainEvent.ENTITLEMENT_EXPIRED,
                aggregate_type="MerchantEntitlement",
                aggregate_id=entitlement.id,
                payload={
                    "merchant_account_id": str(entitlement.merchant_account_id),
                    "entitlement_type": entitlement.entitlement_type,
                    "quantity": entitlement.quantity,
                },
            )
        )
        await db.commit()
        expired_count += 1

    return expired_count


async def cleanup_orphaned_allocations(db: AsyncSession) -> int:
    """A StaffCapacityAllocation whose entitlement has expired/been
    revoked, or whose tenant has been archived, no longer represents
    anything real — delete it rather than let it silently continue
    contributing to a storefront's computed capacity.

    This IS a safe, deterministic repair (unlike over-allocation below):
    an allocation against a dead entitlement or an archived tenant has
    no valid interpretation other than "stale."
    """
    removed_count = 0

    for _ in range(100):
        result = await db.execute(
            select(StaffCapacityAllocation)
            .join(
                MerchantEntitlement,
                MerchantEntitlement.id == StaffCapacityAllocation.merchant_entitlement_id,
            )
            .join(Tenant, Tenant.id == StaffCapacityAllocation.tenant_id)
            .where(
                (MerchantEntitlement.status != EntitlementStatus.ACTIVE.value)
                | (Tenant.status == TenantStatus.ARCHIVED)
            )
            .limit(1)
            .with_for_update(of=StaffCapacityAllocation, skip_locked=True)
        )
        allocation = result.scalar_one_or_none()
        if allocation is None:
            break

        logger.info(
            "Removing orphaned staff allocation %s (entitlement_id=%s, tenant_id=%s)",
            allocation.id,
            allocation.merchant_entitlement_id,
            allocation.tenant_id,
        )
        await db.delete(allocation)
        await db.commit()
        removed_count += 1

    return removed_count


async def detect_allocation_anomalies(db: AsyncSession) -> int:
    """Open each allocation anomaly once and resolve it once fixed."""
    result = await db.execute(
        select(
            MerchantEntitlement.id,
            MerchantEntitlement.merchant_account_id,
            MerchantEntitlement.quantity,
            func.coalesce(func.sum(StaffCapacityAllocation.quantity), 0).label("allocated"),
        )
        .join(StaffCapacityAllocation, StaffCapacityAllocation.merchant_entitlement_id == MerchantEntitlement.id)
        .where(
            MerchantEntitlement.entitlement_type == EntitlementType.EXTRA_STAFF.value,
            MerchantEntitlement.status == EntitlementStatus.ACTIVE.value,
        )
        .group_by(MerchantEntitlement.id, MerchantEntitlement.merchant_account_id, MerchantEntitlement.quantity)
        .having(func.coalesce(func.sum(StaffCapacityAllocation.quantity), 0) > MerchantEntitlement.quantity)
    )
    anomalies = {row[0]: (row[1], row[2], row[3]) for row in result.all()}
    open_rows = (await db.execute(select(AllocationAnomaly).where(AllocationAnomaly.status == "open").with_for_update())).scalars().all()
    open_by_entitlement = {row.merchant_entitlement_id: row for row in open_rows}
    emitted = 0
    now = datetime.now(timezone.utc)

    for entitlement_id, (merchant_account_id, granted, allocated) in anomalies.items():
        row = open_by_entitlement.get(entitlement_id)
        if row is None:
            row = AllocationAnomaly(
                merchant_entitlement_id=entitlement_id,
                anomaly_type="over_allocation",
                status="open",
                granted_quantity=granted,
                allocated_quantity=allocated,
            )
            db.add(row)
            await db.flush()
            await OutboxRepository(db).append(EventEnvelope(
                event_type=DomainEvent.ALLOCATION_ANOMALY_DETECTED,
                aggregate_type="MerchantEntitlement",
                aggregate_id=entitlement_id,
                payload={"merchant_account_id": str(merchant_account_id), "granted": granted, "allocated": allocated},
            ))
            emitted += 1
        else:
            row.granted_quantity = granted
            row.allocated_quantity = allocated

    for row in open_rows:
        if row.merchant_entitlement_id not in anomalies:
            row.status = "resolved"
            row.resolved_at = now

    if anomalies or open_rows:
        await db.commit()
    return emitted


async def run_entitlement_reconciliation_sweep(db: AsyncSession) -> dict:
    expired = await expire_lapsed_entitlements(db)
    orphaned = await cleanup_orphaned_allocations(db)
    anomalies = await detect_allocation_anomalies(db)
    return {"expired": expired, "orphaned_removed": orphaned, "anomalies_detected": anomalies}


async def run_entitlement_reconciliation_loop(interval_seconds: int = POLL_INTERVAL_SECONDS, session_factory=None) -> None:
    if session_factory is None:
        _engine, session_factory = create_worker_runtime()

    logger.info("Entitlement reconciliation loop started (interval=%ds)", interval_seconds)
    while True:
        async with session_factory() as session:
            started_at = worker_started()
            try:
                result = await run_entitlement_reconciliation_sweep(session)
                record_worker_success("entitlement_reconciliation", items=sum(result.values()), started_at=started_at)
                if any(result.values()):
                    logger.info("Entitlement reconciliation sweep: %s", result)
            except Exception:
                WORKER_FAILURES.labels("entitlement_reconciliation" ).inc()
                logger.exception("Entitlement reconciliation sweep failed")
                await session.rollback()
        await asyncio.sleep(interval_seconds)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run_entitlement_reconciliation_loop())
