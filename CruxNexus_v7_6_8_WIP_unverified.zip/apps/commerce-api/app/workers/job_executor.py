"""Durable worker command executor with leases, retries and dead-letter state."""
from sqlalchemy import select
import asyncio, logging, socket
from app.infrastructure.worker_jobs import LeaseLostError, WorkerJob, claim_job, complete_job, fail_job
from app.workers.runtime import create_worker_runtime
from app.infrastructure.metrics import WORKER_FAILURES, record_worker_success, worker_started

logger=logging.getLogger(__name__)
POLL_INTERVAL_SECONDS=2
HANDLERS: dict[str, object] = {}

def register_job_handler(job_type: str, handler) -> None:
    HANDLERS[job_type] = handler

async def run_job_executor_loop(session_factory=None):
    from app.workers import job_handlers  # noqa: F401
    if session_factory is None:
        _engine, session_factory=create_worker_runtime()
    worker_id=f"{socket.gethostname()}:{id(asyncio.current_task())}"
    while True:
        started=worker_started(); processed=0; sweep_ok=True
        job_id=None; lease_token=None
        try:
            # Claim is its own committed transaction. The handler never runs
            # while holding the claim transaction open, so a process crash
            # leaves a durable running+lease row that another worker can reclaim.
            async with session_factory() as claim_session:
                job=await claim_job(claim_session,worker_id)
                if job is None:
                    await claim_session.commit()
                else:
                    job_id=job.id; lease_token=job.lease_token
                    await claim_session.commit()
            if job_id is not None:
                handler=HANDLERS.get(job.job_type)
                if handler is None:
                    async with session_factory() as fail_session:
                        row=(await fail_session.execute(select(WorkerJob).where(WorkerJob.id==job_id).with_for_update())).scalar_one_or_none()
                        if row is not None and row.locked_by==worker_id and row.lease_token==lease_token:
                            await fail_job(fail_session,row,f"No handler registered for job type {row.job_type}")
                        await fail_session.commit()
                else:
                    async with session_factory() as work_session:
                        row=(await work_session.execute(select(WorkerJob).where(WorkerJob.id==job_id).with_for_update())).scalar_one_or_none()
                        if row is None or row.locked_by!=worker_id or row.lease_token!=lease_token:
                            raise RuntimeError("Worker job lease was lost before execution")
                        await handler(work_session,row.payload)
                        # Atomic with the handler's effects: if the lease expired or was taken over,
                        # complete_job raises LeaseLostError and NOTHING from this run is committed.
                        await complete_job(work_session,row)
                        await work_session.commit()
                        processed=1
        except LeaseLostError as exc:
            # Another worker owns (or will re-run) this job; nothing of ours was committed. Do not touch it.
            sweep_ok=False
            WORKER_FAILURES.labels("job_executor").inc()
            logger.warning("Job lease lost, work discarded: %s", exc)
        except Exception as exc:
            sweep_ok=False
            WORKER_FAILURES.labels("job_executor").inc()
            logger.exception("Durable worker job execution failed: %s", exc)
            if job_id is not None:
                try:
                    async with session_factory() as fail_session:
                        row=(await fail_session.execute(select(WorkerJob).where(WorkerJob.id==job_id).with_for_update())).scalar_one_or_none()
                        if row is not None and row.locked_by==worker_id and row.lease_token==lease_token:
                            await fail_job(fail_session,row,str(exc))
                            await fail_session.commit()
                except Exception:
                    logger.exception("Failed to persist durable worker job failure for %s", job_id)
        if sweep_ok:
            record_worker_success("job_executor",items=processed,started_at=started)
        await asyncio.sleep(POLL_INTERVAL_SECONDS)
