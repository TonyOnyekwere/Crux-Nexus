import logging
import time
import os
import uuid
from contextlib import asynccontextmanager

import redis.asyncio as redis
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.auth.tenant_context import get_tenant_context
from app.config import get_settings
from app.contexts.identity.api.routes import router as identity_router
from app.contexts.merchant_management.api.routes import router as merchant_router
from app.contexts.onboarding.api.routes import router as onboarding_router
from app.contexts.onboarding.api.journey_routes import router as onboarding_journey_router
from app.contexts.tenant_management.api.routes import router as tenant_router
from app.contexts.admin.api.routes import router as admin_router
from app.contexts.admin.api.governance_routes import router as governance_admin_router
from app.contexts.billing.api.staff_invitation_routes import router as invitation_router
from app.contexts.billing.api.subscription_payment_routes import router as subscription_payment_router
from app.contexts.billing.api.plan_routes import router as billing_plan_router
from app.contexts.billing.api.webhook_routes import router as billing_webhook_router
from app.contexts.billing.api.entitlement_routes import router as entitlement_router
from app.contexts.commerce import merchant as commerce_router, public as public_storefront_router
from app.contexts.commerce.api.merchant_payment_routes import webhook_router as merchant_payment_webhook_router
from app.infrastructure.rate_limiter import limiter, rate_limit_exceeded_handler
from slowapi.middleware import SlowAPIMiddleware
from app.kernel.errors.handlers import register_exception_handlers
from slowapi.errors import RateLimitExceeded
from app.infrastructure.metrics import HTTP_REQUESTS, HTTP_LATENCY, metrics_payload

logger = logging.getLogger(__name__)

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Owns the app-lifetime Redis client that account-lockout tracking
    depends on.

    Previously, no code path ever set app.state.redis_client at all — the
    only Redis client in the app was created, pinged, and immediately
    closed inside the /health/ready handler, entirely unrelated to
    app.state. get_login_tracker()'s `hasattr(request.app.state,
    'redis_client')` check therefore always failed, silently disabling
    account lockout on every login attempt despite AccountLockoutService
    being fully implemented. decode_responses=True here matches the
    string-keyed reads in app/infrastructure/account_lockout.py (which
    previously assumed byte keys — fixed alongside this).
    """
    app.state.redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)
    try:
        await app.state.redis_client.ping()
    except Exception:
        logger.warning(
            "Could not reach Redis at startup; account lockout tracking "
            "will be unavailable until connectivity is restored.",
            exc_info=True,
        )

    from app.infrastructure.payments.setup import configure_payment_providers

    configure_payment_providers()

    yield
    await app.state.redis_client.close()


app = FastAPI(
    title=settings.APP_NAME,
    debug=settings.DEBUG,
    version="0.1.0",
    lifespan=lifespan,
)

register_exception_handlers(app)

# Rate limiting: the limiter is applied by this middleware (default per-IP ceiling) and by explicit
# @limiter.limit decorators on sensitive routes (login, credential intake, checkout, webhooks).
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    # Explicitly list allowed methods instead of wildcard
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    # Explicitly list allowed headers instead of wildcard
    allow_headers=[
        "Authorization",
        "Content-Type",
        "X-Request-ID",
        "X-API-Key",
        # Fixed a real gap (external review): both of these are required
        # by endpoints already shipped (onboarding session possession,
        # onboarding idempotency) but were missing here, meaning a
        # browser frontend would fail CORS preflight before the request
        # ever reached a backend that handles them correctly.
        "X-Device-Session-Token",
        "Idempotency-Key",
        # Public storefront bearer credentials (carried in headers, never URLs). Missing from this list the
        # browser preflight fails and a real storefront cannot add to cart or look up an order.
        "X-Cart-Token",
        "X-Order-Token",
    ],
    allow_origin_regex=r"https://.*\.cruxnexus\.com"
)

@limiter.exempt
@app.get("/metrics", include_in_schema=False)
async def metrics():
    payload, content_type = metrics_payload()
    from fastapi.responses import Response
    return Response(content=payload, media_type=content_type.split(";", 1)[0])


@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    started = time.perf_counter()
    response = await call_next(request)
    route = request.scope.get("route")
    path = getattr(route, "path", None) or "unmatched"   # '/orders/{order_id}', not '/orders/<uuid>'
    elapsed = time.perf_counter() - started
    HTTP_REQUESTS.labels(request.method, path, str(response.status_code)).inc()
    HTTP_LATENCY.labels(request.method, path).observe(elapsed)
    return response


@app.middleware("http")
async def security_headers(request: Request, call_next):
    """Add security headers to all responses."""
    response = await call_next(request)

    # Prevent clickjacking attacks
    response.headers["X-Frame-Options"] = "DENY"
    # Prevent MIME type sniffing
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Enable XSS filter in browsers
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # Enforce HTTPS for 1 year including subdomains
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    # Control referrer information
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # Restrict browser features
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"

    return response

app.include_router(identity_router)
app.include_router(tenant_router)
app.include_router(merchant_router)
app.include_router(onboarding_router)
app.include_router(onboarding_journey_router)
app.include_router(admin_router)
app.include_router(governance_admin_router)
app.include_router(invitation_router)
app.include_router(subscription_payment_router)
app.include_router(billing_plan_router)
app.include_router(billing_webhook_router)
app.include_router(entitlement_router)
app.include_router(commerce_router)
app.include_router(public_storefront_router)
app.include_router(merchant_payment_webhook_router)

@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request.state.request_id = str(uuid.uuid4())
    return await call_next(request)


@app.middleware("http")
async def tenant_middleware(request: Request, call_next):
    """
    Middleware subdomain hint only — does NOT establish JWT tenant authority.

    Authenticated tenant access is verified exclusively through route
    dependencies (get_current_tenant_context / get_verified_tenant_context).
    """
    # Liveness must answer even when Postgres is down — that's the whole
    # point of separating it from /health/ready. Resolving tenant context
    # below opens a DB session unconditionally, so without this bypass a
    # transient DB outage would 500 the liveness probe too and could cause
    # an orchestrator to restart an otherwise-healthy process in response
    # to a downstream dependency issue.
    if request.url.path in ("/health/live", "/health"):
        return await call_next(request)

    from sqlalchemy.exc import ProgrammingError

    try:
        # Resolve tenant with a short-lived session before handing off the request.
        from app.database import AsyncSessionLocal

        try:
            async with AsyncSessionLocal() as db:
                tenant_context = await get_tenant_context(request, db)
        except ProgrammingError:
            # Database schema may not be ready (missing tenants table).
            # Treat as no tenant rather than failing the whole request.
            tenant_context = None

        request.state.tenant_context = tenant_context

        if tenant_context:
            request.state.current_tenant_id = str(tenant_context.tenant_id)

        return await call_next(request)
    except HTTPException:
        # Let HTTPException bubble up for proper error responses
        raise
    except Exception:
        # Other unexpected exceptions should result in 500 for observability
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error during tenant resolution"
        )


@limiter.exempt
@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": settings.APP_NAME}


@limiter.exempt
@app.get("/health/ready")
async def readiness_check():
    """Readiness check - verifies DB and Redis connectivity."""
    from app.database import engine
    from app.config import get_settings
    import redis.asyncio as redis
    
    settings = get_settings()
    checks = {"database": False, "redis": False}
    
    # Check database connectivity
    try:
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        checks["database"] = True
    except Exception:
        # Log the exception server-side, don't expose details to client
        checks["database"] = False
    
    # Check Redis connectivity
    try:
        redis_client = redis.from_url(settings.REDIS_URL)
        await redis_client.ping()
        await redis_client.close()
        checks["redis"] = True
    except Exception:
        # Log the exception server-side, don't expose details to client
        checks["redis"] = False
    
    # Return 503 if any mandatory dependency is down
    if not all(checks.values()):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "status": "not_ready",
                "checks": checks
            }
        )
    
    return {"status": "ready", "checks": checks}


@limiter.exempt
@app.get("/health/live")
async def liveness_check():
    return {"status": "alive"}


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", settings.PORT))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=settings.DEBUG)


