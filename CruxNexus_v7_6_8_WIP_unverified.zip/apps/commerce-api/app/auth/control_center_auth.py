"""Service-to-service authentication for Control Center.

Control Center is a separate service with its own database and its own
admin identity/RBAC — it has no direct access to commerce-api's database,
specifically so that an incident in Control Center (its own bugs, its own
outages) can't disrupt commerce-api's commercial traffic. It reaches
commerce-api's platform-only endpoints (tenant lifecycle transitions,
entitlement grants) purely over the API, authenticated as a *service*,
not as an individual admin user.

This replaced an earlier approach (migration 018, since removed, plus a
now-removed /platform-admin/login endpoint and is_platform_admin column
on `users`) that modeled platform-admin access as a user login inside
commerce-api itself. That was the wrong shape once it was confirmed that
Control Center owns admin identity/RBAC/audit entirely in its own
database: commerce-api's `users` table is the merchant/customer identity
plane, and mixing a platform-admin identity into it re-couples exactly
what the separate-database design was meant to keep apart, just one
layer up (at the identity/authorization layer instead of the storage
layer).

The trust boundary here is therefore "is this request really from
Control Center" (a shared secret, service-level), not "which admin is
making this request" (which Control Center has already authorized on its
own side before ever calling commerce-api). commerce-api trusts and logs
whatever admin identity Control Center asserts via headers, for audit
purposes, without independently verifying it — verifying it is Control
Center's job, already done by the time the request arrives here.
"""

import hmac
import logging
from typing import Optional

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.config import get_settings
from app.kernel.errors.responses import error_response

logger = logging.getLogger(__name__)

security = HTTPBearer(auto_error=False)


class ControlCenterContext:
    """What commerce-api knows about the calling request once the service
    boundary has been verified. `acting_admin_id`/`acting_admin_email` are
    Control Center's assertions, included for audit logging only — they
    are not independently authenticated by commerce-api."""

    def __init__(
        self,
        acting_admin_id: Optional[str] = None,
        acting_admin_email: Optional[str] = None,
    ):
        self.acting_admin_id = acting_admin_id
        self.acting_admin_email = acting_admin_email


async def verify_control_center_service(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    x_acting_admin_id: Optional[str] = Header(None, alias="X-Acting-Admin-Id"),
    x_acting_admin_email: Optional[str] = Header(None, alias="X-Acting-Admin-Email"),
) -> ControlCenterContext:
    """Gate for endpoints that should only ever be called by Control
    Center: PATCH /tenants/{id}/status, POST /entitlements/grant-plan-based,
    and any future platform-only mutation.

    Not a user-authorization check - there is no concept of "which human"
    at this layer. Presenting the correct shared token proves "this call
    came from Control Center"; Control Center is responsible for having
    already checked that the human behind it was allowed to trigger it.
    """
    settings = get_settings()

    if credentials is None or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error_response(
                code="CONTROL_CENTER_AUTH_REQUIRED",
                message="This operation may only be performed by Control Center.",
            ),
            headers={"WWW-Authenticate": "Bearer"},
        )

    expected = settings.CONTROL_CENTER_SERVICE_TOKEN or ""
    provided = credentials.credentials

    # Constant-time comparison - a naive `==` here would leak how many
    # leading characters matched via response timing, letting an attacker
    # recover the token byte by byte.
    if not expected or not hmac.compare_digest(provided, expected):
        logger.warning("Rejected a call to a Control-Center-only endpoint with an invalid service token.")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=error_response(
                code="CONTROL_CENTER_AUTH_REQUIRED",
                message="This operation may only be performed by Control Center.",
            ),
        )

    return ControlCenterContext(
        acting_admin_id=x_acting_admin_id,
        acting_admin_email=x_acting_admin_email,
    )
