"""Shared password strength policy.

Extracted from app/contexts/identity/api/schemas.py's UserCreate
validator (previously duplicated nowhere, but at risk of being duplicated
incorrectly): a real gap found in external review was that invitation-
based account creation (StaffInvitationAccept) hashed whatever password
was supplied with no strength check at all, while ordinary signup
enforced length/complexity/common-password rules. A single shared
function means both paths can never drift out of sync again.
"""

import re

WEAK_PASSWORDS = ["password", "password123", "12345678", "qwerty123", "letmein"]


def validate_password_strength(password: str) -> str:
    """Raises ValueError with a user-facing message if the password
    doesn't meet policy. Returns the password unchanged if it does, so
    this can be used directly as a Pydantic field_validator body."""
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters long")
    if len(password) > 128:
        raise ValueError("Password must not exceed 128 characters")
    if not re.search(r"[A-Z]", password):
        raise ValueError("Password must contain at least one uppercase letter")
    if not re.search(r"[a-z]", password):
        raise ValueError("Password must contain at least one lowercase letter")
    if not re.search(r"\d", password):
        raise ValueError("Password must contain at least one number")
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        raise ValueError(
            'Password must contain at least one special character (!@#$%^&*(),.?":{}|<>)'
        )
    if password.lower() in WEAK_PASSWORDS:
        raise ValueError("Password is too common. Please choose a stronger password")
    return password
