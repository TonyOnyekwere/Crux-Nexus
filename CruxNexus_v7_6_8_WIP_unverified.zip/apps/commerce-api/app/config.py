import secrets
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache


class Settings(BaseSettings):
    DATABASE_URL: str | None = None
    DATABASE_RUNTIME_URL: str | None = None
    DATABASE_WORKER_URL: str | None = None
    REDIS_URL: str | None = None
    SECRET_KEY: str | None = None
    JWT_SECRET_KEY: str | None = None
    CONTROL_CENTER_SERVICE_TOKEN: str | None = None
    # Payment provider credentials. None until real sandbox/live keys are
    # supplied — PaymentProviderRegistry only registers an adapter whose
    # key is actually configured (see app/infrastructure/payments/setup.py),
    # so an unconfigured provider fails loudly with "not registered"
    # rather than attempting a call with an empty key.
    PAYSTACK_SECRET_KEY: str | None = None
    FLUTTERWAVE_SECRET_KEY: str | None = None
    # Flutterwave's webhook "secret hash" - a value you set once in the
    # Flutterwave dashboard (Settings > Webhooks), distinct from the API
    # secret key. See FlutterwaveAdapter.verify_webhook_signature for the
    # verification-method ambiguity this needs confirming against your
    # actual dashboard docs before relying on it.
    FLUTTERWAVE_WEBHOOK_SECRET_HASH: str | None = None
    SENDGRID_API_KEY: str | None = None
    SENDGRID_FROM_EMAIL: str | None = None
    # Merchant payment-credential encryption (see infrastructure/secrets/credential_vault.py).
    # Format: "v1:<base64 32-byte key>;v2:...". Required before any merchant can connect a provider.
    CREDENTIAL_ENCRYPTION_KEYS: str | None = None
    CREDENTIAL_ACTIVE_KEY_VERSION: str | None = None
    # Rate limiting (SlowAPI over Redis). Disable ONLY for tests that do not exercise it.
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_DEFAULT: str = "300 per minute"
    # Number of trusted reverse-proxy hops in front of the app (Railway edge = 1). 0 = ignore X-Forwarded-For.
    TRUSTED_PROXY_HOPS: int = 1
    ENVIRONMENT: str = "development"
    APP_NAME: str = "CruxNexus Commerce API"
    DEBUG: bool = False
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15  # Reduced from 30 to 15 minutes for security
    CORS_ORIGINS: list[str] | None = None
    PLATFORM_DEFAULT_PAYMENT_PROVIDER: str = "paystack"
    PLATFORM_DEFAULT_LOGISTICS_PROVIDER: str = "fallback"
    PLATFORM_DEFAULT_NOTIFICATION_PROVIDER: str = "sendgrid"
    PORT: int = 8000
    PUBLIC_APP_URL: str = "http://localhost:3000"
    RAILWAY_ENVIRONMENT: str = "development"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", case_sensitive=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        env_name = (self.ENVIRONMENT or "development").lower()

        # Validate environment
        allowed_envs = {"development", "staging", "production", "testing"}
        if env_name not in allowed_envs:
            raise ValueError(f"ENVIRONMENT must be one of {allowed_envs}")

        if env_name == "production":
            if not self.DATABASE_URL:
                raise ValueError("DATABASE_URL must be provided in production environment")
            if not self.DATABASE_RUNTIME_URL:
                raise ValueError("DATABASE_RUNTIME_URL must be provided in production environment")
            if not self.DATABASE_WORKER_URL:
                raise ValueError("DATABASE_WORKER_URL must be provided in production environment")
            from urllib.parse import urlparse
            runtime_user = urlparse(self.DATABASE_RUNTIME_URL).username
            worker_user = urlparse(self.DATABASE_WORKER_URL).username
            if runtime_user == "postgres" or worker_user == "postgres":
                raise ValueError("DATABASE_RUNTIME_URL must use a non-superuser runtime role")
            if not self.REDIS_URL:
                raise ValueError("REDIS_URL must be provided in production environment")
            if not self.SECRET_KEY or self._is_weak_secret(self.SECRET_KEY):
                raise ValueError("SECRET_KEY must be a strong, unique value in production")
            if not self.JWT_SECRET_KEY or self._is_weak_secret(self.JWT_SECRET_KEY):
                raise ValueError("JWT_SECRET_KEY must be a strong, unique value in production")
            if len(self.JWT_SECRET_KEY) < 32:
                raise ValueError("JWT_SECRET_KEY must be at least 32 characters for security")
            if len(self.SECRET_KEY) < 32:
                raise ValueError("SECRET_KEY must be at least 32 characters for security")
            if not self.CONTROL_CENTER_SERVICE_TOKEN or self._is_weak_secret(self.CONTROL_CENTER_SERVICE_TOKEN):
                raise ValueError("CONTROL_CENTER_SERVICE_TOKEN must be a strong, unique value in production")
            if not self.SENDGRID_API_KEY or not self.SENDGRID_FROM_EMAIL:
                raise ValueError("SENDGRID_API_KEY and SENDGRID_FROM_EMAIL must be provided in production for onboarding and notification delivery")
            if not self.PAYSTACK_SECRET_KEY and not self.FLUTTERWAVE_SECRET_KEY:
                raise ValueError("At least one real payment provider secret must be configured in production")
            if self.FLUTTERWAVE_SECRET_KEY and not self.FLUTTERWAVE_WEBHOOK_SECRET_HASH:
                raise ValueError("FLUTTERWAVE_WEBHOOK_SECRET_HASH is required when Flutterwave is configured")
            if not self.PUBLIC_APP_URL.lower().startswith("https://"):
                raise ValueError("PUBLIC_APP_URL must use HTTPS in production")
            # Merchant payment credentials are sealed with this key set. Without it every merchant payment
            # connection would fail at runtime while the service still looks healthy, so fail at startup.
            from app.infrastructure.secrets.credential_vault import VaultNotConfigured, vault_from_settings
            try:
                vault_from_settings(self)
            except VaultNotConfigured as exc:
                raise ValueError(f"CREDENTIAL_ENCRYPTION_KEYS must configure at least one valid 32-byte key in production ({exc})")
            self.CORS_ORIGINS = self.CORS_ORIGINS or ["https://cruxnexus.com"]
        elif env_name == "staging":
            self.CORS_ORIGINS = self.CORS_ORIGINS or ["https://staging.cruxnexus.com"]
        else:
            self.CORS_ORIGINS = self.CORS_ORIGINS or ["http://localhost:3000"]

        # Local/test runs should still be able to boot with safe placeholders to support
        # unit tests and development without turning off production validation.
        if self.DATABASE_URL:
            try:
                from app.database.url import normalize_async_database_url
                self.DATABASE_URL = normalize_async_database_url(self.DATABASE_URL)
            except ValueError:
                pass
        if self.DATABASE_RUNTIME_URL:
            try:
                from app.database.url import normalize_async_database_url
                self.DATABASE_RUNTIME_URL = normalize_async_database_url(self.DATABASE_RUNTIME_URL)
            except ValueError:
                pass
        if self.DATABASE_WORKER_URL:
            try:
                from app.database.url import normalize_async_database_url
                self.DATABASE_WORKER_URL = normalize_async_database_url(self.DATABASE_WORKER_URL)
            except ValueError:
                pass

        if env_name not in {"production", "staging"}:
            self.DATABASE_URL = self.DATABASE_URL or "postgresql+asyncpg://user:pass@localhost:5432/crux"
            self.DATABASE_RUNTIME_URL = self.DATABASE_RUNTIME_URL or self.DATABASE_URL
            self.DATABASE_WORKER_URL = self.DATABASE_WORKER_URL or self.DATABASE_RUNTIME_URL
            self.REDIS_URL = self.REDIS_URL or "redis://localhost:6379/0"
            # Generate cryptographically secure random secrets for non-production environments
            self.SECRET_KEY = self.SECRET_KEY or secrets.token_hex(32)
            self.JWT_SECRET_KEY = self.JWT_SECRET_KEY or secrets.token_hex(32)
            self.CONTROL_CENTER_SERVICE_TOKEN = self.CONTROL_CENTER_SERVICE_TOKEN or secrets.token_hex(32)

    @staticmethod
    def _is_weak_secret(secret: str) -> bool:
        """Check if a secret is weak or matches known default values."""
        if not secret or len(secret) < 32:
            return True
        weak_defaults = [
            "12345678901234567890123456789012",
            "development-secret-key-change-in-production",
            "change-this-in-production-railway-secret-key",
            "development-jwt-secret-key",
            "change-this-in-production-jwt-secret-key",
            "changeme",
            "secret",
            "password",
        ]
        return secret in weak_defaults


@lru_cache()
def get_settings() -> Settings:
    return Settings()