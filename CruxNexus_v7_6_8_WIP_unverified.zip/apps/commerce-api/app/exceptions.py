"""Backward-compatible re-exports. Prefer app.kernel.errors.exceptions."""

from app.kernel.errors.exceptions import (
    AuthorizationError,
    CapacityExceeded,
    CapacityExceededError,
    CruxNexusError,
    IdempotencyKeyConflictError,
    NotFoundError,
    OnboardingInProgressError,
    SubscriptionRequiredError,
    ValidationError,
)

__all__ = [
    "AuthorizationError",
    "CapacityExceeded",
    "CapacityExceededError",
    "CruxNexusError",
    "IdempotencyKeyConflictError",
    "NotFoundError",
    "OnboardingInProgressError",
    "SubscriptionRequiredError",
    "ValidationError",
]
