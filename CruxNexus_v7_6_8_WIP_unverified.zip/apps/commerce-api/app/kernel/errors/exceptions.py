
from app.kernel.errors.codes import TENANT_ACCESS_DENIED, SUBSCRIPTION_REQUIRED


class CruxNexusError(Exception):
    """Base exception for all CruxNexus domain errors."""

    def __init__(self, code: str, message: str, details: dict | None = None):
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(message)


class ValidationError(CruxNexusError):
    """Raised when supplied data or a requested state transition is invalid."""

    def __init__(
        self,
        message: str,
        code: str = "VALIDATION_ERROR",
        details: dict | None = None,
    ):
        super().__init__(
            code=code,
            message=message,
            details=details,
        )


class CapacityExceededError(CruxNexusError):
    """Raised when merchant exceeds their capacity limits."""

    def __init__(self, resource: str, capacity: int, current: int):
        super().__init__(
            code=f"{resource.upper()}_CAPACITY_EXCEEDED",
            message=f"This merchant has reached its {resource} capacity.",
            details={"capacity": capacity, "current": current},
        )


class SubscriptionRequiredError(CruxNexusError):
    """Raised when an operation requires an active/trialing subscription."""

    def __init__(
        self,
        message: str = "An active or trialing subscription is required for this operation.",
    ):
        super().__init__(
            code=SUBSCRIPTION_REQUIRED,
            message=message,
        )


class NotFoundError(CruxNexusError):
    def __init__(self, resource: str, message: str | None = None):
        super().__init__(
            code=f"{resource.upper()}_NOT_FOUND",
            message=message or f"{resource} not found.",
        )


class AuthorizationError(CruxNexusError):
    def __init__(
        self,
        message: str,
        code: str = TENANT_ACCESS_DENIED,
    ):
        super().__init__(
            code=code,
            message=message,
        )


class IdempotencyKeyConflictError(CruxNexusError):
    """Raised when an Idempotency-Key is reused with different request
    parameters than the original request that key was first used for."""

    def __init__(self, message: str | None = None):
        super().__init__(
            code="IDEMPOTENCY_KEY_CONFLICT",
            message=message
            or "This Idempotency-Key was already used with different request parameters.",
        )


class OnboardingInProgressError(CruxNexusError):
    """Raised when a request with this Idempotency-Key is still being
    processed by a concurrent/earlier request that hasn't finished yet."""

    def __init__(self, message: str | None = None):
        super().__init__(
            code="ONBOARDING_IN_PROGRESS",
            message=message
            or "A request with this Idempotency-Key is already being processed. Retry shortly.",
        )


# Backward-compatible alias
CapacityExceeded = CapacityExceededError
