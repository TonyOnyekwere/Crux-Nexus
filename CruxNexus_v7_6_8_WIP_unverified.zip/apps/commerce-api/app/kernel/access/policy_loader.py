"""Loads the effective tier policy for a tenant from the synchronized plan.

Control Center is the source of truth for tiers; Commerce only reads the
synchronized `subscription_plans.capabilities` / `.resource_limits` columns and
the merchant's latest subscription. No tier names or tier numbers live here.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, Tuple
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.merchant_entitlement import MerchantEntitlement
from app.contexts.billing.domain.merchant_subscription import MerchantSubscription
from app.contexts.merchant_management.domain.merchant_account_tenant import MerchantAccountTenant
from app.kernel.access.entitlement_policy import (
    Decision,
    EffectivePolicy,
    Standing,
    addon_grants,
    effective_policy,
    standing_for_subscription,
)


async def merchant_id_for_tenant(db: AsyncSession, tenant_id: UUID) -> Optional[UUID]:
    return await db.scalar(
        select(MerchantAccountTenant.merchant_account_id).where(MerchantAccountTenant.tenant_id == tenant_id)
    )


async def load_policy_for_tenant(db: AsyncSession, tenant_id: UUID) -> Tuple[EffectivePolicy, Standing]:
    """Fail closed: unknown merchant / no subscription / no plan => BLOCKED, empty policy."""
    merchant_id = await merchant_id_for_tenant(db, tenant_id)
    if merchant_id is None:
        return effective_policy(plan_capabilities=[], plan_limits={}), Standing.BLOCKED
    subscription = (
        await db.execute(
            select(MerchantSubscription)
            .where(MerchantSubscription.merchant_account_id == merchant_id)
            .order_by(MerchantSubscription.created_at.desc())
            .limit(1)
        )
    ).scalar_one_or_none()
    if subscription is None:
        return effective_policy(plan_capabilities=[], plan_limits={}), Standing.BLOCKED
    plan = (
        await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == subscription.subscription_plan_id))
    ).scalar_one_or_none()
    if plan is None:
        return effective_policy(plan_capabilities=[], plan_limits={}), Standing.BLOCKED
    # Purchased / granted add-ons (e.g. a custom domain bought on a lower tier). What each grant gives
    # is stated by the Control Center in the entitlement's grant_metadata; time windows are enforced
    # here, synchronously, not left to a cleanup worker.
    entitlements = (
        await db.execute(select(MerchantEntitlement).where(MerchantEntitlement.merchant_account_id == merchant_id))
    ).scalars().all()
    addon_caps, addon_bonus = addon_grants(entitlements, now=datetime.now(timezone.utc))
    policy = effective_policy(
        plan_capabilities=getattr(plan, "capabilities", None) or {},
        plan_limits=getattr(plan, "resource_limits", None) or {},
        addon_capabilities=addon_caps,
        addon_limit_bonus=addon_bonus,
    )
    return policy, standing_for_subscription(subscription.status)


def deny(decision: Decision, status_code: int = 403) -> HTTPException:
    return HTTPException(
        status_code,
        detail={"error": {"code": decision.code, "message": decision.reason, "details": dict(decision.details)}},
    )
