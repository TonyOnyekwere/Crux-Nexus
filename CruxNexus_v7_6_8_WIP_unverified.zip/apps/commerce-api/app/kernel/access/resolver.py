"""MerchantAccessResolver — locked Onboarding & Activation Architecture,
section 13.

Every protected capability check is supposed to go through one place:

    can_create_storefront()
    can_add_staff()
    can_publish_store()
    can_process_orders()
    can_use_premium_feature()
    can_reactivate_store()

evaluating Merchant Status + Subscription Status + Entitlements +
Storefront Status + Role + Policy together — never a scattered
`if plan == "BUSINESS":` throughout route handlers.

WHAT THIS CLOSES: CapacityService.can_create_storefront/can_add_staff
(app/contexts/merchant_management/application/capacity.py) already existed
and are still the source of truth for entitlement/capacity arithmetic —
this resolver does not duplicate that math, it wraps it. What was missing
before this file existed: neither method checked whether the merchant's
*subscription* was actually in a commercially-valid state first. A
merchant whose subscription had lapsed to PAST_DUE or SUSPENDED, but who
still had unused storefront/staff slots on paper, could pass those checks
anyway. That's exactly the class of bug section 37 of the locked
architecture is written to prevent ("must not create a sellable merchant
based on capacity numbers alone — must query the authoritative commercial
state first").

Commerce capabilities are implemented against the current MVP domains.
Premium feature codes remain entitlement-governed and unknown feature codes
are denied rather than implicitly allowed.
"""

from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.contexts.billing.domain.merchant_subscription import MerchantSubscription, SubscriptionStatus
from app.contexts.merchant_management.application.capacity import CapacityService
from app.contexts.merchant_management.domain.entities import MerchantAccount, MerchantStatus
from app.contexts.tenant_management.domain.entities import Tenant, TenantStatus

# Subscription states that permit granting new commercial capability
# (creating a storefront, adding staff). Locked architecture section 26/37:
# onboarding "must not advance ... until the subscription becomes
# trial-active or active" — applied here as the general gate for any new
# capability grant, not just the initial onboarding launch. PAST_DUE is
# deliberately excluded: a merchant behind on payment can keep using what
# they already have (that's a separate, softer policy this resolver does
# not currently enforce either way), but should not be granted *new*
# capacity while payment is unresolved.
_SUBSCRIPTION_STATES_PERMITTING_NEW_CAPABILITY = {
    SubscriptionStatus.TRIALING,
    SubscriptionStatus.ACTIVE,
}


class AccessDenied:
    """Result of a resolver check that failed, carrying why — callers
    should surface `reason` in the API error rather than a bare 403."""

    def __init__(self, reason: str):
        self.allowed = False
        self.reason = reason

    def __bool__(self) -> bool:
        return False


class AccessGranted:
    def __init__(self):
        self.allowed = True
        self.reason = None

    def __bool__(self) -> bool:
        return True


class MerchantAccessResolver:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.capacity = CapacityService(db)

    async def _merchant_and_subscription(self, merchant_account_id: UUID):
        merchant_result = await self.db.execute(
            select(MerchantAccount).where(MerchantAccount.id == merchant_account_id)
        )
        merchant = merchant_result.scalar_one_or_none()

        subscription_result = await self.db.execute(
            select(MerchantSubscription)
            .where(MerchantSubscription.merchant_account_id == merchant_account_id)
            .order_by(MerchantSubscription.created_at.desc())
            .limit(1)
        )
        subscription = subscription_result.scalar_one_or_none()

        return merchant, subscription

    async def can_create_storefront(self, merchant_account_id: UUID):
        merchant, subscription = await self._merchant_and_subscription(merchant_account_id)

        if merchant is None:
            return AccessDenied("Merchant account not found.")
        if merchant.status != MerchantStatus.ACTIVE:
            return AccessDenied(f"Merchant account is {merchant.status.value}, not active.")
        if subscription is None:
            return AccessDenied("Merchant has no subscription.")
        if subscription.status not in {s.value for s in _SUBSCRIPTION_STATES_PERMITTING_NEW_CAPABILITY}:
            return AccessDenied(
                f"Subscription is {subscription.status}, which does not permit creating a new storefront."
            )

        has_capacity = await self.capacity.can_create_storefront(merchant_account_id)
        if not has_capacity:
            return AccessDenied("No available storefront capacity on the current plan.")

        return AccessGranted()

    async def can_add_staff(self, merchant_account_id: UUID, tenant_id: UUID):
        merchant, subscription = await self._merchant_and_subscription(merchant_account_id)

        if merchant is None:
            return AccessDenied("Merchant account not found.")
        if merchant.status != MerchantStatus.ACTIVE:
            return AccessDenied(f"Merchant account is {merchant.status.value}, not active.")
        if subscription is None:
            return AccessDenied("Merchant has no subscription.")
        if subscription.status not in {s.value for s in _SUBSCRIPTION_STATES_PERMITTING_NEW_CAPABILITY}:
            return AccessDenied(
                f"Subscription is {subscription.status}, which does not permit adding staff."
            )

        tenant_result = await self.db.execute(select(Tenant).where(Tenant.id == tenant_id))
        tenant = tenant_result.scalar_one_or_none()
        if tenant is None:
            return AccessDenied("Storefront not found.")
        if tenant.status not in (TenantStatus.ACTIVE, TenantStatus.ONBOARDING):
            return AccessDenied(f"Storefront is {tenant.status.value}, cannot add staff.")

        has_capacity = await self.capacity.can_add_staff(merchant_account_id, tenant_id)
        if not has_capacity:
            return AccessDenied("No available staff capacity for this storefront.")

        return AccessGranted()

    async def can_publish_store(self, merchant_account_id: UUID, tenant_id: UUID):
        merchant, subscription = await self._merchant_and_subscription(merchant_account_id)
        if merchant is None or merchant.status != MerchantStatus.ACTIVE:
            return AccessDenied("Merchant account is not active.")
        if subscription is None or subscription.status not in {SubscriptionStatus.TRIALING.value, SubscriptionStatus.ACTIVE.value}:
            return AccessDenied("An active or trialing subscription is required.")
        tenant = (await self.db.execute(select(Tenant).where(Tenant.id == tenant_id))).scalar_one_or_none()
        if tenant is None or tenant.status != TenantStatus.ACTIVE:
            return AccessDenied("Storefront is not active.")
        from app.contexts.commerce import StorefrontProfile, Product
        profile = (await self.db.execute(select(StorefrontProfile).where(StorefrontProfile.tenant_id == tenant_id))).scalar_one_or_none()
        if profile is None or not profile.business_name or not profile.currency:
            return AccessDenied("Storefront profile is incomplete.")
        product = await self.db.scalar(select(Product.id).where(Product.tenant_id == tenant_id, Product.published.is_(True)).limit(1))
        if product is None:
            return AccessDenied("At least one published product is required.")
        return AccessGranted()

    async def can_process_orders(self, merchant_account_id: UUID, tenant_id: UUID):
        merchant, subscription = await self._merchant_and_subscription(merchant_account_id)
        if merchant is None or merchant.status != MerchantStatus.ACTIVE:
            return AccessDenied("Merchant account is not active.")
        if subscription is None or subscription.status not in {SubscriptionStatus.TRIALING.value, SubscriptionStatus.ACTIVE.value}:
            return AccessDenied("Subscription does not permit order processing.")
        tenant = (await self.db.execute(select(Tenant).where(Tenant.id == tenant_id))).scalar_one_or_none()
        if tenant is None or tenant.status != TenantStatus.ACTIVE:
            return AccessDenied("Storefront is not active.")
        return AccessGranted()

    async def can_use_premium_feature(self, merchant_account_id: UUID, feature_code: str):
        # The current entitlement domain exposes capacity entitlements. Until
        # a dedicated feature-entitlement type exists, unknown premium features
        # are denied rather than inferred from plan names.
        return AccessDenied(f"Premium feature '{feature_code}' is not entitled on the current MVP.")

    async def can_reactivate_store(self, merchant_account_id: UUID, tenant_id: UUID):
        merchant, subscription = await self._merchant_and_subscription(merchant_account_id)
        if merchant is None or merchant.status != MerchantStatus.ACTIVE:
            return AccessDenied("Merchant account is not active.")
        if subscription is None or subscription.status != SubscriptionStatus.ACTIVE.value:
            return AccessDenied("An active paid subscription is required for reactivation.")
        tenant = (await self.db.execute(select(Tenant).where(Tenant.id == tenant_id))).scalar_one_or_none()
        if tenant is None or tenant.status != TenantStatus.SUSPENDED:
            return AccessDenied("Storefront is not suspended.")
        return AccessGranted()
