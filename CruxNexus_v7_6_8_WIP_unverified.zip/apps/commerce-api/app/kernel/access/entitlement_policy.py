"""Tier entitlement policy: capabilities + resource limits (pure, no I/O).

Product rules this implements (stated by Kratos):
  * A tier controls which CAPABILITIES a merchant can use AND imposes LIMITS
    (products, storage, staff, orders, bandwidth, customization depth, ...).
  * Both are DATA owned by the Control Center and synchronized into
    `subscription_plans.capabilities` / `.resource_limits`. Keys are opaque
    strings here, so a new capability or limit can be introduced by the
    Control Center without a code change to this engine.
  * Downgrade / lapse: PRESERVE existing configuration, DISABLE further use,
    RESTORE automatically when the entitlement returns.

Semantics (deliberate, documented, tested):
  * Capability absent or not true  -> NOT granted (deny by default).
  * Limit absent / null            -> no limit configured (unlimited).
  * Limit = 0                      -> none allowed.
  * Limit malformed (negative, non-integer, bool) -> treated as 0 (fail closed);
    the Control Center payload validator rejects such values before they sync.
  * Usage above a limit (after a downgrade) is never deleted or hidden; it only
    blocks NEW usage until it falls back under the limit.
  * Standing comes from the subscription: active/trialing = FULL; past_due =
    RESTRICTED (keeps what exists, nothing new); everything else = BLOCKED.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Iterable, Mapping, Optional


class Standing(str, enum.Enum):
    FULL = "full"
    RESTRICTED = "restricted"
    BLOCKED = "blocked"


_FULL_STATUSES = frozenset({"active", "trialing"})
_RESTRICTED_STATUSES = frozenset({"past_due"})


def standing_for_subscription(status: Optional[str]) -> Standing:
    if status in _FULL_STATUSES:
        return Standing.FULL
    if status in _RESTRICTED_STATUSES:
        return Standing.RESTRICTED
    return Standing.BLOCKED


@dataclass(frozen=True)
class EffectivePolicy:
    capabilities: frozenset = field(default_factory=frozenset)
    limits: Mapping[str, int] = field(default_factory=dict)

    def has(self, capability: str) -> bool:
        return capability in self.capabilities

    def limit(self, key: str) -> Optional[int]:
        return self.limits.get(key)


def _parse_capabilities(raw) -> set:
    if isinstance(raw, Mapping):
        return {str(k) for k, v in raw.items() if v is True}
    if isinstance(raw, (list, tuple, set, frozenset)):
        return {str(k) for k in raw if isinstance(k, str)}
    return set()


def _parse_limits(raw) -> dict:
    out: dict = {}
    if not isinstance(raw, Mapping):
        return out
    for key, value in raw.items():
        if value is None:
            continue  # explicit null = no limit configured
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            out[str(key)] = 0  # malformed -> fail closed
        else:
            out[str(key)] = value
    return out


def effective_policy(
    *,
    plan_capabilities,
    plan_limits,
    addon_capabilities: Iterable[str] = (),
    addon_limit_bonus: Optional[Mapping[str, int]] = None,
) -> EffectivePolicy:
    """Plan entitlements plus purchased add-ons (e.g. a custom domain bought
    separately on Starter/Business). Add-on bonuses only extend limits that the
    plan actually set; they never turn an unlimited limit into a bounded one."""
    caps = _parse_capabilities(plan_capabilities) | {str(c) for c in addon_capabilities}
    limits = _parse_limits(plan_limits)
    for key, bonus in (addon_limit_bonus or {}).items():
        if key in limits and isinstance(bonus, int) and not isinstance(bonus, bool) and bonus > 0:
            limits[key] += bonus
    return EffectivePolicy(frozenset(caps), limits)


def addon_grants(entitlements, *, now) -> tuple:
    """Fold purchased / granted entitlements into (capabilities, per-key limit bonus).

    Each entitlement is a mapping (or object) with: status, starts_at, ends_at, quantity and
    grant_metadata. The CONTROL CENTER states what a grant gives in its metadata:

        {"capabilities": ["storefront.custom_domain"], "limits": {"storefront.custom_domains": 1}}

    Limit values are PER UNIT and are multiplied by quantity (5 x extra_staff @ 1 each = +5).
    Only entitlements that are ACTIVE and inside their validity window count - the synchronous
    authority must not wait for a worker to expire a lapsed grant. Malformed metadata grants
    nothing (fail closed). Rows with empty metadata (e.g. the legacy extra_staff /
    extra_storefront rows, governed by CapacityService) have no effect here.
    """
    def get(entry, name, default=None):
        return entry.get(name, default) if isinstance(entry, Mapping) else getattr(entry, name, default)

    capabilities: set = set()
    bonus: dict = {}
    for entry in entitlements or ():
        status = get(entry, "status")
        status = getattr(status, "value", status)
        if status != "active":
            continue
        starts_at, ends_at = get(entry, "starts_at"), get(entry, "ends_at")
        if starts_at is not None and starts_at > now:
            continue
        if ends_at is not None and ends_at <= now:
            continue
        quantity = get(entry, "quantity", 1)
        if isinstance(quantity, bool) or not isinstance(quantity, int) or quantity < 1:
            continue
        meta = get(entry, "grant_metadata") or {}
        if not isinstance(meta, Mapping):
            continue
        caps = meta.get("capabilities")
        if isinstance(caps, (list, tuple)):
            capabilities |= {c for c in caps if isinstance(c, str) and c}
        limits = meta.get("limits")
        if isinstance(limits, Mapping):
            for key, per_unit in limits.items():
                if isinstance(per_unit, int) and not isinstance(per_unit, bool) and per_unit > 0:
                    bonus[str(key)] = bonus.get(str(key), 0) + per_unit * quantity
    return capabilities, bonus


@dataclass(frozen=True)
class Decision:
    allowed: bool
    code: str = "OK"
    reason: str = ""
    details: Mapping = field(default_factory=dict)

    def __bool__(self) -> bool:
        return self.allowed


ALLOW = Decision(True)


def can_use_capability(policy: EffectivePolicy, standing: Standing, capability: str, *, new_use: bool = True) -> Decision:
    """May the merchant use / newly configure `capability` right now?
    `new_use=False` asks only whether already-configured use may continue."""
    if standing is Standing.BLOCKED:
        return Decision(False, "SUBSCRIPTION_BLOCKED", "The subscription does not currently permit this.")
    if not policy.has(capability):
        return Decision(False, "CAPABILITY_NOT_IN_PLAN", f"'{capability}' is not included in the current plan.")
    if new_use and standing is Standing.RESTRICTED:
        return Decision(False, "PLAN_RESTRICTED", "Payment is overdue; existing setup keeps working but cannot be changed.")
    return ALLOW


def can_consume_limit(
    policy: EffectivePolicy, standing: Standing, key: str, *, current: int, adding: int = 1
) -> Decision:
    """May `adding` more units of resource `key` be created given `current` usage?"""
    if standing is Standing.BLOCKED:
        return Decision(False, "SUBSCRIPTION_BLOCKED", "The subscription does not currently permit this.")
    if standing is Standing.RESTRICTED:
        return Decision(False, "PLAN_RESTRICTED", "Payment is overdue; new items cannot be added.")
    limit = policy.limit(key)
    if limit is None:
        return ALLOW
    if current + adding > limit:
        return Decision(
            False, "LIMIT_REACHED", f"The plan allows {limit} {key}; {current} already in use.",
            {"limit": limit, "current": current, "key": key},
        )
    return ALLOW


def check_absolute_limit(policy: EffectivePolicy, standing: Standing, key: str, *, requested_total: int) -> Decision:
    """For configuration 'depth' limits where the requested TOTAL is compared
    (e.g. number of component slots), rather than incremental usage."""
    if standing is Standing.BLOCKED:
        return Decision(False, "SUBSCRIPTION_BLOCKED", "The subscription does not currently permit this.")
    limit = policy.limit(key)
    if limit is not None and requested_total > limit:
        return Decision(False, "LIMIT_REACHED", f"The plan allows at most {limit} for '{key}'.",
                        {"limit": limit, "requested": requested_total, "key": key})
    return ALLOW


# Per-feature lifecycle state, used for UI and for deciding what the public
# storefront renders.
ACTIVE = "active"                      # entitled and in good standing
READ_ONLY = "read_only"                # entitled, payment overdue: renders, cannot be edited
PRESERVED_INACTIVE = "preserved_inactive"  # configured, no longer entitled: kept, inert, auto-restores
UNAVAILABLE = "unavailable"            # not entitled, nothing configured
SUSPENDED = "suspended"                # subscription blocked


def feature_state(policy: EffectivePolicy, standing: Standing, capability: str, *, configured: bool) -> str:
    if standing is Standing.BLOCKED:
        return SUSPENDED
    if not policy.has(capability):
        return PRESERVED_INACTIVE if configured else UNAVAILABLE
    return READ_ONLY if standing is Standing.RESTRICTED else ACTIVE


RENDERING_STATES = frozenset({ACTIVE, READ_ONLY})
