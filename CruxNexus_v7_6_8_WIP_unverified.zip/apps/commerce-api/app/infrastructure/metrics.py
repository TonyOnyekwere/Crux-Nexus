"""Prometheus metrics for API and worker execution."""
from __future__ import annotations

from time import monotonic
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST

HTTP_REQUESTS = Counter("cruxnexus_http_requests_total", "HTTP requests", ["method", "path", "status"])
HTTP_LATENCY = Histogram("cruxnexus_http_request_duration_seconds", "HTTP request latency", ["method", "path"])
WORKER_FAILURES = Counter("cruxnexus_worker_failures_total", "Worker loop failures", ["worker"])
WORKER_RUNS = Counter("cruxnexus_worker_runs_total", "Worker successful sweeps", ["worker"])
WORKER_ITEMS = Counter("cruxnexus_worker_items_processed_total", "Items processed by worker sweeps", ["worker"])
WORKER_DURATION = Histogram("cruxnexus_worker_duration_seconds", "Worker sweep duration", ["worker"])
WORKER_LAST_SUCCESS = Gauge("cruxnexus_worker_last_success_timestamp", "Unix timestamp of last successful worker sweep", ["worker"])


def worker_started() -> float:
    return monotonic()


def record_worker_success(worker: str, *, items: int = 0, started_at: float | None = None) -> None:
    WORKER_RUNS.labels(worker).inc()
    if items:
        WORKER_ITEMS.labels(worker).inc(items)
    if started_at is not None:
        WORKER_DURATION.labels(worker).observe(monotonic() - started_at)
    import time
    WORKER_LAST_SUCCESS.labels(worker).set(time.time())


def metrics_payload():
    return generate_latest(), CONTENT_TYPE_LATEST
