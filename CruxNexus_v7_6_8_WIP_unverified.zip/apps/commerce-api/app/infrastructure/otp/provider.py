"""Real OTP delivery for the merchant onboarding flow.

Email OTP is delivered through SendGrid. SMS is explicitly rejected until a
real SMS provider is configured; the application never reports a simulated
delivery as successful.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("otp")


@dataclass
class OTPDeliveryResult:
    sent: bool
    channel: str
    provider: str
    sent_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    detail: Optional[str] = None


class OTPProvider(ABC):
    @abstractmethod
    async def send_code(self, *, channel: str, destination: str, code: str) -> OTPDeliveryResult:
        """Deliver a code. Must not raise for expected failure modes
        (invalid number/address, vendor rejection) - return
        sent=False instead, same contract as NotificationProvider.send."""
        raise NotImplementedError


class SendGridEmailOTPProvider(OTPProvider):
    """Production email OTP delivery through SendGrid's HTTPS API."""

    async def send_code(self, *, channel: str, destination: str, code: str) -> OTPDeliveryResult:
        if channel != "email":
            return OTPDeliveryResult(False, channel, "sendgrid", detail="SMS OTP is not configured.")

        from app.config import get_settings
        import httpx

        settings = get_settings()
        if not settings.SENDGRID_API_KEY or not settings.SENDGRID_FROM_EMAIL:
            return OTPDeliveryResult(False, channel, "sendgrid", detail="SendGrid email delivery is not configured.")

        payload = {
            "personalizations": [{"to": [{"email": destination}]}],
            "from": {"email": settings.SENDGRID_FROM_EMAIL},
            "subject": "Your CruxNexus verification code",
            "content": [{
                "type": "text/plain",
                "value": f"Your CruxNexus verification code is {code}. It expires in 10 minutes. If you did not request this code, ignore this message.",
            }],
        }
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    "https://api.sendgrid.com/v3/mail/send",
                    headers={"Authorization": f"Bearer {settings.SENDGRID_API_KEY}", "Content-Type": "application/json"},
                    json=payload,
                )
            if 200 <= response.status_code < 300:
                return OTPDeliveryResult(True, channel, "sendgrid")
            return OTPDeliveryResult(False, channel, "sendgrid", detail=f"SendGrid rejected delivery ({response.status_code}).")
        except httpx.HTTPError as exc:
            logger.exception("SendGrid OTP delivery failed")
            return OTPDeliveryResult(False, channel, "sendgrid", detail=f"SendGrid transport error: {exc}")


def get_otp_provider() -> OTPProvider:
    """Return the configured real OTP provider. No development logger is a delivery provider."""
    from app.config import get_settings
    settings = get_settings()
    return SendGridEmailOTPProvider()
