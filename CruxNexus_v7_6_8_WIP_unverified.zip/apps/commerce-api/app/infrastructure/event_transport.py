from redis.asyncio import Redis
from app.config import get_settings

class RedisEventTransport:
    stream_name="cruxnexus:events"
    def __init__(self, redis: Redis): self.redis=redis
    async def close(self):
        await self.redis.close()
    async def publish(self, *, event_id: str, event_type: str, aggregate_type: str, aggregate_id: str, tenant_id: str | None, payload: dict) -> str:
        return await self.redis.xadd(self.stream_name, {
            "event_id": event_id, "event_type": event_type, "aggregate_type": aggregate_type,
            "aggregate_id": aggregate_id, "tenant_id": tenant_id or "", "payload": __import__("json").dumps(payload),
        }, maxlen=100000, approximate=True)

def create_event_transport() -> RedisEventTransport:
    settings=get_settings()
    return RedisEventTransport(Redis.from_url(settings.REDIS_URL, decode_responses=True))
