"""Account lockout service to prevent brute force attacks."""
import logging
from datetime import datetime, timedelta
from typing import Optional

from redis.asyncio import Redis

logger = logging.getLogger(__name__)


class AccountLockoutError(Exception):
    """Raised when an account is locked out due to too many failed attempts."""

    def __init__(self, message: str = "Account temporarily locked due to too many failed login attempts",
                 unlock_at: Optional[datetime] = None):
        super().__init__(message)
        self.unlock_at = unlock_at


class LoginAttemptTracker:
    """Track login attempts and enforce account lockout."""

    def __init__(
        self,
        redis_client: Redis,
        *,
        max_attempts: int = 5,
        lockout_duration_minutes: int = 15,
        attempt_window_minutes: int = 15,
        key_prefix: str = "",
    ):
        self.redis = redis_client
        # Configuration
        self.max_attempts = max_attempts
        self.lockout_duration_minutes = lockout_duration_minutes
        self.attempt_window_minutes = attempt_window_minutes
        # Namespaces Redis keys so a stricter policy for a different login
        # surface (e.g. a future Control Center admin login, should one
        # ever be added directly to this app rather than living entirely
        # in Control Center's own service) can't share a counter with, or
        # be reset by, an unrelated ordinary merchant login for the same
        # email address. Not currently used by any caller - kept as a
        # general capability on this class.
        self.key_prefix = key_prefix

    def _get_failed_attempts_key(self, identifier: str) -> str:
        """Get Redis key for tracking failed attempts."""
        return f"{self.key_prefix}login_failed:{identifier}"

    def _get_lockout_key(self, identifier: str) -> str:
        """Get Redis key for lockout status."""
        return f"{self.key_prefix}login_locked:{identifier}"

    async def record_failed_attempt(self, identifier: str) -> int:
        """
        Record a failed login attempt.

        Args:
            identifier: User identifier (email or user ID)

        Returns:
            Current count of failed attempts

        Raises:
            AccountLockoutError: If account should be locked out
        """
        # Check if already locked out
        is_locked = await self.is_locked_out(identifier)
        if is_locked:
            lockout_info = await self.get_lockout_info(identifier)
            raise AccountLockoutError(
                message=f"Account locked until {lockout_info['unlock_at']}",
                unlock_at=lockout_info['unlock_at']
            )

        # Increment failed attempt counter
        key = self._get_failed_attempts_key(identifier)
        pipe = self.redis.pipeline()
        pipe.incr(key)
        pipe.expire(key, int(self.attempt_window_minutes * 60))
        await pipe.execute()

        # Get current count
        count = await self.redis.get(key)
        current_count = int(count) if count else 0

        logger.info(f"Failed login attempt {current_count} for {identifier}")

        # Check if lockout threshold reached
        if current_count >= self.max_attempts:
            await self._lock_account(identifier)
            raise AccountLockoutError(
                message=f"Account locked after {current_count} failed attempts",
                unlock_at=datetime.now() + timedelta(minutes=self.lockout_duration_minutes)
            )

        return current_count

    async def record_successful_login(self, identifier: str) -> None:
        """Reset failed attempt counter on successful login."""
        key = self._get_failed_attempts_key(identifier)
        lockout_key = self._get_lockout_key(identifier)

        pipe = self.redis.pipeline()
        pipe.delete(key)
        pipe.delete(lockout_key)
        await pipe.execute()

        logger.info(f"Successful login for {identifier}, reset failed attempt counter")

    async def is_locked_out(self, identifier: str) -> bool:
        """Check if an account is currently locked out."""
        lockout_key = self._get_lockout_key(identifier)
        exists = await self.redis.exists(lockout_key)
        return bool(exists)

    async def get_lockout_info(self, identifier: str) -> Optional[dict]:
        """Get lockout information if account is locked."""
        lockout_key = self._get_lockout_key(identifier)
        data = await self.redis.hgetall(lockout_key)

        if not data:
            return None

        # Keys here are plain str, not bytes: the Redis client this class
        # is constructed with (app.state.redis_client, see app/main.py)
        # uses decode_responses=True, so hgetall already returns
        # {'locked_at': '...', ...} rather than {b'locked_at': b'...'}.
        # This previously used b'...' byte-literal lookups against a
        # string-keyed dict, which always missed and fell through to
        # datetime.fromisoformat('') — a guaranteed crash the one time
        # this function was actually reached (which, until the
        # app.state.redis_client wiring fix, was never, since
        # get_login_tracker() always returned None).
        return {
            'locked_at': datetime.fromisoformat(data.get('locked_at', '')),
            'unlock_at': datetime.fromisoformat(data.get('unlock_at', '')),
            'attempts': int(data.get('attempts', 0)),
        }

    async def _lock_account(self, identifier: str) -> None:
        """Lock an account."""
        lockout_key = self._get_lockout_key(identifier)
        now = datetime.now()
        unlock_at = now + timedelta(minutes=self.lockout_duration_minutes)

        await self.redis.hset(lockout_key, mapping={
            'locked_at': now.isoformat(),
            'unlock_at': unlock_at.isoformat(),
            'attempts': self.max_attempts,
        })
        await self.redis.expire(lockout_key, int(self.lockout_duration_minutes * 60))

        logger.warning(f"Account {identifier} locked until {unlock_at}")

    async def get_failed_attempts(self, identifier: str) -> int:
        """Get current count of failed attempts."""
        key = self._get_failed_attempts_key(identifier)
        count = await self.redis.get(key)
        return int(count) if count else 0

    async def manual_unlock(self, identifier: str) -> None:
        """Manually unlock an account (for admin use)."""
        key = self._get_failed_attempts_key(identifier)
        lockout_key = self._get_lockout_key(identifier)

        pipe = self.redis.pipeline()
        pipe.delete(key)
        pipe.delete(lockout_key)
        await pipe.execute()

        logger.info(f"Account {identifier} manually unlocked")
