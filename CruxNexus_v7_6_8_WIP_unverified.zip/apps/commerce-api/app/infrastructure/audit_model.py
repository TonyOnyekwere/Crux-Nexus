import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, DateTime, String, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = Column(String(100), nullable=False)
    occurred_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    user_id = Column(UUID(as_uuid=True), nullable=True)
    tenant_id = Column(UUID(as_uuid=True), nullable=True)
    actor_type = Column(String(40), nullable=False, default="system")
    success = Column(Boolean, nullable=False, default=True)
    reason = Column(Text, nullable=True)
    metadata = Column(JSONB, nullable=False, default=dict)
