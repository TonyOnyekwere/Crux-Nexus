"""Real outbound notification providers for CruxNexus."""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import httpx

from app.config import get_settings

logger = logging.getLogger("notifications")


@dataclass
class NotificationResult:
    sent: bool
    channel: str
    provider: str
    sent_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    detail: str | None = None


class NotificationProvider(ABC):
    @abstractmethod
    async def send(self, *, channel: str, recipient: str, template: str, context: dict[str, Any]) -> NotificationResult:
        raise NotImplementedError


class SendGridNotificationProvider(NotificationProvider):
    """Send transactional email through SendGrid."""

    def __init__(self, api_key: str, from_email: str):
        self._api_key = api_key
        self._from_email = from_email

    async def send(self, *, channel: str, recipient: str, template: str, context: dict[str, Any]) -> NotificationResult:
        if channel != "email":
            return NotificationResult(False, channel, "sendgrid", detail=f"SendGrid does not deliver {channel} notifications")

        subject = str(context.get("subject") or "CruxNexus notification")
        invitation_token = context.get("invitation_token")
        if template == "staff_invitation":
            body = (
                "You have been invited to join a CruxNexus storefront.\n\n"
                f"Role: {context.get('role', 'staff')}\n"
                f"Invitation expires: {context.get('expires_at', '')}\n\n"
                f"Invitation token: {invitation_token}\n"
                "Use the CruxNexus invitation flow to accept this invitation."
            )
        else:
            body = str(context.get("body") or "CruxNexus notification")

        payload = {
            "personalizations": [{"to": [{"email": recipient}], "subject": subject}],
            "from": {"email": self._from_email},
            "content": [{"type": "text/plain", "value": body}],
        }
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    "https://api.sendgrid.com/v3/mail/send",
                    headers={"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"},
                    json=payload,
                )
        except httpx.HTTPError as exc:
            logger.error("SendGrid transport failure: %s", exc)
            return NotificationResult(False, channel, "sendgrid", detail="Notification provider unavailable")

        if response.status_code >= 400:
            logger.error("SendGrid rejected notification: HTTP %s", response.status_code)
            return NotificationResult(False, channel, "sendgrid", detail="Notification provider rejected the message")
        return NotificationResult(True, channel, "sendgrid")




def get_notification_provider() -> NotificationProvider:
    settings = get_settings()
    if not settings.SENDGRID_API_KEY or not settings.SENDGRID_FROM_EMAIL:
        raise RuntimeError("SendGrid notification provider is not configured")
    return SendGridNotificationProvider(settings.SENDGRID_API_KEY, settings.SENDGRID_FROM_EMAIL)
