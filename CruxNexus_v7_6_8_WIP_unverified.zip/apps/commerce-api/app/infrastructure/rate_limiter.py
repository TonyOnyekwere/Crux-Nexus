"""Rate limiting: SlowAPI over Redis, with identity-aware keys.

What was wrong before: the limiter object was created and an exception handler registered, but no
middleware and no decorator ever applied a limit (so nothing was limited); the key function was `async`
(SlowAPI calls it synchronously, so every key was a coroutine object); it keyed on a client-supplied
`X-API-Key` header (an attacker picks a new key per request); and the 429 handler returned a dict (an
invalid response). All four are fixed here.

Keys never trust client-chosen values for the OUTER ceiling:
  * client IP honours exactly `TRUSTED_PROXY_HOPS` entries of X-Forwarded-For counted from the RIGHT (the
    entries our own proxy appended); anything further left is attacker-controlled and ignored.
  * per-tenant keys combine IP + the tenant claim read from the (unverified) bearer token. Because that
    claim is client-controlled, every per-identity limit is stacked UNDER an IP-wide limit, so rotating
    claims cannot escape the IP ceiling.
  * webhooks are keyed by their per-merchant webhook token, not by IP, so one noisy provider/merchant
    cannot throttle unrelated tenants (providers share a small set of source IPs).
"""
from __future__ import annotations

import logging
import re
from typing import Optional

from fastapi import Request
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded

from app.config import get_settings

logger = logging.getLogger(__name__)

_UNIT_SECONDS = {"second": 1, "minute": 60, "hour": 3600, "day": 86400, "month": 2_592_000, "year": 31_536_000}
_LIMIT_RE = re.compile(r"(\d+)\s*(?:per|/)\s*(\d*)\s*(second|minute|hour|day|month|year)s?", re.IGNORECASE)


def client_ip(forwarded_for: Optional[str], peer: Optional[str], trusted_hops: int) -> str:
    """The client IP as seen by our own trusted proxy chain. With N trusted hops the real client is the
    Nth entry from the right of X-Forwarded-For; with 0 the header is ignored entirely (direct exposure)."""
    if trusted_hops > 0 and forwarded_for:
        parts = [p.strip() for p in forwarded_for.split(",") if p.strip()]
        if len(parts) >= trusted_hops:
            return parts[-trusted_hops]
    return peer or "unknown"


def _ip(request: Request) -> str:
    peer = request.client.host if request.client else None
    return client_ip(request.headers.get("x-forwarded-for"), peer, get_settings().TRUSTED_PROXY_HOPS)


def key_ip(request: Request) -> str:
    return f"ip:{_ip(request)}"


def _unverified_tenant(request: Request) -> str:
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        return "anon"
    try:
        from jose import jwt as jose_jwt
        claims = jose_jwt.get_unverified_claims(auth[7:].strip())
        return str(claims.get("tenant_id") or claims.get("sub") or "anon")[:64]
    except Exception:
        return "anon"


def key_ip_tenant(request: Request) -> str:
    """Per-merchant bucket. Stack under an IP-wide limit (see module docstring)."""
    return f"ip:{_ip(request)}|t:{_unverified_tenant(request)}"


def key_ip_slug(request: Request) -> str:
    return f"ip:{_ip(request)}|s:{str(request.path_params.get('slug', ''))[:64]}"


def key_webhook_token(request: Request) -> str:
    return f"wh:{str(request.path_params.get('webhook_token', ''))[:64]}"


def key_provider_path(request: Request) -> str:
    return f"provider:{str(request.path_params.get('provider', ''))[:32]}"


def key_static(name: str):
    """One shared bucket (e.g. a platform webhook whose senders are a fixed provider, not clients)."""
    def _key(request: Request) -> str:
        return f"static:{name}"
    return _key


def retry_after_seconds(limit_text: str) -> int:
    """Upper bound for Retry-After from a limit description such as '5 per 1 hour' or '10 per 1 minute'."""
    m = _LIMIT_RE.search(limit_text or "")
    if not m:
        return 60
    multiple = int(m.group(2) or 1)
    return multiple * _UNIT_SECONDS[m.group(3).lower()]


def build_limiter(settings) -> Limiter:
    return Limiter(
        key_func=key_ip,
        default_limits=[settings.RATE_LIMIT_DEFAULT],
        storage_uri=settings.REDIS_URL or "memory://",
        enabled=settings.RATE_LIMIT_ENABLED,
        in_memory_fallback_enabled=True,   # Redis outage degrades to per-instance limits instead of no limits
        headers_enabled=False,
    )


limiter = build_limiter(get_settings())


async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    retry_after = retry_after_seconds(str(exc.detail))
    logger.warning("Rate limit exceeded: %s on %s %s (%s)", request.headers.get("x-request-id", "-"),
                   request.method, request.url.path, exc.detail)
    return JSONResponse(
        status_code=429,
        content={"detail": {"error": {"code": "RATE_LIMITED", "message": "Too many requests. Please try again later.",
                                      "details": {"retry_after_seconds": retry_after}}}},
        headers={"Retry-After": str(retry_after)},
    )
