"""Flutterwave adapter.

Built against Flutterwave's v3 "Standard" flow (checked 2026-09-17, not
from memory):

    POST https://api.flutterwave.com/v3/payments
        Authorization: Bearer <secret_key>
        body: {tx_ref, amount, currency, redirect_url,
               customer: {email, name, phonenumber}}
        -> {status: "success", data: {link: <hosted checkout URL>}}

    GET https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=<ref>
        Authorization: Bearer <secret_key>
        -> {data: {status: "successful"|..., amount, currency, tx_ref, id}}
        (verified 2026-09-17: this endpoint exists specifically so callers
        who generate their own tx_ref never need the provider-internal
        numeric id to verify - see
        https://developer.flutterwave.com/reference/verify-transaction-with-tx_ref.
        An earlier version of this adapter used the id-based
        /v3/transactions/{id}/verify endpoint instead, which required an id
        that isn't known until after the fact - a confirmed bug, fixed.)

IMPORTANT, explicitly flagged rather than silently picked: Flutterwave
currently has two live API generations. v3 (above) is the long-standing,
stable, officially-still-recommended-as-the-default flow per Flutterwave's
own current integration guide. v4 is a newer generation (OAuth2 client
credentials instead of a static secret key, a customer/payment-method/
charge flow instead of one-shot checkout, and a different webhook
signature scheme) that multiple sources describe as still in public beta
as of this check. Building against v4 while it's beta, for a commercial
subscription-payment path, seemed like the wrong default risk to take
silently - this adapter targets v3. If Flutterwave's v4 has since become
the recommended default by the time this is deployed, that's a real
decision to make explicitly, not something to discover after the fact.

SECOND AMBIGUITY, also flagged rather than resolved: sources disagreed
on exactly how the `verif-hash` webhook header is validated. Flutterwave's
traditional v3 documentation describes it as a plain shared-secret string
you set in the dashboard (Settings > Webhooks) and compare for exact
equality against the header value. At least one current third-party
source instead described computing an HMAC-SHA256 of the body. This
adapter implements the plain constant-time string-equality check (the
traditional and more commonly documented v3 behavior) - confirm this
against your actual Flutterwave dashboard's webhook documentation before
relying on it in production, and correct this method if it's wrong.

NOT YET TESTED against a real Flutterwave sandbox - no credentials were
available in this environment. Same standing as the Paystack adapter:
implemented against current docs, unverified end-to-end.
"""

from __future__ import annotations

import hmac
from decimal import Decimal
from typing import Any, Optional

import httpx

from app.contexts.billing.domain.financial_transaction import (
    PaymentAuthorizationType,
    PaymentProvider,
)
from app.infrastructure.payments.adapter import (
    ChargeInitializationResult,
    PaymentProviderAdapter,
    ProviderOutcomeUnknownError,
    ProviderRejectedError,
    ProviderTransactionNotFoundError,
    TransactionVerificationResult,
    WebhookVerificationResult,
    classify_transport_error,
    normalize_flutterwave_status,
    parse_json_or_unknown,
)

FLUTTERWAVE_BASE_URL = "https://api.flutterwave.com/v3"


class FlutterwaveAdapter(PaymentProviderAdapter):
    # Flutterwave may hold no transaction record for a tx_ref until a customer actually attempts payment,
    # so "not found" is NOT proof that an issued checkout link cannot still be paid. Until the provider's
    # behaviour is confirmed in a sandbox it is never treated as conclusive (None) and keeps blocking a
    # new charge rather than risk a duplicate.
    not_found_conclusive_after = None
    provider = PaymentProvider.FLUTTERWAVE

    def __init__(self, secret_key: str, webhook_secret_hash: Optional[str] = None):
        if not secret_key:
            raise ValueError("FlutterwaveAdapter requires a non-empty secret_key")
        self._secret_key = secret_key
        self._webhook_secret_hash = webhook_secret_hash

    async def initialize_charge(
        self,
        *,
        reference: str,
        amount: Decimal,
        currency: str,
        merchant_email: str,
        redirect_url: str,
        payment_method: Optional[str] = None,
    ) -> ChargeInitializationResult:
        # Unlike Paystack, Flutterwave v3 takes amount in the currency's
        # major unit (Naira, not kobo) - do not multiply by 100 here.
        #
        # Fixed bug (external review): this previously passed
        # `payment_method` into the `redirect_url` field, so a call with
        # payment_method="card" would send "redirect_url": "card" to
        # Flutterwave - two genuinely different values were being
        # conflated because the shared interface never defined a proper
        # redirect_url parameter at all. Now takes both correctly.
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{FLUTTERWAVE_BASE_URL}/payments",
                    headers={
                        "Authorization": f"Bearer {self._secret_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "tx_ref": reference,
                        "amount": str(amount),
                        "currency": currency,
                        "redirect_url": redirect_url,
                        "customer": {"email": merchant_email},
                    },
                )
        except httpx.TransportError as exc:
            raise classify_transport_error(exc) from exc

        if response.status_code >= 500 or response.status_code in (408, 429):
            raise ProviderOutcomeUnknownError(
                f"Flutterwave initialize returned HTTP {response.status_code}; charge may exist"
            )
        body = parse_json_or_unknown(response)
        if response.status_code >= 400 or body.get("status") != "success":
            raise ProviderRejectedError(
                f"Flutterwave payment initialization refused ({response.status_code}): "
                f"{body.get('message', 'unknown error')}"
            )

        return ChargeInitializationResult(
            provider_reference=reference,  # our own tx_ref - see verify_transaction
            redirect_url=body["data"]["link"],
            authorization_type=PaymentAuthorizationType.ONE_TIME_PAYMENT,
        )

    async def verify_transaction(self, provider_reference: str) -> TransactionVerificationResult:
        # Fixed bug (external review): this previously called
        # /v3/transactions/{id}/verify, which requires Flutterwave's own
        # internal numeric transaction id - a value that doesn't exist
        # yet at the point CruxNexus needs to verify (it only appears in
        # the redirect query params or the webhook payload afterward).
        # That was inconsistent with initialize_charge returning tx_ref
        # (CruxNexus's own reference) as provider_reference. Flutterwave's
        # own current docs confirm a verify-by-reference endpoint exists
        # for exactly this case:
        # https://developer.flutterwave.com/reference/verify-transaction-with-tx_ref
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{FLUTTERWAVE_BASE_URL}/transactions/verify_by_reference",
                headers={"Authorization": f"Bearer {self._secret_key}"},
                params={"tx_ref": provider_reference},
            )

        if response.status_code == 404:
            raise ProviderTransactionNotFoundError(
                f"Flutterwave has no transaction for tx_ref {provider_reference}"
            )
        body = parse_json_or_unknown(response)
        if response.status_code in (400, 408, 429) or response.status_code >= 500:
            raise ProviderOutcomeUnknownError(
                f"Flutterwave verify failed ({response.status_code}): "
                f"{body.get('message', 'unknown error')}"
            )

        data = body.get("data", {})
        raw_status = str(data.get("status", "")).lower()
        normalized = normalize_flutterwave_status(raw_status)
        return TransactionVerificationResult(
            successful=normalized == "SUCCESS",
            status=normalized,
            provider_reference=str(data.get("tx_ref", provider_reference)),
            amount=Decimal(str(data.get("amount", 0))),
            currency=data.get("currency", "NGN"),
            raw=data,
        )

    async def verify_credentials(self) -> None:
        """Read-only call that only succeeds with a valid secret key (sandbox semantics unconfirmed)."""
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                response = await client.get(
                    f"{FLUTTERWAVE_BASE_URL}/banks/NG",
                    headers={"Authorization": f"Bearer {self._secret_key}"},
                )
        except httpx.TransportError as exc:
            raise classify_transport_error(exc) from exc
        if response.status_code in (401, 403):
            raise ProviderRejectedError("Flutterwave rejected the supplied credentials.")
        if response.status_code >= 500 or response.status_code in (408, 425, 429):
            raise ProviderOutcomeUnknownError(f"Flutterwave credential check inconclusive (HTTP {response.status_code}).")
        if response.status_code >= 400:
            raise ProviderRejectedError(f"Flutterwave credential check failed (HTTP {response.status_code}).")

    def verify_webhook_signature(
        self, *, headers: dict, raw_body: bytes
    ) -> WebhookVerificationResult:
        received_hash = headers.get("verif-hash", "")
        # See module docstring: plain constant-time equality against the
        # dashboard-configured secret hash, per traditional v3 docs -
        # confirm against your actual dashboard before trusting this in
        # production.
        expected = self._webhook_secret_hash or ""
        signature_valid = bool(expected) and hmac.compare_digest(received_hash, expected)

        event_id = ""
        event_type = ""
        provider_reference = None
        payload: dict[str, Any] = {}

        if signature_valid:
            import json

            try:
                payload = json.loads(raw_body)
            except (json.JSONDecodeError, UnicodeDecodeError):
                payload = {}

            event_type = payload.get("event", payload.get("event.type", ""))
            data = payload.get("data", {}) or {}
            # CruxNexus owns tx_ref and persists it as provider_reference.
            # Flutterwave also exposes its internal numeric transaction id,
            # but that id is not the reconciliation key used by this adapter.
            # Normalize the webhook to tx_ref so the inbox can resolve the
            # FinancialTransaction created during initialization.
            provider_reference = (
                str(data.get("tx_ref", "")).strip()
                or str(data.get("reference", "")).strip()
                or None
            )
            stable_event_reference = provider_reference or str(data.get("id", "")).strip()
            event_id = f"{event_type}:{stable_event_reference}" if stable_event_reference else ""

        return WebhookVerificationResult(
            signature_valid=signature_valid,
            event_id=event_id,
            event_type=event_type,
            provider_reference=provider_reference,
            normalized_payload=payload,
        )


class FlutterwaveAPIError(RuntimeError):
    pass
