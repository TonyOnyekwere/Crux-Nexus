"""Paystack adapter.

Built against Paystack's current, documented transaction API (checked
2026-09-17, not from memory):

    POST https://api.paystack.co/transaction/initialize
        Authorization: Bearer <secret_key>
        body: {email, amount (in kobo - smallest currency unit),
               currency, reference, callback_url}
        -> {status, data: {authorization_url, access_code, reference}}

    GET https://api.paystack.co/transaction/verify/{reference}
        Authorization: Bearer <secret_key>
        -> {status, data: {status: "success"|..., amount, currency,
                            reference, gateway_response}}

    Webhook: header `x-paystack-signature` = HMAC-SHA512 of the exact
    raw request body, keyed with the secret key. Compare in constant
    time. Event of interest: "charge.success" (data.reference identifies
    the transaction). Best practice confirmed from multiple current
    sources: verify signature first, then still call the verify endpoint
    before granting value - a webhook is a prompt to check, not proof by
    itself. This adapter's verify_webhook_signature does NOT call the
    verify endpoint itself (that's a separate, explicit verify_transaction
    call the webhook handler is responsible for making) - keeping
    "is this really from Paystack" and "is this transaction actually
    successful" as two separate steps, matching the locked architecture's
    webhook pipeline (signature validation -> persist -> verify -> act).

NOT YET TESTED against a real Paystack sandbox - no credentials were
available in this environment. The request/response shapes above are
correct per current documentation; what hasn't been exercised is the
actual network round-trip, error-response shapes for edge cases (invalid
key, unsupported currency, etc.), and rate-limit behavior. Treat this as
"implemented against current docs, unverified end-to-end" until run
against PAYSTACK_SECRET_KEY=sk_test_... for real.
"""

from __future__ import annotations

from datetime import timedelta
import hashlib
import hmac
from decimal import Decimal
from typing import Any, Optional

import httpx

from app.contexts.billing.domain.financial_transaction import (
    PaymentAuthorizationType,
    PaymentProvider,
)
from app.infrastructure.payments.adapter import (
    ChargeInitializationResult,
    PaymentProviderAdapter,
    ProviderOutcomeUnknownError,
    ProviderRejectedError,
    ProviderTransactionNotFoundError,
    TransactionVerificationResult,
    WebhookVerificationResult,
    classify_transport_error,
    normalize_paystack_status,
    parse_json_or_unknown,
)

PAYSTACK_BASE_URL = "https://api.paystack.co"


class PaystackAdapter(PaymentProviderAdapter):
    # Paystack creates the transaction record at initialize, so a 404 on verify, once the initialization
    # can no longer be in flight, means the charge never existed.
    not_found_conclusive_after = timedelta(seconds=120)
    provider = PaymentProvider.PAYSTACK

    def __init__(self, secret_key: str):
        if not secret_key:
            raise ValueError("PaystackAdapter requires a non-empty secret_key")
        self._secret_key = secret_key

    async def initialize_charge(
        self,
        *,
        reference: str,
        amount: Decimal,
        currency: str,
        merchant_email: str,
        redirect_url: str,
        payment_method: Optional[str] = None,
    ) -> ChargeInitializationResult:
        # Paystack amounts are in the smallest currency unit (kobo for
        # NGN) - multiply by 100 and round to an integer.
        amount_kobo = int((amount * 100).to_integral_value())

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{PAYSTACK_BASE_URL}/transaction/initialize",
                    headers={
                        "Authorization": f"Bearer {self._secret_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "email": merchant_email,
                        "amount": amount_kobo,
                        "currency": currency,
                        "reference": reference,
                        "callback_url": redirect_url,
                    },
                )
        except httpx.TransportError as exc:
            # Duplicate-charge safety: distinguish "request never sent"
            # (rejected) from "sent, outcome unknown" (timeout etc).
            raise classify_transport_error(exc) from exc

        if response.status_code >= 500 or response.status_code in (408, 429):
            raise ProviderOutcomeUnknownError(
                f"Paystack initialize returned HTTP {response.status_code}; charge may exist"
            )
        body = parse_json_or_unknown(response)
        if response.status_code >= 400 or not body.get("status"):
            raise ProviderRejectedError(
                f"Paystack initialize refused ({response.status_code}): "
                f"{body.get('message', 'unknown error')}"
            )

        data = body["data"]
        return ChargeInitializationResult(
            provider_reference=data["reference"],
            redirect_url=data.get("authorization_url"),
            # Card is Paystack's standard recurring-capable method; bank
            # transfer/other channels selected within the hosted page may
            # not be - see the locked architecture's own note that not
            # every method auto-renews. Without inspecting which channel
            # the merchant actually used inside Paystack's hosted flow
            # (only available after the fact, via verify_transaction),
            # the safest default here is the non-recurring assumption.
            authorization_type=PaymentAuthorizationType.ONE_TIME_PAYMENT,
        )

    async def verify_transaction(self, provider_reference: str) -> TransactionVerificationResult:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{PAYSTACK_BASE_URL}/transaction/verify/{provider_reference}",
                headers={"Authorization": f"Bearer {self._secret_key}"},
            )

        if response.status_code == 404:
            raise ProviderTransactionNotFoundError(
                f"Paystack has no transaction for reference {provider_reference}"
            )
        if response.status_code >= 500 or response.status_code in (408, 429):
            raise ProviderOutcomeUnknownError(
                f"Paystack verify returned HTTP {response.status_code}"
            )
        body = parse_json_or_unknown(response)
        if response.status_code >= 400 or not body.get("status"):
            raise PaystackAPIError(
                f"Paystack verify failed ({response.status_code}): "
                f"{body.get('message', 'unknown error')}"
            )

        data = body["data"]
        raw_status = str(data.get("status", "")).lower()
        normalized = normalize_paystack_status(raw_status)
        return TransactionVerificationResult(
            successful=normalized == "SUCCESS",
            status=normalized,
            provider_reference=data.get("reference", provider_reference),
            amount=Decimal(str(data.get("amount", 0))) / Decimal(100),
            currency=data.get("currency", "NGN"),
            raw=data,
        )

    async def verify_credentials(self) -> None:
        """Read-only call that only succeeds with a valid secret key."""
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                response = await client.get(
                    f"{PAYSTACK_BASE_URL}/bank",
                    params={"perPage": 1},
                    headers={"Authorization": f"Bearer {self._secret_key}"},
                )
        except httpx.TransportError as exc:
            raise classify_transport_error(exc) from exc
        if response.status_code in (401, 403):
            raise ProviderRejectedError("Paystack rejected the supplied credentials.")
        if response.status_code >= 500 or response.status_code in (408, 425, 429):
            raise ProviderOutcomeUnknownError(f"Paystack credential check inconclusive (HTTP {response.status_code}).")
        if response.status_code >= 400:
            raise ProviderRejectedError(f"Paystack credential check failed (HTTP {response.status_code}).")

    def verify_webhook_signature(
        self, *, headers: dict, raw_body: bytes
    ) -> WebhookVerificationResult:
        signature = headers.get("x-paystack-signature", "")
        expected = hmac.new(
            self._secret_key.encode(), raw_body, hashlib.sha512
        ).hexdigest()
        signature_valid = hmac.compare_digest(signature, expected)

        event_id = ""
        event_type = ""
        provider_reference = None
        payload: dict[str, Any] = {}

        if signature_valid:
            import json

            try:
                payload = json.loads(raw_body)
            except (json.JSONDecodeError, UnicodeDecodeError):
                payload = {}

            event_type = payload.get("event", "")
            data = payload.get("data", {}) or {}
            provider_reference = data.get("reference")
            # Paystack's webhook payload doesn't guarantee a single
            # top-level unique event ID field the way some providers do.
            # data.id (the numeric transaction ID) is the most stable
            # candidate for the reference this event concerns; combined
            # with event_type it's what backs the dedup constraint.
            event_id = f"{event_type}:{data.get('id', provider_reference or '')}"

        return WebhookVerificationResult(
            signature_valid=signature_valid,
            event_id=event_id,
            event_type=event_type,
            provider_reference=provider_reference,
            normalized_payload=payload,
        )


class PaystackAPIError(RuntimeError):
    pass
