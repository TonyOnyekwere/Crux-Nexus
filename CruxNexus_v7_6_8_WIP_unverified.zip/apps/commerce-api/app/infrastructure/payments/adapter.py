"""Payment provider abstraction for CruxNexus subscription checkout.

Locked Onboarding & Activation Architecture, section 9:

    SubscriptionService
            |
            v
    PaymentProviderRegistry
            |
            +-- PaystackAdapter
            |
            +-- FlutterwaveAdapter

Domain code (the subscription/onboarding services) is only ever allowed
to depend on PaymentProviderAdapter and PaymentProviderRegistry — never
import a Paystack or Flutterwave SDK directly. That boundary is what lets
a provider be added, removed, or temporarily disabled (e.g. an outage)
without touching subscription logic.

Concrete Paystack and Flutterwave adapters implement this boundary in
`app/infrastructure/payments/`. Their sandbox behavior must be verified with
provider credentials before production release; the application does not
contain a synthetic payment provider.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Optional

from app.contexts.billing.domain.financial_transaction import (
    PaymentAuthorizationType,
    PaymentProvider,
)


_IN_FLIGHT_RAW = {"pending", "processing", "ongoing", "queued", "new", "initiated", "in_progress", "in-progress"}


def normalize_paystack_status(raw) -> str:
    """Paystack transaction status -> SUCCESS | PENDING | FAILED | ABANDONED | UNKNOWN.
    In-flight values (pending/processing/ongoing/queued) MUST NOT map to FAILED: a customer can still
    complete them, and treating them as dead would permit a duplicate charge."""
    raw = str(raw or "").strip().lower()
    if raw == "success":
        return "SUCCESS"
    if raw in _IN_FLIGHT_RAW:
        return "PENDING"
    if raw == "abandoned":
        return "ABANDONED"
    if raw in {"failed", "reversed"}:
        return "FAILED"
    return "UNKNOWN"


def normalize_flutterwave_status(raw) -> str:
    raw = str(raw or "").strip().lower()
    if raw in {"successful", "success", "completed"}:
        return "SUCCESS"
    if raw in _IN_FLIGHT_RAW:
        return "PENDING"
    if raw in {"cancelled", "canceled", "abandoned"}:
        return "ABANDONED"
    if raw in {"failed", "error"}:
        return "FAILED"
    return "UNKNOWN"


def is_in_flight(status: str) -> bool:
    """A provider answer that decides nothing yet: keep reconciling, never fail or re-charge on it."""
    return status in ("PENDING", "UNKNOWN")


class ProviderRejectedError(RuntimeError):
    """The provider received the request and definitively refused it
    (HTTP 4xx with a parseable error body), or the request provably never
    left this process (connection could not be established). No charge can
    exist at the provider, so the local transaction may safely be marked
    FAILED and the merchant may retry with a fresh reference."""


class ProviderOutcomeUnknownError(RuntimeError):
    """The request may have reached the provider but we do not know what
    happened: read/write timeout, connection dropped mid-request, HTTP 5xx,
    or an unparseable response. A charge MAY exist. The local transaction
    must stay PENDING and be resolved by verify_transaction / webhook
    reconciliation - never marked FAILED, and never retried with a new
    reference until the original is resolved (duplicate-charge risk)."""


class ProviderTransactionNotFoundError(RuntimeError):
    """verify_transaction: the provider has no record of this reference.
    For a reference we sent in an initialize call whose outcome was unknown,
    this is positive evidence that no charge was created."""


@dataclass
class ChargeInitializationResult:
    """What an adapter returns after starting a payment attempt."""

    provider_reference: str
    # URL the merchant's browser is sent to complete payment (card entry,
    # bank selection, etc.) - None for providers/methods that don't need
    # a redirect (e.g. a pre-shared bank transfer account).
    redirect_url: Optional[str]
    authorization_type: PaymentAuthorizationType


@dataclass
class TransactionVerificationResult:
    """What an adapter returns after independently re-querying a
    transaction's true status from the provider — never trust a webhook
    or frontend callback alone; this is the re-query step both Paystack
    and Flutterwave's own documentation recommend before granting value."""

    successful: bool
    status: str  # SUCCESS | PENDING | FAILED | NOT_FOUND | UNKNOWN
    provider_reference: str
    amount: Any  # Decimal - typed loosely here to avoid importing decimal at this layer
    currency: str
    raw: dict


@dataclass
class WebhookVerificationResult:
    """What an adapter returns after validating a webhook's signature and
    normalizing its payload. `event_id` is what
    UNIQUE(provider_code, provider_event_id) on provider_webhook_events
    deduplicates against — it must be a value the provider guarantees is
    stable and unique per event, never derived from mutable payload
    fields."""

    signature_valid: bool
    event_id: str
    event_type: str
    provider_reference: Optional[str]
    normalized_payload: dict


def classify_transport_error(exc: Exception) -> Exception:
    """Map an httpx transport failure to the right error class.
    Connect-phase failures mean the request never reached the provider
    (safe to treat as rejected); everything else after the request may have
    been sent is unknown."""
    import httpx

    if isinstance(exc, (httpx.ConnectError, httpx.ConnectTimeout)):
        return ProviderRejectedError(f"Provider unreachable (request not sent): {exc}")
    return ProviderOutcomeUnknownError(f"Provider outcome unknown: {exc!r}")


def parse_json_or_unknown(response) -> dict:
    try:
        body = response.json()
    except ValueError as exc:
        raise ProviderOutcomeUnknownError(
            f"Unparseable provider response (HTTP {response.status_code})"
        ) from exc
    return body if isinstance(body, dict) else {}


class PaymentProviderAdapter(ABC):
    # How long after initialization a provider "transaction not found" counts as STRONG evidence that no
    # charge exists. None = never conclusive (the provider may create no record until a customer attempt).
    not_found_conclusive_after = None

    """Every concrete provider (Paystack, Flutterwave, and any future
    provider) implements this. Nothing outside app/infrastructure/payments
    is allowed to know which concrete class is in use."""

    provider: PaymentProvider

    @abstractmethod
    async def initialize_charge(
        self,
        *,
        reference: str,
        amount: Any,
        currency: str,
        merchant_email: str,
        redirect_url: str,
        payment_method: Optional[str] = None,
    ) -> ChargeInitializationResult:
        """Start a payment attempt. Must not raise for the provider being
        temporarily unavailable — callers need to distinguish "provider
        rejected this charge" from "provider is down right now" to decide
        whether to offer a fallback provider (locked architecture
        section 47) or just ask the merchant to retry.

        `redirect_url` (where the provider sends the browser back to after
        the merchant completes/abandons the hosted checkout) and
        `payment_method` (an optional hint like "card"/"bank_transfer" for
        providers that support pre-selecting a channel) are deliberately
        separate parameters — an earlier version of this interface didn't
        define redirect_url at all, and FlutterwaveAdapter was passing
        payment_method into Flutterwave's redirect_url field, which is a
        confirmed bug (see FlutterwaveAdapter's fix note)."""
        raise NotImplementedError

    @staticmethod
    def peek_reference(raw_body: bytes):
        """Best-effort, UNAUTHENTICATED read of the payment reference in a webhook body. Used ONLY to pick
        which stored credential to authenticate the webhook with; nothing is trusted until the signature
        verifies. Returns None if the body is not a recognizable event."""
        import json
        try:
            data = json.loads(raw_body or b"{}").get("data") or {}
        except (ValueError, AttributeError):
            return None
        if not isinstance(data, dict):
            return None
        ref = data.get("reference") or data.get("tx_ref")
        return str(ref) if ref else None

    async def verify_credentials(self) -> None:
        """Prove the configured credentials are accepted by the provider, without moving money.
        Returns None on success; raises ProviderRejectedError if the provider refuses them and
        ProviderOutcomeUnknownError if the answer cannot be trusted (timeout, 5xx, throttling)."""
        raise NotImplementedError

    @abstractmethod
    async def verify_transaction(self, provider_reference: str) -> TransactionVerificationResult:
        """Independently re-query the provider for a transaction's true
        status. Called after a webhook arrives and before any commercial
        state changes — the webhook signals "go check", it is never
        itself sufficient evidence (locked architecture sections 11, 45).

        `provider_reference` is always the same value initialize_charge
        returned as ChargeInitializationResult.provider_reference — i.e.
        CruxNexus's own transaction reference, never a provider-internal
        ID that only becomes known after the fact. Each adapter is
        responsible for translating that into whatever the provider's own
        API actually needs internally (Paystack verifies by its own
        `reference` directly; Flutterwave uses its verify_by_reference
        endpoint rather than the id-based one, for exactly this reason)."""
        raise NotImplementedError

    @abstractmethod
    def verify_webhook_signature(
        self, *, headers: dict, raw_body: bytes
    ) -> WebhookVerificationResult:
        """Validate the inbound webhook's signature and extract its event
        identity, without yet acting on it. A signature failure must
        result in the request being rejected before a row is ever written
        to provider_webhook_events — an unverified request is not
        "an event we haven't processed yet", it's not our event at all."""
        raise NotImplementedError


class PaymentProviderRegistry:
    """Looks up the adapter for a given provider. Subscription/onboarding
    services depend on this, never on a concrete adapter class."""

    def __init__(self) -> None:
        self._adapters: dict[PaymentProvider, PaymentProviderAdapter] = {}

    def register(self, adapter: PaymentProviderAdapter) -> None:
        self._adapters[adapter.provider] = adapter

    def get(self, provider: PaymentProvider) -> PaymentProviderAdapter:
        try:
            return self._adapters[provider]
        except KeyError:
            raise ValueError(
                f"No payment provider adapter registered for {provider.value}. "
                "Configure a real provider credential."
            )

    def available_providers(self) -> list[PaymentProvider]:
        return list(self._adapters.keys())


_registry: Optional[PaymentProviderRegistry] = None


def get_payment_provider_registry() -> PaymentProviderRegistry:
    """Process-wide registry singleton populated with configured real providers at startup."""
    global _registry
    if _registry is None:
        _registry = PaymentProviderRegistry()
    return _registry
