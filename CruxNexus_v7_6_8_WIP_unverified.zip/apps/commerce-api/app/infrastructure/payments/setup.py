"""Wires configured payment provider adapters into the registry at
startup. A provider with no secret key configured is simply left
unregistered — PaymentProviderRegistry.get() then fails loudly and
specifically ("no adapter registered for X") rather than an adapter
silently attempting a call with an empty/placeholder key.
"""

import logging

from app.config import get_settings
from app.infrastructure.payments.adapter import get_payment_provider_registry
from app.infrastructure.payments.flutterwave import FlutterwaveAdapter
from app.infrastructure.payments.paystack import PaystackAdapter

logger = logging.getLogger(__name__)


def configure_payment_providers() -> None:
    settings = get_settings()
    registry = get_payment_provider_registry()

    if settings.PAYSTACK_SECRET_KEY:
        registry.register(PaystackAdapter(settings.PAYSTACK_SECRET_KEY))
        logger.info("Paystack payment adapter registered.")
    else:
        logger.info("PAYSTACK_SECRET_KEY not configured — Paystack adapter not registered.")

    if settings.FLUTTERWAVE_SECRET_KEY:
        registry.register(
            FlutterwaveAdapter(
                settings.FLUTTERWAVE_SECRET_KEY,
                webhook_secret_hash=settings.FLUTTERWAVE_WEBHOOK_SECRET_HASH,
            )
        )
        logger.info("Flutterwave payment adapter registered.")
    else:
        logger.info("FLUTTERWAVE_SECRET_KEY not configured — Flutterwave adapter not registered.")


