"""Encrypted store for MERCHANT-OWNED payment-provider credentials.

Why this exists: customer payments settle directly into each merchant's own
Paystack/Flutterwave account. CruxNexus therefore holds merchant API secrets, and
they must never be readable through ordinary CRUD, logs, or API responses.

Design:
  * AES-256-GCM (authenticated encryption) with a per-record random 96-bit nonce.
  * Versioned master keys from configuration, so keys can be rotated: new writes
    use the active version, old records stay decryptable until re-encrypted.
  * AAD binds every ciphertext to its owner (tenant | connection | provider), so a
    ciphertext copied onto another merchant's row fails authentication.
  * Plaintext is a small JSON object; callers never persist it anywhere else.

Master keys live in the environment (CREDENTIAL_ENCRYPTION_KEYS =
"v1:<base64 of 32 random bytes>;v2:..."), never in the database. An external KMS
can replace this class without changing callers (same encrypt/decrypt contract).
"""

from __future__ import annotations

import base64
import binascii
import json
import os
from dataclasses import dataclass
from typing import Mapping

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEY_BYTES = 32
NONCE_BYTES = 12


class VaultNotConfigured(RuntimeError):
    """No usable master key is configured; credential operations must fail closed."""


class VaultDecryptionError(RuntimeError):
    """Ciphertext failed authentication or its key version is unknown."""


@dataclass(frozen=True)
class SealedCredential:
    key_version: str
    nonce: bytes
    ciphertext: bytes


def parse_keys(raw: str | None) -> dict[str, bytes]:
    """Parse 'v1:<b64>;v2:<b64>'. Every key must decode to exactly 32 bytes."""
    keys: dict[str, bytes] = {}
    for part in (raw or "").split(";"):
        part = part.strip()
        if not part:
            continue
        version, sep, encoded = part.partition(":")
        version = version.strip()
        if not sep or not version or not version.replace("_", "").replace("-", "").isalnum():
            raise VaultNotConfigured("Malformed CREDENTIAL_ENCRYPTION_KEYS entry (expected 'version:base64key').")
        try:
            key = base64.b64decode(encoded.strip(), validate=True)
        except (binascii.Error, ValueError) as exc:
            raise VaultNotConfigured(f"Credential key '{version}' is not valid base64.") from exc
        if len(key) != KEY_BYTES:
            raise VaultNotConfigured(f"Credential key '{version}' must decode to exactly {KEY_BYTES} bytes.")
        if version in keys:
            raise VaultNotConfigured(f"Duplicate credential key version '{version}'.")
        keys[version] = key
    return keys


def generate_key() -> str:
    """Helper for operators: a fresh base64 key suitable for CREDENTIAL_ENCRYPTION_KEYS."""
    return base64.b64encode(os.urandom(KEY_BYTES)).decode()


class CredentialVault:
    def __init__(self, keys: Mapping[str, bytes], active_version: str):
        if not keys:
            raise VaultNotConfigured("No credential encryption keys configured.")
        if active_version not in keys:
            raise VaultNotConfigured(f"Active credential key version '{active_version}' is not configured.")
        self._keys = dict(keys)
        self._active = active_version

    @property
    def active_version(self) -> str:
        return self._active

    @staticmethod
    def aad_for(tenant_id, connection_id, provider: str) -> bytes:
        return f"cnx-cred|{tenant_id}|{connection_id}|{provider}".encode()

    def seal(self, secrets: Mapping[str, str], *, aad: bytes) -> SealedCredential:
        nonce = os.urandom(NONCE_BYTES)
        plaintext = json.dumps(dict(secrets), separators=(",", ":"), sort_keys=True).encode()
        ciphertext = AESGCM(self._keys[self._active]).encrypt(nonce, plaintext, aad)
        return SealedCredential(self._active, nonce, ciphertext)

    def open(self, sealed: SealedCredential, *, aad: bytes) -> dict:
        key = self._keys.get(sealed.key_version)
        if key is None:
            raise VaultDecryptionError(f"Unknown credential key version '{sealed.key_version}'.")
        try:
            plaintext = AESGCM(key).decrypt(sealed.nonce, sealed.ciphertext, aad)
        except InvalidTag as exc:
            raise VaultDecryptionError("Credential failed authentication (tampered or bound to another owner).") from exc
        return json.loads(plaintext)

    def needs_rotation(self, sealed: SealedCredential) -> bool:
        return sealed.key_version != self._active


def vault_from_settings(settings) -> CredentialVault:
    keys = parse_keys(getattr(settings, "CREDENTIAL_ENCRYPTION_KEYS", None))
    active = getattr(settings, "CREDENTIAL_ACTIVE_KEY_VERSION", None) or (sorted(keys)[-1] if keys else "")
    return CredentialVault(keys, active)


def aad_for_revision(tenant_id, connection_id, provider: str, credential_id) -> bytes:
    """AAD for credential REVISIONS (aad_version 2). In addition to tenant, connection and provider it
    binds the ciphertext to its own revision id, so a sealed secret cannot be swapped between two
    revisions of the same connection (which would silently redirect old payments to another account)."""
    return f"cnx-cred-rev|{tenant_id}|{connection_id}|{provider}|{credential_id}".encode()
