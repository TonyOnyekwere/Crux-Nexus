from datetime import datetime, timezone, timedelta
from uuid import uuid4
from sqlalchemy import Column, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID as PGUUID, JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, select, update
from app.database import Base

class WorkerJob(Base):
    __tablename__ = "worker_jobs"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    job_type = Column(String(120), nullable=False)
    payload = Column(JSONB, nullable=False, default=dict)
    status = Column(String(20), nullable=False, default="queued")
    available_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    attempts = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=8)
    lease_until = Column(DateTime(timezone=True), nullable=True)
    locked_by = Column(String(120), nullable=True)
    lease_token = Column(PGUUID(as_uuid=True), nullable=True)
    last_error = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime(timezone=True), nullable=True)

async def enqueue_job(db: AsyncSession, job_type: str, payload: dict, *, available_at=None, max_attempts: int = 8) -> WorkerJob:
    job=WorkerJob(job_type=job_type,payload=payload,available_at=available_at or datetime.now(timezone.utc),max_attempts=max_attempts)
    db.add(job); await db.flush(); return job

class LeaseLostError(RuntimeError):
    """The job's lease expired or was taken over before this worker could finish. Its work must NOT be
    committed: effects and completion share one transaction, so raising here rolls the effects back."""


async def claim_job(db: AsyncSession, worker_id: str, lease_seconds: int = 120) -> WorkerJob | None:
    # All time comparisons use the DATABASE clock, so worker clock skew can never extend or shorten a lease.
    result=await db.execute(select(WorkerJob).where(
        ((WorkerJob.status.in_(("queued","retry")) & (WorkerJob.available_at <= func.now())) |
         ((WorkerJob.status == "running") & WorkerJob.lease_until.is_not(None) & (WorkerJob.lease_until < func.now()))),
    ).order_by(WorkerJob.available_at, WorkerJob.created_at).limit(1).with_for_update(skip_locked=True))
    job=result.scalar_one_or_none()
    if job is None: return None
    job.status="running"; job.attempts += 1; job.locked_by=worker_id; job.lease_token=uuid4()
    job.lease_until=func.now()+timedelta(seconds=lease_seconds)
    await db.flush(); return job

def _holds_lease(job: WorkerJob):
    return (WorkerJob.id == job.id, WorkerJob.status == "running", WorkerJob.locked_by == job.locked_by,
            WorkerJob.lease_token == job.lease_token)

async def complete_job(db: AsyncSession, job: WorkerJob) -> None:
    """Atomic compare-and-set: succeeds only if THIS worker still holds the lease AND it has not expired.
    A stale worker (lease expired, or reclaimed by another worker) raises LeaseLostError, so its handler's
    effects, which share this transaction, are rolled back instead of committed."""
    result = await db.execute(
        update(WorkerJob).where(*_holds_lease(job), WorkerJob.lease_until > func.now())
        .values(status="succeeded", completed_at=func.now(), lease_until=None, locked_by=None, lease_token=None)
        .execution_options(synchronize_session=False))
    if result.rowcount != 1:
        raise LeaseLostError(f"Job {job.id} lease was lost or expired before completion")
    await db.refresh(job)

async def fail_job(db: AsyncSession, job: WorkerJob, error: str, *, retry_delay_seconds: int = 60) -> None:
    """Record a failure only if this worker still owns the job (same token). Ownership, not expiry,
    decides: an expired-but-unclaimed job may still be scheduled for retry by its last owner."""
    dead = job.attempts >= job.max_attempts
    values = dict(last_error=error[:4000], lease_until=None, locked_by=None, lease_token=None,
                  status="dead" if dead else "retry")
    if not dead:
        values["available_at"] = func.now() + timedelta(seconds=retry_delay_seconds * min(job.attempts, 10))
    result = await db.execute(update(WorkerJob).where(*_holds_lease(job)).values(**values).execution_options(synchronize_session=False))
    if result.rowcount != 1:
        raise LeaseLostError(f"Job {job.id} was taken over before its failure could be recorded")
    await db.refresh(job)
