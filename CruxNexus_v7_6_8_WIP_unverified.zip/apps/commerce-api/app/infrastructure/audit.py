"""Audit logging service for security events."""
import json
import logging
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SecurityEventType(str, Enum):
    """Types of security events to audit."""

    # Authentication events
    LOGIN_ATTEMPT = "login_attempt"
    LOGIN_SUCCESS = "login_success"
    LOGIN_FAILURE = "login_failure"
    LOGOUT = "logout"

    # Account events
    PASSWORD_CHANGED = "password_changed"
    PASSWORD_RESET_REQUESTED = "password_reset_requested"
    ACCOUNT_LOCKED = "account_locked"
    ACCOUNT_UNLOCKED = "account_unlocked"
    ACCOUNT_CREATED = "account_created"

    # Authorization events
    PERMISSION_DENIED = "permission_denied"
    TENANT_CONTEXT_SWITCHED = "tenant_context_switched"

    # Token events
    TOKEN_CREATED = "token_created"
    TOKEN_REFRESHED = "token_refreshed"
    TOKEN_REVOKED = "token_revoked"

    # Tenant events
    TENANT_CREATED = "tenant_created"
    TENANT_ARCHIVED = "tenant_archived"
    TENANT_SUSPENDED = "tenant_suspended"
    STAFF_ALLOCATION_CHANGED = "staff_allocation_changed"
    GOVERNANCE_POLICY_CHANGED = "governance_policy_changed"
    PROVIDER_GOVERNANCE_CHANGED = "provider_governance_changed"
    PLAN_GOVERNANCE_CHANGED = "plan_governance_changed"

    # Rate limiting events
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"


class SecurityEvent(BaseModel):
    """Schema for security audit events."""

    event_type: SecurityEventType = Field(..., description="Type of security event")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    user_id: Optional[str] = Field(None, description="User ID if authenticated")
    email: Optional[str] = Field(None, description="User email")
    tenant_id: Optional[str] = Field(None, description="Tenant ID if in tenant context")
    ip_address: Optional[str] = Field(None, description="Client IP address")
    user_agent: Optional[str] = Field(None, description="Client user agent")
    success: bool = Field(True, description="Whether the action was successful")
    reason: Optional[str] = Field(None, description="Reason for failure or additional context")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional event metadata")

    def to_json(self) -> str:
        """Convert event to JSON string for logging."""
        return self.model_dump_json()

    def to_log_dict(self) -> dict:
        """Convert event to dictionary for structured logging."""
        return {
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "user_id": self.user_id,
            "email": self.email,
            "tenant_id": self.tenant_id,
            "ip_address": self.ip_address,
            "user_agent": self.user_agent,
            "success": self.success,
            "reason": self.reason,
            "metadata": self.metadata,
        }


class AuditLogger:
    """Service for logging security audit events."""

    def __init__(self, logger_name: str = "security_audit"):
        self.audit_logger = logging.getLogger(logger_name)
        # Ensure audit logger outputs to separate stream/file in production
        if not self.audit_logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.audit_logger.addHandler(handler)
            self.audit_logger.setLevel(logging.INFO)
            self.audit_logger.propagate = False  # Don't propagate to root logger

    def log_event(self, event: SecurityEvent) -> None:
        """Log a security event."""
        log_level = logging.INFO if event.success else logging.WARNING

        self.audit_logger.log(
            log_level,
            json.dumps(event.to_log_dict()),
            extra={"audit_event": event.to_log_dict()}
        )

    def log_login_attempt(
        self,
        email: str,
        ip_address: str,
        user_agent: Optional[str] = None,
        success: bool = True,
        reason: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> None:
        """Log a login attempt."""
        event_type = SecurityEventType.LOGIN_SUCCESS if success else SecurityEventType.LOGIN_FAILURE
        event = SecurityEvent(
            event_type=event_type,
            email=email,
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            success=success,
            reason=reason,
        )
        self.log_event(event)

    def log_password_change(
        self,
        user_id: str,
        email: str,
        ip_address: str,
        user_agent: Optional[str] = None,
        success: bool = True,
        reason: Optional[str] = None,
    ) -> None:
        """Log a password change event."""
        event = SecurityEvent(
            event_type=SecurityEventType.PASSWORD_CHANGED,
            user_id=user_id,
            email=email,
            ip_address=ip_address,
            user_agent=user_agent,
            success=success,
            reason=reason,
        )
        self.log_event(event)

    def log_permission_denied(
        self,
        user_id: Optional[str],
        email: Optional[str],
        resource: str,
        action: str,
        ip_address: str,
        tenant_id: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> None:
        """Log a permission denied event."""
        event = SecurityEvent(
            event_type=SecurityEventType.PERMISSION_DENIED,
            user_id=user_id,
            email=email,
            tenant_id=tenant_id,
            ip_address=ip_address,
            success=False,
            reason=reason or f"Permission denied for {action} on {resource}",
            metadata={"resource": resource, "action": action},
        )
        self.log_event(event)

    def log_tenant_switch(
        self,
        user_id: str,
        from_tenant_id: Optional[str],
        to_tenant_id: str,
        ip_address: str,
        user_agent: Optional[str] = None,
    ) -> None:
        """Log a tenant context switch."""
        event = SecurityEvent(
            event_type=SecurityEventType.TENANT_CONTEXT_SWITCHED,
            user_id=user_id,
            tenant_id=to_tenant_id,
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            metadata={"from_tenant_id": from_tenant_id, "to_tenant_id": to_tenant_id},
        )
        self.log_event(event)

    def log_account_locked(
        self,
        email: str,
        ip_address: str,
        unlock_at: datetime,
        attempts: int,
    ) -> None:
        """Log an account lockout event."""
        event = SecurityEvent(
            event_type=SecurityEventType.ACCOUNT_LOCKED,
            email=email,
            ip_address=ip_address,
            success=False,
            reason=f"Account locked after {attempts} failed attempts",
            metadata={"unlock_at": unlock_at.isoformat(), "failed_attempts": attempts},
        )
        self.log_event(event)

    def log_rate_limit_exceeded(
        self,
        ip_address: str,
        endpoint: str,
        limit: str,
        retry_after: int,
    ) -> None:
        """Log a rate limit exceeded event."""
        event = SecurityEvent(
            event_type=SecurityEventType.RATE_LIMIT_EXCEEDED,
            ip_address=ip_address,
            success=False,
            reason=f"Rate limit exceeded: {limit}",
            metadata={"endpoint": endpoint, "limit": limit, "retry_after": retry_after},
        )
        self.log_event(event)


# Global audit logger instance
audit_logger = AuditLogger()


async def record_durable_audit(db, event: SecurityEvent, *, actor_type: str = "system") -> None:
    """Persist a security/audit event in the append-only audit table.

    Structured logging remains useful for observability, but commercial and
    governance actions require durable records independent of log retention.
    """
    from app.infrastructure.audit_model import AuditEvent
    from uuid import UUID
    db.add(AuditEvent(
        event_type=event.event_type.value,
        occurred_at=event.timestamp,
        user_id=UUID(event.user_id) if event.user_id else None,
        tenant_id=UUID(event.tenant_id) if event.tenant_id else None,
        actor_type=actor_type,
        success=event.success,
        reason=event.reason,
        metadata=event.metadata,
    ))
    await db.flush()
