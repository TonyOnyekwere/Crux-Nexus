"""CI gate: the subscription payment channel can NEVER be a customer checkout gateway.

Two financial relationships exist and must never be conflated:
  A. Merchant -> CruxNexus (subscription): CruxNexus-owned provider credentials, the platform
     provider registry, and the billing webhook inbox.
  B. Customer -> Merchant (checkout): ONLY the merchant's own provider account via a connection and
     sealed credentials (app/contexts/commerce/application/services/merchant_payments.py).

Rules enforced (AST based, so comments/strings cannot satisfy or defeat them):
  1. Commerce code (app/contexts/commerce/**, app/workers/commerce_*) must not import or reference the
     platform provider registry (get_payment_provider_registry / PaymentProviderRegistry) or the
     platform provider setup module.
  2. Commerce code must not read the CruxNexus-owned provider secrets from settings
     (PAYSTACK_SECRET_KEY, FLUTTERWAVE_SECRET_KEY, FLUTTERWAVE_WEBHOOK_SECRET_HASH).
  3. Billing/subscription code must not import commerce code.
Exit code 1 on any violation.
"""
import ast
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent / "app"
FORBIDDEN_NAMES = {"get_payment_provider_registry", "PaymentProviderRegistry"}
FORBIDDEN_MODULES = ("app.infrastructure.payments.setup",)
FORBIDDEN_SETTINGS = {"PAYSTACK_SECRET_KEY", "FLUTTERWAVE_SECRET_KEY", "FLUTTERWAVE_WEBHOOK_SECRET_HASH"}


def py_files(*patterns):
    seen = []
    for pattern in patterns:
        seen += [p for p in ROOT.glob(pattern) if p.is_file() and "__pycache__" not in p.parts]
    return sorted(set(seen))


def violations_commerce(path):
    out = []
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            if any(mod == m or mod.startswith(m + ".") for m in FORBIDDEN_MODULES):
                out.append((node.lineno, f"imports platform payment setup '{mod}'"))
            for alias in node.names:
                if alias.name in FORBIDDEN_NAMES:
                    out.append((node.lineno, f"imports platform registry '{alias.name}'"))
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if any(alias.name == m or alias.name.startswith(m + ".") for m in FORBIDDEN_MODULES):
                    out.append((node.lineno, f"imports platform payment setup '{alias.name}'"))
        elif isinstance(node, ast.Name) and node.id in FORBIDDEN_NAMES:
            out.append((node.lineno, f"references platform registry '{node.id}'"))
        elif isinstance(node, ast.Attribute) and node.attr in FORBIDDEN_SETTINGS:
            out.append((node.lineno, f"reads CruxNexus-owned provider secret '{node.attr}'"))
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in FORBIDDEN_SETTINGS:
            out.append((node.lineno, f"names CruxNexus-owned provider secret '{node.value}'"))
    return out


def violations_billing(path):
    out = []
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        mod = None
        if isinstance(node, ast.ImportFrom):
            mod = node.module or ""
        elif isinstance(node, ast.Import):
            mod = next((a.name for a in node.names if a.name.startswith("app.contexts.commerce")), None)
        if mod and (mod == "app.contexts.commerce" or mod.startswith("app.contexts.commerce.")):
            out.append((node.lineno, f"subscription code imports commerce '{mod}'"))
    return out


def main() -> int:
    bad = 0
    for path in py_files("contexts/commerce/**/*.py", "workers/commerce_*.py"):
        for line, msg in violations_commerce(path):
            print(f"{path.relative_to(ROOT.parent)}:{line}: {msg}")
            bad += 1
    for path in py_files("contexts/billing/**/*.py", "infrastructure/payments/**/*.py"):
        for line, msg in violations_billing(path):
            print(f"{path.relative_to(ROOT.parent)}:{line}: {msg}")
            bad += 1
    print(f"payment channel separation: {bad} violation(s)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
