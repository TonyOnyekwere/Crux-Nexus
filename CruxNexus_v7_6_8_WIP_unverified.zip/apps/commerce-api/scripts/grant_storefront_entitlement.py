"""
Grant extra storefront entitlement to a merchant, by owner email.

There is no admin API endpoint for this yet (see
CRX-P0-015-TRIAL-LIFECYCLE-HARDENING.md for why). Until one exists, this is
the supported way to grant extra storefront capacity: it goes through
CapacityService.grant_extra_storefront_entitlement(), so the plan's
max_extra_storefronts ceiling is actually enforced, rather than a raw SQL
INSERT that could exceed it by mistake.

Usage (run inside the deployed container — e.g. via Railway's dashboard
Shell tab on the commerce-api service, or `railway run`):

    python scripts/grant_storefront_entitlement.py owner@example.com

Optional quantity (default 1):

    python scripts/grant_storefront_entitlement.py owner@example.com --quantity 2
"""

import argparse
import asyncio
import sys

from sqlalchemy import select

from app.contexts.identity.domain.entities import User
from app.contexts.merchant_management.application.capacity import CapacityService
from app.contexts.merchant_management.domain.entities import MerchantAccount
from app.contexts.merchant_management.domain.merchant_account_user import (
    MerchantAccountUser,
    MerchantUserRole,
)
from app.database.session import AsyncSessionLocal


async def grant(email: str, quantity: int, source: str) -> None:
    async with AsyncSessionLocal() as db:
        user_result = await db.execute(select(User).where(User.email == email))
        user = user_result.scalar_one_or_none()
        if user is None:
            print(f"No user found with email '{email}'")
            sys.exit(1)

        ownership_result = await db.execute(
            select(MerchantAccountUser).where(
                MerchantAccountUser.user_id == user.id,
                MerchantAccountUser.role == MerchantUserRole.OWNER.value,
            )
        )
        ownership = ownership_result.scalar_one_or_none()
        if ownership is None:
            print(f"User '{email}' does not own any merchant account")
            sys.exit(1)

        merchant_result = await db.execute(
            select(MerchantAccount).where(MerchantAccount.id == ownership.merchant_account_id)
        )
        merchant = merchant_result.scalar_one()

        capacity_service = CapacityService(db)

        before = await capacity_service.get_storefront_capacity(merchant.id)

        entitlement = await capacity_service.grant_extra_storefront_entitlement(
            merchant_account_id=merchant.id,
            quantity=quantity,
            source=source,
        )
        await db.commit()

        after = await capacity_service.get_storefront_capacity(merchant.id)

        print(f"Granted entitlement {entitlement.id} to merchant '{merchant.name}' ({merchant.id})")
        print(f"Storefront capacity: {before} -> {after}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("email", help="Email of the merchant account owner")
    parser.add_argument("--quantity", type=int, default=1, help="Extra storefronts to grant (default: 1)")
    parser.add_argument(
        "--source",
        default="admin_grant",
        choices=["admin_grant", "purchase", "promotion"],
        help="Entitlement source to record (default: admin_grant)",
    )
    args = parser.parse_args()

    asyncio.run(grant(args.email, args.quantity, args.source))


if __name__ == "__main__":
    main()
