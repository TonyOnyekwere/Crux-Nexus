"""
RLS Policy Coverage Check Script

This script checks that all tenant-scoped tables have:
1. RLS enabled
2. FORCE ROW LEVEL SECURITY
3. Appropriate tenant isolation policies
4. Both USING and WITH CHECK clauses for write operations
"""

import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import os
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from app.database.tenant_scope import TENANT_SCOPED_TABLES, CONTROL_PLANE_TABLES
from app.database.url import normalize_async_database_url


async def check_table_classification_coverage(conn) -> bool:
    """Every table in the actual database must be classified as either
    tenant-scoped or control-plane — an unclassified table is exactly how
    a genuinely tenant-owned table (e.g. the first real `products` table)
    could land without RLS and nobody notice, since the vacuous-pass
    branch above only checks tables already IN the registry. This check
    looks at what actually exists in the database and fails CI if
    anything is in neither list, rather than trusting the registries to
    have kept up on their own."""
    result = await conn.execute(
        text(
            """
            SELECT tablename FROM pg_tables
            WHERE schemaname = 'public' AND tablename != 'alembic_version'
            """
        )
    )
    actual_tables = {row[0] for row in result.fetchall()}
    known = set(TENANT_SCOPED_TABLES) | set(CONTROL_PLANE_TABLES)
    unclassified = actual_tables - known

    if unclassified:
        print(
            f"\n❌ FAIL: {len(unclassified)} table(s) exist in the database but are "
            f"classified in neither TENANT_SCOPED_TABLES nor CONTROL_PLANE_TABLES "
            f"(app/database/tenant_scope.py): {sorted(unclassified)}"
        )
        print(
            "   A new table must be explicitly classified before it can pass CI — "
            "an unclassified table is exactly how a genuinely tenant-owned table "
            "could go live with no RLS and nobody notice."
        )
        return False

    print(f"✅ All {len(actual_tables)} database table(s) are classified (control-plane or tenant-scoped).")
    return True


async def check_rls_coverage():
    """Check RLS coverage for all tenant-scoped tables."""
    # CRX-P0-008 P0-6: Use CI environment variables directly
    # CI provides explicit env vars for ephemeral infrastructure
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        print("❌ ERROR: DATABASE_URL environment variable not set")
        sys.exit(1)
    
    # Centralized Railway database URL normalization (CRX-P0-007 P0-2)
    database_url = normalize_async_database_url(database_url)
    
    engine = create_async_engine(database_url, echo=False)
    
    # Use canonical registry from tenant_scope.py (CRX-P0-007 P0-1)
    # This ensures CI enforces the same table list as the architecture
    
    failed_tables = []
    partial_failures = []

    if not TENANT_SCOPED_TABLES:
        print(
            "⚠️  VACUOUS PASS: TENANT_SCOPED_TABLES is empty — no tenant-owned commerce "
            "tables exist yet. RLS proof is NOT established for tenant data-plane tables."
        )
        async with engine.begin() as conn:
            classification_ok = await check_table_classification_coverage(conn)
        await engine.dispose()
        sys.exit(0 if classification_ok else 1)

    async with engine.begin() as conn:
        for table_name in TENANT_SCOPED_TABLES:
            # Check if table exists
            result = await conn.execute(
                text("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = :table_name
                    )
                """),
                {"table_name": table_name}
            )
            table_exists = result.scalar()
            
            if not table_exists:
                print(f"❌ FAIL: Required table '{table_name}' does not exist")
                failed_tables.append((table_name, ["Required table missing"]))
                continue
            
            table_issues = []
            
            # Check if RLS is enabled
            result = await conn.execute(
                text("""
                    SELECT relrowsecurity 
                    FROM pg_class 
                    WHERE relname = :table_name
                """),
                {"table_name": table_name}
            )
            rls_enabled = result.scalar()
            
            if not rls_enabled:
                table_issues.append("RLS not enabled")
            
            # Check if FORCE ROW LEVEL SECURITY is enabled
            result = await conn.execute(
                text("""
                    SELECT relforcerowsecurity 
                    FROM pg_class 
                    WHERE relname = :table_name
                """),
                {"table_name": table_name}
            )
            rls_forced = result.scalar()
            
            if not rls_forced:
                table_issues.append("FORCE ROW LEVEL SECURITY not enabled")
            
            # Check if tenant isolation policy exists
            result = await conn.execute(
                text("""
                    SELECT EXISTS (
                        SELECT 1 FROM pg_policy 
                        WHERE tablename = :table_name
                        AND policyname LIKE '%tenant%'
                    )
                """),
                {"table_name": table_name}
            )
            policy_exists = result.scalar()
            
            if not policy_exists:
                table_issues.append("No tenant isolation policy found")
            else:
                # Check if policy has WITH CHECK clause
                result = await conn.execute(
                    text("""
                        SELECT pg_get_expr(qual, oid) as using_expr,
                               pg_get_expr(with_check, oid) as with_check_expr
                        FROM pg_policy 
                        WHERE tablename = :table_name
                        AND policyname LIKE '%tenant%'
                    """),
                    {"table_name": table_name}
                )
                policy_data = result.fetchone()
                
                if policy_data:
                    using_expr, with_check_expr = policy_data
                    if not with_check_expr or with_check_expr.strip() == "":
                        table_issues.append("Policy missing WITH CHECK clause for write operations")
            
            if table_issues:
                if "RLS not enabled" in table_issues or "FORCE ROW LEVEL SECURITY not enabled" in table_issues:
                    failed_tables.append((table_name, table_issues))
                    print(f"❌ FAIL: Table '{table_name}' - {', '.join(table_issues)}")
                else:
                    partial_failures.append((table_name, table_issues))
                    print(f"⚠️  PARTIAL: Table '{table_name}' - {', '.join(table_issues)}")
            else:
                print(f"✅ PASS: Table '{table_name}' has complete RLS protection")
    
    await engine.dispose()
    
    if failed_tables:
        print(f"\n❌ RLS check failed for {len(failed_tables)} table(s):")
        for table, issues in failed_tables:
            print(f"   - {table}: {', '.join(issues)}")
        sys.exit(1)
    
    if partial_failures:
        print(f"\n❌ RLS check has partial failures for {len(partial_failures)} table(s):")
        for table, issues in partial_failures:
            print(f"   - {table}: {', '.join(issues)}")
        print("❌ Partial RLS failures are not acceptable for mandatory tenant isolation")
        sys.exit(1)
    
    print("\n✅ All tenant-scoped tables have complete RLS protection")
    sys.exit(0)


if __name__ == "__main__":
    asyncio.run(check_rls_coverage())