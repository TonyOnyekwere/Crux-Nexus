"""Static release gate for the current commercial-hardening review."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
CI = ROOT.parent.parent / ".github" / "workflows" / "ci.yml"

checks = []

def require(condition, message):
    checks.append((condition, message))

source = "\n".join(p.read_text(encoding="utf-8") for p in APP.rglob("*.py"))
require("ENABLE_TEST_PAYMENT_PROVIDER" not in source, "test payment provider flag is absent from executable app")
require("DEV_PLACEHOLDER_PRICES" not in source, "placeholder prices are absent from executable app")
require("test_payment_simulations" not in source, "test payment table is absent from executable app")
require("DATABASE_RUNTIME_URL" in (APP / "config.py").read_text(), "runtime database role is configured")
require("DATABASE_WORKER_URL" in (APP / "config.py").read_text(), "dedicated worker database role is configured")
require("worker_context" in (APP / "workers/runtime.py").read_text() or "worker_context" in (ROOT / "migrations/versions/036_worker_runtime_role.py").read_text(), "worker RLS execution context is explicit")
require("subscription_period_end" in (APP / "contexts/billing/application/subscription_payment_service.py").read_text(), "paid subscription period is established on activation")
require("run_subscription_lifecycle_loop" in (APP / "workers/runner.py").read_text(), "subscription lifecycle worker is registered")
commerce_source = "\n".join(p.read_text(encoding="utf-8") for p in (APP / "contexts/commerce").rglob("*.py"))
require("X-Cart-Token" in commerce_source, "cart token is header-bound")
require("X-Order-Access-Token" in commerce_source, "guest order access token is enforced")
require("requires_refund" in commerce_source, "late payment refund flag is present")
require("TenantService(self.db).create_storefront" in (APP / "contexts/onboarding/application/journey_service.py").read_text(), "onboarding storefront provisioning uses canonical TenantService")
require("SubscriptionAlreadyActiveError" in (APP / "contexts/billing/application/subscription_payment_service.py").read_text(), "active subscription payment guard is present")
require("tx_ref" in (APP / "infrastructure/payments/flutterwave.py").read_text(), "Flutterwave webhook tx_ref normalization is present")
require("ProviderTransactionNotFoundError" in (APP / "contexts/billing/application/subscription_payment_service.py").read_text(), "definitive provider-not-found webhook classification is present")
require("limit(1)" in (APP / "workers/webhook_reconciliation.py").read_text(), "stale transaction worker uses one-row claims")
require("MerchantEntitlement.ends_at > func.now()" in (APP / "contexts/billing/application/entitlement_allocation.py").read_text(), "expired entitlements are excluded synchronously from staff capacity")
require("with_for_update()" in (APP / "contexts/billing/application/entitlement_allocation.py").read_text(), "staff allocation deallocation uses row locking")
require("record_worker_success" in "\n".join(p.read_text(encoding="utf-8") for p in (APP / "workers").glob("*.py")), "worker success metrics are incremented")
require("tests/adversarial/" in CI.read_text(), "adversarial tests are included in CI")
require((ROOT / "migrations/versions/035_order_access_token.py").exists(), "order access-token migration exists")
require((ROOT / "migrations/versions/034_runtime_role_split.py").exists(), "runtime role migration exists")
require((ROOT / "migrations/versions/036_worker_runtime_role.py").exists(), "worker role migration exists")
require((ROOT / "migrations/versions/040_provider_registry_cache.py").exists(), "provider registry cache migration exists")
require((ROOT / "migrations/versions/041_foundation_hardening.py").exists(), "foundation hardening migration exists")
require((ROOT / "migrations/versions/043_subscription_activation_jobs.py").exists(), "subscription activation job migration exists")
require("Idempotency-Key" in (ROOT / "app/contexts/commerce/api/checkout_routes.py").read_text(), "checkout idempotency is enforced")
require("billing.activate_subscription" in (ROOT / "app/workers/job_handlers.py").read_text(), "durable subscription activation handler exists")
require((ROOT / "../control-center-api/app/main.py").exists(), "separate Control Center service exists")
require((ROOT / "../control-center-api/migrations/versions/001_initial.py").exists(), "separate Control Center database migration exists")
require("MANAGE_PRODUCTS" in source and "require_permission" in source, "Commerce RBAC permission enforcement exists")
require("TenantSuspension" in source, "tenant suspension provenance exists")
require("worker_jobs" in source, "durable worker job state exists")
require("RedisEventTransport" in source, "external event transport exists")
require("audit_events" in source, "durable audit storage exists")

require((APP / "contexts/commerce/domain/models.py").exists(), "Commerce domain models module exists")
require((APP / "contexts/commerce/application/services/payment.py").exists(), "Commerce application payment service exists")
require((APP / "contexts/commerce/api/merchant_routes.py").exists(), "Commerce merchant API adapter exists")
require((APP / "contexts/commerce/api/public_routes.py").exists(), "Commerce public API adapter exists")
require(not (APP / "contexts/commerce.py").exists(), "legacy monolithic commerce.py is removed")

# ---- repository hygiene (Gate 1) -----------------------------------------------------------------------
import ast as _ast
_REPO = ROOT.parent.parent
_SIMULATOR_TOKENS = ("ENABLE_TEST_PAYMENT_PROVIDER", "TEST_PAYMENT_WEBHOOK_SECRET", "test_payment_simulations",
                     "TestPaymentAdapter", "DEV_OTP_LOG_CODES", "dev/test-payments", "DevelopmentOTPProvider")
_SKIP = ("migrations/versions/029_", "migrations/versions/031_", "scripts/review_gate_check.py", "__pycache__", ".git/")
_hits = []
for _p in _REPO.rglob("*"):
    if not _p.is_file() or _p.suffix not in {".py", ".md", ".yml", ".yaml", ".json", ".toml", ".ts", ".env", ".txt", ".ini"}:
        continue
    _rel = _p.relative_to(_REPO).as_posix()
    if any(k in _rel for k in _SKIP):
        continue
    _text = _p.read_text(encoding="utf-8", errors="ignore")
    _hits += [f"{_rel}: {t}" for t in _SIMULATOR_TOKENS if t in _text]
require(not _hits, "no docs, tests, imports, configuration or comments reference the removed payment simulator" + (": " + "; ".join(_hits) if _hits else ""))
_star = [p.relative_to(ROOT).as_posix() for p in (ROOT / "app").rglob("*.py")
         if any(isinstance(n, _ast.ImportFrom) and any(a.name == "*" for a in n.names) for n in _ast.walk(_ast.parse(p.read_text(encoding="utf-8"))))]
require(not _star, "no wildcard imports remain" + (": " + ", ".join(_star) if _star else ""))
_dup = []
for _p in (ROOT / "app").rglob("*.py"):
    for _c in _ast.walk(_ast.parse(_p.read_text(encoding="utf-8"))):
        if isinstance(_c, _ast.ClassDef) and sum(1 for b in _c.body if isinstance(b, _ast.Assign) and any(getattr(t, "id", "") == "__table_args__" for t in b.targets)) > 1:
            _dup.append(f"{_p.name}:{_c.name}")
require(not _dup, "no ORM class defines __table_args__ twice" + (": " + ", ".join(_dup) if _dup else ""))

failed = [message for ok, message in checks if not ok]
for ok, message in checks:
    print(("PASS" if ok else "FAIL") + ": " + message)
if failed:
    sys.exit(1)
print(f"REVIEW_GATE_CHECK_OK ({len(checks)} checks)")
