"""CI gate: undefined-name finder (pyflakes substitute with zero dependencies).

Why it exists: `python -m compileall` cannot see an undefined name, and the
string-grep regression specs cannot either. In v7.6.3 this class of defect
(`@merchant.get` with no `merchant`, a missing `UniqueConstraint` import, ...)
made the whole API fail at import while every other gate passed.
Understands defs/classes/imports/assignments/comprehensions/arguments/decorators
and resolves `from x import *` inside the repo. Exit code 1 on any finding.
Usage: python scripts/check_undefined_names.py [app_dir]
"""
import ast, builtins, pathlib, sys
root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parent.parent / "app"
def module_file(mod):
    p = root.parent.joinpath(*mod.split("."))
    if p.with_suffix(".py").exists(): return p.with_suffix(".py")
    if (p/"__init__.py").exists(): return p/"__init__.py"
def exported(path, seen=None):
    seen = seen or set()
    if path in seen: return set()
    seen.add(path)
    names=set()
    try: tree=ast.parse(path.read_text())
    except Exception: return names
    for n in tree.body:
        names |= binds(n, path, seen)
    if "__all__" in names: pass
    return {x for x in names if not x.startswith("_")}
def binds(n, path, seen):
    out=set()
    for x in ast.walk(n) if isinstance(n,(ast.If,ast.Try,ast.With)) else [n]:
        if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)): out.add(x.name)
        elif isinstance(x,ast.Import):
            for a in x.names: out.add((a.asname or a.name).split(".")[0])
        elif isinstance(x,ast.ImportFrom):
            for a in x.names:
                if a.name=="*":
                    f=module_file(x.module) if x.module and x.level==0 else None
                    if f: out |= exported(f, seen)
                else: out.add(a.asname or a.name)
        elif isinstance(x,ast.Assign):
            for t in x.targets:
                for y in ast.walk(t):
                    if isinstance(y,ast.Name): out.add(y.id)
        elif isinstance(x,(ast.AnnAssign,)) and isinstance(x.target,ast.Name): out.add(x.target.id)
    return out
def check(path):
    tree=ast.parse(path.read_text())
    module_names=set(dir(builtins))|{"__file__","__name__"}
    for n in tree.body: module_names |= binds(n, path, set())
    bad=[]
    def visit(node, scope):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.Lambda)):
            local=set(scope)
            a=node.args
            for arg in a.args+a.kwonlyargs+a.posonlyargs: local.add(arg.arg)
            if a.vararg: local.add(a.vararg.arg)
            if a.kwarg: local.add(a.kwarg.arg)
            body = node.body if isinstance(node.body,list) else [node.body]
            for b in body:
                for y in ast.walk(b):
                    if isinstance(y,ast.Name) and isinstance(y.ctx,ast.Store): local.add(y.id)
                    elif isinstance(y,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)): local.add(y.name)
                    elif isinstance(y,(ast.Import,ast.ImportFrom)):
                        for al in y.names: local.add((al.asname or al.name).split(".")[0])
                    elif isinstance(y,ast.ExceptHandler) and y.name: local.add(y.name)
                    elif isinstance(y,ast.arg): local.add(y.arg)
            for d in getattr(node,'decorator_list',[]): visit(d, scope)
            for dflt in a.defaults+[d for d in a.kw_defaults if d]: visit(dflt, scope)
            for b in body: visit(b, local)
            return
        if isinstance(node,(ast.ListComp,ast.SetComp,ast.GeneratorExp,ast.DictComp)):
            local=set(scope)
            for g in node.generators:
                for y in ast.walk(g.target):
                    if isinstance(y,ast.Name): local.add(y.id)
            for c in ast.iter_child_nodes(node): visit(c, local)
            return
        if isinstance(node,ast.Name) and isinstance(node.ctx,ast.Load):
            if node.id not in scope: bad.append((node.lineno,node.id))
        for c in ast.iter_child_nodes(node): visit(c, scope)
    for n in tree.body:
        if isinstance(n,(ast.Import,ast.ImportFrom)): continue
        visit(n, module_names)
    return bad
tot=0
for f in sorted(root.rglob("*.py")):
    if "__pycache__" in str(f) or "migrations" in str(f): continue
    for ln,name in check(f):
        print(f"{f.relative_to(root)}:{ln}: undefined name '{name}'"); tot+=1
print("undefined:",tot)
sys.exit(1 if tot else 0)
