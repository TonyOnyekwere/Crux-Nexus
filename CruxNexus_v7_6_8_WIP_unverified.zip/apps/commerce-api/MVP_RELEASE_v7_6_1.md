# CruxNexus Commerce MVP v7.6.1

## Purpose

v7.6.1 is the commercial-closure and Commerce-context restructuring release following the v7.6.0 source review. It does not restart the project or replace the existing architecture.

## Architecture rule preserved

**Control Center decides. Commerce authorizes and operates. Worker executes deferred lifecycle consequences.**

Commerce is now explicitly a bounded context under `app/contexts/commerce/` with domain, application, and API layers. Its API surface is further decomposed into capability-specific route modules for storefront, catalog, inventory, orders, carts, checkout, payments, and dashboard operations. It remains a modular monolith. These are internal service/module boundaries, not separate network deployments.

## Gate A closure

- Canonical storefront provisioning is used by onboarding.
- MerchantAccessResolver is used for storefront creation, staff addition, publishing, and order processing.
- ACTIVE subscriptions cannot start another pay-now charge.
- Definitive provider rejection closes the subscription payment lifecycle correctly.
- Flutterwave webhook references are normalized to `tx_ref`.
- Provider-not-found webhook results are terminal.
- Stale transaction reconciliation is one-row claim/process/commit.
- Staff capacity ignores expired/not-yet-active entitlements synchronously.
- Staff deallocation uses row locks.

## Worker observability

Every worker loop now records:
- successful sweep count
- processed item count
- sweep duration
- last successful sweep timestamp
- failures

Metrics are exposed through the existing `/metrics` endpoint.

## Payment safety semantics

A new subscription payment is not initiated while the subscription is already ACTIVE. If an already-created transaction completes after the subscription has become ACTIVE, its successful payment extends the existing paid period from the later of the existing period end and the current time rather than erasing remaining time.

## Runtime verification status

Source/static verification passes. Full PostgreSQL/Redis tests and real provider sandbox verification remain unexecuted in this environment because the required packages and external network access are unavailable.
