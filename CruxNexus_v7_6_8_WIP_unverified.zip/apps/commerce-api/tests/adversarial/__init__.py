"""Adversarial security tests.

These tests verify that the system correctly enforces security boundaries
and prevents various attack vectors.
"""