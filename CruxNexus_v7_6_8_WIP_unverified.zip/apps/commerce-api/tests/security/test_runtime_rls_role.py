import os
import uuid
import pytest
from sqlalchemy.exc import DBAPIError
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from app.database.url import normalize_async_database_url


@pytest.mark.asyncio
async def test_runtime_role_is_non_superuser_and_commerce_rls_is_enforced():
    url = os.environ.get("DATABASE_RUNTIME_URL")
    if not url:
        pytest.skip("DATABASE_RUNTIME_URL is not configured")
    engine = create_async_engine(normalize_async_database_url(url))
    try:
        async with engine.begin() as conn:
            role = (await conn.execute(text("SELECT current_user, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user"))).one()
            assert role.rolsuper is False
            assert role.rolbypassrls is False
            tenant_a = uuid.uuid4()
            tenant_b = uuid.uuid4()
            await conn.execute(text("INSERT INTO tenants (id, slug, status) VALUES (:id, :slug, 'active')"), {"id": tenant_a, "slug": f"rls-a-{tenant_a.hex[:8]}"})
            await conn.execute(text("INSERT INTO tenants (id, slug, status) VALUES (:id, :slug, 'active')"), {"id": tenant_b, "slug": f"rls-b-{tenant_b.hex[:8]}"})
            await conn.execute(text("SET LOCAL app.current_tenant_id = :tid"), {"tid": str(tenant_a)})
            await conn.execute(text("INSERT INTO products (id, tenant_id, name, slug, sku, price, currency) VALUES (:id, :tid, 'A', :slug, :sku, 1, 'NGN')"), {"id": uuid.uuid4(), "tid": tenant_a, "slug": f"a-{tenant_a.hex[:8]}", "sku": f"A-{tenant_a.hex[:8]}"})
            with pytest.raises(DBAPIError):
                await conn.execute(text("INSERT INTO products (id, tenant_id, name, slug, sku, price, currency) VALUES (:id, :tid, 'B', :slug, :sku, 1, 'NGN')"), {"id": uuid.uuid4(), "tid": tenant_b, "slug": f"b-{tenant_b.hex[:8]}", "sku": f"B-{tenant_b.hex[:8]}"})
            count = (await conn.execute(text("SELECT count(*) FROM products"))).scalar_one()
            assert count == 1
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_worker_role_is_non_superuser_and_explicitly_authorized_for_system_rls():
    url = os.environ.get("DATABASE_WORKER_URL")
    if not url:
        pytest.skip("DATABASE_WORKER_URL is not configured")
    engine = create_async_engine(normalize_async_database_url(url))
    try:
        async with engine.begin() as conn:
            role = (await conn.execute(text("SELECT current_user, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user"))).one()
            assert role.rolsuper is False
            assert role.rolbypassrls is False
            assert (await conn.execute(text("SELECT current_setting('app.worker_context', true)"))).scalar_one() == "1"
    finally:
        await engine.dispose()
