"""Integration: GET /api/v1/billing/plans (CRX-FE-001). Requires the CI Postgres."""

from decimal import Decimal
from uuid import uuid4

import pytest
from httpx import AsyncClient
from sqlalchemy import update

from app.auth.jwt_handler import create_global_access_token
from app.contexts.billing.domain.entities import SubscriptionPlan

URL = "/api/v1/billing/plans"


def _auth() -> dict:
    token = create_global_access_token(user_id=uuid4(), email="plans@example.com")
    return {"Authorization": f"Bearer {token}"}


def _plan(code: str, **kw) -> SubscriptionPlan:
    values = dict(
        code=code, name=code.title(), included_storefronts=1, base_staff_per_storefront=2,
        max_extra_storefronts=1, max_extra_staff=3, trial_days=5, active=True,
        price_amount=Decimal("7500.00"), price_currency="NGN", billing_interval="monthly",
        capabilities={"internal.flag": True}, resource_limits={"products.max": 200},
    )
    values.update(kw)
    return SubscriptionPlan(**values)


@pytest.mark.asyncio
async def test_requires_authentication(client: AsyncClient):
    assert (await client.get(URL)).status_code in (401, 403)


@pytest.mark.asyncio
async def test_active_plan_listed_inactive_plan_hidden(client: AsyncClient, db_session):
    db_session.add_all([_plan("zz_active"), _plan("zz_inactive", active=False)])
    await db_session.flush()
    response = await client.get(URL, headers=_auth())
    assert response.status_code == 200
    codes = [p["code"] for p in response.json()["data"]["plans"]]
    assert "zz_active" in codes and "zz_inactive" not in codes


@pytest.mark.asyncio
async def test_price_currency_interval_trial_and_limits_match_the_database(client: AsyncClient, db_session):
    db_session.add(_plan("zz_priced", price_amount=Decimal("12345.67"), price_currency="GHS", billing_interval="annual"))
    await db_session.flush()
    plans = (await client.get(URL, headers=_auth())).json()["data"]["plans"]
    plan = next(p for p in plans if p["code"] == "zz_priced")
    assert plan["price"] == "12345.67" and plan["currency"] == "GHS" and plan["interval"] == "annual"
    assert plan["pricing_configured"] is True and plan["trial_days"] == 5
    assert plan["limits"] == {
        "included_storefronts": 1, "base_staff_per_storefront": 2,
        "max_extra_storefronts": 1, "max_extra_staff": 3,
        "resources": {"products.max": 200},
    }


@pytest.mark.asyncio
async def test_unpriced_plan_is_listed_but_not_presented_as_purchasable(client: AsyncClient, db_session):
    db_session.add(_plan("zz_unpriced", price_amount=None, price_currency=None, billing_interval=None))
    await db_session.flush()
    plans = (await client.get(URL, headers=_auth())).json()["data"]["plans"]
    plan = next(p for p in plans if p["code"] == "zz_unpriced")
    assert plan["pricing_configured"] is False
    assert plan["price"] is None and plan["currency"] is None and plan["interval"] is None


@pytest.mark.asyncio
async def test_response_never_contains_policy_or_administrative_fields(client: AsyncClient, db_session):
    db_session.add(_plan("zz_secret"))
    await db_session.flush()
    body = (await client.get(URL, headers=_auth())).text
    for forbidden in ("capabilities", "internal.flag", "governance_version", "\"active\"", "\"id\""):
        assert forbidden not in body


@pytest.mark.asyncio
async def test_empty_catalogue_returns_empty_list_not_an_error(client: AsyncClient, db_session):
    await db_session.execute(update(SubscriptionPlan).values(active=False))
    await db_session.flush()
    response = await client.get(URL, headers=_auth())
    assert response.status_code == 200
    assert response.json() == {"data": {"plans": []}}


@pytest.mark.asyncio
async def test_listed_plan_is_accepted_by_server_side_selection_rules(client: AsyncClient, db_session):
    """The catalogue must never offer a plan that select_plan would reject:
    both use the same eligibility (active)."""
    from sqlalchemy import func, select

    db_session.add(_plan("zz_selectable"))
    await db_session.flush()
    listed = {p["code"] for p in (await client.get(URL, headers=_auth())).json()["data"]["plans"]}
    selectable = set(
        (await db_session.execute(select(func.lower(SubscriptionPlan.code)).where(SubscriptionPlan.active.is_(True)))).scalars()
    )
    assert {c.lower() for c in listed} == selectable
