"""PostgreSQL integration for CRX-FE-003 WP1. Requires the CI database at alembic head (>= 049).

These are the evidence for: one trial per merchant account (including under real concurrency),
duplicate detection before the constraint, idempotency-record constraints, and race-safe slug claims.
"""

import asyncio
import importlib.util
import os
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
from sqlalchemy import delete, select, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.contexts.billing.domain.entities import SubscriptionPlan
from app.contexts.billing.domain.merchant_trial_history import MerchantTrialHistory
from app.contexts.merchant_management.domain.entities import MerchantAccount
from app.contexts.onboarding.application.journey_v2_repository import SlugClaim, claim_slug
from app.contexts.onboarding.domain.journey_v2_models import OnboardingIdempotencyKey, OnboardingSlugReservation
from app.contexts.onboarding.domain.onboarding_session import OnboardingSession
from app.contexts.tenant_management.domain.entities import Tenant
from app.database.url import normalize_async_database_url

MIGRATION_PATH = Path(__file__).resolve().parents[2] / "migrations" / "versions" / "049_v2_onboarding_foundation.py"


def _plan(code: str) -> SubscriptionPlan:
    return SubscriptionPlan(
        code=code, name=code, included_storefronts=1, base_staff_per_storefront=0,
        max_extra_storefronts=0, max_extra_staff=0, trial_days=3, active=True,
    )


def _session(**kw) -> OnboardingSession:
    values = dict(
        device_session_token=f"digest-{uuid.uuid4().hex}", flow_version="v2", current_step="SALES_CHANNELS",
        completed_steps=[], payload={}, status="in_progress", version=1,
        expires_at=datetime.now(timezone.utc) + timedelta(days=7),
    )
    values.update(kw)
    return OnboardingSession(**values)


def _history(merchant_id, plan_id) -> MerchantTrialHistory:
    return MerchantTrialHistory(merchant_account_id=merchant_id, subscription_plan_id=plan_id, status="trialing")


@pytest.mark.asyncio
async def test_second_trial_history_row_for_the_same_merchant_is_rejected(db_session: AsyncSession):
    merchant = MerchantAccount(name="Trial Merchant")
    plan_a, plan_b = _plan(f"zz_a_{uuid.uuid4().hex[:8]}"), _plan(f"zz_b_{uuid.uuid4().hex[:8]}")
    db_session.add_all([merchant, plan_a, plan_b])
    await db_session.flush()
    db_session.add(_history(merchant.id, plan_a.id))
    await db_session.flush()
    # Switching tier must not obtain another trial.
    with pytest.raises(IntegrityError):
        async with db_session.begin_nested():
            db_session.add(_history(merchant.id, plan_b.id))
            await db_session.flush()


@pytest.mark.asyncio
async def test_duplicate_detection_reports_merchants_before_the_constraint_is_added(db_session: AsyncSession):
    spec = importlib.util.spec_from_file_location("migration_049", MIGRATION_PATH)
    migration = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(migration)

    merchant = MerchantAccount(name="Legacy Duplicate Merchant")
    plan = _plan(f"zz_dup_{uuid.uuid4().hex[:8]}")
    db_session.add_all([merchant, plan])
    await db_session.flush()
    # DDL is transactional in PostgreSQL: lift the constraint inside this (rolled-back) transaction.
    await db_session.execute(text("ALTER TABLE merchant_trial_history DROP CONSTRAINT uq_merchant_trial_history_merchant"))
    db_session.add_all([_history(merchant.id, plan.id), _history(merchant.id, plan.id)])
    await db_session.flush()

    found = await db_session.run_sync(lambda sync: migration.find_duplicate_trial_merchants(sync.connection()))
    assert (str(merchant.id), 2) in found


@pytest.mark.asyncio
async def test_concurrent_trial_attempts_produce_exactly_one_history_row():
    """Real parallel transactions on separate connections, not a single shared session."""
    url = os.environ.get("DATABASE_URL")
    if not url:
        pytest.skip("DATABASE_URL required")
    engine = create_async_engine(normalize_async_database_url(url), pool_size=10)
    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    code = f"zz_conc_{uuid.uuid4().hex[:8]}"
    async with factory() as setup:
        merchant, plan = MerchantAccount(name="Concurrent Trial Merchant"), _plan(code)
        setup.add_all([merchant, plan])
        await setup.commit()
        merchant_id, plan_id = merchant.id, plan.id

    async def attempt() -> bool:
        async with factory() as session:
            try:
                session.add(_history(merchant_id, plan_id))
                await session.commit()
                return True
            except IntegrityError:
                await session.rollback()
                return False

    try:
        results = await asyncio.gather(*[attempt() for _ in range(8)])
        assert results.count(True) == 1 and results.count(False) == 7
        async with factory() as check:
            rows = (await check.execute(select(MerchantTrialHistory).where(MerchantTrialHistory.merchant_account_id == merchant_id))).scalars().all()
            assert len(rows) == 1
    finally:
        async with factory() as cleanup:
            await cleanup.execute(delete(MerchantAccount).where(MerchantAccount.id == merchant_id))
            await cleanup.execute(delete(SubscriptionPlan).where(SubscriptionPlan.id == plan_id))
            await cleanup.commit()
        await engine.dispose()


@pytest.mark.asyncio
async def test_idempotency_key_constraints(db_session: AsyncSession):
    session = _session()
    db_session.add(session)
    await db_session.flush()
    good = dict(session_id=session.id, key="k" * 20, operation="launch", actor="user:1", request_hash="a" * 64,
                expires_at=datetime.now(timezone.utc) + timedelta(days=14))
    db_session.add(OnboardingIdempotencyKey(**good))
    await db_session.flush()

    for bad in (
        dict(good),                                   # duplicate (session_id, key)
        {**good, "key": "short"},                     # key too short
        {**good, "key": "z" * 20, "request_hash": "b" * 10},   # bad hash length
        {**good, "key": "y" * 20, "status": "completed"},       # completed without a result
    ):
        with pytest.raises(IntegrityError):
            async with db_session.begin_nested():
                db_session.add(OnboardingIdempotencyKey(**bad))
                await db_session.flush()

    db_session.add(OnboardingIdempotencyKey(**{**good, "key": "w" * 20, "status": "completed", "response_status": 200, "response_body": {"ok": True}}))
    await db_session.flush()


@pytest.mark.asyncio
async def test_slug_claim_live_reservation_blocks_others_but_not_the_owner(db_session: AsyncSession):
    first, second = _session(), _session()
    db_session.add_all([first, second])
    await db_session.flush()
    slug = f"shop-{uuid.uuid4().hex[:8]}"
    assert await claim_slug(db_session, session_id=first.id, slug=slug) is SlugClaim.CLAIMED
    assert await claim_slug(db_session, session_id=first.id, slug=slug.upper()) is SlugClaim.CLAIMED   # renew, case-insensitive
    assert await claim_slug(db_session, session_id=second.id, slug=slug) is SlugClaim.RESERVED_BY_OTHER


@pytest.mark.asyncio
async def test_expired_reservation_never_blocks_and_is_replaced(db_session: AsyncSession):
    first, second = _session(), _session()
    db_session.add_all([first, second])
    await db_session.flush()
    slug = f"expired-{uuid.uuid4().hex[:8]}"
    assert await claim_slug(db_session, session_id=first.id, slug=slug) is SlugClaim.CLAIMED
    await db_session.execute(update(OnboardingSlugReservation).where(OnboardingSlugReservation.slug_normalized == slug)
                             .values(expires_at=datetime.now(timezone.utc) - timedelta(minutes=1)))
    assert await claim_slug(db_session, session_id=second.id, slug=slug) is SlugClaim.CLAIMED
    holder = (await db_session.execute(select(OnboardingSlugReservation.session_id).where(OnboardingSlugReservation.slug_normalized == slug))).scalar_one()
    assert holder == second.id


@pytest.mark.asyncio
async def test_changing_slug_releases_the_previous_one_and_existing_storefront_slug_is_taken(db_session: AsyncSession):
    owner, other = _session(), _session()
    db_session.add_all([owner, other])
    await db_session.flush()
    first_slug, second_slug = f"one-{uuid.uuid4().hex[:8]}", f"two-{uuid.uuid4().hex[:8]}"
    assert await claim_slug(db_session, session_id=owner.id, slug=first_slug) is SlugClaim.CLAIMED
    assert await claim_slug(db_session, session_id=owner.id, slug=second_slug) is SlugClaim.CLAIMED
    assert await claim_slug(db_session, session_id=other.id, slug=first_slug) is SlugClaim.CLAIMED   # released

    taken_slug = f"live-{uuid.uuid4().hex[:8]}"
    db_session.add(Tenant(slug=taken_slug, status="active"))
    await db_session.flush()
    assert await claim_slug(db_session, session_id=other.id, slug=taken_slug.upper()) is SlugClaim.TAKEN


@pytest.mark.asyncio
async def test_concurrent_slug_claims_have_exactly_one_winner():
    url = os.environ.get("DATABASE_URL")
    if not url:
        pytest.skip("DATABASE_URL required")
    engine = create_async_engine(normalize_async_database_url(url), pool_size=10)
    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    slug = f"race-{uuid.uuid4().hex[:8]}"
    ids = []
    async with factory() as setup:
        sessions = [_session() for _ in range(6)]
        setup.add_all(sessions)
        await setup.commit()
        ids = [s.id for s in sessions]

    async def attempt(session_id) -> SlugClaim:
        async with factory() as db:
            result = await claim_slug(db, session_id=session_id, slug=slug)
            await db.commit()
            return result

    try:
        results = await asyncio.gather(*[attempt(i) for i in ids])
        assert results.count(SlugClaim.CLAIMED) == 1
        assert results.count(SlugClaim.RESERVED_BY_OTHER) == 5
    finally:
        async with factory() as cleanup:
            await cleanup.execute(delete(OnboardingSlugReservation).where(OnboardingSlugReservation.slug_normalized == slug))
            await cleanup.execute(delete(OnboardingSession).where(OnboardingSession.id.in_(ids)))
            await cleanup.commit()
        await engine.dispose()
