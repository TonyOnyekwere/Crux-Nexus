"""The limiter must actually limit (it previously never applied a single limit). Uses a dedicated app and an
in-memory limiter so no Redis is needed. Requires fastapi, slowapi, httpx (CI)."""
import pytest
from fastapi import FastAPI, Request
from httpx import ASGITransport, AsyncClient
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.infrastructure.rate_limiter import key_ip, key_webhook_token, rate_limit_exceeded_handler


def make_app():
    limiter = Limiter(key_func=key_ip, default_limits=["1000/minute"], storage_uri="memory://", enabled=True)
    app = FastAPI()
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)
    app.add_middleware(SlowAPIMiddleware)

    @app.post("/login")
    @limiter.limit("3/minute", key_func=key_ip)
    async def login(request: Request):
        return {"ok": True}

    @app.post("/hook/{webhook_token}")
    @limiter.limit("2/minute", key_func=key_webhook_token)
    async def hook(request: Request, webhook_token: str):
        return {"ok": True}

    return app


@pytest.mark.asyncio
async def test_limit_is_enforced_with_a_valid_429_and_retry_after():
    async with AsyncClient(transport=ASGITransport(app=make_app()), base_url="http://t") as c:
        codes = [(await c.post("/login")).status_code for _ in range(5)]
        assert codes == [200, 200, 200, 429, 429]
        r = await c.post("/login")
        assert r.status_code == 429 and r.headers["retry-after"] == "60"
        assert r.json()["detail"]["error"]["code"] == "RATE_LIMITED"


@pytest.mark.asyncio
async def test_spoofed_forwarded_for_header_cannot_dodge_the_limit():
    async with AsyncClient(transport=ASGITransport(app=make_app()), base_url="http://t") as c:
        codes = []
        for i in range(5):  # one trusted hop: only the rightmost entry counts, whatever the client prepends
            r = await c.post("/login", headers={"X-Forwarded-For": f"10.9.9.{i}, 203.0.113.7"})
            codes.append(r.status_code)
        assert codes == [200, 200, 200, 429, 429]


@pytest.mark.asyncio
async def test_webhook_buckets_are_per_merchant_so_one_noisy_connection_does_not_throttle_another():
    async with AsyncClient(transport=ASGITransport(app=make_app()), base_url="http://t") as c:
        noisy = [(await c.post("/hook/tokenA")).status_code for _ in range(4)]
        assert noisy == [200, 200, 429, 429]
        assert (await c.post("/hook/tokenB")).status_code == 200      # unrelated merchant unaffected
