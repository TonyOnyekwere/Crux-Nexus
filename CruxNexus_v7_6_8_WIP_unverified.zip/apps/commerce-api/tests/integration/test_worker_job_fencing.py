"""Worker job lease fencing against a real PostgreSQL (CI). Independent sessions, no shared connection.

Proves: a worker whose lease expired (or was taken over) cannot mark the job succeeded or failed, its
transaction is rolled back, and the rightful owner still can. Not runnable without a database.
"""
import pytest
from sqlalchemy import text

from app.infrastructure.worker_jobs import LeaseLostError, WorkerJob, claim_job, complete_job, enqueue_job, fail_job
from tests.conftest import TestSessionLocal


async def _new_job(job_type="fencing-test"):
    async with TestSessionLocal() as s:
        job = await enqueue_job(s, job_type, {})
        await s.commit()
        return job.id


async def _claim(worker):
    async with TestSessionLocal() as s:
        job = await claim_job(s, worker, lease_seconds=120)
        await s.commit()
        return job


async def _expire_lease(job_id):
    async with TestSessionLocal() as s:
        await s.execute(text("UPDATE worker_jobs SET lease_until = now() - interval '1 second' WHERE id = :i"), {"i": job_id})
        await s.commit()


async def _state(job_id):
    async with TestSessionLocal() as s:
        row = (await s.execute(text("SELECT status, locked_by, attempts FROM worker_jobs WHERE id=:i"), {"i": job_id})).one()
        return row


@pytest.mark.asyncio
async def test_owner_with_valid_lease_completes():
    job_id = await _new_job()
    job = await _claim("A")
    async with TestSessionLocal() as s:
        row = (await s.execute(text("SELECT 1"))).scalar()
        from sqlalchemy import select
        fresh = (await s.execute(select(WorkerJob).where(WorkerJob.id == job.id))).scalar_one()
        await complete_job(s, fresh)
        await s.commit()
    assert (await _state(job_id)).status == "succeeded"


@pytest.mark.asyncio
async def test_worker_with_expired_lease_cannot_complete():
    job_id = await _new_job()
    job = await _claim("A")
    await _expire_lease(job_id)
    async with TestSessionLocal() as s:
        from sqlalchemy import select
        stale = (await s.execute(select(WorkerJob).where(WorkerJob.id == job.id))).scalar_one()
        with pytest.raises(LeaseLostError):
            await complete_job(s, stale)
        await s.rollback()
    assert (await _state(job_id)).status == "running"   # not marked succeeded by the stale worker


@pytest.mark.asyncio
async def test_reclaimed_job_cannot_be_completed_or_failed_by_the_previous_owner():
    job_id = await _new_job()
    a = await _claim("A")
    await _expire_lease(job_id)
    b = await _claim("B")                      # B legitimately reclaims the expired lease
    assert b is not None and b.id == a.id and b.locked_by == "B" and b.lease_token != a.lease_token
    from sqlalchemy import select
    async with TestSessionLocal() as s:
        stale = (await s.execute(select(WorkerJob).where(WorkerJob.id == job_id))).scalar_one()
        stale.locked_by, stale.lease_token = "A", a.lease_token      # what worker A still believes
        with pytest.raises(LeaseLostError):
            await complete_job(s, stale)
        with pytest.raises(LeaseLostError):
            await fail_job(s, stale, "late failure")
        await s.rollback()
    state = await _state(job_id)
    assert state.status == "running" and state.locked_by == "B"
    async with TestSessionLocal() as s:
        owner = (await s.execute(select(WorkerJob).where(WorkerJob.id == job_id))).scalar_one()
        await complete_job(s, owner)
        await s.commit()
    assert (await _state(job_id)).status == "succeeded"


@pytest.mark.asyncio
async def test_failure_by_the_owner_schedules_retry_then_dead_letter():
    job_id = await _new_job()
    from sqlalchemy import select
    for attempt in range(1, 9):
        async with TestSessionLocal() as s:
            job = await claim_job(s, "A")
            if job is None:      # retry delay not elapsed yet: make it due
                await s.rollback()
                async with TestSessionLocal() as t:
                    await t.execute(text("UPDATE worker_jobs SET available_at = now() - interval '1 second' WHERE id=:i"), {"i": job_id})
                    await t.commit()
                job = await claim_job(s, "A")
            await s.commit()
        async with TestSessionLocal() as s:
            row = (await s.execute(select(WorkerJob).where(WorkerJob.id == job_id))).scalar_one()
            await fail_job(s, row, f"boom {attempt}")
            await s.commit()
    assert (await _state(job_id)).status == "dead"
