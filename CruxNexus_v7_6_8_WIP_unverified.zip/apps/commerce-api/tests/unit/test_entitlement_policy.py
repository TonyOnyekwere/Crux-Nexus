"""Pure tests: tier capabilities/limits, downgrade preservation, presentation validation."""
import importlib.util
import pathlib
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[2]


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ep = load("entitlement_policy", "app/kernel/access/entitlement_policy.py")
pr = load("presentation_rules", "app/contexts/commerce/domain/presentation_rules.py")
FULL, RESTRICTED, BLOCKED = ep.Standing.FULL, ep.Standing.RESTRICTED, ep.Standing.BLOCKED


def policy(caps=(), limits=None, **kw):
    return ep.effective_policy(plan_capabilities=list(caps), plan_limits=limits or {}, **kw)


# ---- standing
def test_standing_from_subscription_status():
    assert ep.standing_for_subscription("active") is FULL and ep.standing_for_subscription("trialing") is FULL
    assert ep.standing_for_subscription("past_due") is RESTRICTED
    for st in ("suspended", "cancelled", "expired", "payment_pending", "trial_expired", None, "weird"):
        assert ep.standing_for_subscription(st) is BLOCKED


# ---- capabilities (data, not code)
def test_capability_denied_by_default_and_granted_by_plan_data():
    assert not ep.can_use_capability(policy(), FULL, "storefront.custom_domain")
    assert ep.can_use_capability(policy(["storefront.custom_domain"]), FULL, "storefront.custom_domain")
    # dict form {"cap": true}, as stored in JSONB; false/non-true values do not grant
    p = ep.effective_policy(plan_capabilities={"a": True, "b": False, "c": "yes"}, plan_limits={})
    assert p.has("a") and not p.has("b") and not p.has("c")


def test_new_capability_key_needs_no_code_change():
    assert ep.can_use_capability(policy(["brand.new.capability.next.year"]), FULL, "brand.new.capability.next.year")


def test_blocked_subscription_denies_everything():
    p = policy(["x"], {"products": 100})
    assert ep.can_use_capability(p, BLOCKED, "x").code == "SUBSCRIPTION_BLOCKED"
    assert ep.can_consume_limit(p, BLOCKED, "products", current=0).code == "SUBSCRIPTION_BLOCKED"


def test_past_due_keeps_existing_use_but_blocks_new_use():
    p = policy(["x"], {"products": 100})
    assert ep.can_use_capability(p, RESTRICTED, "x", new_use=False)
    assert ep.can_use_capability(p, RESTRICTED, "x", new_use=True).code == "PLAN_RESTRICTED"
    assert ep.can_consume_limit(p, RESTRICTED, "products", current=1).code == "PLAN_RESTRICTED"


# ---- limits
def test_limit_boundary_and_unlimited_and_zero():
    p = policy(limits={"products": 10, "staff": 0})
    assert ep.can_consume_limit(p, FULL, "products", current=9)
    assert ep.can_consume_limit(p, FULL, "products", current=10).code == "LIMIT_REACHED"
    assert ep.can_consume_limit(p, FULL, "staff", current=0).code == "LIMIT_REACHED"
    assert ep.can_consume_limit(p, FULL, "orders", current=10**9)  # no limit configured = unlimited
    assert ep.can_consume_limit(policy(limits={"products": None}), FULL, "products", current=10**9)


def test_malformed_limits_fail_closed():
    p = policy(limits={"a": -5, "b": "ten", "c": True, "d": 3.5})
    for k in "abcd":
        assert ep.can_consume_limit(p, FULL, k, current=0).code == "LIMIT_REACHED"


def test_over_limit_after_downgrade_blocks_new_but_never_requires_deletion():
    p = policy(limits={"products": 5})
    d = ep.can_consume_limit(p, FULL, "products", current=40)  # merchant already has 40 from a higher tier
    assert not d and d.details["current"] == 40
    # nothing in the engine deletes/hides: usage above the limit is simply no longer growable


def test_absolute_depth_limit():
    p = policy(limits={"storefront.component_slots": 3})
    assert ep.check_absolute_limit(p, FULL, "storefront.component_slots", requested_total=3)
    assert ep.check_absolute_limit(p, FULL, "storefront.component_slots", requested_total=4).code == "LIMIT_REACHED"


def test_addon_extends_only_limits_the_plan_set():
    p = ep.effective_policy(plan_capabilities=[], plan_limits={"staff": 2},
                            addon_capabilities=["storefront.custom_domain"],
                            addon_limit_bonus={"staff": 3, "products": 99})
    assert p.has("storefront.custom_domain") and p.limit("staff") == 5 and p.limit("products") is None


# ---- downgrade lifecycle: preserve, disable further use, auto-restore
def test_feature_state_machine_preserves_and_restores():
    caps = ["storefront.custom_domain"]
    c = "storefront.custom_domain"
    assert ep.feature_state(policy(caps), FULL, c, configured=True) == ep.ACTIVE
    # downgrade: no longer entitled -> preserved but inert
    assert ep.feature_state(policy(), FULL, c, configured=True) == ep.PRESERVED_INACTIVE
    assert ep.feature_state(policy(), FULL, c, configured=False) == ep.UNAVAILABLE
    # upgrade again: same configured data is active again with no migration
    assert ep.feature_state(policy(caps), FULL, c, configured=True) == ep.ACTIVE
    # lapse
    assert ep.feature_state(policy(caps), RESTRICTED, c, configured=True) == ep.READ_ONLY
    assert ep.feature_state(policy(caps), BLOCKED, c, configured=True) == ep.SUSPENDED
    assert ep.feature_state(policy(), FULL, c, configured=True) not in ep.RENDERING_STATES
    assert ep.feature_state(policy(caps), RESTRICTED, c, configured=True) in ep.RENDERING_STATES


# ---- presentation validation
def test_required_capabilities_only_for_parts_being_set():
    assert pr.required_capabilities() == set()
    assert pr.required_capabilities(theme={}) == {pr.CAP_THEME}
    assert pr.required_capabilities(slots={}, css="a{}") == {pr.CAP_SLOTS, pr.CAP_CSS}


@pytest.mark.parametrize("css", [
    "@import 'x.css';", "a{background:url(http://evil/x)}", "a{width:expression(alert(1))}",
    "a{behavior:url(x)}", "a{-moz-binding:url(x)}", "</style><script>alert(1)</script>",
    "a{background:javascript:alert(1)}", "a{content:'\\41'}", "@font-face{font-family:x}",
    "a{position:fixed}", "a{color:red", "a{background:image-set('x' 1x)}",
])
def test_hostile_css_rejected(css):
    with pytest.raises(pr.PresentationError):
        pr.validate_css(css)


def test_safe_css_accepted_and_size_capped():
    assert pr.validate_css(".hero{color:#333;padding:8px}") is not None
    assert pr.validate_css("   ") is None and pr.validate_css(None) is None
    with pytest.raises(pr.PresentationError):
        pr.validate_css("a{color:red}" * 5000, max_bytes=1000)
    with pytest.raises(pr.PresentationError):  # plan limit cannot exceed the hard ceiling
        pr.validate_css("a{color:red}" * 20000, max_bytes=10**9)


def test_theme_fonts_layout_slots_validation():
    assert pr.validate_theme({"primary": "#112233", "radius": 8})
    for bad in ({"Bad Key": "x"}, {"primary": "red;}</style>"}, {"p": {"nested": 1}}):
        with pytest.raises(pr.PresentationError):
            pr.validate_theme(bad)
    assert pr.validate_fonts({"heading": "Playfair Display", "body": "Inter"})
    for bad in ({"body": "Inter, sans-serif; x"}, {"body": "x" * 80}, {"body": 5}):
        with pytest.raises(pr.PresentationError):
            pr.validate_fonts(bad)
    assert pr.validate_slots({"hero": {"type": "banner"}})
    with pytest.raises(pr.PresentationError):
        pr.validate_slots({"Hero!": {}})
    with pytest.raises(pr.PresentationError):
        pr.validate_theme({"k": "v" * 40_000})


def test_custom_domain_normalization():
    assert pr.normalize_hostname(" Shop.Example.COM. ") == "shop.example.com"
    for bad in ("", "localhost", "10.0.0.1", "http://a.com", "a.com/path", "*.a.com", "a_b.com", "-a.com", "a.c",
                "user@a.com", "a.com:8080", "x" * 300 + ".com"):
        with pytest.raises(pr.PresentationError):
            pr.normalize_hostname(bad)
    with pytest.raises(pr.PresentationError):
        pr.normalize_hostname("evil.cruxnexus.app", platform_domains=("cruxnexus.app",))
    with pytest.raises(pr.PresentationError):
        pr.normalize_hostname("cruxnexus.app", platform_domains=("cruxnexus.app",))


# ---- add-on entitlements (generalized: opaque keys, Control Center states what a grant gives)
from datetime import datetime, timedelta, timezone

NOW = datetime(2026, 10, 5, 12, 0, tzinfo=timezone.utc)
DOMAIN_GRANT = {"capabilities": ["storefront.custom_domain"], "limits": {"storefront.custom_domains": 1}}


def ent(**kw):
    base = dict(status="active", starts_at=NOW - timedelta(days=1), ends_at=None, quantity=1, grant_metadata=DOMAIN_GRANT)
    base.update(kw)
    return base


def test_addon_grants_capability_and_per_unit_limit_times_quantity():
    caps, bonus = ep.addon_grants([ent(quantity=3)], now=NOW)
    assert caps == {"storefront.custom_domain"} and bonus == {"storefront.custom_domains": 3}


def test_starter_buys_custom_domain_and_gains_the_capability_enterprise_already_has_it():
    starter = ep.effective_policy(plan_capabilities=[], plan_limits={"storefront.custom_domains": 0})
    assert not ep.can_use_capability(starter, FULL, "storefront.custom_domain")
    caps, bonus = ep.addon_grants([ent()], now=NOW)
    bought = ep.effective_policy(plan_capabilities=[], plan_limits={"storefront.custom_domains": 0},
                                 addon_capabilities=caps, addon_limit_bonus=bonus)
    assert ep.can_use_capability(bought, FULL, "storefront.custom_domain")
    assert bought.limit("storefront.custom_domains") == 1
    assert ep.can_consume_limit(bought, FULL, "storefront.custom_domains", current=0)
    assert not ep.can_consume_limit(bought, FULL, "storefront.custom_domains", current=1)


def test_time_window_and_status_are_enforced_synchronously():
    for bad in (ent(status="expired"), ent(status="cancelled"), ent(starts_at=NOW + timedelta(days=1)),
                ent(ends_at=NOW), ent(ends_at=NOW - timedelta(seconds=1))):
        assert ep.addon_grants([bad], now=NOW) == (set(), {})
    assert ep.addon_grants([ent(ends_at=NOW + timedelta(days=30))], now=NOW)[0]


def test_malformed_grants_grant_nothing():
    for bad in (ent(grant_metadata=None), ent(grant_metadata="x"), ent(quantity=0), ent(quantity=-2), ent(quantity=True),
                ent(grant_metadata={"capabilities": "storefront.custom_domain", "limits": [1]}),
                ent(grant_metadata={"limits": {"k": -5}}), ent(grant_metadata={"limits": {"k": True}})):
        assert ep.addon_grants([bad], now=NOW) == (set(), {})


def test_legacy_rows_with_no_metadata_have_no_policy_effect():
    assert ep.addon_grants([ent(grant_metadata={})], now=NOW) == (set(), {})


def test_new_addon_key_requires_no_code_change():
    meta = {"capabilities": ["analytics.advanced"], "limits": {"storage.bytes": 10_000_000_000}}
    caps, bonus = ep.addon_grants([ent(grant_metadata=meta, quantity=2)], now=NOW)
    assert caps == {"analytics.advanced"} and bonus == {"storage.bytes": 20_000_000_000}


def test_bonus_never_bounds_a_limit_the_plan_left_unlimited():
    p = ep.effective_policy(plan_capabilities=[], plan_limits={}, addon_limit_bonus={"products": 99})
    assert p.limit("products") is None


def test_downgrade_keeps_domain_config_inert_then_restores_on_purchase():
    c = "storefront.custom_domain"
    lapsed = ep.effective_policy(plan_capabilities=[], plan_limits={})
    assert ep.feature_state(lapsed, FULL, c, configured=True) == ep.PRESERVED_INACTIVE
    caps, bonus = ep.addon_grants([ent()], now=NOW)
    restored = ep.effective_policy(plan_capabilities=[], plan_limits={}, addon_capabilities=caps, addon_limit_bonus=bonus)
    assert ep.feature_state(restored, FULL, c, configured=True) == ep.ACTIVE
