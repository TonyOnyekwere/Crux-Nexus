"""Regression checks for the outbox ORM/schema transport metadata contract."""

from app.infrastructure.outbox.repository import OutboxEvent


def test_outbox_transport_columns_exist():
    columns = OutboxEvent.__table__.c
    assert "transport_id" in columns
    assert "attempt_count" in columns
    assert "last_error" in columns
