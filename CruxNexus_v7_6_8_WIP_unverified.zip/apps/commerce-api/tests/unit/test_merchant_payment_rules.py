"""Pure tests: merchant-owned payment credentials validation and checkout availability."""
import importlib.util
import pathlib
import sys

import pytest

_p = pathlib.Path(__file__).resolve().parents[2] / "app/contexts/commerce/domain/merchant_payment_rules.py"
_spec = importlib.util.spec_from_file_location("merchant_payment_rules", _p)
m = importlib.util.module_from_spec(_spec)
sys.modules["merchant_payment_rules"] = m
_spec.loader.exec_module(m)


def test_paystack_credentials_accepted_and_mode_detected():
    clean, mode = m.validate_credentials("paystack", {"secret_key": " sk_live_abcdefghij1234 "}, allow_test_keys=True)
    assert clean == {"secret_key": "sk_live_abcdefghij1234"} and mode == "live"
    assert m.validate_credentials("Paystack", {"secret_key": "sk_test_abcdefghij1234"}, allow_test_keys=True)[1] == "test"


def test_flutterwave_requires_secret_and_webhook_hash():
    ok = {"secret_key": "FLWSECK-abcdefghij1234-X", "webhook_secret_hash": "my-hash-1234"}
    clean, mode = m.validate_credentials("flutterwave", ok, allow_test_keys=True)
    assert mode == "live" and clean["webhook_secret_hash"] == "my-hash-1234"
    assert m.validate_credentials("flutterwave", {**ok, "secret_key": "FLWSECK_TEST-abcdefghij1234"}, allow_test_keys=True)[1] == "test"
    with pytest.raises(m.CredentialValidationError):
        m.validate_credentials("flutterwave", {"secret_key": ok["secret_key"]}, allow_test_keys=True)
    with pytest.raises(m.CredentialValidationError):
        m.validate_credentials("flutterwave", {**ok, "webhook_secret_hash": "short"}, allow_test_keys=True)


def test_test_keys_are_refused_in_production():
    with pytest.raises(m.CredentialValidationError):
        m.validate_credentials("paystack", {"secret_key": "sk_test_abcdefghij1234"}, allow_test_keys=False)
    assert m.validate_credentials("paystack", {"secret_key": "sk_live_abcdefghij1234"}, allow_test_keys=False)[1] == "live"


def test_malformed_unknown_and_extra_inputs_rejected_without_echoing_the_secret():
    bad = [("paystack", {}), ("paystack", {"secret_key": ""}), ("paystack", {"secret_key": 12345}),
           ("paystack", {"secret_key": "pk_live_abcdefghij1234"}), ("paystack", {"secret_key": "sk_live_x"}),
           ("paystack", {"secret_key": "sk_live_abcdefghij1234", "extra": "x"}),
           ("stripe", {"secret_key": "sk_live_abcdefghij1234"}), ("", {})]
    for provider, payload in bad:
        with pytest.raises(m.CredentialValidationError) as exc:
            m.validate_credentials(provider, payload, allow_test_keys=True)
        assert "sk_live_abcdefghij1234" not in str(exc.value)


def test_webhook_tokens_are_unguessable_and_unique():
    tokens = {m.generate_webhook_token() for _ in range(200)}
    assert len(tokens) == 200 and all(len(t) >= 40 and len(t) <= 64 for t in tokens)
    assert m.webhook_path("abc") == "/api/v1/payments/webhooks/abc"
