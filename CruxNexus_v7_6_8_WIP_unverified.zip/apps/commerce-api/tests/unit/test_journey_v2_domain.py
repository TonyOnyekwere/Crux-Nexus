"""WP2: v2 journey stage machine. Pure; no database. Exhaustive where the space is small."""

import itertools

import pytest

from app.contexts.onboarding.domain.journey_v2 import (
    ANONYMOUS_STEPS,
    OPTIONAL_STEPS,
    STAGE_ORDER,
    STEP_STAGE,
    Facts,
    InvalidV2TransitionError,
    StepNotAllowedError,
    StepNotOptionalError,
    V2Action,
    V2Event,
    V2Stage,
    V2Step,
    allowed_actions,
    allowed_steps,
    apply_event,
    is_entitled_stage,
    next_action,
    plan_action,
    plan_step_skip,
    plan_step_submit,
    stage_index,
)

ALL_FACT_COMBOS = [
    Facts(review_clean=a, trial_available=b, payment_retry_allowed=c, launch_lease_live=d)
    for a, b, c, d in itertools.product([False, True], repeat=4)
]


def _authenticated(stage: V2Stage) -> bool:
    return stage_index(stage) > stage_index(V2Stage.ACCOUNT)


def _walk_to(stage: V2Stage, *, trial: bool) -> V2Stage:
    """Drives the legal path from the first stage to ``stage`` using only server-permitted moves."""
    current = V2Stage.SALES_CHANNELS
    while current is not stage:
        facts = Facts(review_clean=True, trial_available=trial)
        if allowed_steps(current, authenticated=_authenticated(current)) and current not in (
            V2Stage.ACCOUNT, V2Stage.VERIFICATION, V2Stage.REVIEW, V2Stage.TIER_SELECTION,
            V2Stage.SUBSCRIPTION_CHOICE, V2Stage.PAYMENT_PENDING, V2Stage.READY_TO_LAUNCH, V2Stage.LAUNCHING,
        ):
            step = next(s for s in V2Step if s.value == current.value.lower())
            current = plan_step_submit(current, step, authenticated=_authenticated(current)).stage
        elif current is V2Stage.ACCOUNT:
            current = plan_action(current, V2Action.REGISTER, facts)
        elif current is V2Stage.VERIFICATION:
            current = plan_action(current, V2Action.VERIFY_OTP, facts)
        elif current is V2Stage.REVIEW:
            current = plan_action(current, V2Action.CONFIRM_REVIEW, facts)
        elif current is V2Stage.TIER_SELECTION:
            current = plan_action(current, V2Action.SELECT_PLAN, facts)
        elif current is V2Stage.SUBSCRIPTION_CHOICE:
            current = plan_action(current, V2Action.START_TRIAL if trial else V2Action.START_PAYMENT, facts)
        elif current is V2Stage.PAYMENT_PENDING:
            current = apply_event(current, V2Event.PAYMENT_CONFIRMED)
        elif current is V2Stage.READY_TO_LAUNCH:
            current = plan_action(current, V2Action.LAUNCH, facts)
        elif current is V2Stage.LAUNCHING:
            current = apply_event(current, V2Event.LAUNCH_SUCCEEDED)
    return current


def test_stage_order_matches_the_frozen_contract():
    assert [s.value for s in STAGE_ORDER] == [
        "SALES_CHANNELS", "CATEGORY", "BUSINESS_INFO", "ACCOUNT", "VERIFICATION", "CONTACT", "PAYMENT_SETUP",
        "DELIVERY_SETUP", "FIRST_PRODUCT", "BRANDING", "REVIEW", "TIER_SELECTION", "SUBSCRIPTION_CHOICE",
        "PAYMENT_PENDING", "READY_TO_LAUNCH", "LAUNCHING", "COMPLETED",
    ]


def test_trial_path_reaches_completed_through_every_required_gate():
    assert _walk_to(V2Stage.COMPLETED, trial=True) is V2Stage.COMPLETED


def test_paid_path_reaches_completed_only_via_a_server_event():
    assert _walk_to(V2Stage.COMPLETED, trial=False) is V2Stage.COMPLETED
    assert plan_action(V2Stage.SUBSCRIPTION_CHOICE, V2Action.START_PAYMENT) is V2Stage.PAYMENT_PENDING
    assert apply_event(V2Stage.PAYMENT_PENDING, V2Event.PAYMENT_CONFIRMED) is V2Stage.READY_TO_LAUNCH


def test_every_action_not_listed_as_allowed_is_rejected_at_every_stage():
    for stage in STAGE_ORDER:
        for facts in ALL_FACT_COMBOS:
            allowed = allowed_actions(stage, facts)
            for action in V2Action:
                if action in (V2Action.SUBMIT_STEP, V2Action.SKIP_STEP) or action in allowed:
                    continue
                with pytest.raises(InvalidV2TransitionError):
                    plan_action(stage, action, facts)


def test_every_listed_action_produces_a_stage_no_further_than_one_step_ahead():
    for stage in STAGE_ORDER:
        for facts in ALL_FACT_COMBOS:
            for action in allowed_actions(stage, facts):
                if action in (V2Action.SUBMIT_STEP, V2Action.SKIP_STEP):
                    continue
                result = plan_action(stage, action, facts)
                assert stage_index(result) - stage_index(stage) in (0, 1, 2)


def test_no_path_reaches_an_entitled_stage_without_verification_review_and_a_subscription_basis():
    """Breadth-first search over every legal move (steps, skips, actions, server events)."""
    for facts in ALL_FACT_COMBOS:
        start = (V2Stage.SALES_CHANNELS, frozenset())
        seen, frontier = {start}, [start]
        while frontier:
            stage, hist = frontier.pop()
            auth = _authenticated(stage)
            moves = []
            for step in allowed_steps(stage, authenticated=auth):
                moves.append((plan_step_submit(stage, step, authenticated=auth).stage, hist))
                if step in OPTIONAL_STEPS:
                    moves.append((plan_step_skip(stage, step, authenticated=auth).stage, hist))
            for action in allowed_actions(stage, facts, authenticated=auth):
                if action in (V2Action.SUBMIT_STEP, V2Action.SKIP_STEP):
                    continue
                label = {"register", "verify_otp", "confirm_review", "start_trial", "start_payment"} & {action.value}
                moves.append((plan_action(stage, action, facts), hist | frozenset(label)))
            for event in V2Event:
                try:
                    moves.append((apply_event(stage, event), hist | ({"payment_confirmed"} if event is V2Event.PAYMENT_CONFIRMED else set())))
                except InvalidV2TransitionError:
                    pass
            for nxt in moves:
                state = (nxt[0], frozenset(nxt[1]))
                if state not in seen:
                    seen.add(state)
                    frontier.append(state)
        for stage, hist in seen:
            if is_entitled_stage(stage):
                assert {"register", "verify_otp", "confirm_review"} <= hist, (stage, hist)
                assert "start_trial" in hist or "payment_confirmed" in hist, (stage, hist)
                if "start_trial" in hist:
                    assert facts.trial_available
                if "payment_confirmed" in hist:
                    assert "start_payment" in hist


def test_required_steps_cannot_be_skipped_and_optional_ones_can():
    for step in V2Step:
        if step in OPTIONAL_STEPS:
            continue
        with pytest.raises(StepNotOptionalError):
            plan_step_skip(V2Stage.REVIEW, step, authenticated=True)
    assert plan_step_skip(V2Stage.SALES_CHANNELS, V2Step.SALES_CHANNELS, authenticated=False).stage is V2Stage.CATEGORY
    assert plan_step_skip(V2Stage.DELIVERY_SETUP, V2Step.DELIVERY_SETUP, authenticated=True).stage is V2Stage.FIRST_PRODUCT
    assert V2Step.PAYMENT_SETUP not in OPTIONAL_STEPS  # records an explicit decision instead


def test_a_future_step_cannot_be_written_early():
    for stage in STAGE_ORDER:
        for step in V2Step:
            if stage_index(stage) < stage_index(STEP_STAGE[step]):
                with pytest.raises(StepNotAllowedError) as exc:
                    plan_step_submit(stage, step, authenticated=_authenticated(stage))
                assert exc.value.reason in ("future_step", "requires_account")


def test_anonymous_callers_only_reach_pre_account_steps_and_only_until_registration():
    for stage in STAGE_ORDER:
        steps = allowed_steps(stage, authenticated=False)
        if stage_index(stage) > stage_index(V2Stage.ACCOUNT):
            assert steps == []
        else:
            assert set(steps) <= ANONYMOUS_STEPS
    with pytest.raises(StepNotAllowedError) as exc:
        plan_step_submit(V2Stage.CONTACT, V2Step.CATEGORY, authenticated=False)
    assert exc.value.reason == "device_session_retired"


def test_sensitive_steps_require_an_account_even_if_a_stage_could_reach_them():
    with pytest.raises(StepNotAllowedError):
        plan_step_submit(V2Stage.ACCOUNT, V2Step.CONTACT, authenticated=False)


def test_editing_an_earlier_step_follows_the_regression_rules():
    advance = plan_step_submit(V2Stage.CATEGORY, V2Step.CATEGORY, authenticated=False)
    assert advance.kind == "advance" and advance.stage is V2Stage.BUSINESS_INFO and not advance.review_invalidated

    before_review = plan_step_submit(V2Stage.FIRST_PRODUCT, V2Step.CONTACT, authenticated=True)
    assert before_review.kind == "edit" and before_review.stage is V2Stage.FIRST_PRODUCT and not before_review.review_invalidated

    at_review = plan_step_submit(V2Stage.REVIEW, V2Step.BRANDING, authenticated=True)
    assert at_review.stage is V2Stage.REVIEW and at_review.review_invalidated

    for stage in (V2Stage.TIER_SELECTION, V2Stage.SUBSCRIPTION_CHOICE):
        regressed = plan_step_submit(stage, V2Step.BRANDING, authenticated=True)
        assert regressed.stage is V2Stage.REVIEW and regressed.review_invalidated

    for stage in (V2Stage.PAYMENT_PENDING, V2Stage.READY_TO_LAUNCH):
        kept = plan_step_submit(stage, V2Step.BRANDING, authenticated=True)
        assert kept.stage is stage and kept.review_invalidated   # launch re-runs validation


def test_drafts_are_frozen_once_launch_is_claimed():
    for stage in (V2Stage.LAUNCHING, V2Stage.COMPLETED):
        assert allowed_steps(stage, authenticated=True) == []
        with pytest.raises(StepNotAllowedError):
            plan_step_submit(stage, V2Step.BRANDING, authenticated=True)


def test_plan_is_locked_once_payment_is_in_flight_or_the_subscription_is_entitled():
    for stage in (V2Stage.PAYMENT_PENDING, V2Stage.READY_TO_LAUNCH, V2Stage.LAUNCHING, V2Stage.COMPLETED):
        assert V2Action.SELECT_PLAN not in allowed_actions(stage, Facts(trial_available=True))
        assert V2Action.START_TRIAL not in allowed_actions(stage, Facts(trial_available=True))
    assert V2Action.SELECT_PLAN in allowed_actions(V2Stage.SUBSCRIPTION_CHOICE)   # may change before committing


def test_trial_is_offered_only_when_the_server_says_it_is_available():
    assert V2Action.START_TRIAL not in allowed_actions(V2Stage.SUBSCRIPTION_CHOICE, Facts(trial_available=False))
    assert V2Action.START_TRIAL in allowed_actions(V2Stage.SUBSCRIPTION_CHOICE, Facts(trial_available=True))
    with pytest.raises(InvalidV2TransitionError):
        plan_action(V2Stage.SUBSCRIPTION_CHOICE, V2Action.START_TRIAL, Facts(trial_available=False))


def test_payment_retry_is_offered_only_when_no_unresolved_attempt_blocks_it():
    assert V2Action.START_PAYMENT not in allowed_actions(V2Stage.PAYMENT_PENDING, Facts(payment_retry_allowed=False))
    assert V2Action.START_PAYMENT in allowed_actions(V2Stage.PAYMENT_PENDING, Facts(payment_retry_allowed=True))


def test_confirm_review_requires_a_clean_server_review():
    assert V2Action.CONFIRM_REVIEW not in allowed_actions(V2Stage.REVIEW, Facts(review_clean=False))
    assert V2Action.RUN_REVIEW in allowed_actions(V2Stage.REVIEW, Facts(review_clean=False))
    assert next_action(V2Stage.REVIEW, Facts(review_clean=False)) == "run_review"
    assert next_action(V2Stage.REVIEW, Facts(review_clean=True)) == "confirm_review"


def test_server_events_only_apply_from_their_own_stage_and_are_not_client_actions():
    assert "payment_confirmed" not in {a.value for a in V2Action}
    for event in V2Event:
        for stage in STAGE_ORDER:
            try:
                apply_event(stage, event)
            except InvalidV2TransitionError:
                continue
            assert stage in {
                V2Event.PAYMENT_CONFIRMED: {V2Stage.PAYMENT_PENDING},
                V2Event.LAUNCH_SUCCEEDED: {V2Stage.LAUNCHING},
                V2Event.LAUNCH_FAILED: {V2Stage.LAUNCHING},
                V2Event.LAUNCH_LEASE_EXPIRED: {V2Stage.LAUNCHING},
            }[event]


def test_launch_reclaim_is_possible_only_after_the_lease_expires():
    assert V2Action.LAUNCH in allowed_actions(V2Stage.READY_TO_LAUNCH)
    assert V2Action.LAUNCH not in allowed_actions(V2Stage.LAUNCHING, Facts(launch_lease_live=True))
    assert V2Action.LAUNCH in allowed_actions(V2Stage.LAUNCHING, Facts(launch_lease_live=False))
    assert apply_event(V2Stage.LAUNCHING, V2Event.LAUNCH_LEASE_EXPIRED) is V2Stage.READY_TO_LAUNCH
    assert apply_event(V2Stage.LAUNCHING, V2Event.LAUNCH_FAILED) is V2Stage.READY_TO_LAUNCH


def test_completed_is_terminal():
    assert allowed_actions(V2Stage.COMPLETED) == []
    assert allowed_steps(V2Stage.COMPLETED, authenticated=True) == []
    assert next_action(V2Stage.COMPLETED) is None
