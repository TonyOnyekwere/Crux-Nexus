"""Pure tests (no DB, no network) for the canonical order/fulfillment rules.

Regression for the v7.6.3 review: shipping was impossible, pay-on-delivery
orders could not start fulfillment, and shipped orders could be cancelled
(releasing a reservation that had already been consumed at shipment).
Lifecycle: confirmed -> fulfilling -> shipped -> delivered -> completed.
"""
import importlib.util
import pathlib
import sys

import pytest

_p = pathlib.Path(__file__).resolve().parents[2] / "app/contexts/commerce/domain/fulfillment_rules.py"
_spec = importlib.util.spec_from_file_location("fulfillment_rules", _p)
r = importlib.util.module_from_spec(_spec)
sys.modules["fulfillment_rules"] = r  # dataclasses resolve annotations via sys.modules
_spec.loader.exec_module(r)


def plan(order, pay, provider, ful, target):
    return r.plan_fulfillment_change(order_status=order, payment_status=pay, payment_provider=provider,
                                     fulfillment_status=ful, target=target)


def walk(provider, pay):
    order, ful, pay_status, seen = "confirmed", "unfulfilled", pay, []
    for target in ("processing", "shipped", "delivered"):
        p = plan(order, pay_status, provider, ful, target)
        order, ful = p.order_status, p.fulfillment_status
        if p.mark_pod_paid:
            pay_status = "paid"
        seen.append((target, order, p.stock_effect))
    return seen, pay_status


def test_paid_online_order_reaches_delivered():
    seen, pay = walk("paystack", "paid")
    assert seen == [("processing", "fulfilling", "none"), ("shipped", "shipped", "commit"),
                    ("delivered", "delivered", "none")]
    assert pay == "paid"


def test_bank_transfer_after_confirmation_reaches_delivered():
    assert walk("bank_transfer", "paid")[0][-1] == ("delivered", "delivered", "none")


def test_pay_on_delivery_fulfils_before_payment_and_is_paid_on_delivery():
    seen, pay = walk("pay_on_delivery", "pending")
    assert seen[-1] == ("delivered", "delivered", "none")
    assert pay == "paid"


def test_stock_is_deducted_only_at_shipment():
    seen, _ = walk("paystack", "paid")
    assert [s[2] for s in seen] == ["none", "commit", "none"]


def test_unpaid_prepaid_order_cannot_start_or_ship():
    with pytest.raises(r.FulfillmentRuleError):
        plan("confirmed", "pending", "paystack", "unfulfilled", "processing")
    with pytest.raises(r.FulfillmentRuleError):
        plan("fulfilling", "pending", "bank_transfer", "processing", "shipped")


def test_cannot_skip_steps():
    for order, ful, target in [("confirmed", "unfulfilled", "shipped"), ("confirmed", "unfulfilled", "delivered"),
                               ("fulfilling", "processing", "delivered")]:
        with pytest.raises(r.FulfillmentRuleError):
            plan(order, "paid", "paystack", ful, target)


def test_unconfirmed_orders_cannot_enter_fulfillment():
    for st in ("pending_payment", "awaiting_transfer", "payment_failed", "cancelled", "completed"):
        with pytest.raises(r.FulfillmentRuleError):
            plan(st, "paid", "paystack", "unfulfilled", "processing")


def test_terminal_fulfillments_are_frozen():
    for ful in ("delivered", "cancelled"):
        for target in ("processing", "shipped", "unfulfilled", "cancelled"):
            if target == ful:
                continue
            with pytest.raises(r.FulfillmentRuleError):
                plan("delivered", "paid", "paystack", ful, target)


def test_cancel_before_shipment_releases_stock_without_refund_flag_when_unpaid():
    for st, ful in [("pending_payment", "unfulfilled"), ("awaiting_transfer", "unfulfilled"),
                    ("payment_failed", "unfulfilled"), ("confirmed", "unfulfilled"), ("fulfilling", "processing")]:
        p = plan(st, "pending", "paystack", ful, "cancelled")
        assert p.order_status == "cancelled" and p.stock_effect == "release" and not p.flag_refund


def test_cancel_after_shipment_is_refused():
    with pytest.raises(r.FulfillmentRuleError):
        plan("shipped", "paid", "paystack", "shipped", "cancelled")


def test_cancelling_a_paid_prepaid_order_flags_refund_but_pod_never():
    assert plan("confirmed", "paid", "paystack", "unfulfilled", "cancelled").flag_refund
    assert plan("confirmed", "paid", "bank_transfer", "unfulfilled", "cancelled").flag_refund
    assert not plan("confirmed", "pending", "pay_on_delivery", "unfulfilled", "cancelled").flag_refund


def test_same_status_is_a_noop_that_still_allows_detail_updates():
    p = plan("fulfilling", "paid", "paystack", "processing", "processing")
    assert p.noop and p.order_status == "fulfilling"


def test_cannot_move_back_or_to_unknown_status():
    with pytest.raises(r.FulfillmentRuleError):
        plan("fulfilling", "paid", "paystack", "processing", "unfulfilled")
    with pytest.raises(r.FulfillmentRuleError):
        plan("fulfilling", "paid", "paystack", "processing", "teleported")


def test_every_order_status_is_reachable_and_terminals_are_final():
    states = set(r.ORDER_TRANSITIONS)
    for src, targets in r.ORDER_TRANSITIONS.items():
        assert targets <= states
    reach, frontier = set(), ["pending_payment", "awaiting_transfer"]
    while frontier:
        s = frontier.pop()
        if s not in reach:
            reach.add(s)
            frontier += list(r.ORDER_TRANSITIONS[s])
    assert reach == states
    assert r.ORDER_TRANSITIONS["completed"] == set() and r.ORDER_TRANSITIONS["cancelled"] == set()
    assert "cancelled" not in r.ORDER_TRANSITIONS["shipped"]
