"""Regression specifications for v7.6.3 commercial/runtime hardening."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

def test_checkout_requires_request_idempotency():
    source = read("app/contexts/commerce/api/checkout_routes.py")
    assert 'request.headers.get("Idempotency-Key")' in source
    assert "CommerceCheckoutIdempotency" in source

def test_late_payment_requires_refund_when_reservation_is_gone():
    source = read("app/contexts/commerce/application/services/payment.py")
    assert "order.reservation_expires_at is None" in source
    assert "payment.requires_refund = True" in source

def test_subscription_activation_is_durable_job():
    source = read("app/contexts/billing/application/subscription_payment_service.py")
    handler = read("app/workers/job_handlers.py")
    assert 'enqueue_job(self.db, "billing.activate_subscription"' in source
    assert 'register_job_handler("billing.activate_subscription"' in handler

def test_worker_job_has_fencing_token_and_reclaims_expired_running_jobs():
    source = read("app/infrastructure/worker_jobs.py")
    assert "lease_token" in source
    assert 'WorkerJob.status == "running"' in source
    # Expiry is judged by the DATABASE clock (no worker clock skew), and completion is an atomic
    # lease-checked compare-and-set (behaviour proven in tests/integration/test_worker_job_fencing.py).
    assert "WorkerJob.lease_until < func.now()" in source
    assert "WorkerJob.lease_until > func.now()" in source and "LeaseLostError" in source

def test_duplicate_commerce_webhook_boundary_is_retired():
    source = read("app/contexts/commerce/api/payment_routes.py")
    assert "status_code=410" in source
    assert "/api/v1/billing/webhooks/{provider}" in source
