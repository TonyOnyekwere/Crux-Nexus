"""CRX-P0-030: journey state machine rules. Pure - no DB, no network."""
import importlib.util
import pathlib

import pytest

_p = pathlib.Path(__file__).resolve().parents[2] / "app/contexts/onboarding/domain/journey.py"
_spec = importlib.util.spec_from_file_location("journey", _p)
j = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(j)
S, A = j.JourneyStage, j.JourneyAction

HAPPY_PATH = [
    (A.VERIFY_OTP, S.OTP_VERIFIED),
    (A.CREATE_MERCHANT, S.MERCHANT_CREATED),
    (A.CONFIGURE_BUSINESS, S.BUSINESS_CONFIGURED),
    (A.SELECT_PLAN, S.PLAN_SELECTED),
    (A.START_PAYMENT, S.PAYMENT_PENDING),
    (A.CONFIRM_PAYMENT, S.PAYMENT_CONFIRMED),
    (A.CREATE_STOREFRONT, S.STOREFRONT_READY),
    (A.COMPLETE, S.COMPLETED),
]


def test_happy_path_in_order():
    stage = S.REGISTERED
    for action, expected in HAPPY_PATH:
        stage = j.plan_transition(stage, action)
        assert stage == expected


@pytest.mark.parametrize("action", [a for a, _ in HAPPY_PATH if a is not A.VERIFY_OTP])
def test_cannot_act_from_registered(action):
    with pytest.raises(j.InvalidJourneyTransitionError):
        j.plan_transition(S.REGISTERED, action)


def test_cannot_skip_payment_to_storefront_or_complete():
    for stage in (S.REGISTERED, S.OTP_VERIFIED, S.MERCHANT_CREATED, S.BUSINESS_CONFIGURED,
                  S.PLAN_SELECTED, S.PAYMENT_PENDING):
        for action in (A.CREATE_STOREFRONT, A.COMPLETE):
            with pytest.raises(j.InvalidJourneyTransitionError):
                j.plan_transition(stage, action)


def test_confirm_payment_is_never_client_invocable():
    for stage in S:
        assert A.CONFIRM_PAYMENT not in j.allowed_actions(stage)


def test_no_plan_change_once_payment_started():
    with pytest.raises(j.InvalidJourneyTransitionError):
        j.plan_transition(S.PAYMENT_PENDING, A.SELECT_PLAN)


def test_payment_retry_allowed_while_pending():
    assert j.plan_transition(S.PAYMENT_PENDING, A.START_PAYMENT) == S.PAYMENT_PENDING


def test_business_edit_does_not_move_stage_after_first_configuration():
    assert j.plan_transition(S.MERCHANT_CREATED, A.CONFIGURE_BUSINESS) == S.BUSINESS_CONFIGURED
    assert j.plan_transition(S.PLAN_SELECTED, A.CONFIGURE_BUSINESS) == S.PLAN_SELECTED


def test_completed_is_terminal():
    assert j.allowed_actions(S.COMPLETED) == []
    assert j.next_action(S.COMPLETED) is None
    for action in A:
        with pytest.raises(j.InvalidJourneyTransitionError):
            j.plan_transition(S.COMPLETED, action)


def test_every_non_terminal_stage_has_a_next_action():
    for stage in S:
        if stage is not S.COMPLETED:
            assert j.next_action(stage)


def test_subscription_billing_interval_matches_plan_schema():
    """Migration 031 stores annual plans as 'annual'; activation must accept that canonical value."""
    from datetime import datetime, timezone
    from app.contexts.billing.application.subscription_payment_service import subscription_period_end

    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert subscription_period_end(start, "monthly") > start
    assert subscription_period_end(start, "annual") > start
    assert subscription_period_end(start, "yearly") > start
