"""Real cryptographic tests for the merchant credential vault (no DB, no network)."""
import importlib.util
import pathlib
import sys

import pytest

_p = pathlib.Path(__file__).resolve().parents[2] / "app/infrastructure/secrets/credential_vault.py"
_spec = importlib.util.spec_from_file_location("credential_vault", _p)
v = importlib.util.module_from_spec(_spec)
sys.modules["credential_vault"] = v
_spec.loader.exec_module(v)


def vault(active="v1", extra=None):
    keys = {"v1": bytes(range(32)), "v2": bytes(range(32, 64))}
    keys.update(extra or {})
    return v.CredentialVault(keys, active)


AAD = v.CredentialVault.aad_for("tenant-a", "conn-1", "paystack")
SECRET = {"secret_key": "sk_live_SUPERSECRET123"}


def test_round_trip_and_ciphertext_hides_plaintext():
    sealed = vault().seal(SECRET, aad=AAD)
    assert vault().open(sealed, aad=AAD) == SECRET
    assert b"SUPERSECRET" not in sealed.ciphertext and b"sk_live" not in sealed.ciphertext
    assert len(sealed.nonce) == 12 and sealed.key_version == "v1"


def test_nonce_is_unique_per_seal():
    a, b = vault().seal(SECRET, aad=AAD), vault().seal(SECRET, aad=AAD)
    assert a.nonce != b.nonce and a.ciphertext != b.ciphertext


def test_ciphertext_cannot_be_moved_to_another_merchant_or_provider():
    sealed = vault().seal(SECRET, aad=AAD)
    for other in (v.CredentialVault.aad_for("tenant-b", "conn-1", "paystack"),
                  v.CredentialVault.aad_for("tenant-a", "conn-2", "paystack"),
                  v.CredentialVault.aad_for("tenant-a", "conn-1", "flutterwave")):
        with pytest.raises(v.VaultDecryptionError):
            vault().open(sealed, aad=other)


def test_tampering_is_detected():
    sealed = vault().seal(SECRET, aad=AAD)
    flipped = bytearray(sealed.ciphertext)
    flipped[0] ^= 1
    with pytest.raises(v.VaultDecryptionError):
        vault().open(v.SealedCredential(sealed.key_version, sealed.nonce, bytes(flipped)), aad=AAD)
    with pytest.raises(v.VaultDecryptionError):
        vault().open(v.SealedCredential(sealed.key_version, bytes(12), sealed.ciphertext), aad=AAD)


def test_key_rotation_old_records_still_open_and_are_flagged():
    old = vault(active="v1").seal(SECRET, aad=AAD)
    rotated = vault(active="v2")
    assert rotated.open(old, aad=AAD) == SECRET            # still readable after rotation
    assert rotated.needs_rotation(old)                      # and flagged for re-encryption
    fresh = rotated.seal(SECRET, aad=AAD)
    assert fresh.key_version == "v2" and not rotated.needs_rotation(fresh)


def test_unknown_key_version_fails_closed():
    sealed = vault().seal(SECRET, aad=AAD)
    with pytest.raises(v.VaultDecryptionError):
        v.CredentialVault({"v9": bytes(32)}, "v9").open(sealed, aad=AAD)


def test_wrong_key_cannot_decrypt():
    sealed = vault().seal(SECRET, aad=AAD)
    with pytest.raises(v.VaultDecryptionError):
        v.CredentialVault({"v1": bytes(reversed(range(32)))}, "v1").open(sealed, aad=AAD)


def test_misconfiguration_fails_closed():
    for bad in ("", None):
        assert v.parse_keys(bad) == {}
        with pytest.raises(v.VaultNotConfigured):
            v.vault_from_settings(type("S", (), {"CREDENTIAL_ENCRYPTION_KEYS": bad})())
    for bad in ("v1", "v1:", "v1:not base64!!", "v1:" + "QUJD", ":" + "A" * 44):
        with pytest.raises(v.VaultNotConfigured):
            v.parse_keys(bad)
    good = v.generate_key()
    with pytest.raises(v.VaultNotConfigured):
        v.parse_keys(f"v1:{good};v1:{good}")                # duplicate version
    with pytest.raises(v.VaultNotConfigured):
        v.CredentialVault({"v1": bytes(32)}, "v2")          # active version not present


def test_vault_from_settings_defaults_to_newest_version():
    k1, k2 = v.generate_key(), v.generate_key()
    s = type("S", (), {"CREDENTIAL_ENCRYPTION_KEYS": f"v1:{k1};v2:{k2}", "CREDENTIAL_ACTIVE_KEY_VERSION": None})()
    assert v.vault_from_settings(s).active_version == "v2"
    s.CREDENTIAL_ACTIVE_KEY_VERSION = "v1"
    assert v.vault_from_settings(s).active_version == "v1"
