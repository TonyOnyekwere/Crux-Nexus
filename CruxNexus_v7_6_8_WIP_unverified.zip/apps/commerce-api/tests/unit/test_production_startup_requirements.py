"""Production must refuse to start without a valid merchant-credential key set (Gate 1 item 11).
Requires pydantic-settings (CI)."""
import secrets

import pytest

from app.config import Settings
from app.infrastructure.secrets.credential_vault import generate_key


def prod_kwargs(**overrides):
    base = dict(
        ENVIRONMENT="production",
        DATABASE_URL="postgresql://owner:pw@db/cnx",
        DATABASE_RUNTIME_URL="postgresql://cnx_runtime:pw@db/cnx",
        DATABASE_WORKER_URL="postgresql://cnx_worker:pw@db/cnx",
        REDIS_URL="redis://redis:6379/0",
        SECRET_KEY=secrets.token_hex(32),
        JWT_SECRET_KEY=secrets.token_hex(32),
        CONTROL_CENTER_SERVICE_TOKEN=secrets.token_hex(32),
        SENDGRID_API_KEY="SG." + secrets.token_hex(16),
        SENDGRID_FROM_EMAIL="no-reply@example.com",
        PAYSTACK_SECRET_KEY="sk_live_" + secrets.token_hex(12),
        PUBLIC_APP_URL="https://app.example.com",
        CREDENTIAL_ENCRYPTION_KEYS=f"v1:{generate_key()}",
    )
    base.update(overrides)
    return base


def test_valid_production_configuration_boots():
    assert Settings(**prod_kwargs()).CREDENTIAL_ENCRYPTION_KEYS


@pytest.mark.parametrize("keys", [None, "", "v1", "v1:not-base64!!", "v1:QUJD"])
def test_missing_or_malformed_credential_keys_refuse_to_start(keys):
    with pytest.raises(ValueError, match="CREDENTIAL_ENCRYPTION_KEYS"):
        Settings(**prod_kwargs(CREDENTIAL_ENCRYPTION_KEYS=keys))


def test_active_version_must_exist_in_the_key_set():
    with pytest.raises(ValueError, match="CREDENTIAL_ENCRYPTION_KEYS"):
        Settings(**prod_kwargs(CREDENTIAL_ACTIVE_KEY_VERSION="v9"))


def test_development_does_not_require_the_vault():
    kwargs = prod_kwargs(ENVIRONMENT="development", CREDENTIAL_ENCRYPTION_KEYS=None)
    Settings(**kwargs)
