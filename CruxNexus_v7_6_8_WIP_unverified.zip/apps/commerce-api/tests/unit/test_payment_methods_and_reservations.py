"""Pure tests: merchant-configured payment methods, reservation lifecycle (bank transfer / POD / online) and
late bank-transfer confirmation (Gate 1 items 4, 5, 8)."""
import importlib.util
import pathlib
import sys
from datetime import datetime, timedelta, timezone

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location("payment_methods", ROOT / "app/contexts/commerce/domain/payment_methods.py")
pm = importlib.util.module_from_spec(_spec)
sys.modules["payment_methods"] = pm
_spec.loader.exec_module(pm)
NOW = datetime(2026, 10, 6, 12, 0, tzinfo=timezone.utc)
BOTH = {"paystack", "flutterwave"}
GOOD_BANK = {"bank_name": "First Bank", "account_name": "Ada Fabrics Ltd", "account_number": "0123456789"}


# ---- merchant controls which methods exist
def avail(method, **kw):
    base = dict(pod_enabled=False, bank_transfer_enabled=False, bank_transfer_details=None,
                connected_providers=set(), platform_enabled_providers=BOTH)
    base.update(kw)
    return pm.method_availability(method=method, **base)


def test_nothing_is_offered_until_the_merchant_enables_it():
    assert pm.enabled_methods(pod_enabled=False, bank_transfer_enabled=False, bank_transfer_details=None,
                              connected_providers=set(), platform_enabled_providers=BOTH) == []
    assert avail("pay_on_delivery") == (False, "PAYMENT_METHOD_NOT_ENABLED")
    assert avail("bank_transfer") == (False, "PAYMENT_METHOD_NOT_ENABLED")


def test_each_method_is_an_independent_merchant_decision():
    assert avail("pay_on_delivery", pod_enabled=True) == (True, "OK")
    assert avail("bank_transfer", bank_transfer_enabled=True, bank_transfer_details=GOOD_BANK) == (True, "OK")
    assert avail("bank_transfer", bank_transfer_enabled=True) == (False, "BANK_TRANSFER_NOT_CONFIGURED")
    assert avail("paystack", connected_providers={"paystack"}) == (True, "OK")
    assert avail("flutterwave", connected_providers={"paystack"}) == (False, "PAYMENT_PROVIDER_NOT_CONNECTED")
    assert avail("paystack", connected_providers={"paystack"}, platform_enabled_providers=set()) == (False, "PROVIDER_DISABLED_BY_PLATFORM")
    assert avail("crypto") == (False, "UNKNOWN_PAYMENT_METHOD")


def test_enabled_methods_listing_order_is_stable():
    methods = pm.enabled_methods(pod_enabled=True, bank_transfer_enabled=True, bank_transfer_details=GOOD_BANK,
                                 connected_providers={"flutterwave", "paystack"}, platform_enabled_providers=BOTH)
    assert methods == ["pay_on_delivery", "bank_transfer", "flutterwave", "paystack"]


def test_bank_details_validation():
    assert pm.validate_bank_transfer_details({**GOOD_BANK, "account_number": "0123 4567 89", "instructions": "Use order no. as narration"})["account_number"] == "0123456789"
    for bad in ({}, {**GOOD_BANK, "account_number": "12"}, {**GOOD_BANK, "account_number": "abc12345"},
                {**GOOD_BANK, "bank_name": ""}, {**GOOD_BANK, "account_name": "<b>x</b>"},
                {**GOOD_BANK, "extra": "x"}, {**GOOD_BANK, "instructions": "x" * 501},
                {**GOOD_BANK, "instructions": "<script>"}, "string", None):
        with pytest.raises(pm.PaymentConfigError):
            pm.validate_bank_transfer_details(bad)


def test_bank_window_bounds_and_default():
    assert pm.DEFAULT_BANK_WINDOW_HOURS == 24
    for ok in (1, 24, 168):
        assert pm.validate_bank_window_hours(ok) == ok
    for bad in (0, 169, -1, 1.5, "24", True, None):
        with pytest.raises(pm.PaymentConfigError):
            pm.validate_bank_window_hours(bad)


# ---- reservation lifecycle
def test_initial_states():
    assert pm.initial_order_state("pay_on_delivery") == ("confirmed", "pending")
    assert pm.initial_order_state("bank_transfer") == ("awaiting_transfer", "pending")
    assert pm.initial_order_state("paystack") == ("pending_payment", "pending")


def test_pod_has_no_automatic_reservation_expiry():
    assert pm.reservation_deadline("pay_on_delivery", NOW) is None
    # even years later, a held POD reservation is still live
    assert pm.reservation_is_live(order_status="confirmed", reserved_units_held=True, deadline=None,
                                  now=NOW + timedelta(days=3650), method="pay_on_delivery")


def test_bank_transfer_window_is_merchant_configurable():
    assert pm.reservation_deadline("bank_transfer", NOW) == NOW + timedelta(hours=24)
    assert pm.reservation_deadline("bank_transfer", NOW, bank_window_hours=48) == NOW + timedelta(hours=48)
    with pytest.raises(pm.PaymentConfigError):
        pm.reservation_deadline("bank_transfer", NOW, bank_window_hours=500)
    assert pm.reservation_deadline("paystack", NOW) == NOW + timedelta(hours=1)


def test_a_reservation_is_live_only_if_the_ledger_holds_it_and_the_deadline_has_not_passed():
    d = NOW + timedelta(hours=1)
    assert pm.reservation_is_live(order_status="awaiting_transfer", reserved_units_held=True, deadline=d, now=NOW, method="bank_transfer")
    assert not pm.reservation_is_live(order_status="awaiting_transfer", reserved_units_held=True, deadline=d, now=d, method="bank_transfer")
    assert not pm.reservation_is_live(order_status="awaiting_transfer", reserved_units_held=False, deadline=d, now=NOW, method="bank_transfer")
    assert not pm.reservation_is_live(order_status="awaiting_transfer", reserved_units_held=True, deadline=None, now=NOW, method="bank_transfer")


# ---- late bank-transfer confirmation: never resurrect because money arrived
def plan(status, reason=None, live=False, can=False):
    return pm.plan_late_bank_transfer(order_status=status, cancellation_reason=reason, reservation_live=live, can_rereserve=can)


def test_confirmation_with_a_live_reservation_just_confirms():
    assert plan("awaiting_transfer", live=True) == pm.CONFIRM


def test_expired_but_not_yet_cancelled_rechecks_stock():
    assert plan("awaiting_transfer", live=False, can=True) == pm.RERESERVE_AND_CONFIRM
    assert plan("awaiting_transfer", live=False, can=False) == pm.REFUND_REQUIRED


def test_worker_expired_order_may_reopen_only_if_stock_can_be_rereserved():
    assert plan("cancelled", "reservation_expired", can=True) == pm.REOPEN_AND_CONFIRM
    assert plan("cancelled", "reservation_expired", can=False) == pm.REFUND_REQUIRED


def test_deliberately_cancelled_or_failed_orders_are_never_revived():
    for status, reason in (("cancelled", "merchant"), ("cancelled", "payment_failed"), ("cancelled", None),
                           ("payment_failed", None), ("pending_payment", None)):
        for can in (True, False):
            assert plan(status, reason, live=True, can=can) == pm.REFUND_REQUIRED, (status, reason, can)


def test_repeat_confirmation_is_idempotent():
    for status in ("confirmed", "fulfilling", "shipped", "delivered", "completed"):
        assert plan(status) == pm.ALREADY_CONFIRMED


def test_money_alone_never_decides():
    """The only inputs that can yield a confirmation are reservation state and stock availability."""
    confirming = {pm.CONFIRM, pm.RERESERVE_AND_CONFIRM, pm.REOPEN_AND_CONFIRM}
    for status in ("cancelled", "payment_failed", "pending_payment", "awaiting_transfer"):
        for reason in (None, "merchant", "reservation_expired"):
            for live in (True, False):
                result = plan(status, reason, live=live, can=False)
                if result in confirming:
                    assert status == "awaiting_transfer" and live      # only a still-held reservation, with no stock needed
