"""CRX-P0-029: duplicate-charge safety on payment initiation.

Pure unit tests (no database, no network): adapters are driven through a
patched httpx.AsyncClient, the service through a scripted fake session.
Not executed in the authoring environment (pytest/sqlalchemy unavailable
there) - run in CI.
"""
import asyncio
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import httpx
import pytest

from app.contexts.billing.application import subscription_payment_service as svc_mod
from app.contexts.billing.domain.financial_transaction import (
    FinancialTransactionStatus,
    PaymentAuthorizationType,
    PaymentProvider,
)
from app.contexts.billing.domain.merchant_subscription import SubscriptionStatus
from app.infrastructure.payments.adapter import (
    ChargeInitializationResult,
    ProviderOutcomeUnknownError,
    ProviderRejectedError,
    ProviderTransactionNotFoundError,
)
from app.infrastructure.payments.flutterwave import FlutterwaveAdapter
from app.infrastructure.payments.paystack import PaystackAdapter


def run(coro):
    return asyncio.run(coro)


def _client_raising(exc):
    client = MagicMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=False)
    client.post = AsyncMock(side_effect=exc)
    client.get = AsyncMock(side_effect=exc)
    return client


def _client_returning(status_code, body):
    response = MagicMock()
    response.status_code = status_code
    response.json = MagicMock(return_value=body)
    client = MagicMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=False)
    client.post = AsyncMock(return_value=response)
    client.get = AsyncMock(return_value=response)
    return client


ADAPTERS = [
    (PaystackAdapter("sk_test_x"), "app.infrastructure.payments.paystack.httpx.AsyncClient"),
    (FlutterwaveAdapter("FLWSECK_TEST-x"), "app.infrastructure.payments.flutterwave.httpx.AsyncClient"),
]
INIT_KW = dict(reference="CNX-1", amount=Decimal("5000"), currency="NGN",
               merchant_email="m@x.com", redirect_url="https://x/cb")


@pytest.mark.parametrize("adapter,target", ADAPTERS)
def test_read_timeout_is_outcome_unknown(adapter, target):
    with patch(target, return_value=_client_raising(httpx.ReadTimeout("slow"))):
        with pytest.raises(ProviderOutcomeUnknownError):
            run(adapter.initialize_charge(**INIT_KW))


@pytest.mark.parametrize("adapter,target", ADAPTERS)
def test_connect_error_is_rejected_not_sent(adapter, target):
    with patch(target, return_value=_client_raising(httpx.ConnectError("refused"))):
        with pytest.raises(ProviderRejectedError):
            run(adapter.initialize_charge(**INIT_KW))


@pytest.mark.parametrize("adapter,target", ADAPTERS)
def test_5xx_is_outcome_unknown(adapter, target):
    with patch(target, return_value=_client_returning(503, {})):
        with pytest.raises(ProviderOutcomeUnknownError):
            run(adapter.initialize_charge(**INIT_KW))


@pytest.mark.parametrize("adapter,target", ADAPTERS)
def test_4xx_is_definitive_rejection(adapter, target):
    with patch(target, return_value=_client_returning(400, {"status": False, "message": "bad"})):
        with pytest.raises(ProviderRejectedError):
            run(adapter.initialize_charge(**INIT_KW))


@pytest.mark.parametrize("adapter,target", ADAPTERS)
def test_verify_404_is_not_found(adapter, target):
    with patch(target, return_value=_client_returning(404, {"status": False})):
        with pytest.raises(ProviderTransactionNotFoundError):
            run(adapter.verify_transaction("CNX-1"))


# ---------------- service level (scripted fake session) ----------------

class FakeResult:
    def __init__(self, scalar=None, rows=None):
        self._scalar, self._rows = scalar, rows or []

    def scalar_one_or_none(self):
        return self._scalar

    def all(self):
        return self._rows

    def scalars(self):
        first_column = [row[0] for row in self._rows]
        return SimpleNamespace(all=lambda: first_column)


class FakeSession:
    def __init__(self, results):
        self.results, self.added, self.commits, self.rollbacks = list(results), [], 0, 0

    async def execute(self, *_a, **_k):
        return self.results.pop(0)

    def add(self, obj):
        self.added.append(obj)

    async def commit(self):
        self.commits += 1

    async def rollback(self):
        self.rollbacks += 1


def _fixtures():
    merchant_id, sub_id = uuid4(), uuid4()
    sub = SimpleNamespace(id=sub_id, merchant_account_id=merchant_id,
                          subscription_plan_id=uuid4(), status=SubscriptionStatus.TRIAL_EXPIRED.value)
    plan = SimpleNamespace(id=sub.subscription_plan_id, code="pro",
                           price_amount=Decimal("5000"), price_currency="NGN")
    return merchant_id, sub, plan


def _service(adapter, session):
    registry = MagicMock()
    registry.get = MagicMock(return_value=adapter)
    return registry


def test_timeout_leaves_transaction_pending_and_raises_unknown():
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[])])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock(side_effect=ProviderOutcomeUnknownError("timeout"))
    with patch.object(svc_mod, "get_payment_provider_registry",
                      return_value=_service(adapter, session)):
        with pytest.raises(svc_mod.PaymentOutcomeUnknownError):
            run(svc_mod.SubscriptionPaymentService(session).initiate_payment(
                merchant_account_id=merchant_id, subscription_id=sub.id,
                merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK,
                redirect_url="https://x/cb"))
    txn = session.added[0]
    assert txn.status == FinancialTransactionStatus.PENDING.value  # NOT failed
    assert txn.provider_reference == txn.reference  # webhook can resolve it
    assert sub.status == SubscriptionStatus.PAYMENT_PENDING.value


def test_definitive_rejection_marks_failed():
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[]), FakeResult(sub)])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock(side_effect=ProviderRejectedError("no"))
    with patch.object(svc_mod, "get_payment_provider_registry",
                      return_value=_service(adapter, session)):
        with pytest.raises(ProviderRejectedError):
            run(svc_mod.SubscriptionPaymentService(session).initiate_payment(
                merchant_account_id=merchant_id, subscription_id=sub.id,
                merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK,
                redirect_url="https://x/cb"))
    assert session.added[0].status == FinancialTransactionStatus.FAILED.value


def test_pending_record_is_committed_before_provider_is_called():
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[])])
    seen = {}

    async def initialize_charge(**_kw):
        seen["commits_before_call"] = session.commits
        return ChargeInitializationResult("ref", "https://pay", PaymentAuthorizationType.ONE_TIME_PAYMENT)

    adapter = MagicMock()
    adapter.initialize_charge = initialize_charge
    with patch.object(svc_mod, "get_payment_provider_registry",
                      return_value=_service(adapter, session)):
        run(svc_mod.SubscriptionPaymentService(session).initiate_payment(
            merchant_account_id=merchant_id, subscription_id=sub.id,
            merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK,
            redirect_url="https://x/cb"))
    assert seen["commits_before_call"] >= 1


def test_new_charge_refused_when_prior_attempt_was_paid():
    merchant_id, sub, plan = _fixtures()
    prior_id = uuid4()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[(prior_id,)])])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock()
    service = svc_mod.SubscriptionPaymentService(session)
    service.reconcile_transaction = AsyncMock(return_value=FinancialTransactionStatus.SUCCESSFUL.value)
    with patch.object(svc_mod, "get_payment_provider_registry",
                      return_value=_service(adapter, session)):
        with pytest.raises(svc_mod.PaymentAlreadyCompletedError):
            run(service.initiate_payment(
                merchant_account_id=merchant_id, subscription_id=sub.id,
                merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK,
                redirect_url="https://x/cb"))
    adapter.initialize_charge.assert_not_called()


def test_new_charge_refused_when_prior_attempt_unverifiable():
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[(uuid4(),)])])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock()
    service = svc_mod.SubscriptionPaymentService(session)
    service.reconcile_transaction = AsyncMock(side_effect=ProviderOutcomeUnknownError("down"))
    with patch.object(svc_mod, "get_payment_provider_registry",
                      return_value=_service(adapter, session)):
        with pytest.raises(svc_mod.PriorPaymentUnverifiableError):
            run(service.initiate_payment(
                merchant_account_id=merchant_id, subscription_id=sub.id,
                merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK,
                redirect_url="https://x/cb"))
    adapter.initialize_charge.assert_not_called()


def test_definitive_rejection_moves_subscription_to_payment_failed():
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[]), FakeResult(sub)])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock(side_effect=ProviderRejectedError("no"))
    with patch.object(svc_mod, "get_payment_provider_registry", return_value=_service(adapter, session)):
        with pytest.raises(ProviderRejectedError):
            run(svc_mod.SubscriptionPaymentService(session).initiate_payment(
                merchant_account_id=merchant_id,
                subscription_id=sub.id,
                merchant_email="m@x.com",
                provider=PaymentProvider.PAYSTACK,
                redirect_url="https://x/cb",
            ))
    assert session.added[0].status == FinancialTransactionStatus.FAILED.value
    assert sub.status == SubscriptionStatus.PAYMENT_FAILED.value


def test_active_subscription_cannot_start_new_payment():
    merchant_id, sub, _plan = _fixtures()
    sub.status = SubscriptionStatus.ACTIVE.value
    session = FakeSession([FakeResult(sub)])
    adapter = MagicMock()
    with patch.object(svc_mod, "get_payment_provider_registry", return_value=_service(adapter, session)):
        with pytest.raises(svc_mod.SubscriptionAlreadyActiveError):
            run(svc_mod.SubscriptionPaymentService(session).initiate_payment(
                merchant_account_id=merchant_id,
                subscription_id=sub.id,
                merchant_email="m@x.com",
                provider=PaymentProvider.PAYSTACK,
                redirect_url="https://x/cb",
            ))
    adapter.initialize_charge.assert_not_called()


def test_flutterwave_webhook_normalizes_tx_ref():
    adapter = FlutterwaveAdapter("FLWSECK_TEST-x", webhook_secret_hash="secret")
    payload = b'{"event":"charge.completed","data":{"id":12345,"tx_ref":"CNX-abc123"}}'
    result = adapter.verify_webhook_signature(
        headers={"verif-hash": "secret"},
        raw_body=payload,
    )
    assert result.signature_valid is True
    assert result.provider_reference == "CNX-abc123"
    assert result.event_id == "charge.completed:CNX-abc123"


def test_provider_pending_prior_attempt_blocks_a_new_charge():
    """v7.6.6 review P0 #1: a prior attempt the provider still reports as PENDING must block a new
    charge. Previously only 'paid' or an exception blocked, so a pending attempt let a second charge
    through and both could later succeed."""
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[(uuid4(),)])])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock()
    service = svc_mod.SubscriptionPaymentService(session)
    service.reconcile_transaction = AsyncMock(return_value=FinancialTransactionStatus.PENDING.value)
    with patch.object(svc_mod, "get_payment_provider_registry", return_value=_service(adapter, session)):
        with pytest.raises(svc_mod.PriorPaymentUnverifiableError):
            run(service.initiate_payment(
                merchant_account_id=merchant_id, subscription_id=sub.id,
                merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK, redirect_url="https://x/cb"))
    adapter.initialize_charge.assert_not_called()
    assert session.added == []          # no second transaction row was even created


def test_terminal_prior_attempt_allows_a_new_charge():
    merchant_id, sub, plan = _fixtures()
    session = FakeSession([FakeResult(sub), FakeResult(plan), FakeResult(rows=[(uuid4(),)]), FakeResult(sub)])
    adapter = MagicMock()
    adapter.initialize_charge = AsyncMock(return_value=ChargeInitializationResult(
        "ref", "https://pay", PaymentAuthorizationType.ONE_TIME_PAYMENT))
    service = svc_mod.SubscriptionPaymentService(session)
    service.reconcile_transaction = AsyncMock(return_value=FinancialTransactionStatus.ABANDONED.value)
    with patch.object(svc_mod, "get_payment_provider_registry", return_value=_service(adapter, session)):
        run(service.initiate_payment(
            merchant_account_id=merchant_id, subscription_id=sub.id,
            merchant_email="m@x.com", provider=PaymentProvider.PAYSTACK, redirect_url="https://x/cb"))
    adapter.initialize_charge.assert_awaited_once()
