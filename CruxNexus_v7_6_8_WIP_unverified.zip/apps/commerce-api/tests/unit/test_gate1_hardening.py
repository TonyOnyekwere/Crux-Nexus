"""Gate 1 hardening: rate-limit keys, metrics labels, CORS headers, retired routes, hygiene (pure / source-level;
the HTTP behaviour of these is proven by CI integration tests)."""
import ast
import importlib.util
import pathlib
import re
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[2]
APP = ROOT / "app"

# rate_limiter.py imports fastapi/slowapi; execute only its two pure functions
_src = (APP / "infrastructure/rate_limiter.py").read_text()
_ns = {"re": re, "Optional": __import__("typing").Optional}
exec(_src[_src.index("_UNIT_SECONDS"):_src.index("def _ip(")], _ns)  # noqa: S102 - our own source
exec(_src[_src.index("def retry_after_seconds"):_src.index("def build_limiter")], _ns)  # noqa: S102
client_ip, retry_after_seconds = _ns["client_ip"], _ns["retry_after_seconds"]


# ---- client IP: only entries appended by OUR proxy are trusted
def test_one_trusted_hop_uses_the_rightmost_entry_not_attacker_supplied_ones():
    assert client_ip("9.9.9.9, 203.0.113.7", "10.0.0.1", 1) == "203.0.113.7"        # spoofed left entry ignored
    assert client_ip("203.0.113.7", "10.0.0.1", 1) == "203.0.113.7"


def test_two_trusted_hops_and_no_trust():
    assert client_ip("203.0.113.7, 198.51.100.2", "10.0.0.1", 2) == "203.0.113.7"
    assert client_ip("203.0.113.7, 198.51.100.2", "10.0.0.1", 0) == "10.0.0.1"      # header ignored when not behind a proxy


def test_missing_or_short_header_falls_back_to_the_peer():
    assert client_ip(None, "10.0.0.1", 1) == "10.0.0.1"
    assert client_ip("", "10.0.0.1", 1) == "10.0.0.1"
    assert client_ip("203.0.113.7", "10.0.0.1", 3) == "10.0.0.1"
    assert client_ip(None, None, 1) == "unknown"


def test_retry_after_is_derived_from_the_limit_window():
    assert retry_after_seconds("5 per 1 hour") == 3600
    assert retry_after_seconds("10 per 1 minute") == 60
    assert retry_after_seconds("20 per 2 hour") == 7200
    assert retry_after_seconds("300 per 1 second") == 1
    assert retry_after_seconds("garbage") == 60


# ---- source-level guarantees that only CI can prove behaviourally
def test_every_sensitive_route_is_rate_limited_with_a_stacked_ip_ceiling():
    checks = {
        "contexts/identity/api/routes.py": ['"/login"', '10/minute'],
        "contexts/commerce/api/merchant_payment_routes.py": ["5/hour", "key_webhook_token", "300/minute"],
        "contexts/commerce/api/checkout_routes.py": ["30/minute", "key_ip_slug"],
    }
    for rel, needles in checks.items():
        text = (APP / rel).read_text()
        for n in needles:
            assert n in text, (rel, n)
    creds = (APP / "contexts/commerce/api/merchant_payment_routes.py").read_text()
    # per-tenant limit (client-influenced claim) must sit UNDER an IP-wide limit so claims cannot dodge it
    assert 'key_func=key_ip_tenant' in creds and '30/hour", key_func=key_ip)' in creds


def test_limiter_is_actually_installed_not_merely_created():
    main = (APP / "main.py").read_text()
    assert "SlowAPIMiddleware" in main and "add_middleware(SlowAPIMiddleware)" in main
    assert "rate_limit_exceeded_handler" in main
    assert "X-API-Key" not in (APP / "infrastructure/rate_limiter.py").read_text().split("def build_limiter")[0].replace("`X-API-Key`", "")


def test_metrics_label_is_the_route_template_and_cors_allows_storefront_tokens():
    main = (APP / "main.py").read_text()
    assert 'request.scope.get("route")' in main and "request.url.path" not in main.split("HTTP_REQUESTS")[1][:400]
    assert '"X-Cart-Token"' in main and '"X-Order-Token"' in main


def test_legacy_routes_are_retired_with_410_and_no_consumers_remain():
    for rel in ("contexts/commerce/api/storefront_routes.py", "contexts/commerce/api/presentation_routes.py"):
        text = (APP / rel).read_text()
        assert "ROUTE_RETIRED" in text and "410" in text
    storefront = (APP / "contexts/commerce/api/storefront_routes.py").read_text()
    body = storefront.split("async def retired_storefront_configuration")[1]
    assert "get_db" not in body.split("raise _retired")[0] and "commit" not in body   # takes no DB session: it can write nothing
    for path in (ROOT.parent.parent).rglob("*.py"):
        if "__pycache__" in path.parts or path.name == "test_gate1_hardening.py":
            continue
        assert "/storefront/configuration" not in path.read_text(encoding="utf-8", errors="ignore") or "retired" in path.read_text(encoding="utf-8", errors="ignore")


def test_no_wildcard_imports_and_no_duplicate_table_args_anywhere():
    for path in APP.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                assert all(a.name != "*" for a in node.names), f"{path}: wildcard import"
            if isinstance(node, ast.ClassDef):
                n = sum(1 for b in node.body if isinstance(b, ast.Assign) and any(getattr(t, "id", "") == "__table_args__" for t in b.targets))
                assert n <= 1, f"{path}:{node.name} defines __table_args__ {n} times"


def test_the_public_boundary_is_the_only_public_tenant_resolver():
    for path in (APP / "contexts/commerce/api").glob("*.py"):
        text = path.read_text()
        assert "_set_public_tenant" not in text, path.name
        assert "Tenant.status == \"active\"" not in text, path.name
    for name in ("cart_routes", "checkout_routes", "order_public_routes", "storefront_public_routes"):
        assert "resolve_public_storefront" in (APP / f"contexts/commerce/api/{name}.py").read_text(), name


def test_storefront_cannot_publish_without_readiness_and_onboarding_never_publishes():
    assert "storefront_readiness" in (APP / "contexts/commerce/api/storefront_routes.py").read_text()
    assert "published=False" in (APP / "contexts/onboarding/application/journey_service.py").read_text()
