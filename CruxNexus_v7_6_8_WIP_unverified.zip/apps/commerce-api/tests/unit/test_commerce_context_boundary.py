from pathlib import Path

from app.infrastructure.payments.adapter import TransactionVerificationResult


def test_transaction_verification_result_declares_normalized_status():
    result = TransactionVerificationResult(
        successful=True,
        status="SUCCESS",
        provider_reference="CNX-test",
        amount="5000",
        currency="NGN",
        raw={},
    )
    assert result.status == "SUCCESS"


def test_commerce_is_a_bounded_context_package_not_a_monolith_file():
    root = Path(__file__).parents[2] / "app" / "contexts" / "commerce"
    assert root.is_dir()
    assert (root / "domain" / "models.py").exists()
    assert (root / "domain" / "invariants.py").exists()
    assert (root / "application" / "services" / "payment.py").exists()
    assert (root / "api" / "merchant_routes.py").exists()
    assert (root / "api" / "public_routes.py").exists()
    assert not (root.parent / "commerce.py").exists()
