"""WP2: typed step data. Requires pydantic (CI). Covers the frozen D3-D6 rules."""

import pytest
from pydantic import ValidationError

from app.contexts.onboarding.domain.journey_v2 import V2Step
from app.contexts.onboarding.domain.journey_v2_schemas import (
    STEP_SCHEMAS,
    BrandingData,
    BusinessInfoData,
    CategoryData,
    ContactData,
    DeliverySetupData,
    FirstProductData,
    PaymentSetupData,
    SalesChannelsData,
)

BANK = {"bank_name": "Access Bank", "account_name": "Ada Stores", "account_number": "0123456789"}


def test_every_draft_step_has_a_schema_and_unknown_fields_are_rejected():
    assert set(STEP_SCHEMAS) == set(V2Step)
    with pytest.raises(ValidationError):
        CategoryData(category="Fashion", stage="COMPLETED")          # a client cannot smuggle a stage
    with pytest.raises(ValidationError):
        BusinessInfoData(business_name="Ada", country="NG", currency="NGN", completed=True)


def test_sales_channels_are_unique_and_bounded():
    assert SalesChannelsData(channels=["whatsapp", "instagram"]).channels
    with pytest.raises(ValidationError):
        SalesChannelsData(channels=["whatsapp", "whatsapp"])
    with pytest.raises(ValidationError):
        SalesChannelsData(channels=["telegram"])


def test_category_is_normalised_and_blank_rejected():
    assert CategoryData(category="  Fashion   &  Beauty ").category == "Fashion & Beauty"
    for bad in ("", "   ", "a", "x" * 61):
        with pytest.raises(ValidationError):
            CategoryData(category=bad)


def test_business_info_enforces_supported_country_and_currency():
    ok = BusinessInfoData(business_name="  Ada   Stores ", country="NG", currency="ngn")
    assert ok.business_name == "Ada Stores" and ok.currency == "NGN"
    for bad in ({"country": "US"}, {"currency": "USD"}, {"business_name": " a "}):
        with pytest.raises(ValidationError):
            BusinessInfoData(**{"business_name": "Ada", "country": "NG", "currency": "NGN", **bad})


def test_contact_requires_valid_support_email_and_e164_phone_when_given():
    data = ContactData(support_email=" Help@Ada.com ", phone="+234 801 234 5678", address="  ", city="")
    assert data.support_email == "help@ada.com" and data.phone == "+2348012345678"
    assert data.address is None and data.city is None
    for bad in ({"support_email": "not-an-email"}, {"phone": "08012345678"}, {"phone": "+0123456"}):
        with pytest.raises(ValidationError):
            ContactData(**{"support_email": "a@b.co", **bad})
    with pytest.raises(ValidationError):
        ContactData()   # support email is the only required contact field (D6)


def test_payment_setup_skip_connect_and_offline_rules():
    assert PaymentSetupData(decision="skip").counts_as_online_provider is False
    with pytest.raises(ValidationError):
        PaymentSetupData(decision="skip", offline_methods=["pay_on_delivery"])

    connect = PaymentSetupData(decision="connect", provider="paystack", credentials={"secret_key": "sk_test_abcdefghij"})
    assert connect.counts_as_online_provider is True
    assert "sk_test" not in repr(connect) and "credentials" not in connect.public_data()
    assert connect.public_data()["has_credentials"] is True
    for bad in ({"provider": "stripe"}, {"credentials": None}):
        with pytest.raises(ValidationError):
            PaymentSetupData(**{"decision": "connect", "provider": "paystack", "credentials": {"secret_key": "x"}, **bad})

    pod = PaymentSetupData(decision="offline_only", offline_methods=["pay_on_delivery"])
    assert pod.counts_as_online_provider is False
    bank = PaymentSetupData(decision="offline_only", offline_methods=["bank_transfer"], bank_transfer_details=BANK)
    assert bank.bank_transfer_window_hours == 24 and bank.counts_as_online_provider is False


def test_offline_only_is_not_a_loophole():
    with pytest.raises(ValidationError):
        PaymentSetupData(decision="offline_only")                                    # nothing configured
    with pytest.raises(ValidationError):
        PaymentSetupData(decision="offline_only", offline_methods=["bank_transfer"])  # no bank details
    with pytest.raises(ValidationError):
        PaymentSetupData(decision="offline_only", offline_methods=["bank_transfer"],
                         bank_transfer_details={**BANK, "account_number": "12"})     # invalid details
    with pytest.raises(ValidationError):
        PaymentSetupData(decision="offline_only", offline_methods=["pay_on_delivery"], bank_transfer_details=BANK)
    with pytest.raises(ValidationError):
        PaymentSetupData(decision="offline_only", offline_methods=["pay_on_delivery"], provider="paystack")


def test_delivery_setup_needs_a_method_or_an_explicit_skip():
    assert DeliverySetupData(pickup_enabled=True, delivery_enabled=False)
    with pytest.raises(ValidationError):
        DeliverySetupData(pickup_enabled=False, delivery_enabled=False)


def test_first_product_validates_price_stock_and_rejects_any_image_reference():
    ok = FirstProductData(title="  Ankara  Dress ", price="12500.50", starting_stock=10)
    assert ok.title == "Ankara Dress" and str(ok.price) == "12500.50"
    for bad in ({"price": "0"}, {"price": "-1"}, {"price": "1.234"}, {"starting_stock": -1}, {"title": " "}):
        with pytest.raises(ValidationError):
            FirstProductData(**{"title": "Dress", "price": "10", "starting_stock": 1, **bad})
    with pytest.raises(ValidationError):
        FirstProductData(title="Dress", price="10", starting_stock=1, image_ref="https://example.com/x.png")  # D4


def test_branding_normalises_slug_and_accent_and_rejects_logo_reference():
    ok = BrandingData(display_name="Ada Stores", slug="  Ada's Stores!! ", accent="#1D7F48")
    assert ok.slug and ok.slug == ok.slug.lower() and " " not in ok.slug and ok.accent == "#1d7f48"
    assert BrandingData(display_name="Ada Stores", slug="   ").slug is None
    for bad in ({"slug": "!!"}, {"accent": "green"}, {"logo_ref": "x"}):
        with pytest.raises(ValidationError):
            BrandingData(**{"display_name": "Ada Stores", **bad})
