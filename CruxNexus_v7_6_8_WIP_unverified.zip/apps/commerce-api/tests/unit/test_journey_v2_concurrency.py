"""WP4 core: If-Match parsing, request hashing and the ordered mutation decision. Pure."""

from datetime import datetime, timedelta, timezone

import pytest

from app.contexts.onboarding.domain.journey_v2_concurrency import (
    IDEMPOTENT_OPERATIONS,
    RequestOutcome,
    StoredKey,
    canonical_request_hash,
    etag,
    parse_if_match,
    plan_mutation,
)

NOW = datetime(2026, 10, 18, 12, 0, tzinfo=timezone.utc)
KEY = "k" * 20
HASH = canonical_request_hash("launch", {})


def _stored(**kw) -> StoredKey:
    base = dict(operation="launch", actor="user:1", request_hash=HASH, status="completed", expires_at=NOW + timedelta(days=1))
    base.update(kw)
    return StoredKey(**base)


def _plan(**kw):
    base = dict(operation="launch", actor="user:1", authorized=True, idempotency_key=KEY, if_match='"3"',
                request_hash=HASH, stored_key=None, current_version=3, now=NOW)
    base.update(kw)
    return plan_mutation(**base)


def test_if_match_parsing_accepts_strong_weak_and_bare_versions_only():
    assert parse_if_match('"3"') == 3 and parse_if_match('W/"12"') == 12 and parse_if_match("7") == 7
    assert parse_if_match(None) is None and parse_if_match("   ") is None
    for bad in ("*", '"1","2"', "0", '"-1"', "abc", '"99999999999"', "3 4"):
        with pytest.raises(ValueError):
            parse_if_match(bad)
    assert etag(5) == '"5"'


def test_request_hash_is_canonical_and_keyed_when_requested():
    assert canonical_request_hash("x", {"a": 1, "b": 2}) == canonical_request_hash("x", {"b": 2, "a": 1})
    assert canonical_request_hash("x", {"a": 1}) != canonical_request_hash("y", {"a": 1})
    assert canonical_request_hash("x", {"p": "secret"}, secret=b"k1") != canonical_request_hash("x", {"p": "secret"}, secret=b"k2")
    assert canonical_request_hash("x", {"p": "secret"}, secret=b"k1") != canonical_request_hash("x", {"p": "secret"})
    assert len(canonical_request_hash("x", None)) == 64


def test_happy_path_executes():
    plan = _plan()
    assert plan.outcome is RequestOutcome.EXECUTE and plan.proceeds and plan.parsed_version == 3


def test_unauthorised_caller_learns_nothing_even_with_a_matching_key_record():
    plan = _plan(authorized=False, stored_key=_stored())
    assert plan.outcome is RequestOutcome.FORBIDDEN and plan.http_status == 403 and not plan.proceeds


def test_missing_or_malformed_headers_are_rejected_before_any_replay():
    assert _plan(idempotency_key=None).outcome is RequestOutcome.IDEMPOTENCY_KEY_REQUIRED
    assert _plan(idempotency_key="short").outcome is RequestOutcome.IDEMPOTENCY_KEY_INVALID
    assert _plan(if_match=None).outcome is RequestOutcome.IF_MATCH_REQUIRED
    assert _plan(if_match=None).http_status == 428
    assert _plan(if_match="*").outcome is RequestOutcome.IF_MATCH_INVALID
    assert _plan(if_match=None, stored_key=_stored()).outcome is RequestOutcome.IF_MATCH_REQUIRED


def test_stale_version_is_a_conflict_with_the_documented_code():
    plan = _plan(if_match='"2"')
    assert plan.outcome is RequestOutcome.VERSION_CONFLICT and plan.http_status == 409
    assert plan.error_code == "JOURNEY_VERSION_CONFLICT"
    assert _plan(if_match='"4"').outcome is RequestOutcome.VERSION_CONFLICT   # from the future is also wrong


def test_lost_response_retry_replays_even_though_the_version_has_moved_on():
    plan = _plan(if_match='"3"', current_version=4, stored_key=_stored())
    assert plan.outcome is RequestOutcome.REPLAY and not plan.proceeds


def test_same_key_with_a_different_request_operation_or_actor_is_rejected():
    assert _plan(stored_key=_stored(request_hash=canonical_request_hash("launch", {"x": 1}))).outcome is RequestOutcome.IDEMPOTENCY_KEY_REUSED
    assert _plan(stored_key=_stored(operation="start_payment")).outcome is RequestOutcome.IDEMPOTENCY_KEY_REUSED
    assert _plan(stored_key=_stored(actor="user:2")).outcome is RequestOutcome.IDEMPOTENCY_KEY_REUSED
    assert _plan(stored_key=_stored(actor="user:2")).http_status == 422


def test_in_progress_key_is_reported_not_re_executed():
    assert _plan(stored_key=_stored(status="in_progress")).outcome is RequestOutcome.IDEMPOTENCY_IN_PROGRESS


def test_expired_key_record_is_ignored_and_the_version_check_applies():
    expired = _stored(expires_at=NOW - timedelta(seconds=1))
    assert _plan(stored_key=expired).outcome is RequestOutcome.EXECUTE
    assert _plan(stored_key=expired, if_match='"2"').outcome is RequestOutcome.VERSION_CONFLICT


def test_operations_without_a_required_key_still_enforce_if_match():
    for op in ("submit_step", "skip_step", "confirm_review", "verify_otp", "request_otp"):
        assert op not in IDEMPOTENT_OPERATIONS
        assert _plan(operation=op, idempotency_key=None).outcome is RequestOutcome.EXECUTE
        assert _plan(operation=op, idempotency_key=None, if_match=None).outcome is RequestOutcome.IF_MATCH_REQUIRED
        assert _plan(operation=op, idempotency_key=None, if_match='"1"').outcome is RequestOutcome.VERSION_CONFLICT


def test_commercial_operations_all_require_a_key():
    assert IDEMPOTENT_OPERATIONS == {"register", "select_plan", "start_trial", "start_payment", "launch"}
    for op in IDEMPOTENT_OPERATIONS:
        assert _plan(operation=op, idempotency_key=None).outcome is RequestOutcome.IDEMPOTENCY_KEY_REQUIRED
