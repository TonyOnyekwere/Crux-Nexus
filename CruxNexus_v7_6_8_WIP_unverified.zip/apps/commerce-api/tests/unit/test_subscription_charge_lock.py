"""Pure tests: the subscription charge lock and provider status normalization (Gate 1 item 2)."""
import importlib.util
import pathlib
import re
import sys
from datetime import timedelta

ROOT = pathlib.Path(__file__).resolve().parents[2]


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


lock = load("charge_lock", "app/contexts/billing/domain/charge_lock.py")

# adapter.py imports project modules; extract and execute only its two pure normalizers
_src = (ROOT / "app/infrastructure/payments/adapter.py").read_text()
_pure = _src[_src.index("_IN_FLIGHT_RAW"):_src.index("class ProviderRejectedError")]
ns = {}
exec(_pure, ns)  # noqa: S102 - our own source, pure functions only
norm_ps, norm_fw, in_flight = ns["normalize_paystack_status"], ns["normalize_flutterwave_status"], ns["is_in_flight"]

GRACE = timedelta(seconds=120)


def decide(state, age_s, conclusive=GRACE):
    return lock.classify_prior_attempt(provider_state=state, age=timedelta(seconds=age_s), not_found_conclusive_after=conclusive)


def test_pending_blocks_forever_no_timeout_authorizes_a_second_charge():
    for age in (0, 60, 3600, 86400, 86400 * 30, 86400 * 3650):
        assert decide("PENDING", age) == lock.BLOCK
        assert decide("UNKNOWN", age) == lock.BLOCK
        assert not lock.allows_new_charge(decide("PENDING", age))


def test_terminal_states_allow_a_new_charge_success_does_not():
    assert decide("FAILED", 0) == lock.TERMINAL_FAILED and lock.allows_new_charge(decide("FAILED", 0))
    assert decide("ABANDONED", 0) == lock.TERMINAL_ABANDONED and lock.allows_new_charge(decide("ABANDONED", 0))
    assert decide("SUCCESS", 0) == lock.PAID and not lock.allows_new_charge(decide("SUCCESS", 0))


def test_not_found_is_terminal_only_with_strong_evidence():
    assert decide("NOT_FOUND", 10) == lock.BLOCK                       # initialization may still be in flight
    assert decide("NOT_FOUND", 119) == lock.BLOCK
    assert decide("NOT_FOUND", 120) == lock.TERMINAL_FAILED            # boundary: conclusive window reached
    assert decide("NOT_FOUND", 10**7) == lock.TERMINAL_FAILED
    # a provider whose not-found is not conclusive (e.g. no record until a customer attempt) never unlocks
    assert decide("NOT_FOUND", 10**9, conclusive=None) == lock.BLOCK


def test_unrecognized_provider_state_fails_closed():
    for state in ("", "WEIRD", "success", None):
        assert decide(state, 10**6) == lock.BLOCK


def test_paystack_in_flight_statuses_are_never_failed():
    for raw in ("pending", "processing", "ongoing", "queued", " Ongoing "):
        assert norm_ps(raw) == "PENDING" and in_flight(norm_ps(raw)), raw
    assert norm_ps("success") == "SUCCESS" and norm_ps("failed") == "FAILED" and norm_ps("reversed") == "FAILED"
    assert norm_ps("abandoned") == "ABANDONED"
    for unknown in ("", None, "something_new"):
        assert norm_ps(unknown) == "UNKNOWN" and in_flight(norm_ps(unknown))


def test_flutterwave_statuses():
    assert norm_fw("successful") == "SUCCESS" and norm_fw("failed") == "FAILED"
    assert norm_fw("cancelled") == "ABANDONED" and norm_fw("pending") == "PENDING"
    assert norm_fw("new") == "PENDING" and norm_fw("brand-new-status") == "UNKNOWN"


def test_only_pending_and_unknown_are_in_flight():
    for s in ("PENDING", "UNKNOWN"):
        assert in_flight(s)
    for s in ("SUCCESS", "FAILED", "ABANDONED", "NOT_FOUND"):
        assert not in_flight(s)


def test_service_wires_the_rule_and_has_no_age_based_unlock():
    text = (ROOT / "app/contexts/billing/application/subscription_payment_service.py").read_text()
    assert "classify_prior_attempt" in text
    assert "STALE_PENDING_AFTER" not in text.split("async def _resolve_prior_pending")[1].split("async def _close_unpaid")[0]
    resolver = text.split("async def _resolve_prior_pending")[1].split("async def reconcile_transaction")[0]
    assert "PriorPaymentUnverifiableError" in resolver and "PENDING" in resolver


def test_flutterwave_not_found_is_never_conclusive_until_sandbox_confirmed_and_paystack_is():
    fw = (ROOT / "app/infrastructure/payments/flutterwave.py").read_text()
    ps = (ROOT / "app/infrastructure/payments/paystack.py").read_text()
    assert re.search(r"not_found_conclusive_after\s*=\s*None", fw)
    assert re.search(r"not_found_conclusive_after\s*=\s*timedelta\(seconds=120\)", ps)
