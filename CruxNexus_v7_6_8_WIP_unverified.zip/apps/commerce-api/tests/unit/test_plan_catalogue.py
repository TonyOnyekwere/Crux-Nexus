"""Unit: plan catalogue serialisation (CRX-FE-001). Pure, no database."""

from decimal import Decimal
from types import SimpleNamespace

from app.contexts.billing.application.plan_catalogue import (
    serialize_plan,
    serialize_resource_limits,
)


def _plan(**overrides):
    base = dict(
        code="starter", name="Starter",
        price_amount=Decimal("5000.00"), price_currency="NGN", billing_interval="monthly",
        trial_days=3, included_storefronts=1, base_staff_per_storefront=0,
        max_extra_storefronts=0, max_extra_staff=0,
        resource_limits={"products.max": 50},
        capabilities={"storefront.custom_domain": True},
        governance_version="v9", id="internal", active=True,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def test_priced_plan_is_serialised_with_currency_interval_trial_and_limits():
    out = serialize_plan(_plan())
    assert out["code"] == "starter" and out["name"] == "Starter"
    assert out["pricing_configured"] is True
    assert out["price"] == "5000.00"
    assert out["currency"] == "NGN"
    assert out["interval"] == "monthly"
    assert out["trial_days"] == 3
    assert out["limits"] == {
        "included_storefronts": 1,
        "base_staff_per_storefront": 0,
        "max_extra_storefronts": 0,
        "max_extra_staff": 0,
        "resources": {"products.max": 50},
    }


def test_internal_and_administrative_fields_are_never_exposed():
    out = serialize_plan(_plan())
    flat = repr(out)
    for forbidden in ("capabilities", "governance_version", "storefront.custom_domain", "internal", "active"):
        assert forbidden not in flat


def test_missing_price_reports_unconfigured_without_inventing_values():
    out = serialize_plan(_plan(price_amount=None))
    assert out["pricing_configured"] is False
    assert out["price"] is None and out["currency"] is None and out["interval"] is None


def test_missing_currency_or_unsupported_interval_is_unconfigured():
    assert serialize_plan(_plan(price_currency=None))["pricing_configured"] is False
    assert serialize_plan(_plan(billing_interval="weekly"))["pricing_configured"] is False
    assert serialize_plan(_plan(billing_interval=None))["pricing_configured"] is False


def test_currency_and_interval_are_normalised_and_decimals_not_floated():
    out = serialize_plan(_plan(price_currency=" ghs ", billing_interval="Annual", price_amount=Decimal("120000.5")))
    assert out["currency"] == "GHS" and out["interval"] == "annual"
    assert out["price"] == "120000.5"


def test_resource_limits_follow_entitlement_engine_semantics():
    out = serialize_resource_limits(
        {"b.none": None, "a.ok": 7, "c.neg": -1, "d.bool": True, "e.float": 1.5, "f.zero": 0}
    )
    assert out == {"a.ok": 7, "b.none": None, "c.neg": 0, "d.bool": 0, "e.float": 0, "f.zero": 0}
    assert list(out) == sorted(out)


def test_non_mapping_resource_limits_yield_empty():
    assert serialize_resource_limits(None) == {}
    assert serialize_resource_limits([1, 2]) == {}
