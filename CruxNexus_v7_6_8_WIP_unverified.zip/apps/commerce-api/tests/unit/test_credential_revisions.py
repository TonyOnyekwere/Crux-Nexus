"""Pure tests: immutable credential revisions (retention, purge, webhook candidates, safe activation) and
revision-bound encryption."""
import importlib.util
import pathlib
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[2]


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


rules = load("merchant_payment_rules", "app/contexts/commerce/domain/merchant_payment_rules.py")
vault = load("credential_vault", "app/infrastructure/secrets/credential_vault.py")


# ---- retention: a revision lives exactly as long as a payment may need it
def test_pending_payment_needs_its_credentials_and_settled_does_not():
    assert rules.payment_needs_credentials(status="pending", requires_refund=False)
    assert rules.payment_needs_credentials(status="successful", requires_refund=True)   # refund still owed
    for status in ("successful", "failed", "abandoned"):
        assert not rules.payment_needs_credentials(status=status, requires_refund=False)


def test_only_retired_revisions_can_be_purged_and_only_when_all_payments_settled():
    settled = [("successful", False), ("failed", False)]
    assert rules.revision_purgeable(revision_status="retired", referencing_payments=settled)
    assert rules.revision_purgeable(revision_status="retired", referencing_payments=[])
    assert not rules.revision_purgeable(revision_status="retired", referencing_payments=settled + [("pending", False)])
    assert not rules.revision_purgeable(revision_status="retired", referencing_payments=[("successful", True)])
    for status in ("active", "pending", "purged"):
        assert not rules.revision_purgeable(revision_status=status, referencing_payments=[])


def test_old_payment_keeps_resolving_against_old_account_after_replacement():
    """The disaster scenario: payment #1 on account A, merchant switches to B."""
    revisions = {"A": "retired", "B": "active"}
    payments = {"p1": ("A", "pending")}                     # payment 1 started against revision A
    # B is active, A is retired - but A must NOT be purgeable while p1 is pending
    refs_a = [(status, False) for rev, status in payments.values() if rev == "A"]
    assert not rules.revision_purgeable(revision_status=revisions["A"], referencing_payments=refs_a)
    # verification candidates for a webhook about p1: its own revision first
    assert rules.webhook_signature_candidates(payment_revision_id="A", active_revision_id="B") == ["A", "B"]
    # once p1 settles, A may be purged
    refs_a = [("successful", False)]
    assert rules.revision_purgeable(revision_status=revisions["A"], referencing_payments=refs_a)


def test_webhook_candidates_are_ordered_unique_and_bounded():
    assert rules.webhook_signature_candidates(payment_revision_id=None, active_revision_id="B") == ["B"]
    assert rules.webhook_signature_candidates(payment_revision_id="B", active_revision_id="B") == ["B"]
    assert rules.webhook_signature_candidates(payment_revision_id="A", active_revision_id=None) == ["A"]
    assert rules.webhook_signature_candidates(payment_revision_id=None, active_revision_id=None) == []


# ---- revision numbering and activation race
def test_revision_numbers_increase_monotonically():
    assert rules.next_revision_number([]) == 1
    assert rules.next_revision_number([1, 2, 5]) == 6


def test_slow_verification_cannot_overwrite_a_newer_change():
    assert rules.may_activate(candidate_revision=3, highest_revision=3, candidate_status="pending")
    # a newer replacement started while we were verifying
    assert not rules.may_activate(candidate_revision=3, highest_revision=4, candidate_status="pending")
    # a delete/replace already consumed this revision
    assert not rules.may_activate(candidate_revision=3, highest_revision=3, candidate_status="retired")
    assert not rules.may_activate(candidate_revision=3, highest_revision=3, candidate_status="active")


# ---- encryption binds a ciphertext to its own revision
def test_revision_aad_prevents_swapping_secrets_between_revisions():
    v = vault.CredentialVault({"v1": bytes(range(32))}, "v1")
    aad_a = vault.aad_for_revision("t", "c", "paystack", "rev-A")
    aad_b = vault.aad_for_revision("t", "c", "paystack", "rev-B")
    sealed_a = v.seal({"secret_key": "sk_live_AAAAAAAAAA"}, aad=aad_a)
    assert v.open(sealed_a, aad=aad_a)["secret_key"] == "sk_live_AAAAAAAAAA"
    with pytest.raises(vault.VaultDecryptionError):
        v.open(sealed_a, aad=aad_b)                      # revision A's secret cannot be served as revision B
    assert aad_a != vault.CredentialVault.aad_for("t", "c", "paystack")   # distinct from the legacy AAD format
