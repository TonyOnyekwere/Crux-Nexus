"""Test to verify UUID validation fix in staff invitation system."""

import pytest
from uuid import UUID, uuid4
from datetime import datetime, timezone

from app.contexts.billing.api.staff_invitation_schemas import (
    StaffInvitationResponse,
    StaffInvitationAcceptResponse,
    InvitationValidationResponse,
)


def test_staff_invitation_response_with_uuid_objects():
    """Test that StaffInvitationResponse can accept UUID objects from database."""
    # Simulate what the database model returns (UUID objects)
    invitation_data = {
        "id": uuid4(),
        "tenant_id": uuid4(),
        "invited_email": "test@example.com",
        "role": "staff",
        "status": "PENDING",
        "invited_by": uuid4(),
        "accepted_at": None,
        "accepted_by": None,
        "expires_at": datetime.now(timezone.utc),
        "notification_channel": "email",
        "notification_sent_at": None,
        "created_at": datetime.now(timezone.utc),
    }
    
    # This should not raise a validation error
    response = StaffInvitationResponse(**invitation_data)
    
    # Verify the data is correctly parsed
    assert isinstance(response.id, UUID)
    assert isinstance(response.tenant_id, UUID)
    assert isinstance(response.invited_by, UUID)
    assert response.invited_email == "test@example.com"
    assert response.role == "staff"
    assert response.status == "PENDING"


def test_staff_invitation_accept_response_with_uuid_objects():
    """Test that StaffInvitationAcceptResponse can accept UUID objects."""
    membership_data = {
        "membership_id": uuid4(),
        "tenant_id": uuid4(),
        "user_id": uuid4(),
        "role": "staff",
        "status": "ACTIVE",
        "message": "Invitation accepted successfully"
    }
    
    # This should not raise a validation error
    response = StaffInvitationAcceptResponse(**membership_data)
    
    # Verify the data is correctly parsed
    assert isinstance(response.membership_id, UUID)
    assert isinstance(response.tenant_id, UUID)
    assert isinstance(response.user_id, UUID)
    assert response.role == "staff"
    assert response.status == "ACTIVE"


def test_invitation_validation_response_with_string_tenant_id():
    """Test that InvitationValidationResponse can accept string tenant_id."""
    validation_data = {
        "valid": True,
        "tenant_id": str(uuid4()),  # String representation
        "invited_email": "test@example.com",
        "role": "staff",
        "expires_at": datetime.now(timezone.utc),
        "message": "Invitation is valid"
    }
    
    # This should work with string tenant_id
    response = InvitationValidationResponse(**validation_data)
    
    # Verify the data is correctly parsed
    assert response.valid is True
    assert isinstance(response.tenant_id, str)
    assert response.invited_email == "test@example.com"


def test_invitation_validation_response_without_tenant_id():
    """Test that InvitationValidationResponse works without tenant_id."""
    validation_data = {
        "valid": False,
        "message": "Invalid or expired invitation token"
    }
    
    # This should work without tenant_id
    response = InvitationValidationResponse(**validation_data)
    
    # Verify the data is correctly parsed
    assert response.valid is False
    assert response.tenant_id is None
    assert response.message == "Invalid or expired invitation token"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
