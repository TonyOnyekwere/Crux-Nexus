from app.contexts.commerce.domain.invariants import FULFILLMENT_TRANSITIONS, ORDER_TRANSITIONS


def test_order_lifecycle_reaches_completion():
    assert "confirmed" in ORDER_TRANSITIONS["pending_payment"]
    assert "fulfilling" in ORDER_TRANSITIONS["confirmed"]
    assert "shipped" in ORDER_TRANSITIONS["fulfilling"]
    assert "delivered" in ORDER_TRANSITIONS["shipped"]
    assert "completed" in ORDER_TRANSITIONS["delivered"]


def test_fulfillment_lifecycle_is_monotonic():
    assert FULFILLMENT_TRANSITIONS["unfulfilled"] == {"processing", "cancelled"}
    assert FULFILLMENT_TRANSITIONS["processing"] == {"shipped", "cancelled"}
    # Cancelling after shipment is not allowed: stock has already left, so a cancel
    # would release a reservation that no longer exists. Post-shipment = returns.
    assert FULFILLMENT_TRANSITIONS["shipped"] == {"delivered"}
    assert FULFILLMENT_TRANSITIONS["delivered"] == set()


def test_product_constitution_is_present():
    text = __import__("pathlib").Path("../../docs/CRUXNEXUS_PRODUCT_CONSTITUTION.md").read_text()
    required = [
        "Own Your Storefront",
        "Merchant-owned payments",
        "Merchant-configurable fulfillment",
        "Dynamic plans and entitlements",
        "Data portability",
    ]
    assert all(item in text for item in required)
