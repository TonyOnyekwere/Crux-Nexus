"""Pure tests: single storefront currency (NGN/GHS/KES/ZAR) as the authority for cart, order and payment."""
import importlib.util
import pathlib
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location("currency_rules", ROOT / "app/contexts/commerce/domain/currency_rules.py")
c = importlib.util.module_from_spec(_spec)
sys.modules["currency_rules"] = c
_spec.loader.exec_module(c)


def test_supported_set_is_exactly_the_four_locked_currencies_default_ngn():
    assert c.SUPPORTED_CURRENCIES == ("NGN", "GHS", "KES", "ZAR") and c.DEFAULT_CURRENCY == "NGN"


def test_normalization_defaults_and_rejections():
    assert c.normalize_currency(None) == "NGN" and c.normalize_currency("") == "NGN" and c.normalize_currency("  ") == "NGN"
    assert c.normalize_currency("ghs") == "GHS" and c.normalize_currency(" kes ") == "KES" and c.normalize_currency("ZAR") == "ZAR"
    for bad in ("USD", "EUR", "GBP", "XOF", "NG", "NAIRA", "123"):
        with pytest.raises(c.CurrencyError) as exc:
            c.normalize_currency(bad)
        assert exc.value.code == "UNSUPPORTED_CURRENCY"


def test_currency_change_allowed_only_while_nothing_is_priced():
    c.check_currency_change(current="NGN", requested="GHS", product_count=0, order_count=0)
    c.check_currency_change(current="NGN", requested="NGN", product_count=50, order_count=9)   # no change = fine
    for products, orders in ((1, 0), (0, 1), (10, 10)):
        with pytest.raises(c.CurrencyError) as exc:
            c.check_currency_change(current="NGN", requested="KES", product_count=products, order_count=orders)
        assert exc.value.code == "CURRENCY_LOCKED"


def test_mixed_or_foreign_currency_cart_is_rejected_not_converted():
    c.assert_single_currency_cart("NGN", ["NGN", "NGN"])
    c.assert_single_currency_cart("GHS", [])
    assert c.mismatched_currencies("NGN", ["NGN", "USD", "GHS", "usd"]) == ["GHS", "USD", "usd"]
    with pytest.raises(c.CurrencyError) as exc:
        c.assert_single_currency_cart("NGN", ["NGN", "GHS"])
    assert exc.value.code == "CURRENCY_MISMATCH" and "GHS" in exc.value.message


def test_the_storefront_scenario_from_the_review():
    """Storefront USD-like mismatch: product priced 100 in another currency must never become an NGN charge."""
    with pytest.raises(c.CurrencyError):
        c.assert_single_currency_cart("NGN", ["ZAR"])


def test_no_hardcoded_charge_currency_remains_in_checkout_or_cart():
    for rel in ("app/contexts/commerce/api/checkout_routes.py", "app/contexts/commerce/api/cart_routes.py"):
        text = (ROOT / rel).read_text()
        assert 'currency="NGN"' not in text and '"currency": "NGN"' not in text, rel
    checkout = (ROOT / "app/contexts/commerce/api/checkout_routes.py").read_text()
    assert checkout.count("currency=store_currency") >= 5          # order + payments + provider initialization


def test_clients_cannot_choose_a_product_currency_or_reset_the_storefront_currency():
    schemas = (ROOT / "app/contexts/commerce/api/schemas.py").read_text()
    product = schemas.split("class ProductCreate")[1].split("class ProductPatch")[0]
    import re
    assert not re.search(r"^\s+currency\s*:", product, re.M)       # no client-settable currency field
    upsert = schemas.split("class StorefrontUpsert")[1].split("class ProductCreate")[0]
    assert "currency: str | None" in upsert and 'default="NGN"' not in upsert
    routes = (ROOT / "app/contexts/commerce/api/storefront_routes.py").read_text()
    assert "exclude_unset=True" in routes.split("async def upsert_storefront")[1].split("async def publish_storefront")[0]
