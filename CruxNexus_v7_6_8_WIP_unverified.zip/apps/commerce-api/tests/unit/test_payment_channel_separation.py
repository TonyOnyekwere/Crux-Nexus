"""The subscription channel is never a customer gateway: gate logic + the real tree stay clean."""
import importlib.util
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location("check_sep", ROOT / "scripts/check_payment_channel_separation.py")
gate = importlib.util.module_from_spec(_spec)
sys.modules["check_sep"] = gate
_spec.loader.exec_module(gate)


def _scan(source: str, fn):
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d) / "x.py"
        p.write_text(source)
        return fn(p)


def test_real_tree_has_no_violations():
    bad = []
    for path in gate.py_files("contexts/commerce/**/*.py", "workers/commerce_*.py"):
        bad += [(str(path), *v) for v in gate.violations_commerce(path)]
    for path in gate.py_files("contexts/billing/**/*.py", "infrastructure/payments/**/*.py"):
        bad += [(str(path), *v) for v in gate.violations_billing(path)]
    assert bad == []


def test_detects_registry_import_reference_and_platform_secret_use():
    assert _scan("from app.infrastructure.payments.adapter import get_payment_provider_registry\n", gate.violations_commerce)
    assert _scan("def f():\n    return get_payment_provider_registry()\n", gate.violations_commerce)
    assert _scan("from app.infrastructure.payments.setup import configure_payment_providers\n", gate.violations_commerce)
    assert _scan("def f(s):\n    return s.PAYSTACK_SECRET_KEY\n", gate.violations_commerce)
    assert _scan("def f(s):\n    return getattr(s, 'FLUTTERWAVE_SECRET_KEY')\n", gate.violations_commerce)


def test_detects_subscription_code_importing_commerce():
    assert _scan("from app.contexts.commerce.domain.models import Order\n", gate.violations_billing)
    assert _scan("import app.contexts.commerce.api.x\n", gate.violations_billing)


def test_comments_and_docstrings_cannot_trigger_or_hide_it():
    clean = '"""Mentions get_payment_provider_registry in docs only."""\n# PAYSTACK_SECRET_KEY\nx = 1\n'
    assert _scan(clean, gate.violations_commerce) == []


def test_the_merchant_adapter_builder_is_the_only_checkout_adapter_source():
    text = (ROOT / "app/contexts/commerce/api/checkout_routes.py").read_text()
    assert "_mp.build_adapter(db, merchant_connection, merchant_credential.id)" in text
    assert "PAYMENT_PROVIDER_NOT_CONNECTED" in text
