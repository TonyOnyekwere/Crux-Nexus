"""Architecture gate: honest RLS status reporting."""

from app.database.tenant_scope import CONTROL_PLANE_TABLES, TENANT_SCOPED_TABLES


def test_commerce_tables_are_registered_for_rls():
    assert set(TENANT_SCOPED_TABLES) == {
        "storefront_profiles", "products", "inventory_movements", "customers",
        "carts", "cart_items", "orders", "order_items", "commerce_payments", "fulfillments",
        "storefront_configurations", "merchant_payment_connections", "commerce_checkout_idempotency",
        "merchant_payment_credentials", "merchant_payment_events",
    }


def test_rls_gate_documents_vacuous_pass_when_registry_empty():
    from pathlib import Path

    tenant_scope = Path(__file__).resolve().parents[2] / "app" / "database" / "tenant_scope.py"
    content = tenant_scope.read_text(encoding="utf-8")
    assert "FORCE ROW LEVEL SECURITY" in Path(__file__).resolve().parents[2].joinpath("migrations/versions/030_commerce_os_mvp.py").read_text()


def test_every_commerce_model_with_tenant_id_is_registered_for_rls():
    """A new tenant-owned table must be added to TENANT_SCOPED_TABLES in the same change."""
    import re
    from pathlib import Path

    root = Path(__file__).resolve().parents[2]
    models = (root / "app/contexts/commerce/domain/models.py").read_text(encoding="utf-8")
    blocks = re.split(r"\nclass ", models)
    unregistered = []
    for block in blocks:
        table = re.search(r'__tablename__ = "(\w+)"', block)
        if table and "tenant_id = Column(" in block and table.group(1) not in TENANT_SCOPED_TABLES and table.group(1) not in CONTROL_PLANE_TABLES:
            unregistered.append(table.group(1))
    assert not unregistered, f"tenant-owned tables missing from TENANT_SCOPED_TABLES (or CONTROL_PLANE_TABLES for non-secret routing): {unregistered}"


def test_migration_045_forces_rls_on_late_added_tables():
    from pathlib import Path

    text = Path(__file__).resolve().parents[2].joinpath(
        "migrations/versions/045_rls_for_storefront_config_payment_connections_idempotency.py").read_text()
    for table in ("storefront_configurations", "merchant_payment_connections", "commerce_checkout_idempotency"):
        assert table in text
    assert "FORCE ROW LEVEL SECURITY" in text and "WITH CHECK" in text
    assert "webhook_access" not in text  # credential references must stay unreadable under the webhook flag


def test_credential_tables_are_tenant_scoped_and_routing_table_holds_no_secrets():
    from pathlib import Path

    assert {"merchant_payment_credentials", "merchant_payment_events"} <= set(TENANT_SCOPED_TABLES)
    assert "payment_webhook_routes" in CONTROL_PLANE_TABLES
    models = (Path(__file__).resolve().parents[2] / "app/contexts/commerce/domain/models.py").read_text(encoding="utf-8")
    route_block = models.split("class PaymentWebhookRoute")[1]
    for forbidden in ("ciphertext", "secret", "credential", "payload"):
        assert forbidden not in route_block.lower().split("created_at")[0]


def test_every_orm_table_is_classified_exactly_once():
    """A new table must be declared tenant-scoped (RLS) or control-plane in the same change."""
    import re
    from pathlib import Path

    app_dir = Path(__file__).resolve().parents[2] / "app"
    tables = set()
    for path in app_dir.rglob("*.py"):
        tables |= set(re.findall(r'__tablename__ = "(\w+)"', path.read_text(encoding="utf-8")))
    scoped, control = set(TENANT_SCOPED_TABLES), set(CONTROL_PLANE_TABLES)
    assert not (tables - scoped - control), f"unclassified tables: {sorted(tables - scoped - control)}"
    assert not (scoped & control)
