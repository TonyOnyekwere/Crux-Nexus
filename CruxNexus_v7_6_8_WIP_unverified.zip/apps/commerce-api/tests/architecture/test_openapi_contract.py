"""Architecture gate: OpenAPI contract exposes canonical routes."""

import json
from pathlib import Path

from app.main import app

CORE_ROUTES = [
    "/api/v1/identity/users",
    "/api/v1/identity/login",
    "/api/v1/identity/switch-tenant",
    "/api/v1/identity/storefronts",
    "/api/v1/onboarding/journey/register",
    "/api/v1/onboarding/journey/merchant",
    "/api/v1/storefronts",
    "/api/v1/merchant/storefronts",
    "/health/live",
    "/health/ready",
]


def test_openapi_contains_core_routes():
    schema = app.openapi()
    paths = schema["paths"]
    for route in CORE_ROUTES:
        assert route in paths, f"Missing route: {route}"


def test_openapi_artifact_can_be_generated():
    from pathlib import Path

    script = Path(__file__).resolve().parents[2] / "scripts" / "generate_openapi.py"
    assert script.exists()


def test_committed_openapi_route_contract_matches_runtime():
    artifact = Path(__file__).resolve().parents[2] / "openapi.json"
    committed = json.loads(artifact.read_text(encoding="utf-8"))
    runtime = app.openapi()
    assert set(committed["paths"]) == set(runtime["paths"]), "openapi.json route set is stale"
    for path, operations in runtime["paths"].items():
        assert set(committed["paths"][path]) == set(operations), f"openapi.json methods are stale for {path}"
