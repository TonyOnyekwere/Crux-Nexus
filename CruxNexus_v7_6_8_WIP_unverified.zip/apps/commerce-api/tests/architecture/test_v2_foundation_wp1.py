"""Architecture gate for CRX-FE-003 WP1: migration 049 shape, classification and model parity.

Static checks only. They are NOT evidence that the migration applies; that is the Postgres
integration test and the CI migration smoke test.
"""

import re
from pathlib import Path

from app.database.tenant_scope import CONTROL_PLANE_TABLES, TENANT_SCOPED_TABLES

ROOT = Path(__file__).resolve().parents[2]
MIGRATIONS = ROOT / "migrations" / "versions"
MIGRATION = MIGRATIONS / "049_v2_onboarding_foundation.py"


def test_migration_049_is_the_single_head_after_048():
    revisions = {}
    for path in MIGRATIONS.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        rev = re.search(r'^revision\s*=\s*"([^"]+)"', text, re.M)
        down = re.search(r'^down_revision\s*=\s*(?:"([^"]+)"|None)', text, re.M)
        if rev:
            revisions[rev.group(1)] = down.group(1) if down else None
    assert revisions["049"] == "048"
    parents = {d for d in revisions.values() if d}
    heads = [r for r in revisions if r not in parents]
    assert heads == ["049"], f"expected a single head 049, got {heads}"


def test_migration_detects_duplicates_before_adding_the_constraint_and_never_deletes_history():
    text = MIGRATION.read_text(encoding="utf-8")
    assert text.index("find_duplicate_trial_merchants(connection)") < text.index("create_unique_constraint")
    assert "raise RuntimeError" in text
    upgrade = text.split("def upgrade()")[1].split("def downgrade()")[0]
    assert "DELETE FROM merchant_trial_history" not in upgrade
    assert "DELETE FROM" not in upgrade


def test_new_tables_are_control_plane_and_not_tenant_scoped():
    for table in ("onboarding_idempotency_keys", "onboarding_slug_reservations"):
        assert table in CONTROL_PLANE_TABLES
        assert table not in TENANT_SCOPED_TABLES


def test_downgrade_reverses_everything_upgrade_creates():
    text = MIGRATION.read_text(encoding="utf-8")
    down = text.split("def downgrade()")[1]
    for needle in (
        'drop_table("onboarding_slug_reservations")',
        'drop_table("onboarding_idempotency_keys")',
        "drop_constraint(TRIAL_UNIQUE_NAME",
    ):
        assert needle in down


def test_constraint_names_match_between_migration_and_models():
    migration = MIGRATION.read_text(encoding="utf-8")
    models = (ROOT / "app/contexts/onboarding/domain/journey_v2_models.py").read_text(encoding="utf-8")
    trial = (ROOT / "app/contexts/billing/domain/merchant_trial_history.py").read_text(encoding="utf-8")
    names = set(re.findall(r'name="([^"]+)"', models))
    assert names, "models must declare named constraints"
    for name in names:
        assert name in migration, f"{name} declared in model but missing from migration 049"
    assert "uq_merchant_trial_history_merchant" in trial
    assert 'TRIAL_UNIQUE_NAME = "uq_merchant_trial_history_merchant"' in migration
