# CruxNexus Commerce OS MVP v7.6.0

This release implements the Gate 1, Gate 2 and Gate 3 corrections from the current v7.5.2 source review. It is a hardening release on top of the real Commerce MVP, not a new architecture prototype.

## Gate 1: commercial correctness

- Paid subscription periods now establish `ends_at` from persisted plan billing intervals.
- Renewal activation extends the paid period instead of leaving `ends_at` stale.
- Added subscription lifecycle worker: `ACTIVE -> PAST_DUE -> SUSPENDED` with a three-day grace period.
- Suspension propagates to owned active storefront tenants; successful payment reactivation restores suspended tenants.
- Commerce payment reconciliation now handles stale online payments independently of subscription reconciliation.
- Late successful payment never resurrects a cancelled order; it is recorded and marked `requires_refund` for reconciliation.
- Product PATCH can no longer mutate stock. Inventory adjustment is the stock mutation authority.
- Storefront publishing now requires active/trialing commercial state, an active tenant, complete profile and at least one published product.
- Onboarding creates storefronts unpublished; publishing is a separate readiness-gated operation.
- Checkout delivery fees are server-owned. The current MVP policy is zero until a logistics pricing domain exists.
- Order fulfillment transitions are centrally guarded by order/payment state.
- Provider verification now distinguishes `SUCCESS`, `PENDING`, `FAILED`, `NOT_FOUND` and `UNKNOWN` instead of treating every non-success response as failure.
- Fresh subscription payment attempts cannot be closed as provider-not-found during the initialization window, preventing a concurrent second charge.

## Gate 2: worker and entitlement hardening

- All worker loops share one database engine/session factory.
- Added the subscription lifecycle loop as the seventh worker loop.
- Commerce worker now reconciles stale online payments as well as inventory reservations.
- Entitlement allocation checks enforce entitlement start/end windows synchronously.
- Added merchant-facing staff-capacity allocation/deallocation endpoints.
- Allocation anomalies are stateful and deduplicated through `allocation_anomalies` instead of emitting repeated events every sweep.
- Stale subscription payment reconciliation uses `FOR UPDATE SKIP LOCKED`.

## Gate 3: security/runtime correctness

- Production requires a separate non-superuser `DATABASE_RUNTIME_URL`.
- Migration `034` provisions/updates the runtime role from that URL and explicitly enforces `NOSUPERUSER NOBYPASSRLS`.
- Commerce tenant RLS remains active and forced for all merchant-owned tables.
- Added a runtime-role security test proving the role is not superuser/BYPASSRLS and cannot read another tenant's Commerce rows.
- Adversarial tests are now included in CI.
- Replaced phone + order-number guest authorization with a per-order access token delivered at checkout and supplied through `X-Order-Access-Token`.
- Added Redis-backed rate limiting to public order lookup.
- Added Prometheus `/metrics` and worker failure metrics.
- Production requires at least one real payment provider and requires HTTPS `PUBLIC_APP_URL`.
- Real SendGrid notification delivery replaces the logging notification provider as the application default.
- CI now checks the committed OpenAPI artifact against the runtime FastAPI schema.
- Corrected Railway IaC repository reference to `TonyOnyekwere/Crux-Nexus`.

## Database head

`035` is the current Alembic head.

## Verification

- `python -m compileall -q app migrations tests`: PASS
- Model attribute static check: PASS, 30 models / 0 issues
- Test-reference static check: PASS
- Frozen identifier check: PASS
- OpenAPI artifact regenerated from the runtime application schema using the authoring environment's import stubs; CI must perform the authoritative dependency-backed check.
- PostgreSQL integration/security tests were not executable in this authoring environment because `asyncpg` and the project PostgreSQL service are unavailable here. CI/PostgreSQL remains the authoritative runtime verification gate.
