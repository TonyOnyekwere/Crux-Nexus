# CruxNexus v7.6.6 — merchant-owned payments, generalized entitlements, baseline plan matrix

Base: v7.6.5. Implements the three engineering gates from the confirmed answers (plan matrix, add-on purchases,
merchant-owned payments) plus the rule that the subscription payment channel is never a customer gateway.

## Correction to my v7.6.5 notes
I wrote that `merchant_entitlements.entitlement_type` was "DB-constrained to extra_storefront/extra_staff". That was wrong: the column is a
free `String(50)`; only the Python enum was narrow. Generalizing it therefore needed no data rewrite (migration 046 adds `kind` and
`grant_metadata` and a key-format CHECK).

## 1. Customer payments are now merchant-owned (the previous design was a violation)
Before: checkout, the commerce webhook path and the reconciliation worker all used the PLATFORM provider registry and the platform webhook
inbox, i.e. customers paid into CruxNexus's provider account. Now:
- `infrastructure/secrets/credential_vault.py`: AES-256-GCM, versioned keys (rotation), AAD binds each ciphertext to
  tenant|connection|provider so a copied ciphertext fails authentication. Keys come from `CREDENTIAL_ENCRYPTION_KEYS` (never the DB).
- Migration 046: `merchant_payment_credentials` (sealed, tenant RLS), `merchant_payment_events` (per-merchant webhook inbox, tenant RLS,
  unique per connection+event id, worker access policy), `payment_webhook_routes` (non-secret token -> tenant/connection routing; the only
  way an unauthenticated webhook finds its merchant without loosening RLS on credentials), `commerce_payments.connection_id`.
- `PUT /api/v1/commerce/payment-connections/{provider}/credentials` is WRITE-ONLY: validates key shape, seals, verifies with the provider
  (read-only call), and only then marks `connected`. Returns the merchant's webhook URL; never a secret. `DELETE` purges stored secrets.
  Test-mode keys are refused in production. The number of providers is bounded by the plan limit `payments.providers`.
- Checkout: an online method requires the merchant's own `connected` connection, checked BEFORE stock is reserved
  (409 `PAYMENT_PROVIDER_NOT_CONNECTED`). The payment is initialized with an adapter built from that merchant's credentials and records
  `connection_id`. No connection => no online option; POD / bank transfer / pickup are unaffected.
- `POST /api/v1/payments/webhooks/{token}`: route by token, verify the signature with THAT merchant's credentials, persist, then verify
  with the merchant's provider account and apply through the existing order/payment state machine. Unreachable provider => left
  unprocessed for the worker; duplicate delivery => 200.
- Worker (`commerce_reconciliation`): stale payments are re-queried with each payment's own merchant credentials under that tenant's
  binding; unprocessed merchant events are swept; reservation expiry now releases via the movement ledger and handles retried payments.
- The platform webhook inbox no longer processes commerce events at all.
- **CI gate** `scripts/check_payment_channel_separation.py` (AST; 13 violations on v7.6.4, 0 now): commerce code may not import the platform
  registry or read platform provider secrets; subscription code may not import commerce. Added to CI with the undefined-name gate;
  the lint job now installs requirements before its `import app.main` step (it could not have passed without them).

## 2. Entitlements generalized (migration 046)
`merchant_entitlements`: `entitlement_type` is an opaque key; new `kind` (capability|resource|add_on) and `grant_metadata`
(`{"capabilities": [...], "limits": {key: per_unit}}`, multiplied by quantity). `entitlement_policy.addon_grants()` folds active,
in-window grants into the effective policy (time windows enforced synchronously). Starter buys `custom_domain` => capability +
domain-count bonus; Enterprise has it in-plan. Legacy `extra_staff` / `extra_storefront` rows are unchanged (empty metadata => no policy
effect; CapacityService still governs them).

## 3. Baseline plan matrix (Control Center data)
`apps/control-center-api/app/seed/plan_policy_v1.json` encodes the supplied matrix (capabilities + limits, depth levels 1/2/3 for
Basic/Advanced/Full). `POST /api/v1/governance/plan-policy/baseline?dry_run=true|false` (platform_admin) shows a diff, then applies through
audit + sync outbox. It touches ONLY capabilities and resource_limits; plans must already exist (price/interval/quantities are never invented).
Both Control Center and Commerce now validate capability/limit shapes (non-negative integers, key format), and warn when `staff.accounts` /
`storefronts.active` disagree with the legacy plan columns that CapacityService still enforces.

## Verification (precise)
- EXECUTED: vault 9 (real AES-GCM), merchant payment rules 9, channel-separation 5, fulfillment rules 14, entitlement/presentation/add-on 36,
  Control Center plan policy 8. compileall, undefined-name gate (both services), model-attribute checker, review gate 40/40, ci.yml parse,
  migration chain 001-046 single head, tenant-index gate, ORM-table classification (every table scoped or control-plane).
- NOT executed: anything touching PostgreSQL/Redis/providers: migration 046, the credential intake and webhook routes, checkout/worker
  changes, the baseline route. Provider credential-check endpoints (Paystack `/bank`, Flutterwave `/banks/NG`) and Flutterwave webhook
  header/hash behaviour are unconfirmed against real sandboxes.

## Deploy order (required)
1. Set `CREDENTIAL_ENCRYPTION_KEYS` (e.g. `v1:<base64 of 32 random bytes>`; `credential_vault.generate_key()` makes one) on the Commerce API
   and worker services, and keep it in a secret manager. Losing it makes stored merchant credentials unrecoverable.
2. Run migrations 045 and 046. 3. Define the three plans in the Control Center, then call the baseline route with `dry_run=true`, review, apply.
Until step 3, capability checks DENY (deny by default) and unlimited limits apply.

## Still open
- Tier-gated enforcement points for: variants, orders/month, storage, bandwidth, staff via the policy engine, delivery zones, promotions,
  analytics depth, theme/layout depth levels (limits exist as data; most are not yet checked in code). Products, custom domains,
  payment providers, component slots and CSS size are enforced.
- Add-on purchase/grant API in the Control Center (the table and policy fold are ready; nothing issues add-on grants yet).
- Bank-transfer instructions per merchant; fulfillment methods/zones as merchant data (delivery fee still server-owned zero); checkout
  currency is still hard-coded NGN; refunds/returns; DNS verification + TLS for custom domains; visual builder; cross-merchant discovery;
  data export; behavioural tests on CI Postgres.
- The payment-intake route is rate-limited by nothing yet; a credential-guessing/abuse limiter is needed before launch.
- Platform `PaymentProvider` enum still names paystack/flutterwave in the checkout contract; making checkout fully provider-neutral
  (merchant picks any registered adapter) remains.
