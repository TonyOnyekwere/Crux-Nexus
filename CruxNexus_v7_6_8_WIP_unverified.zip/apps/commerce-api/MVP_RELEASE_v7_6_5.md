# CruxNexus v7.6.5 — defect fixes + tier entitlement engine + merchant-owned presentation/payment connections

Base: CruxNexus_MVP_v7_6_4_product_foundation.zip (your build). Guided by the confirmed decisions in
docs/CRUXNEXUS_PRODUCT_CONSTITUTION.md section 13.

## Defects fixed (all verified against the code first)
1. `merchant_management/application/services.py`: `TenantMembership` never imported (staff entitlement routes would NameError).
2. 53 `__pycache__` dirs / 239 `.pyc` files shipped in the archive; removed, `.gitignore` added.
3. Cancelling a shipped order released a reservation already consumed at shipment (corrupting other orders' reservations).
   Cancellation is now refused after shipment; post-shipment issues belong to returns (not built).
4. Cancelling a paid prepaid/bank-transfer order never flagged a refund; now sets `requires_refund` on the payment.
5. Fulfillment handler used a single-row payment lookup (raises on retried payments); now uses the latest attempt.
6. Reservation release trusted counters, not the ledger: a failed/expired order could release twice. New `outstanding_reservation()`
   (sum of reserved_delta per order reference) is now the authority; shipment verifies this order's own reservation.
7. Amount/currency-mismatch payment path set `payment_failed` but never released the reservation (held until manual action).
8. Tenant isolation: `storefront_configurations`, `merchant_payment_connections`, `commerce_checkout_idempotency` had no RLS and
   were unregistered. Migration 045 forces RLS + isolation policy (no webhook policy on payment connections) and adds the four
   tenant-first indexes the architecture gate found missing on older tables. New gate test fails if any commerce model with
   `tenant_id` is not registered.

## Canonical order/fulfillment rules
`commerce/domain/fulfillment_rules.py` (pure) holds BOTH transition tables and the planner:
confirmed -> fulfilling -> shipped -> delivered -> completed. POD may fulfil before payment (paid on delivery); prepaid and bank
transfer require payment. Stock deducted at shipment. `invariants.py` re-exports the tables. 14 pure tests.

## Tier entitlement engine (Control Center data, no tier names in code)
`app/kernel/access/entitlement_policy.py` + `policy_loader.py`: capability (deny by default) and limit (absent = unlimited,
0 = none, malformed = fail closed) checks; standing from subscription (active/trialing FULL, past_due RESTRICTED, else BLOCKED);
per-feature lifecycle ACTIVE / READ_ONLY / PRESERVED_INACTIVE / UNAVAILABLE / SUSPENDED implementing "preserve, disable further
use, auto-restore". 28 pure tests (policy + presentation validation).

## New merchant APIs (/api/v1/commerce) and public read
- `GET/PUT /storefront/presentation`: theme, fonts, layout, component slots, custom CSS. Only CHANGED parts need entitlement
  (a downgraded merchant can still save other settings); slot depth and CSS-size limits come from the plan; CSS is validated hard
  (no url(), @import, expression, escapes, @font-face, fixed positioning, size caps).
- `POST/DELETE /storefront/custom-domain`: capability `storefront.custom_domain`; hostname validated (no IPs, platform domains,
  reserved names); status stays `pending` - only a future DNS-verification flow may set `verified`. Removal is always allowed.
- `GET/PUT /payment-connections`, `POST .../{provider}/disable`: records which provider account the merchant intends to use.
  Rejects any secret-looking field. Status never becomes `connected` via this API.
- `GET /api/v1/storefronts/{slug}/presentation` (public): renders only features the merchant is currently entitled to;
  preserved-but-inactive customization stays in the database and is not served.
- Product creation enforces the plan limit `products` (existing products are never touched by a downgrade).

Capability keys: `storefront.theme_customization`, `storefront.component_slots`, `storefront.custom_css`, `storefront.custom_domain`.
Limit keys: `products`, `storefront.component_slots`, `storefront.custom_css_bytes`.

## Verification (precise)
- EXECUTED: 14 fulfillment-rule tests + 28 entitlement/presentation tests pass; compileall PASS (both services); undefined-name
  gate 0 (both services); model-attribute checker 0; review gate 40/40; migration chain 001-045 single head, no breaks; every
  tenant-scoped table has a tenant-first index; no duplicate routes (30).
- NOT executed: anything touching PostgreSQL/Redis (the rewritten fulfillment handler, ledger queries, new routes, migration 045).
  CI is the proof; do not call this live-verified.

## NOT done - needs your decision or a later build
1. **Tier matrix.** Plans currently have empty capabilities, so every customization capability is DENIED until the Control Center
   sets them (deny by default). Which capabilities/limits does each tier get? I seeded nothing.
2. **Add-on purchases** (custom domain on Starter/Business): `merchant_entitlements.entitlement_type` is DB-constrained to
   extra_storefront/extra_staff. A feature-type entitlement + migration is required; `effective_policy` already accepts add-ons.
3. **Merchant-owned checkout payments.** Checkout still initializes payments with the PLATFORM provider adapters. Per the confirmed
   decision it must instead use each merchant's own provider credentials. Needs a credential-storage design (envelope encryption /
   KMS, rotation, verification flow) before any code. Until then, online customer payments should stay disabled for real merchants.
4. Custom-domain DNS verification + TLS issuance; visual storefront builder; fulfillment methods/zones as merchant data (delivery fee
   is still a server-owned zero); promotions; storage/bandwidth/order limits enforcement points; data export; cross-merchant
   discovery; refunds/returns; behavioural commerce tests on CI Postgres (current "specs" only grep source text).
5. Idempotency table stores the checkout response (including the order access token) in plaintext JSONB.
