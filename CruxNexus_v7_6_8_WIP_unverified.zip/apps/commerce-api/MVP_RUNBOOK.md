# CruxNexus Commerce OS MVP Backend

This repository now contains a concrete merchant runtime in addition to the onboarding and platform foundation.

## Runtime flow

Merchant:

1. Register and verify OTP.
2. Create merchant account.
3. Configure business/storefront.
4. Select plan and complete subscription payment.
5. Storefront profile is provisioned through the canonical tenant/capacity service and remains unpublished until readiness checks pass.
6. Switch into the tenant.
7. Create/publish products and adjust inventory.

Customer:

1. Open `GET /api/v1/storefronts/{slug}`.
2. Create a guest cart.
3. Add published products.
4. Checkout with pay-on-delivery, bank transfer, Paystack, or Flutterwave.
5. Receive a durable order number.
6. Merchant processes fulfillment and tracking.
7. Guest retrieves the order using the one-time order access token returned at checkout.

## Database

Run migrations through the current Alembic head:

```powershell
alembic upgrade head
```

The Commerce migrations create and RLS-protect:

- storefront_profiles
- products
- inventory_movements
- customers
- carts
- cart_items
- orders
- order_items
- commerce_payments
- fulfillments

It also adds the public active-storefront read policy required by the existing `tenants` RLS design.

## Merchant API

- `PUT /api/v1/commerce/storefront`
- `POST /api/v1/commerce/storefront/publish`
- `POST /api/v1/commerce/products`
- `GET /api/v1/commerce/products`
- `PATCH /api/v1/commerce/products/{product_id}`
- `POST /api/v1/commerce/inventory/{product_id}/adjust`
- `GET /api/v1/commerce/orders`
- `GET /api/v1/commerce/orders/{order_id}`
- `PATCH /api/v1/commerce/orders/{order_id}/fulfillment`
- `POST /api/v1/commerce/payments/{reference}/confirm-bank-transfer`

All merchant endpoints require the existing verified tenant token and PostgreSQL tenant context.

## Public storefront API

- `GET /api/v1/storefronts/{slug}`
- `GET /api/v1/storefronts/{slug}/products`
- `POST /api/v1/storefronts/{slug}/cart`
- `GET /api/v1/storefronts/{slug}/cart with `X-Cart-Token` header`
- `POST /api/v1/storefronts/{slug}/cart/items with `X-Cart-Token` header`
- `POST /api/v1/storefronts/{slug}/checkout with `X-Cart-Token` header`
- `GET /api/v1/storefronts/{slug}/orders/{order_number} with `X-Order-Access-Token` header`
- `POST /api/v1/billing/webhooks/{provider}`

Guest checkout requires no customer account.

## Background processing

The worker now also runs commerce reservation reconciliation. Abandoned or expired pending checkouts release reserved stock and write an inventory movement.

## Payment providers

Paystack and Flutterwave use the existing provider adapter contract. When credentials are configured, checkout initializes the hosted provider payment after the local order/payment records are committed. Webhooks independently verify amount and currency before marking the commerce payment successful.

Pay-on-delivery and bank transfer work without external provider credentials. Bank transfers are confirmed by the merchant after receipt verification.

## Verification performed on the archive

Python bytecode compilation succeeds for the application, tests, migrations, and new commerce code. Full PostgreSQL integration tests still require the project's CI/PostgreSQL environment.
