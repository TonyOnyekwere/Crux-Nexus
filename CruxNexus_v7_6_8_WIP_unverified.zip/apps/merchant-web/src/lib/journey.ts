import type { Journey, JourneyStage } from "./types";

/** Rail rows shown to the merchant; each maps to the server stages that make it current. */
export const RAIL: { key: string; label: string; stages: JourneyStage[] }[] = [
  { key: "verify", label: "Verify your account", stages: ["REGISTERED"] },
  { key: "business-name", label: "Name your business", stages: ["OTP_VERIFIED"] },
  { key: "business-details", label: "Business details", stages: ["MERCHANT_CREATED"] },
  { key: "plan", label: "Choose a plan", stages: ["BUSINESS_CONFIGURED"] },
  { key: "payment", label: "Pay for your plan", stages: ["PLAN_SELECTED", "PAYMENT_PENDING"] },
  { key: "storefront", label: "Create your storefront", stages: ["PAYMENT_CONFIRMED"] },
  { key: "finish", label: "Finish setup", stages: ["STOREFRONT_READY"] },
];

export function railIndex(stage: JourneyStage): number {
  if (stage === "COMPLETED") return RAIL.length;
  const idx = RAIL.findIndex((r) => r.stages.includes(stage));
  return idx === -1 ? 0 : idx;
}

const ORDER: JourneyStage[] = [
  "REGISTERED",
  "OTP_VERIFIED",
  "MERCHANT_CREATED",
  "BUSINESS_CONFIGURED",
  "PLAN_SELECTED",
  "PAYMENT_PENDING",
  "PAYMENT_CONFIRMED",
  "STOREFRONT_READY",
  "COMPLETED",
];

export function stageAtLeast(stage: JourneyStage, minimum: JourneyStage): boolean {
  return ORDER.indexOf(stage) >= ORDER.indexOf(minimum);
}

export function allows(journey: Journey, action: string): boolean {
  return journey.allowed_actions.includes(action);
}
