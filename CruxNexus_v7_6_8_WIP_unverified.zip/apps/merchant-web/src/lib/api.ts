import { COMMERCE_API_URL } from "./config";
import { type FaultKind, record, sanitize } from "./diagnostics";
import { getGlobalToken, getTenantSession } from "./session";

export type TokenKind = "global" | "tenant" | "none";

/** Codes where the provider's outcome is unknown or unverifiable: never treat as failure, never re-charge. */
const PROVIDER_UNCERTAIN = new Set(["PAYMENT_OUTCOME_UNKNOWN", "PRIOR_PAYMENT_UNVERIFIED"]);

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details: Record<string, unknown>;
  readonly kind: FaultKind;
  readonly retryAfterSeconds: number | null;
  readonly requestId: string | null;

  constructor(init: {
    status: number;
    code: string;
    message: string;
    details?: Record<string, unknown>;
    kind: FaultKind;
    retryAfterSeconds?: number | null;
    requestId?: string | null;
  }) {
    super(init.message);
    this.name = "ApiError";
    this.status = init.status;
    this.code = init.code;
    this.details = init.details ?? {};
    this.kind = init.kind;
    this.retryAfterSeconds = init.retryAfterSeconds ?? null;
    this.requestId = init.requestId ?? null;
  }
}

export const AUTH_EXPIRED_EVENT = "cnx:auth-expired";

interface ParsedError {
  code: string;
  message: string;
  details: Record<string, unknown>;
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/** Understands the backend's {detail:{error:{code,message,details}}} envelope, plain string and 422 list details. */
function parseError(body: unknown): ParsedError | null {
  if (!isRecord(body)) return null;
  const detail = body["detail"];
  const envelope = isRecord(detail) ? detail["error"] : body["error"];
  if (isRecord(envelope) && typeof envelope["code"] === "string") {
    return {
      code: envelope["code"],
      message: typeof envelope["message"] === "string" ? envelope["message"] : "The request was rejected.",
      details: isRecord(envelope["details"]) ? envelope["details"] : {},
    };
  }
  if (typeof detail === "string") return { code: "REJECTED", message: detail, details: {} };
  if (Array.isArray(detail)) {
    const messages = detail
      .map((d) => (isRecord(d) && typeof d["msg"] === "string" ? d["msg"].replace(/^Value error, /, "") : null))
      .filter((m): m is string => m !== null);
    return { code: "VALIDATION", message: messages.join(" ") || "Some fields are invalid.", details: {} };
  }
  return null;
}

function classify(status: number, code: string): FaultKind {
  if (PROVIDER_UNCERTAIN.has(code)) return "provider_uncertain";
  if (status === 401) return "auth_expired";
  if (status === 429 || status === 423) return "rate_limited";
  if (status >= 500) return "server_error";
  return "api_rejection";
}

function pickToken(kind: TokenKind): string | null {
  if (kind === "none") return null;
  if (kind === "tenant") return getTenantSession()?.token ?? null;
  return getGlobalToken();
}

export interface ApiOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  token?: TokenKind;
  signal?: AbortSignal;
}

export async function api<T>(path: string, options: ApiOptions = {}): Promise<T> {
  const method = options.method ?? "GET";
  const tokenKind = options.token ?? "global";
  const started = performance.now();
  const requestSummary = sanitize(options.body ?? null);

  if (!COMMERCE_API_URL) {
    const err = new ApiError({
      status: 0,
      code: "FRONTEND_NOT_CONFIGURED",
      message: "NEXT_PUBLIC_COMMERCE_API_URL is not set for this deployment.",
      kind: "frontend",
    });
    record({ method, path, status: null, durationMs: 0, kind: "frontend", requestId: null, retryAfter: null, rateLimit: {}, request: requestSummary, response: null, note: err.message });
    throw err;
  }

  const token = pickToken(tokenKind);
  if (tokenKind !== "none" && !token) {
    const err = new ApiError({ status: 401, code: "NO_SESSION", message: "Sign in to continue.", kind: "auth_expired" });
    if (typeof window !== "undefined") window.dispatchEvent(new Event(AUTH_EXPIRED_EVENT));
    throw err;
  }

  const headers: Record<string, string> = { Accept: "application/json" };
  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;

  let response: Response;
  try {
    response = await fetch(`${COMMERCE_API_URL}${path}`, {
      method,
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      signal: options.signal,
      cache: "no-store",
    });
  } catch (cause) {
    if (cause instanceof DOMException && cause.name === "AbortError") throw cause;
    const message =
      "Could not reach the server. Check your connection; if it persists, the API origin or CORS configuration is wrong.";
    record({ method, path, status: null, durationMs: Math.round(performance.now() - started), kind: "frontend", requestId: null, retryAfter: null, rateLimit: {}, request: requestSummary, response: null, note: String(cause) });
    throw new ApiError({ status: 0, code: "NETWORK_ERROR", message, kind: "frontend" });
  }

  const durationMs = Math.round(performance.now() - started);
  const text = await response.text();
  let body: unknown = null;
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = { raw: text.slice(0, 200) };
    }
  }

  // Only headers the backend exposes to browsers are readable; absent ones are simply null.
  const requestId = response.headers.get("x-request-id");
  const retryAfterHeader = response.headers.get("retry-after");
  const rateLimit: Record<string, string> = {};
  response.headers.forEach((value, name) => {
    if (/^(x-)?ratelimit/i.test(name)) rateLimit[name] = value;
  });

  // The backend can answer a non-error status (e.g. 202 PAYMENT_OUTCOME_UNKNOWN) with an error envelope.
  const parsed = parseError(body);
  const failed = !response.ok || (parsed !== null && isRecord(body) && "detail" in body);

  if (failed) {
    const err = parsed ?? { code: "REJECTED", message: `Request failed (${response.status}).`, details: {} };
    const kind = classify(response.status, err.code);
    const retryDetail = err.details["retry_after_seconds"];
    const retryAfterSeconds =
      typeof retryDetail === "number" ? retryDetail : retryAfterHeader && !Number.isNaN(Number(retryAfterHeader)) ? Number(retryAfterHeader) : null;
    record({ method, path, status: response.status, durationMs, kind, requestId, retryAfter: retryAfterHeader, rateLimit, request: requestSummary, response: sanitize(body) });
    if (kind === "auth_expired" && typeof window !== "undefined") window.dispatchEvent(new Event(AUTH_EXPIRED_EVENT));
    throw new ApiError({ status: response.status, code: err.code, message: err.message, details: err.details, kind, retryAfterSeconds, requestId });
  }

  record({ method, path, status: response.status, durationMs, kind: "ok", requestId, retryAfter: retryAfterHeader, rateLimit, request: requestSummary, response: sanitize(body) });
  if (isRecord(body) && "data" in body) return body["data"] as T;
  return body as T;
}

export function describeError(error: unknown): { title: string; message: string; kind: FaultKind } {
  if (error instanceof ApiError) {
    const titles: Record<FaultKind, string> = {
      ok: "Done",
      frontend: "This device could not reach the server",
      api_rejection: "The server rejected this request",
      provider_uncertain: "The payment provider's result is not known yet",
      rate_limited: "Too many attempts",
      auth_expired: "Your session has ended",
      server_error: "The server had a problem",
      worker_delay: "Waiting on a background process",
    };
    return { title: titles[error.kind], message: error.message, kind: error.kind };
  }
  return { title: "Unexpected error in the app", message: error instanceof Error ? error.message : String(error), kind: "frontend" };
}
