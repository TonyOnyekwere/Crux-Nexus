export const APP_ENV = process.env.NEXT_PUBLIC_APP_ENV ?? "development";

export const COMMERCE_API_URL = (process.env.NEXT_PUBLIC_COMMERCE_API_URL ?? "").replace(/\/+$/, "");

/** Diagnostics are compiled out of the UI in production builds. */
export const DIAGNOSTICS_ENABLED = APP_ENV !== "production";

/** Subscription billing provider for Phase 1 (backend PaymentProvider enum value). */
export const SUBSCRIPTION_PROVIDER = "paystack" as const;

export const PAYMENT_REDIRECT_HOSTS = (process.env.NEXT_PUBLIC_PAYMENT_REDIRECT_HOSTS ?? "paystack.com,paystack.co")
  .split(",")
  .map((h) => h.trim().toLowerCase())
  .filter(Boolean);

/** Only https URLs on an allow-listed provider host may receive the browser. */
export function isAllowedPaymentRedirect(raw: string): boolean {
  try {
    const url = new URL(raw);
    if (url.protocol !== "https:") return false;
    const host = url.hostname.toLowerCase();
    return PAYMENT_REDIRECT_HOSTS.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
  } catch {
    return false;
  }
}
