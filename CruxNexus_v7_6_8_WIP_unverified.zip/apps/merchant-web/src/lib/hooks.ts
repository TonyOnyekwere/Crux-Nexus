"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ApiError, AUTH_EXPIRED_EVENT, api } from "./api";
import { recordNote, setContext } from "./diagnostics";
import { stageAtLeast } from "./journey";
import { clearSession, getGlobalToken } from "./session";
import type { Journey } from "./types";

/** Redirects to /login when there is no usable token or any call reports the session ended. */
export function useAuthGuard(): boolean {
  const router = useRouter();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!getGlobalToken()) {
      router.replace("/login?reason=signin");
      return;
    }
    setReady(true);
    const onExpired = () => {
      clearSession();
      router.replace("/login?reason=expired");
    };
    window.addEventListener(AUTH_EXPIRED_EVENT, onExpired);
    return () => window.removeEventListener(AUTH_EXPIRED_EVENT, onExpired);
  }, [router]);

  return ready;
}

export function publishJourney(journey: Journey): void {
  setContext({
    stage: journey.stage,
    sessionId: journey.session_id,
    merchantAccountId: journey.merchant_account_id,
    tenantId: journey.tenant_id,
    paymentReference: journey.payment_reference,
    planCode: journey.plan_code,
  });
}

export interface JourneyHandle {
  journey: Journey | null;
  error: unknown;
  loading: boolean;
  /** Re-reads the server's state; the server is the only source of the stage. */
  refresh: () => Promise<Journey | null>;
  /** Adopts a snapshot returned by an action endpoint. */
  adopt: (journey: Journey) => void;
}

export function useJourney(enabled: boolean): JourneyHandle {
  const [journey, setJourney] = useState<Journey | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);

  const adopt = useCallback((next: Journey) => {
    publishJourney(next);
    setJourney(next);
    setError(null);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const next = await api<Journey>("/api/v1/onboarding/journey/state");
      adopt(next);
      return next;
    } catch (e) {
      if (!(e instanceof DOMException)) setError(e);
      return null;
    } finally {
      setLoading(false);
    }
  }, [adopt]);

  useEffect(() => {
    if (enabled) void refresh();
  }, [enabled, refresh]);

  return { journey, error, loading, refresh, adopt };
}

/** Runs an action at most once at a time so a double tap can never send the request twice. */
export function useAction<A extends unknown[], R>(fn: (...args: A) => Promise<R>) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const lock = useRef(false);

  const run = useCallback(
    async (...args: A): Promise<R | undefined> => {
      if (lock.current) return undefined;
      lock.current = true;
      setPending(true);
      setError(null);
      try {
        return await fn(...args);
      } catch (e) {
        setError(e);
        return undefined;
      } finally {
        lock.current = false;
        setPending(false);
      }
    },
    [fn],
  );

  return { run, pending, error, clearError: () => setError(null) };
}

export type PollOutcome = "idle" | "polling" | "confirmed" | "timed_out" | "error";

const POLL_FIRST_MS = 2500;
const POLL_MAX_MS = 10000;
const POLL_BUDGET_MS = 10 * 60 * 1000;
const WORKER_DELAY_NOTE_AFTER_MS = 60 * 1000;

/**
 * Asks the backend (never the provider, never the redirect) whether payment is confirmed.
 * Bounded: stops at confirmation or after the time budget, then waits for a manual re-check.
 */
export function usePaymentPolling(active: boolean, onState: (j: Journey) => void) {
  const [outcome, setOutcome] = useState<PollOutcome>("idle");
  const [attempts, setAttempts] = useState(0);
  const [runId, setRunId] = useState(0);
  const noted = useRef(false);

  useEffect(() => {
    if (!active) {
      setOutcome("idle");
      return;
    }
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const startedAt = Date.now();
    let delay = POLL_FIRST_MS;
    noted.current = false;
    setOutcome("polling");
    setAttempts(0);

    const tick = async () => {
      if (cancelled) return;
      try {
        const next = await api<Journey>("/api/v1/onboarding/journey/state");
        if (cancelled) return;
        setAttempts((n) => n + 1);
        onState(next);
        if (stageAtLeast(next.stage, "PAYMENT_CONFIRMED")) {
          setOutcome("confirmed");
          return;
        }
      } catch (e) {
        if (cancelled) return;
        if (e instanceof ApiError && e.kind === "auth_expired") return;
        // Transient failures keep the poll alive; they are already recorded in diagnostics.
      }
      const elapsed = Date.now() - startedAt;
      if (elapsed > WORKER_DELAY_NOTE_AFTER_MS && !noted.current) {
        noted.current = true;
        recordNote(
          "worker_delay",
          "Payment still unconfirmed after 60s. Activation depends on the provider webhook and the activation worker; check they are running.",
        );
      }
      if (elapsed >= POLL_BUDGET_MS) {
        setOutcome("timed_out");
        return;
      }
      delay = Math.min(Math.round(delay * 1.4), POLL_MAX_MS);
      timer = setTimeout(() => void tick(), delay);
    };

    timer = setTimeout(() => void tick(), 600);
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
    // onState is intentionally excluded: callers pass a stable adopter.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, runId]);

  return { outcome, attempts, recheck: () => setRunId((n) => n + 1) };
}
