import { DIAGNOSTICS_ENABLED } from "./config";

/**
 * Staging diagnostics store. Read-only by construction: it records what happened, it exposes no
 * way to feed values back into requests or state. Secrets are redacted before anything is stored.
 */
export type FaultKind =
  | "ok"
  | "frontend"
  | "api_rejection"
  | "provider_uncertain"
  | "rate_limited"
  | "auth_expired"
  | "server_error"
  | "worker_delay";

export interface DiagnosticEntry {
  id: number;
  at: string;
  method: string;
  path: string;
  status: number | null;
  durationMs: number;
  kind: FaultKind;
  requestId: string | null;
  retryAfter: string | null;
  rateLimit: Record<string, string>;
  request: unknown;
  response: unknown;
  note?: string;
}

export interface DiagnosticContext {
  stage?: string | null;
  sessionId?: string | null;
  merchantAccountId?: string | null;
  tenantId?: string | null;
  paymentReference?: string | null;
  planCode?: string | null;
}

const MAX_ENTRIES = 60;
const REDACT_KEYS = /pass(word)?|otp|^code$|token|authorization|secret|api[-_]?key|cookie/i;

export function sanitize(value: unknown, depth = 0): unknown {
  if (depth > 6) return "[truncated]";
  if (value === null || typeof value === "number" || typeof value === "boolean") return value;
  if (typeof value === "string") return value.length > 400 ? `${value.slice(0, 400)}…` : value;
  if (Array.isArray(value)) return value.slice(0, 25).map((v) => sanitize(v, depth + 1));
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = REDACT_KEYS.test(k) ? "[redacted]" : sanitize(v, depth + 1);
    }
    return out;
  }
  return String(value);
}

type Listener = () => void;
let entries: DiagnosticEntry[] = [];
let context: DiagnosticContext = {};
let counter = 0;
const listeners = new Set<Listener>();

function emit(): void {
  listeners.forEach((l) => l());
}

export function record(entry: Omit<DiagnosticEntry, "id" | "at">): void {
  if (!DIAGNOSTICS_ENABLED) return;
  counter += 1;
  entries = [{ ...entry, id: counter, at: new Date().toISOString() }, ...entries].slice(0, MAX_ENTRIES);
  emit();
}

export function recordNote(kind: FaultKind, note: string): void {
  record({
    method: "—",
    path: "(client)",
    status: null,
    durationMs: 0,
    kind,
    requestId: null,
    retryAfter: null,
    rateLimit: {},
    request: null,
    response: null,
    note,
  });
}

export function setContext(patch: DiagnosticContext): void {
  if (!DIAGNOSTICS_ENABLED) return;
  context = { ...context, ...patch };
  emit();
}

export function clearDiagnostics(): void {
  entries = [];
  context = {};
  emit();
}

export const diagnosticsStore = {
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
  getEntries: (): DiagnosticEntry[] => entries,
  getContext: (): DiagnosticContext => context,
};
