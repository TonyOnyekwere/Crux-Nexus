export type JourneyStage =
  | "REGISTERED"
  | "OTP_VERIFIED"
  | "MERCHANT_CREATED"
  | "BUSINESS_CONFIGURED"
  | "PLAN_SELECTED"
  | "PAYMENT_PENDING"
  | "PAYMENT_CONFIRMED"
  | "STOREFRONT_READY"
  | "COMPLETED";

export interface BusinessSnapshot {
  storefront_slug: string;
  category: string | null;
  contact_phone: string | null;
  city: string | null;
  address: string | null;
}

/** Server-owned journey snapshot. The client never sends a stage. */
export interface Journey {
  session_id: string;
  stage: JourneyStage;
  next_action: string | null;
  allowed_actions: string[];
  completed_stages: string[];
  business: BusinessSnapshot | null;
  plan_code: string | null;
  merchant_account_id: string | null;
  tenant_id: string | null;
  payment_reference: string | null;
  version: number;
}

export interface Checkout {
  reference: string;
  redirect_url: string;
  provider: string;
}

export type JourneyWithCheckout = Journey & { checkout: Checkout };

export interface UserDto {
  id: string;
  email: string;
  auth_provider: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface RegisterResult {
  access_token: string;
  token_type: string;
  journey: Journey;
}

export interface LoginResult {
  access_token: string;
  token_type: string;
  user: UserDto;
}

export interface TenantTokenResult {
  access_token: string;
  token_type: string;
  tenant_id: string;
  role: string;
}

export interface StorefrontSummary {
  tenant_id: string;
  slug: string;
  role: string;
}

export interface PlanLimits {
  included_storefronts: number;
  base_staff_per_storefront: number;
  max_extra_storefronts: number;
  max_extra_staff: number;
  resources: Record<string, number | null>;
}

export interface Plan {
  code: string;
  name: string;
  pricing_configured: boolean;
  price: string | null;
  currency: string | null;
  interval: string | null;
  trial_days: number;
  limits: PlanLimits;
}
