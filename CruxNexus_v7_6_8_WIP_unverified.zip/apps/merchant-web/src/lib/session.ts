/**
 * Client-side token custody. Tokens live in sessionStorage (cleared when the tab closes).
 * There is no refresh or revocation endpoint: logout only disposes of the token in this browser,
 * and an expired token requires signing in again.
 */
const GLOBAL_KEY = "cnx.token";
const TENANT_KEY = "cnx.tenant";

export interface TenantSession {
  token: string;
  tenantId: string;
  role: string;
}

function read(key: string): string | null {
  try {
    return window.sessionStorage.getItem(key);
  } catch {
    return null;
  }
}
function write(key: string, value: string): void {
  try {
    window.sessionStorage.setItem(key, value);
  } catch {
    /* storage unavailable: the user will be asked to sign in again */
  }
}
function remove(key: string): void {
  try {
    window.sessionStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

/** Reads the unverified `exp` claim purely so the UI can ask for a new sign-in early. */
export function tokenExpiry(token: string): number | null {
  try {
    const part = token.split(".")[1];
    if (!part) return null;
    const json = atob(part.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(part.length / 4) * 4, "="));
    const exp = (JSON.parse(json) as { exp?: unknown }).exp;
    return typeof exp === "number" ? exp * 1000 : null;
  } catch {
    return null;
  }
}

function usable(token: string | null): string | null {
  if (!token) return null;
  const exp = tokenExpiry(token);
  return exp !== null && exp <= Date.now() ? null : token;
}

export function getGlobalToken(): string | null {
  const token = usable(read(GLOBAL_KEY));
  if (!token) remove(GLOBAL_KEY);
  return token;
}
export function setGlobalToken(token: string): void {
  write(GLOBAL_KEY, token);
}
export function getTenantSession(): TenantSession | null {
  const raw = read(TENANT_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as TenantSession;
    return usable(parsed.token) ? parsed : null;
  } catch {
    return null;
  }
}
export function setTenantSession(session: TenantSession): void {
  write(TENANT_KEY, JSON.stringify(session));
}
export function clearSession(): void {
  remove(GLOBAL_KEY);
  remove(TENANT_KEY);
}
