import { RAIL, railIndex } from "@/lib/journey";
import type { JourneyStage } from "@/lib/types";

/** Progress is drawn only from the stage the server reported; nothing here can advance it. */
export function JourneyRail({ stage }: { stage: JourneyStage }) {
  const current = railIndex(stage);
  return (
    <nav aria-label="Setup progress">
      <ol className="rail">
        {RAIL.map((item, i) => {
          const state = i < current ? "done" : i === current ? "current" : "todo";
          return (
            <li key={item.key} className={state} aria-current={state === "current" ? "step" : undefined}>
              <span className="dot" aria-hidden="true">
                {state === "done" ? "✓" : i + 1}
              </span>
              <span>
                <span className="label">{item.label}</span>
                {state === "done" ? <span className="proof"> Confirmed by the server</span> : null}
              </span>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
