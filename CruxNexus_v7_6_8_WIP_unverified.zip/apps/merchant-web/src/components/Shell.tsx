"use client";

import type { ReactNode } from "react";
import { APP_ENV, DIAGNOSTICS_ENABLED } from "@/lib/config";
import { DiagnosticsPanel } from "./DiagnosticsPanel";

export function Shell({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <>
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true" />
          CruxNexus
        </div>
        <div className="row">
          {DIAGNOSTICS_ENABLED ? <span className="env-chip">{APP_ENV}</span> : null}
          {right}
        </div>
      </header>
      {children}
      <DiagnosticsPanel />
    </>
  );
}
