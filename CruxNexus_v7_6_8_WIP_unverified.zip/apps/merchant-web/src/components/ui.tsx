"use client";

import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from "react";
import { describeError } from "@/lib/api";

export function Button({
  variant = "primary",
  block,
  loading,
  children,
  disabled,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "link"; block?: boolean; loading?: boolean }) {
  const cls = ["btn", variant === "primary" ? "" : variant, block ? "block" : ""].join(" ").trim();
  return (
    <button {...rest} className={cls} disabled={disabled || loading} aria-busy={loading || undefined}>
      {loading ? "Working…" : children}
    </button>
  );
}

export function Field({
  label,
  hint,
  id,
  invalid,
  ...rest
}: InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: ReactNode; id: string; invalid?: boolean }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input id={id} className="input" aria-invalid={invalid || undefined} aria-describedby={hint ? `${id}-hint` : undefined} {...rest} />
      {hint ? (
        <p className="hint" id={`${id}-hint`}>
          {hint}
        </p>
      ) : null}
    </div>
  );
}

export function Alert({ tone, title, children }: { tone: "error" | "warn" | "info"; title?: string; children: ReactNode }) {
  return (
    <div className={`alert ${tone}`} role={tone === "error" ? "alert" : "status"}>
      {title ? <strong>{title}</strong> : null}
      {children}
    </div>
  );
}

/** Separates frontend faults, API rejections and provider uncertainty instead of "Something went wrong". */
export function ErrorAlert({ error }: { error: unknown }) {
  if (!error) return null;
  const { title, message, kind } = describeError(error);
  return (
    <Alert tone={kind === "provider_uncertain" ? "warn" : "error"} title={title}>
      {message}
    </Alert>
  );
}
