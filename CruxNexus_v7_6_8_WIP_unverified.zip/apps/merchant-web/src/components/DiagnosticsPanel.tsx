"use client";

import { useState, useSyncExternalStore } from "react";
import { APP_ENV, COMMERCE_API_URL, DIAGNOSTICS_ENABLED } from "@/lib/config";
import { clearDiagnostics, diagnosticsStore } from "@/lib/diagnostics";

const EMPTY: never[] = [];

/** Staging-only, read-only view of what the app sent and what the server answered. Secrets are redacted at capture. */
export function DiagnosticsPanel() {
  const [open, setOpen] = useState(false);
  const entries = useSyncExternalStore(diagnosticsStore.subscribe, diagnosticsStore.getEntries, () => EMPTY);
  const ctx = useSyncExternalStore(diagnosticsStore.subscribe, diagnosticsStore.getContext, () => ({}));

  if (!DIAGNOSTICS_ENABLED) return null;

  const ids: [string, string | null | undefined][] = [
    ["Server stage", ctx.stage],
    ["Journey session", ctx.sessionId],
    ["Merchant account", ctx.merchantAccountId],
    ["Tenant", ctx.tenantId],
    ["Plan", ctx.planCode],
    ["Payment ref", ctx.paymentReference],
  ];

  return (
    <aside className="diag" aria-label="Staging diagnostics">
      <button className="diag-bar" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <span>
          Diagnostics · {APP_ENV} · stage {ctx.stage ?? "unknown"}
        </span>
        <span>{open ? "Hide" : `Show (${entries.length})`}</span>
      </button>
      {open ? (
        <div className="diag-body">
          <h4>API origin</h4>
          <dl>
            <dt>Commerce</dt>
            <dd>{COMMERCE_API_URL || "not configured"}</dd>
          </dl>
          <h4>Server-reported identifiers (non-secret)</h4>
          <dl>
            {ids.map(([k, v]) => (
              <div key={k} style={{ display: "contents" }}>
                <dt>{k}</dt>
                <dd>{v ?? "—"}</dd>
              </div>
            ))}
          </dl>
          <div className="row" style={{ justifyContent: "space-between" }}>
            <h4>Requests (newest first, read-only)</h4>
            <button className="btn link" style={{ color: "#8fd0a6" }} onClick={clearDiagnostics}>
              Clear
            </button>
          </div>
          {entries.length === 0 ? <p>No requests yet.</p> : null}
          {entries.map((e) => (
            <details key={e.id}>
              <summary>
                <span className={`tag ${e.kind}`}>{e.kind}</span>
                <span>
                  {e.method} {e.path}
                </span>
                <span>{e.status ?? "no response"}</span>
                <span>{e.durationMs}ms</span>
              </summary>
              <dl>
                <dt>Time</dt>
                <dd>{e.at}</dd>
                <dt>Request ID</dt>
                <dd>{e.requestId ?? "not exposed to the browser"}</dd>
                <dt>Retry-After</dt>
                <dd>{e.retryAfter ?? "—"}</dd>
                <dt>Rate limit</dt>
                <dd>{Object.keys(e.rateLimit).length ? JSON.stringify(e.rateLimit) : "not exposed to the browser"}</dd>
                {e.note ? (
                  <>
                    <dt>Note</dt>
                    <dd>{e.note}</dd>
                  </>
                ) : null}
              </dl>
              {e.request !== null ? <pre>{`request  ${JSON.stringify(e.request, null, 2)}`}</pre> : null}
              {e.response !== null ? <pre>{`response ${JSON.stringify(e.response, null, 2)}`}</pre> : null}
            </details>
          ))}
        </div>
      ) : null}
    </aside>
  );
}
