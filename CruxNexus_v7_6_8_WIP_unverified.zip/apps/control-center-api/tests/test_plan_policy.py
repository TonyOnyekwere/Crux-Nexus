"""Pure tests for Control Center plan policy validation and the baseline tier matrix."""
import importlib.util
import pathlib
import sys

import pytest

_p = pathlib.Path(__file__).resolve().parents[1] / "app/plan_policy.py"
_spec = importlib.util.spec_from_file_location("plan_policy", _p)
pp = importlib.util.module_from_spec(_spec)
sys.modules["plan_policy"] = pp
_spec.loader.exec_module(pp)
GIB = 1024 ** 3


def test_capability_validation():
    assert pp.validate_capabilities(["a.b", "c.d"]) == {"a.b": True, "c.d": True}
    assert pp.validate_capabilities({"a.b": True, "c.d": False}) == {"a.b": True}
    assert pp.validate_capabilities(None) == {}
    for bad in ("x", 5, {"Bad Key": True}, {"a.b": "yes"}, {"a": True}, {"A.B": True}):
        with pytest.raises(pp.PlanPolicyError):
            pp.validate_capabilities(bad)


def test_limit_validation_rejects_everything_commerce_would_fail_closed_on():
    assert pp.validate_resource_limits({"products": 10, "x.y": None}) == {"products": 10, "x.y": None}
    for bad in ({"products": -1}, {"products": "10"}, {"products": 1.5}, {"products": True},
                {"products": 10 ** 16}, {"Bad": 1}, {"ok.key": [1]}, ["products"]):
        with pytest.raises(pp.PlanPolicyError):
            pp.validate_resource_limits(bad)


def test_baseline_loads_and_has_the_three_tiers():
    b = pp.load_baseline()
    assert b["version"] == "plan-matrix-v1" and set(b["plans"]) == {"starter", "business", "enterprise"}


def test_baseline_matches_the_stated_quantitative_matrix():
    L = {c: v["resource_limits"] for c, v in pp.load_baseline()["plans"].items()}
    expect = {
        "products": (100, 2500, 25000), "variants": (300, 7500, 75000), "staff.accounts": (2, 10, 50),
        "storefronts.active": (1, 1, 5), "orders.monthly": (500, 5000, 50000),
        "storage.bytes": (2 * GIB, 20 * GIB, 200 * GIB), "bandwidth.monthly_bytes": (20 * GIB, 200 * GIB, 2048 * GIB),
        "storefront.custom_domains": (0, 0, 5), "payments.providers": (1, 3, 10), "fulfillment.delivery_zones": (5, 25, 100),
    }
    for key, (s, b, e) in expect.items():
        assert (L["starter"][key], L["business"][key], L["enterprise"][key]) == (s, b, e), key


def test_baseline_capability_matrix_rules():
    C = {c: set(v["capabilities"]) for c, v in pp.load_baseline()["plans"].items()}
    assert C["starter"] < C["business"] < C["enterprise"]            # strict tier ladder
    for cap in ("storefront.component_slots", "storefront.custom_css", "api.access", "fulfillment.third_party_logistics",
                "fulfillment.advanced_rules", "support.priority", "payments.multiple_providers"):
        assert cap not in C["starter"] and cap in C["business"] and cap in C["enterprise"], cap
    for cap in ("storefront.custom_domain", "storefronts.multiple", "integrations.advanced", "platform.custom_configuration"):
        assert cap not in C["starter"] and cap not in C["business"] and cap in C["enterprise"], cap
    # core capabilities exist on every tier, and nothing is merchant-type specific
    for cap in ("data.export", "catalog.variants", "payments.merchant_connections", "fulfillment.pickup", "discovery.listing"):
        assert all(cap in caps for caps in C.values()), cap
    for caps in C.values():
        assert not any(w in cap for cap in caps for w in ("fashion", "food", "grocery", "restaurant"))


def test_depth_limits_follow_basic_advanced_full():
    L = {c: v["resource_limits"] for c, v in pp.load_baseline()["plans"].items()}
    for key, vals in {"storefront.theme_depth": (1, 2, 3), "storefront.layout_depth": (1, 2, 3), "fulfillment.depth": (1, 2, 3),
                      "promotions.depth": (1, 2, 3), "analytics.depth": (1, 2, 2)}.items():
        assert tuple(L[c][key] for c in ("starter", "business", "enterprise")) == vals, key


def test_enterprise_is_bounded_not_infinite():
    for key, value in pp.load_baseline()["plans"]["enterprise"]["resource_limits"].items():
        assert value is not None, key


def test_diff_and_consistency_warnings():
    d = pp.diff_policy({"a.b": True, "x.y": True}, {"products": 10, "old.k": 1}, {"a.b": True, "n.w": True}, {"products": 20})
    assert d["capabilities_added"] == ["n.w"] and d["capabilities_removed"] == ["x.y"]
    assert d["limits_changed"] == {"products": {"from": 10, "to": 20}} and d["limits_removed"] == ["old.k"]
    row = {"included_storefronts": 1, "max_extra_storefronts": 0, "base_staff_per_storefront": 3}
    w = pp.consistency_warnings("starter", row, {"storefronts.active": 1, "staff.accounts": 2})
    assert len(w) == 1 and "staff.accounts" in w[0]
    assert pp.consistency_warnings("starter", {**row, "base_staff_per_storefront": 2}, {"storefronts.active": 1, "staff.accounts": 2}) == []
