import base64,hmac,hashlib,struct,time
from jose import jwt
from passlib.context import CryptContext
from fastapi import HTTPException,status
from app.config import settings
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")

def verify_totp(secret: str, code: str, window: int=1)->bool:
    try: raw=base64.b32decode(secret.upper()+"="*((8-len(secret)%8)%8),casefold=True)
    except Exception:return False
    for offset in range(-window,window+1):
        counter=int(time.time()//30)+offset
        msg=struct.pack(">Q",counter); digest=hmac.new(raw,msg,hashlib.sha1).digest(); idx=digest[-1]&15
        value=(struct.unpack(">I",digest[idx:idx+4])[0]&0x7fffffff)%1000000
        if hmac.compare_digest(f"{value:06d}",code): return True
    return False

def token(admin_id,role): return jwt.encode({"sub":str(admin_id),"role":role,"exp":int(time.time())+900},settings.JWT_SECRET_KEY,algorithm="HS256")
def decode(token_value):
    try:return jwt.decode(token_value,settings.JWT_SECRET_KEY,algorithms=["HS256"])
    except Exception:raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="Invalid admin token")
