import uuid
from datetime import datetime, timezone
from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base
class AdminUser(Base):
    __tablename__="admin_users"
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    email=Column(String(320),nullable=False,unique=True)
    password_hash=Column(String(255),nullable=False)
    role=Column(String(40),nullable=False,default="platform_admin")
    mfa_secret=Column(String(64),nullable=False)
    active=Column(Boolean,nullable=False,default=True)
    failed_login_attempts=Column(Integer,nullable=False,default=0)
    locked_until=Column(DateTime(timezone=True),nullable=True)
    created_at=Column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
class GovernancePolicy(Base):
    __tablename__="governance_policies"
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    key=Column(String(80),nullable=False,unique=True,default="default")
    grace_period_days=Column(Integer,nullable=False,default=3)
    monthly_period_days=Column(Integer,nullable=False,default=30)
    yearly_period_days=Column(Integer,nullable=False,default=365)
    allow_early_renewal=Column(Boolean,nullable=False,default=False)
    governance_version=Column(String(80),nullable=False,default="initial")
    updated_at=Column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc),onupdate=lambda:datetime.now(timezone.utc))
class Plan(Base):
    __tablename__="governance_plans"
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    code=Column(String(30),nullable=False,unique=True)
    name=Column(String(100),nullable=False)
    included_storefronts=Column(Integer,nullable=False)
    base_staff_per_storefront=Column(Integer,nullable=False)
    max_extra_storefronts=Column(Integer,nullable=False)
    max_extra_staff=Column(Integer,nullable=False)
    trial_days=Column(Integer,nullable=False)
    price_amount=Column(String(30))
    price_currency=Column(String(3))
    billing_interval=Column(String(20))
    active=Column(Boolean,nullable=False,default=True)
    governance_version=Column(String(80),nullable=False,default="initial")
    capabilities=Column(JSONB,nullable=False,default=dict)
    resource_limits=Column(JSONB,nullable=False,default=dict)
class Provider(Base):
    __tablename__="governance_providers"
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    provider_type=Column(String(40),nullable=False,unique=True)
    enabled=Column(Boolean,nullable=False,default=True)
    priority=Column(Integer,nullable=False,default=100)
    version=Column(String(80),nullable=False,default="initial")
class AuditEvent(Base):
    __tablename__="control_audit_events"
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    admin_id=Column(UUID(as_uuid=True),nullable=True)
    action=Column(String(120),nullable=False)
    target=Column(String(255),nullable=True)
    metadata=Column(JSONB,nullable=False,default=dict)
    occurred_at=Column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))


class GovernanceSyncOutbox(Base):
    __tablename__="governance_sync_outbox"
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    kind=Column(String(40),nullable=False)
    target=Column(String(255),nullable=False)
    payload=Column(JSONB,nullable=False)
    status=Column(String(20),nullable=False,default="pending")
    attempts=Column(Integer,nullable=False,default=0)
    available_at=Column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
    locked_until=Column(DateTime(timezone=True),nullable=True)
    last_error=Column(Text,nullable=True)
    created_at=Column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
    completed_at=Column(DateTime(timezone=True),nullable=True)
