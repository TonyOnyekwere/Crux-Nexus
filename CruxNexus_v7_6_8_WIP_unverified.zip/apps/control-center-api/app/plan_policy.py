"""Plan policy (capabilities + resource limits): validation and baseline application. Pure.

The Control Center owns tier policy as DATA. Commerce enforces whatever it is told, using opaque
keys, so adding/changing a capability or limit never requires a Commerce code change. These
validators reject anything the Commerce engine would have to treat as malformed (and fail closed on).
"""
from __future__ import annotations

import json
import pathlib
import re
from typing import Mapping, Optional

KEY_RE = re.compile(r"^[a-z][a-z0-9_.]{1,60}$")
MAX_KEYS = 300
MAX_LIMIT = 10**15  # ~1 PB in bytes; anything above is certainly a mistake
BASELINE_PATH = pathlib.Path(__file__).resolve().parent / "seed" / "plan_policy_v1.json"


class PlanPolicyError(ValueError):
    pass


def validate_capabilities(value) -> dict:
    """Stored form: {"capability.key": true}. Only true grants; false entries are dropped."""
    if value is None:
        return {}
    if isinstance(value, (list, tuple, set)):
        value = {k: True for k in value}
    if not isinstance(value, Mapping):
        raise PlanPolicyError("capabilities must be an object of key -> true")
    if len(value) > MAX_KEYS:
        raise PlanPolicyError("too many capabilities")
    out = {}
    for key, granted in value.items():
        if not isinstance(key, str) or not KEY_RE.match(key):
            raise PlanPolicyError(f"invalid capability key {key!r}")
        if not isinstance(granted, bool):
            raise PlanPolicyError(f"capability {key!r} must be true or false")
        if granted:
            out[key] = True
    return out


def validate_resource_limits(value) -> dict:
    """Non-negative integers (or null = no limit). Booleans, floats, strings, negatives are rejected."""
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise PlanPolicyError("resource_limits must be an object of key -> integer")
    if len(value) > MAX_KEYS:
        raise PlanPolicyError("too many resource limits")
    out = {}
    for key, limit in value.items():
        if not isinstance(key, str) or not KEY_RE.match(key):
            raise PlanPolicyError(f"invalid limit key {key!r}")
        if limit is None:
            out[key] = None
        elif isinstance(limit, bool) or not isinstance(limit, int) or limit < 0 or limit > MAX_LIMIT:
            raise PlanPolicyError(f"limit {key!r} must be an integer between 0 and {MAX_LIMIT}")
        else:
            out[key] = limit
    return out


def load_baseline(path: Optional[pathlib.Path] = None) -> dict:
    data = json.loads((path or BASELINE_PATH).read_text(encoding="utf-8"))
    plans = data.get("plans")
    if not isinstance(plans, Mapping) or not plans:
        raise PlanPolicyError("baseline has no plans")
    out = {}
    for code, spec in plans.items():
        out[code] = {
            "capabilities": validate_capabilities(spec.get("capabilities", [])),
            "resource_limits": validate_resource_limits(spec.get("resource_limits", {})),
        }
    return {"version": data.get("version", "unversioned"), "plans": out}


def diff_policy(current_caps, current_limits, new_caps, new_limits) -> dict:
    cc, nc = set((current_caps or {}).keys()), set(new_caps.keys())
    cl, nl = dict(current_limits or {}), dict(new_limits)
    return {
        "capabilities_added": sorted(nc - cc), "capabilities_removed": sorted(cc - nc),
        "limits_changed": {k: {"from": cl.get(k), "to": nl[k]} for k in sorted(nl) if cl.get(k) != nl[k]},
        "limits_removed": sorted(set(cl) - set(nl)),
    }


def consistency_warnings(code: str, row: Mapping, limits: Mapping) -> list:
    """Legacy plan columns are still what CapacityService enforces for storefronts/staff. If the new
    limits disagree, the operator must know (we warn; we do not silently rewrite the legacy columns)."""
    out = []
    active = limits.get("storefronts.active")
    if active is not None and row.get("included_storefronts") is not None and active != row["included_storefronts"] + 0 \
            and active != row["included_storefronts"] + row.get("max_extra_storefronts", 0):
        out.append(f"{code}: limit storefronts.active={active} vs plan columns included_storefronts={row['included_storefronts']} "
                   f"(+max_extra_storefronts={row.get('max_extra_storefronts')}). CapacityService enforces the columns.")
    staff = limits.get("staff.accounts")
    if staff is not None and row.get("base_staff_per_storefront") is not None and staff != row["base_staff_per_storefront"]:
        out.append(f"{code}: limit staff.accounts={staff} vs base_staff_per_storefront={row['base_staff_per_storefront']}. "
                   "CapacityService enforces the column.")
    return out
