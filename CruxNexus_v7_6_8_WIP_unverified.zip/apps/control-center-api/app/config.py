from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    DATABASE_URL: str
    JWT_SECRET_KEY: str
    BOOTSTRAP_TOKEN: str
    COMMERCE_API_URL: str = "http://localhost:8000"
    COMMERCE_SERVICE_TOKEN: str
    ENVIRONMENT: str = "development"
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", case_sensitive=True)
