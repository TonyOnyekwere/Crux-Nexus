from uuid import UUID
import time
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone, timedelta
import hmac
from fastapi import APIRouter, Depends, Header, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.auth import decode, pwd, token, verify_totp
from app.config import settings
from app.database import get_db
from app.models import AdminUser, AuditEvent, GovernancePolicy, Plan, Provider, GovernanceSyncOutbox
from app import plan_policy

router=APIRouter(prefix="/api/v1",tags=["control-center"])
security=HTTPBearer()

class Bootstrap(BaseModel):
    email:str
    password:str=Field(min_length=12)
    mfa_secret:str=Field(min_length=16)
class Login(BaseModel):
    email:str
    password:str
    otp:str=Field(min_length=6,max_length=6)
class Policy(BaseModel):
    governance_version:str=Field(min_length=1,max_length=80)
    grace_period_days:int=Field(ge=0,le=90)
    monthly_period_days:int=Field(ge=1,le=366)
    yearly_period_days:int=Field(ge=1,le=1000)
    allow_early_renewal:bool=False
class ProviderPayload(BaseModel):
    enabled:bool
    priority:int=Field(ge=0)
    version:str=Field(min_length=1,max_length=80)
class PlanPayload(BaseModel):
    code:str
    name:str
    included_storefronts:int=Field(ge=0)
    base_staff_per_storefront:int=Field(ge=0)
    max_extra_storefronts:int=Field(ge=0)
    max_extra_staff:int=Field(ge=0)
    trial_days:int=Field(ge=0,le=365)
    price_amount:str|None=None
    price_currency:str|None=None
    billing_interval:str|None=None
    active:bool=True
    governance_version:str=Field(default="initial",min_length=1,max_length=80)
    capabilities:dict=Field(default_factory=dict)
    resource_limits:dict=Field(default_factory=dict)

    @field_validator("capabilities")
    @classmethod
    def validate_capabilities(cls,value):
        try: return plan_policy.validate_capabilities(value)
        except plan_policy.PlanPolicyError as exc: raise ValueError(str(exc))

    @field_validator("resource_limits")
    @classmethod
    def validate_resource_limits(cls,value):
        try: return plan_policy.validate_resource_limits(value)
        except plan_policy.PlanPolicyError as exc: raise ValueError(str(exc))

    @field_validator("price_amount")
    @classmethod
    def validate_price(cls,value):
        if value is None:return value
        try: amount=Decimal(value)
        except (InvalidOperation,ValueError): raise ValueError("price_amount must be numeric")
        if amount<=0: raise ValueError("price_amount must be greater than zero")
        return format(amount,"f")

    @field_validator("price_currency")
    @classmethod
    def validate_currency(cls,value):
        if value is None:return value
        value=value.upper()
        if len(value)!=3: raise ValueError("price_currency must be a 3-letter ISO currency")
        return value

    @field_validator("billing_interval")
    @classmethod
    def validate_interval(cls,value):
        if value is None:return value
        if value not in {"monthly","annual","yearly"}: raise ValueError("billing_interval must be monthly or annual")
        return "annual" if value=="yearly" else value

async def enqueue_sync(db,kind,target,payload):
    db.add(GovernanceSyncOutbox(kind=kind,target=target,payload=payload))

def admin_claims(credentials:HTTPAuthorizationCredentials=Depends(security)):
    return decode(credentials.credentials)

def require_role(*roles):
    def dependency(claims=Depends(admin_claims)):
        if claims.get("role") not in roles: raise HTTPException(403,"Insufficient platform-admin permission")
        return claims
    return dependency

@router.post("/bootstrap/admin")
async def bootstrap(payload:Bootstrap,x_bootstrap_token:str=Header(...),db:AsyncSession=Depends(get_db)):
    if not settings.BOOTSTRAP_TOKEN or not hmac.compare_digest(x_bootstrap_token,settings.BOOTSTRAP_TOKEN): raise HTTPException(403,"Invalid bootstrap token")
    if await db.scalar(select(AdminUser.id).limit(1)): raise HTTPException(409,"Admin bootstrap is already closed")
    row=AdminUser(email=payload.email.lower(),password_hash=pwd.hash(payload.password),role="platform_admin",mfa_secret=payload.mfa_secret.upper())
    db.add(row); await db.commit(); return {"data":{"admin_id":str(row.id),"email":row.email}}

@router.post("/auth/login")
async def login(payload:Login,db:AsyncSession=Depends(get_db)):
    row=await db.scalar(select(AdminUser).where(AdminUser.email==payload.email.lower(),AdminUser.active.is_(True)).with_for_update())
    now=datetime.now(timezone.utc)
    if row is None or (row.locked_until is not None and row.locked_until > now):
        raise HTTPException(401,"Invalid admin credentials")
    valid=pwd.verify(payload.password,row.password_hash) and verify_totp(row.mfa_secret,payload.otp)
    if not valid:
        row.failed_login_attempts += 1
        if row.failed_login_attempts >= 5:
            row.locked_until=now+timedelta(minutes=15); row.failed_login_attempts=0
        await db.commit()
        raise HTTPException(401,"Invalid admin credentials")
    row.failed_login_attempts=0; row.locked_until=None
    db.add(AuditEvent(admin_id=row.id,action="admin_login",metadata={"email":row.email})); await db.commit(); return {"data":{"access_token":token(row.id,row.role)}}

@router.get("/governance/policy")
async def get_policy(claims=Depends(require_role("platform_admin","billing_admin")),db:AsyncSession=Depends(get_db)):
    row=await db.scalar(select(GovernancePolicy).where(GovernancePolicy.key=="default"))
    return {"data":{k:getattr(row,k) for k in ("governance_version","grace_period_days","monthly_period_days","yearly_period_days","allow_early_renewal")}}

@router.put("/governance/policy")
async def put_policy(payload:Policy,claims=Depends(require_role("platform_admin")),db:AsyncSession=Depends(get_db)):
    row=await db.scalar(select(GovernancePolicy).where(GovernancePolicy.key=="default").with_for_update())
    if row is None: row=GovernancePolicy(key="default"); db.add(row)
    data=payload.model_dump(); data["governance_version"]=str(time.time_ns());
    for k,v in data.items(): setattr(row,k,v)
    db.add(AuditEvent(admin_id=UUID(claims["sub"]),action="policy_update",target="default",metadata=payload.model_dump()))
    await enqueue_sync(db,"policy","default",data)
    await db.commit(); return {"data":data}

@router.put("/governance/providers/{provider_type}")
async def put_provider(provider_type:str,payload:ProviderPayload,claims=Depends(require_role("platform_admin")),db:AsyncSession=Depends(get_db)):
    row=await db.scalar(select(Provider).where(Provider.provider_type==provider_type).with_for_update())
    if row is None: row=Provider(provider_type=provider_type); db.add(row)
    version=str(time.time_ns()); row.enabled=payload.enabled; row.priority=payload.priority; row.version=version
    data=payload.model_dump(); data["version"]=version; data["governance_version"]=version
    db.add(AuditEvent(admin_id=UUID(claims["sub"]),action="provider_update",target=provider_type,metadata=data))
    await enqueue_sync(db,"provider",provider_type,{"provider_type":provider_type,**data})
    await db.commit(); return {"data":data}

@router.put("/governance/plans/{code}")
async def put_plan(code:str,payload:PlanPayload,claims=Depends(require_role("platform_admin")),db:AsyncSession=Depends(get_db)):
    if payload.code!=code: raise HTTPException(400,"plan code mismatch")
    row=await db.scalar(select(Plan).where(Plan.code==code).with_for_update())
    if row is None: row=Plan(code=code); db.add(row)
    data=payload.model_dump(); data["governance_version"]=str(time.time_ns())
    for k,v in data.items():
        if k!="code": setattr(row,k,v)
    db.add(AuditEvent(admin_id=UUID(claims["sub"]),action="plan_update",target=code,metadata=payload.model_dump()))
    await enqueue_sync(db,"plan",code,data)
    await db.commit(); return {"data":payload.model_dump()}

def _plan_sync_payload(row)->dict:
    return {"code":row.code,"name":row.name,"included_storefronts":row.included_storefronts,
            "base_staff_per_storefront":row.base_staff_per_storefront,"max_extra_storefronts":row.max_extra_storefronts,
            "max_extra_staff":row.max_extra_staff,"trial_days":row.trial_days,"price_amount":row.price_amount,
            "price_currency":row.price_currency,"billing_interval":row.billing_interval,"active":row.active,
            "governance_version":row.governance_version,"capabilities":row.capabilities or {},
            "resource_limits":row.resource_limits or {}}

@router.post("/governance/plan-policy/baseline")
async def apply_plan_policy_baseline(dry_run:bool=True,claims=Depends(require_role("platform_admin")),db:AsyncSession=Depends(get_db)):
    """Apply the versioned baseline tier matrix (app/seed/plan_policy_v1.json) to existing plans.

    Only capabilities and resource_limits are touched. Plan rows must already exist: price, billing
    interval and included quantities are commercial decisions this endpoint never invents (a missing
    plan is reported, not created). Defaults to dry_run so the operator sees the diff first. Applying
    goes through the normal audit + sync outbox path, so Commerce follows via the sync worker."""
    try: baseline=plan_policy.load_baseline()
    except plan_policy.PlanPolicyError as exc: raise HTTPException(500,f"baseline invalid: {exc}")
    report={"version":baseline["version"],"dry_run":dry_run,"applied":[],"missing_plans":[],"warnings":[]}
    for code,spec in baseline["plans"].items():
        row=await db.scalar(select(Plan).where(Plan.code==code).with_for_update())
        if row is None:
            report["missing_plans"].append(code); continue
        diff=plan_policy.diff_policy(row.capabilities,row.resource_limits,spec["capabilities"],spec["resource_limits"])
        report["warnings"]+=plan_policy.consistency_warnings(code,{"included_storefronts":row.included_storefronts,"max_extra_storefronts":row.max_extra_storefronts,"base_staff_per_storefront":row.base_staff_per_storefront},spec["resource_limits"])
        report["applied"].append({"code":code,"diff":diff})
        if dry_run: continue
        row.capabilities=spec["capabilities"]; row.resource_limits=spec["resource_limits"]
        row.governance_version=str(time.time_ns())
        db.add(AuditEvent(admin_id=UUID(claims["sub"]),action="plan_policy_baseline",target=code,metadata={"baseline":baseline["version"],"diff":diff}))
        await enqueue_sync(db,"plan",code,_plan_sync_payload(row))
    if not dry_run: await db.commit()
    return {"data":report}

@router.patch("/merchants/{tenant_id}/suspension")
async def suspend_or_restore(tenant_id:UUID,suspended:bool,reason:str="Control Center governance action",claims=Depends(require_role("platform_admin"))):
    status_value="suspended" if suspended else "active"
    async with __import__('httpx').AsyncClient(timeout=15) as client:
        r=await client.patch(f"{settings.COMMERCE_API_URL.rstrip('/')}/api/v1/tenants/{tenant_id}/status",json={"status":status_value,"reason":reason},headers={"Authorization":f"Bearer {settings.COMMERCE_SERVICE_TOKEN}","X-Acting-Admin-Id":claims["sub"]})
        if r.status_code>=300: raise HTTPException(502,"Commerce tenant governance operation failed")
    return {"data":{"tenant_id":str(tenant_id),"status":status_value,"reason":reason}}
