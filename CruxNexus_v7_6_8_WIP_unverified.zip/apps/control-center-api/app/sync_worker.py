import asyncio, logging, socket
from datetime import datetime, timezone, timedelta
import httpx
from sqlalchemy import select,or_
from app.config import settings
from app.database import SessionLocal
from app.models import GovernanceSyncOutbox
logger=logging.getLogger(__name__)
async def run_sync_loop():
    worker=f"{socket.gethostname()}:{id(asyncio.current_task())}"
    while True:
        try:
            async with SessionLocal() as db:
                now=datetime.now(timezone.utc)
                row=(await db.execute(select(GovernanceSyncOutbox).where(or_(GovernanceSyncOutbox.status=="pending",(GovernanceSyncOutbox.status=="sending") & (GovernanceSyncOutbox.locked_until<now)),GovernanceSyncOutbox.available_at<=now).order_by(GovernanceSyncOutbox.created_at).limit(1).with_for_update(skip_locked=True))).scalar_one_or_none()
                if row is None:
                    await db.commit()
                else:
                    row.status="sending"; row.attempts+=1; row.locked_until=now+timedelta(seconds=60); await db.commit()
                    try:
                        if row.kind=="policy": path="/api/v1/admin/governance/policy"
                        elif row.kind=="provider": path=f"/api/v1/admin/governance/providers/{row.target}"
                        else: path=f"/api/v1/admin/governance/plans/{row.target}"
                        async with httpx.AsyncClient(timeout=15) as client:
                            r=await client.put(f"{settings.COMMERCE_API_URL.rstrip('/')}{path}",json=row.payload,headers={"Authorization":f"Bearer {settings.COMMERCE_SERVICE_TOKEN}"})
                            r.raise_for_status()
                        row.status="completed"; row.completed_at=datetime.now(timezone.utc); row.locked_until=None; row.last_error=None
                    except Exception as exc:
                        row.status="pending"; row.available_at=datetime.now(timezone.utc)+timedelta(seconds=min(900,30*(2**min(row.attempts,5)))); row.locked_until=None; row.last_error=str(exc)[:4000]
                        logger.exception("Governance synchronization failed for %s",row.id)
                    await db.commit()
        except Exception:
            logger.exception("Governance sync loop failed")
        await asyncio.sleep(2)
