import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from app.routes import router
from app.sync_worker import run_sync_loop
@asynccontextmanager
async def lifespan(app):
    task=asyncio.create_task(run_sync_loop())
    try: yield
    finally:
        task.cancel()
        try: await task
        except asyncio.CancelledError: pass
app=FastAPI(title="CruxNexus Control Center API",version="1.1.0",lifespan=lifespan)
app.include_router(router)
@app.get("/health")
async def health(): return {"status":"ok"}
