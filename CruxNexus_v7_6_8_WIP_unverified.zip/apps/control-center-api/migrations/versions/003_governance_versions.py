from alembic import op
import sqlalchemy as sa
revision="003"
down_revision="002"
branch_labels=None
depends_on=None
def upgrade():
 op.add_column("governance_policies",sa.Column("governance_version",sa.String(80),nullable=False,server_default="initial"))
 op.add_column("governance_plans",sa.Column("governance_version",sa.String(80),nullable=False,server_default="initial"))
def downgrade():
 op.drop_column("governance_plans","governance_version"); op.drop_column("governance_policies","governance_version")
