from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision="002"
down_revision="001"
branch_labels=None
depends_on=None
def upgrade():
 op.create_table("governance_sync_outbox",sa.Column("id",postgresql.UUID(as_uuid=True),primary_key=True),sa.Column("kind",sa.String(40),nullable=False),sa.Column("target",sa.String(255),nullable=False),sa.Column("payload",postgresql.JSONB,nullable=False),sa.Column("status",sa.String(20),nullable=False,server_default="pending"),sa.Column("attempts",sa.Integer(),nullable=False,server_default="0"),sa.Column("available_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),sa.Column("locked_until",sa.DateTime(timezone=True)),sa.Column("last_error",sa.Text()),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False,server_default=sa.text("now()")),sa.Column("completed_at",sa.DateTime(timezone=True)))
 op.create_index("ix_governance_sync_claim","governance_sync_outbox",["status","available_at"])
def downgrade():
 op.drop_index("ix_governance_sync_claim",table_name="governance_sync_outbox"); op.drop_table("governance_sync_outbox")
