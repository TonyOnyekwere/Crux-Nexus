from alembic import op
import sqlalchemy as sa
revision="004"
down_revision="003"
branch_labels=None
depends_on=None
def upgrade():
 op.add_column("admin_users",sa.Column("failed_login_attempts",sa.Integer(),nullable=False,server_default="0"))
 op.add_column("admin_users",sa.Column("locked_until",sa.DateTime(timezone=True),nullable=True))
def downgrade():
 op.drop_column("admin_users","locked_until"); op.drop_column("admin_users","failed_login_attempts")
