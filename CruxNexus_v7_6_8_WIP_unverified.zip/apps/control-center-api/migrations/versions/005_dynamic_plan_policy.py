from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision="005"
down_revision="004"
branch_labels=None
depends_on=None
def upgrade():
    op.add_column("governance_plans", sa.Column("capabilities", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")))
    op.add_column("governance_plans", sa.Column("resource_limits", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")))
def downgrade():
    op.drop_column("governance_plans", "resource_limits")
    op.drop_column("governance_plans", "capabilities")
