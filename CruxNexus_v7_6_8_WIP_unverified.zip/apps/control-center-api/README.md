# CruxNexus Control Center API

The Control Center is the platform governance service. It owns administrator identity, MFA, platform RBAC, plans, pricing, provider governance, merchant governance actions and platform audit.

Governance changes are committed together with a durable synchronization outbox. A background sync loop retries Commerce synchronization and sends versioned governance payloads. Commerce rejects stale governance versions.

## Migrations

Run Alembic through revision `004`.

## Required configuration

- `DATABASE_URL`
- `JWT_SECRET_KEY`
- `BOOTSTRAP_TOKEN`
- `COMMERCE_API_URL`
- `COMMERCE_SERVICE_TOKEN`

Production deployment must use HTTPS, rotate bootstrap material, and protect the database credentials as secrets.
