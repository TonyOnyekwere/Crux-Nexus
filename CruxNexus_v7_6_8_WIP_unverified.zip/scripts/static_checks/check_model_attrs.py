import ast, sys, pathlib, re
root = pathlib.Path(sys.argv[1])
# collect model columns from classes that define __tablename__
models = {}
for p in root.rglob("*.py"):
    try: tree = ast.parse(p.read_text())
    except Exception: continue
    for n in tree.body:
        if isinstance(n, ast.ClassDef):
            attrs, is_model = set(), False
            for b in n.body:
                if isinstance(b, ast.Assign):
                    for t in b.targets:
                        if isinstance(t, ast.Name):
                            attrs.add(t.id)
                            if t.id == "__tablename__": is_model = True
                elif isinstance(b, ast.AnnAssign) and isinstance(b.target, ast.Name):
                    attrs.add(b.target.id)
                elif isinstance(b, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    attrs.add(b.name)
            if is_model: models[n.name] = attrs
bad = 0
for p in root.rglob("*.py"):
    try: tree = ast.parse(p.read_text())
    except Exception: continue
    for n in ast.walk(tree):
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in models:
            if n.attr not in models[n.value.id] and not n.attr.startswith("__") and n.attr not in ("metadata","query","registry"):
                print(f"{p}:{n.lineno}: {n.value.id}.{n.attr} not a column/attr")
                bad += 1
print("models:", len(models), "issues:", bad)
