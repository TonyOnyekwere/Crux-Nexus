import ast, sys, pathlib, importlib.util
root = pathlib.Path(sys.argv[1]); tests = pathlib.Path(sys.argv[2])
classes = {}  # name -> (attrs, is_model)
for p in root.rglob("*.py"):
    try: tree = ast.parse(p.read_text())
    except Exception: continue
    for n in tree.body:
        if isinstance(n, ast.ClassDef):
            attrs, model = set(), False
            for b in n.body:
                if isinstance(b, ast.Assign):
                    for t in b.targets:
                        if isinstance(t, ast.Name):
                            attrs.add(t.id); model |= t.id == "__tablename__"
                elif isinstance(b, ast.AnnAssign) and isinstance(b.target, ast.Name): attrs.add(b.target.id)
                elif isinstance(b, (ast.FunctionDef, ast.AsyncFunctionDef)): attrs.add(b.name)
            classes.setdefault(n.name, []).append((attrs, model, p))
issues = 0
for p in tests.rglob("*.py"):
    tree = ast.parse(p.read_text())
    # 1. imported names exist
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module and n.module.startswith("app"):
            mod = root / pathlib.Path(*n.module.split(".")[1:]) if False else None
            path = root.parent.joinpath(*n.module.split("."))
            f = path.with_suffix(".py") if path.with_suffix(".py").exists() else path / "__init__.py"
            if not f.exists(): print(f"{p}:{n.lineno}: module {n.module} missing"); issues += 1; continue
            src = f.read_text(); names = set()
            for x in ast.parse(src).body:
                if isinstance(x, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)): names.add(x.name)
                elif isinstance(x, ast.Assign): names |= {t.id for t in x.targets if isinstance(t, ast.Name)}
                elif isinstance(x, ast.AnnAssign) and isinstance(x.target, ast.Name): names.add(x.target.id)
                elif isinstance(x, ast.ImportFrom): names |= {a.asname or a.name for a in x.names}
                elif isinstance(x, ast.Import): names |= {(a.asname or a.name).split(".")[0] for a in x.names}
            for a in n.names:
                if a.name in names:
                    continue
                submodule = f.parent / f"{a.name}.py"
                subpackage = f.parent / a.name / "__init__.py"
                if submodule.exists() or subpackage.exists():
                    continue
                print(f"{p}:{n.lineno}: {a.name} not in {n.module}"); issues += 1
    # 2. model constructor kwargs are real columns
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in classes:
            ms = [c for c in classes[n.func.id] if c[1]]
            if ms:
                for k in n.keywords:
                    if k.arg and not any(k.arg in m[0] for m in ms):
                        print(f"{p}:{n.lineno}: {n.func.id}({k.arg}=...) not a column"); issues += 1
print("issues:", issues)
