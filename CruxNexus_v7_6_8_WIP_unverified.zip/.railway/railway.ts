/**
 * CruxNexus Commerce Worker — Railway Infrastructure as Code.
 *
 * Why this file exists and why it's IaC, not Config as Code:
 * Railway's `railway.toml`/`railway.json` (Config as Code) is deprecated
 * as of the check that produced this file (2026-09-19) — existing
 * services using it keep working until 2026-12-01, but "new services
 * cannot opt into Config as Code" per Railway's own current docs
 * (https://docs.railway.com/config-as-code). The existing
 * apps/commerce-api/railway.toml governs the already-deployed web
 * service and is deliberately left untouched by this file — only the
 * new worker service is declared here.
 *
 * IMPORTANT — read before running anything:
 * Railway's docs state "a service cannot be managed by both systems at
 * the same time" and describe migrating one CaC-managed service to IaC
 * as an explicit, separate step (`railway config migrate --service web`).
 * This file does NOT declare the web service, specifically to avoid
 * that conflict — but whether a Railway project can have some services
 * under railway.toml and others under .railway/railway.ts
 * simultaneously (rather than requiring the whole project to migrate at
 * once) was not something the available documentation stated
 * unambiguously either way. Do not guess past this:
 *
 *   1. Run `railway config plan` first. It is read-only — Railway's own
 *      docs confirm this makes no changes.
 *   2. Read the plan output carefully. It should propose creating
 *      exactly one new service ("CruxNexus Commerce Worker") and
 *      nothing else.
 *   3. If the plan proposes touching, migrating, or modifying the
 *      existing web service in any way, STOP — do not run
 *      `railway config apply`. That would mean partial adoption doesn't
 *      work the way this file assumes, and the web service (already
 *      correctly deployed and proven via your own Railway logs) must
 *      not be put at risk to add the worker.
 *   4. Only if the plan is exactly "add one new worker service" should
 *      `railway config apply` be run.
 *
 * What the worker service runs, and why:
 * Same Docker image as the web service (same GitHub source, same
 * Dockerfile) — the branching already exists in
 * apps/commerce-api/entrypoint.sh:
 *
 *     if [ "$PROCESS_TYPE" = "worker" ]; then
 *         exec python -m app.workers.runner
 *     fi
 *
 * Setting PROCESS_TYPE=worker below is the entire difference between
 * the two services. The worker does not run uvicorn and does not run
 * migrations (entrypoint.sh's own comment: "Migrations are applied by
 * the web process on deploy; the worker does not re-run them to avoid
 * two processes racing on the migration lock"). No build/start override
 * is specified here since the Dockerfile's own ENTRYPOINT/CMD already
 * does the right thing once PROCESS_TYPE is set.
 *
 * DATABASE_URL is intentionally NOT set here as a literal — it must
 * reference the same Postgres instance the web service uses. Bind it in
 * the Railway dashboard to the existing database's connection variable
 * (or extend this file with a `postgres(...)` reference once the
 * database itself is also under IaC) rather than hardcoding a
 * duplicate value that can drift from the web service's.
 *
 * Acceptance evidence to look for once deployed (per the locked
 * expectation): Railway logs for this service should show
 *
 *     Starting CruxNexus Commerce API background worker...
 *     Starting background worker process (8 loop(s))
 *
 * followed by periodic activity from the event relay, trial expiration,
 * onboarding expiry, webhook reconciliation, and entitlement
 * reconciliation loops (app/workers/runner.py,
 * app/workers/event_relay.py, app/workers/trial_expiration.py,
 * app/workers/onboarding_expiry.py, app/workers/webhook_reconciliation.py). That log output — not this file
 * compiling or existing — is what actually proves the worker is
 * running; nothing here can prove that on its own.
 */
import { defineRailway, github, project, service } from "railway/iac";

export default defineRailway(() => {
  const worker = service("CruxNexus Commerce Worker", {
    source: github("TonyOnyekwere/Crux-Nexus", { branch: "main" }),
    env: {
      PROCESS_TYPE: "worker",
      // The worker loads the worker Settings; it uses a dedicated DATABASE_WORKER_URL role, not the merchant API runtime role
      // (app/config.py) and needs the same secrets/connection strings —
      // a real bug found in external review: PROCESS_TYPE alone is not
      // a self-sufficient config. Bind these in the Railway dashboard
      // (ideally via a shared variable group referenced by both
      // services, so a rotated secret updates both at once) rather than
      // hardcoding values here:
      //   DATABASE_URL, DATABASE_WORKER_URL, REDIS_URL, SECRET_KEY, JWT_SECRET_KEY,
      //   CONTROL_CENTER_SERVICE_TOKEN, PAYSTACK_SECRET_KEY,
      //   FLUTTERWAVE_SECRET_KEY, FLUTTERWAVE_WEBHOOK_SECRET_HASH
      // This file does not declare them as literals on purpose — the
      // exact Railway syntax for referencing another service's shared
      // variable group from within this IaC file was not something the
      // available documentation covered with enough certainty to write
      // here without guessing. Bind via the dashboard for now; revisit
      // this file once that reference syntax is confirmed.
    },
    replicas: 1,
  });

  return project("CruxNexus", {
    resources: [worker],
  });
});
