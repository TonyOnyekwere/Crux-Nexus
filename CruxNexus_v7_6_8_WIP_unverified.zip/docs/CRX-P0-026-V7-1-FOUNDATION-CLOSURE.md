# CRX-P0-026: V7.1 Foundation Closure Batch

**Date:** 2026-09-22
**Status:** Code-complete for what's listed below, runtime-unverified except where noted. Two decisions confirmed by Kratos before this batch started (recorded here, not assumed): the real GitHub repo is `tonyonyekwere734/CruxNexus` (the external review's assertion of a different path was not trusted and was checked directly rather than copied in), and subscription reactivation restores **all** of a merchant's suspended storefronts (no suspension-reason distinction exists in the data model, and none was requested).

## P0 — Exploitable bypasses closed

**Staff invitation capacity bypass.** `StaffInvitationService.accept_invitation` created `TenantMembership` directly with no capacity check at all — a Starter merchant with zero staff capacity could invite and accept unlimited staff. The deprecated `POST /tenants/{id}/members` endpoint enforced this; its replacement didn't. Fixed: `accept_invitation` now resolves the owning `merchant_account_id` and calls `MerchantAccessResolver.can_add_staff` before creating the membership, inside the same transaction.

**Storefront creation bypassing `MerchantAccessResolver`.** `POST /storefronts` went straight to `TenantService`/`CapacityService`, which check subscription and capacity but never `MerchantAccount.status` — a `SUSPENDED` merchant with an active subscription and available capacity could still create a storefront. Fixed: the route now calls `MerchantAccessResolver.can_create_storefront` first. `TenantService`'s own row-locked capacity check remains the authoritative, concurrency-safe capacity gate — this only adds the merchant-status check that was missing entirely.

**Staff allocation never actually used.** `CapacityService.get_storefront_staff_capacity` added the merchant's *entire* extra-staff entitlement to *every* storefront independently — a merchant with 2 extra staff and 2 storefronts effectively got 4 usable slots. `StaffCapacityAllocation` existed specifically to represent per-storefront allocation and was never read. Fixed: the calculation now uses `EntitlementAllocationService.get_storefront_allocated_staff(tenant_id)` — this storefront's actual allocated share, not the merchant-wide sum.

**Consequence worth flagging plainly, not burying:** nothing currently calls `allocate_staff_to_storefront` from any API route. That means, as of this fix, a merchant's extra-staff entitlement is real but has **no way to actually be assigned to a storefront yet** — effective extra capacity is correctly computed as zero until an allocation endpoint exists. This is not a new bug introduced by the fix; it's an existing gap (no allocation API) that the correctness fix makes newly visible. The next necessary companion piece, not built in this pass.

## P0 — Subscription lifecycle completed

**Reactivation from `TRIAL_EXPIRED`/`SUSPENDED` was never implemented.** `SubscriptionPaymentService.process_webhook_event` only activated from `PAYMENT_PENDING`/`PAST_DUE` — the very real "trial expired, storefront suspended, merchant now pays" path did nothing, even though the state machine documents both transitions as valid. Fixed: both states now reactivate, and (per Kratos's confirmed policy) reactivating from a lapsed state (`TRIAL_EXPIRED` or `SUSPENDED`) also restores every `SUSPENDED` storefront the merchant owns back to `ACTIVE` — `ARCHIVED`/`OFFBOARDING`/`PROVISIONING`/`ONBOARDING` tenants are untouched, since those are unrelated, more final states this has no business overriding.

**No API path to initiate a subscription payment.** `SubscriptionPaymentService.initiate_payment` existed with nothing calling it. Added `POST /api/v1/billing/subscription/payment` — resolves the caller's merchant account and current subscription server-side, validates the requested provider is actually configured before calling the service, and requires the same OTP-verification gate (`get_current_merchant_context`) as every other payment-adjacent operation.

## P0 — Worker concurrency corrected (a bug in this session's own prior work)

**Webhook reconciliation's `FOR UPDATE SKIP LOCKED` didn't actually protect the batch.** The worker claimed a batch of rows under one lock, but `process_webhook_event` commits internally per event — the first commit ended that transaction and released every lock in the batch, including events not yet processed. A second worker could then claim the "still locked" remainder. Fixed: now claims and processes exactly one row per transaction, so the lock's lifetime always matches the commit boundary that actually needs it.

**Onboarding expiry worker had no row claiming at all**, unlike the other three loops. Fixed with `FOR UPDATE SKIP LOCKED` on both its queries — safe to add without the batch/commit issue above, since this worker does one `SELECT`, one bulk `UPDATE`, and one `commit()`, with no per-row commits in between.

## P1 — Smaller confirmed fixes

- **CORS was missing `X-Device-Session-Token` and `Idempotency-Key`** in `allow_headers` — both required by endpoints already shipped, meaning a browser frontend would fail preflight before the request ever reached backend logic that handles them correctly.
- **Email case sensitivity** — `IdentityService.create_user`/`get_user_by_email` and `StaffInvitationService.create_invitation` now normalize (`.strip().lower()`) on both write and lookup paths. Previously `Tony@x.com` and `tony@x.com` could become distinct accounts, affecting login, lockout keys, and invitation matching.
- **OTP delivery failure was silently discarded.** `OTPService.request_code` now returns `(OTPCode, OTPDeliveryResult)`; the `/verify/request` route gives an honest message when `delivery.sent` is `False` (currently always, since real OTP delivery is now provided through SendGrid) instead of unconditionally claiming a code was sent. Deliberately does not fail the request outright — that would make OTP entirely unusable in this pre-vendor state — it makes the response truthful instead.
- **Railway IaC placeholder replaced** with the confirmed real repository (`tonyonyekwere734/CruxNexus`), and the required environment variables (`DATABASE_URL`, `REDIS_URL`, `SECRET_KEY`, `JWT_SECRET_KEY`, `CONTROL_CENTER_SERVICE_TOKEN`, both payment provider keys) are now documented in the file as needing dashboard binding — the exact Railway syntax for referencing a shared variable group from within `.railway/railway.ts` wasn't confirmable from available documentation, so this is flagged rather than guessed.

## Explicitly not done this pass, staged

Per the review's own P1/P2 groupings, not attempted here: OTP resend's own request/lookup race (the verification race was fixed earlier; the *resend* check-then-insert is still non-atomic), the idempotency lease using `created_at` rather than a renewed lease timestamp, the deprecated `POST /tenants/{id}/members` endpoint still being live alongside its replacement, storefront retrieval/listing not routing through the same tenant-context resolver used elsewhere, pricing DB constraints (positive amount, valid currency code), payment-initiation network-timeout-vs-failure distinction (currently any exception marks the transaction `FAILED`, which could cause a duplicate charge on retry if the provider actually succeeded before the timeout), stale adversarial tests, the concurrency test that doesn't prove a real race, stale OpenAPI artifact, unpinned dependencies, `/metrics`, refresh tokens, and the still-nonexistent Control Center application itself.

## Verification status

`py_compile` clean across every file touched this session and a full `app/`+`migrations/` sweep. Migration chain unchanged from CRX-P0-025 (no new migrations this batch — every fix here is application logic, not schema). No CRLF regressions. `.env` confirmed absent. Nothing has run against a live database, Redis, or a real provider/OTP sandbox.
