# CRX-P0-023: Phase 2 + Gates 2/3 — Session Engine, Payment Adapters, Verification

**Date:** 2026-09-17 (continuation of the same day as CRX-P0-022)
**Status:** Code-complete for what's listed below, not verified against a live database, not tested against real Paystack/Flutterwave/OTP-vendor sandboxes (no credentials available in this environment). Same standing caveat as every prior doc in this series.

## Scope for this pass

Kratos gave explicit answers closing several open questions from
CRX-P0-022 and set two sequencing rules: **no Commerce OS work until the
onboarding journey is completely built and tested**, and **no frontend
until the backend is completely built and tested**. This pass stays
entirely within onboarding/verification/payment-foundation scope — no
Product/Order/Cart/Inventory code was written, consistent with that rule.

## What's built and compiles clean

**Identity verification (Gate 3)**
- `UserStatus.UNVERIFIED` added (Python + migration 023 for the Postgres
  enum). `IdentityService.create_user` and the `User` model's own column
  default both now default to `UNVERIFIED` instead of `ACTIVE` — this
  also means a staff-invitation-created user (migration 014's flow) now
  correctly requires verification too, closing a small consistency gap
  that existed before this pass.
- Login gate updated: `UNVERIFIED` users can still authenticate (they
  need a session to reach the OTP step and resume onboarding after
  closing the browser) — only `SUSPENDED`/`INACTIVE` block login
  entirely. Payment-adjacent operations get their own, stricter check at
  the point they're attempted (not yet built — that's the Phase 4
  activation-mode step).
- `otp_codes` table (migration 024) + `OTPCode` model: hashed codes
  (sha256, matching the existing staff-invitation-token convention),
  attempt limits, expiry.
- `OTPProvider` interface + real SendGrid email delivery
  (`app/infrastructure/otp/`), matching the `NotificationProvider`
  pattern exactly — no SMS/email vendor has been chosen yet, so this
  logs and reports `sent=False` rather than fabricating delivery.
- `OTPService` (generate, hash, send via provider, verify with
  attempt/expiry checks, flips user to `ACTIVE` on success) and two
  endpoints: `POST /api/v1/identity/verify/request`,
  `POST /api/v1/identity/verify/confirm`.

**Payment provider foundation (Gate 2)**
- Researched Paystack's and Flutterwave's *current* APIs (not from
  training-data memory, per Kratos's explicit instruction) before
  writing any adapter code. Two ambiguities surfaced and were flagged
  rather than silently resolved:
  - Flutterwave currently has two live API generations — v3 (stable,
    long-documented, still the officially-recommended default) and v4
    (OAuth2-based, in public beta). Built against v3. If v4 has since
    become the recommended default, that's a decision to make
    explicitly, not something this adapter should have guessed.
  - Sources disagreed on Flutterwave's `verif-hash` webhook check: some
    describe a plain shared-secret string comparison (traditional v3
    docs), one described an HMAC-SHA256 computation. Implemented the
    plain constant-time comparison and flagged this needs confirming
    against the actual Flutterwave dashboard before production use.
- `PaystackAdapter` and `FlutterwaveAdapter`
  (`app/infrastructure/payments/`): real `initialize_charge`,
  `verify_transaction`, `verify_webhook_signature` implementations
  against each provider's documented request/response shapes. **Not run
  against a real sandbox** — no credentials were available.
- `configure_payment_providers()`: registers an adapter only if its
  secret key is actually configured via environment variable — an
  unconfigured provider stays unregistered and fails loudly and
  specifically if anything calls it, rather than attempting a request
  with an empty key. Wired into the app's startup lifespan.
- Webhook ingestion endpoints (`POST /api/v1/billing/webhooks/paystack`,
  `/flutterwave`): verify signature, persist verbatim to
  `provider_webhook_events`, dedup via the existing unique constraint. **Does
  not yet activate a subscription on a successful payment** — that
  requires a `SubscriptionPaymentService` tying a webhook event back to a
  `financial_transaction` and driving the subscription state transition,
  which is explicitly the next slice (see below), not built in this pass
  to avoid rushing the one piece where a shortcut becomes a double-charge
  or double-activation bug.

**Onboarding session engine (Phase 2)**
- `OnboardingSessionService`: create, resume by `device_session_token`,
  `advance_step` with real optimistic concurrency (a single
  `UPDATE ... WHERE id = :id AND version = :expected_version` — the
  conflict is detected by `rowcount == 0`, not by a read-then-compare
  race), launch/complete state transitions, step-event emission for
  funnel analytics.
- `expire_stale_sessions` / `run_onboarding_expiry_loop`
  (`app/workers/onboarding_expiry.py`), wired into the existing worker
  runner alongside trial expiration and the event relay. Flips sessions
  past their 7-day window to `EXPIRED`. Does not yet implement the
  1hr/24hr reminder notifications (needs a real notification vendor,
  same standing gap as everywhere else that seam is referenced) or the
  30-day payload-retention purge (nothing reads or purges against that
  window yet, so building it now would be speculative).
- Three generic endpoints proving the mechanism end-to-end:
  `POST /api/v1/onboarding/sessions` (create-or-resume, deliberately
  unauthenticated — the locked journey's first steps precede account
  creation), `GET /api/v1/onboarding/sessions/{id}`,
  `PATCH /api/v1/onboarding/sessions/{id}` (generic advance, returns 409
  on stale version). These are the mechanism the ~12 step-specific
  endpoints (welcome, business info, plan selection, etc. — Phase 4) will
  each thinly wrap; building the generic mechanism correctly first,
  proven by real endpoints, before building all the step-specific ones
  on top of it.

## Explicitly not done, and why

- **Subscription activation on successful payment** — the orchestration
  between a webhook event, its `financial_transaction`, and the actual
  `SubscriptionStatus` transition. This is the next concrete slice.
- **The ~12 step-specific onboarding journey endpoints** (Phase 4 proper)
  — business info, contact info, plan selection, activation mode, delivery
  setup, first product, branding/slug, review, launch. The generic
  session mechanism they depend on is now built and endpoint-reachable;
  the step-specific validation/payload shapes for each are not.
- **Slug reservation** — Kratos flagged the TTL as a genuine open
  business/config decision, not something to invent. Not built this
  pass; needs that number before it can be.
- **Real vendor wiring** for OTP delivery and both payment providers —
  blocked on credentials/vendor choice exactly as scoped in the prior
  exchange, not on anything this pass could have built differently.

## Verification status

`py_compile` clean across every file touched this pass and a full
`app/`+`migrations/` sweep. Migration chain verified linear 001→024 by
inspection. No CRLF regressions. `.env` confirmed absent from the
delivered archive. Nothing has been run against a live database, Redis,
or any real payment/OTP provider sandbox — that remains Gate 1's job
(Railway/CI), unchanged from every prior doc in this series.
