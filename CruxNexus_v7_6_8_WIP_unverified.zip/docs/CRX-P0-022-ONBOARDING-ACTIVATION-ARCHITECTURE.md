# CRX-P0-022: Locked Onboarding & Activation Architecture — Phase 1

**Date:** 2026-09-17
**Status:** Phase 1 (schema/domain foundation) code-complete, not verified against a live database. Phases 2-8 staged, not built — see section map below for exactly why each one is or isn't in this pass.

## Why this document exists

Kratos locked a complete Merchant Onboarding & Activation Architecture
(57 numbered sections) as the implementation contract for onboarding,
superseding the "bootstrap transaction, not a journey" framing from
CRX-P0-020/021's discussion. This document does two things: records the
architecture durably in this repo (not just in chat), and maps every
section to one of three honest outcomes — **built this pass**, **already
compliant**, or **staged**, with a reason for every staged item. Nothing
was silently dropped; what follows is the complete map.

Building a system of this size (two payment provider integrations, a
resumable session state machine, an access resolver, and eventually a
full commerce/fulfillment/logistics loop) in a single pass is not
possible without either taking shortcuts or fabricating untested work —
both of which this project's remediation history has already paid for
once (see CRX-P0-019 through 021). So instead: everything with no
external dependency and no unresolved design ambiguity was built for
real in this pass (Phase 1). Everything else is sequenced, not skipped.

## What was built this pass (Phase 1)

1. **Subscription state machine** (section 6) — `SubscriptionStatus` now
   has all nine locked states (`PENDING_SELECTION`, `TRIALING`,
   `PAYMENT_PENDING`, `PAYMENT_FAILED`, `ACTIVE`, `PAST_DUE`,
   `TRIAL_EXPIRED`, `SUSPENDED`, `CANCELLED`; `EXPIRED` kept only for
   backward compatibility with old rows). Migrations 019 and 020 expand
   the DB check constraint to match. `trial_expiration.py`'s worker was
   updated to write `TRIAL_EXPIRED` instead of the old generic `EXPIRED`,
   matching the locked naming exactly — this was a real, silent
   naming/semantics drift the locked architecture caught.
2. **`onboarding_sessions` / `onboarding_step_events`** (sections 15,
   48-52) — migration 021 and the matching ORM models. Schema supports
   resumability (`device_session_token`, `expires_at`), optimistic
   concurrency (`version`), flow pinning (`flow_version`), and append-only
   funnel analytics (`onboarding_step_events`). This is schema only — see
   Phase 2 below for why the session *service* isn't built yet.
3. **`financial_transactions` / `provider_webhook_events`** (sections 10,
   11) — migration 022. The canonical CNX-TXN identity table and the
   immutable, deduplicated webhook inbox (`UNIQUE(provider_code,
   provider_event_id)`), independent of which provider is behind them.
4. **`PaymentProviderAdapter` interface + `PaymentProviderRegistry`**
   (section 9) — `app/infrastructure/payments/adapter.py`. Domain code
   depends on this interface, never a provider SDK. Registry is currently
   empty (raises a clear `ValueError` naming exactly what's missing if
   anything calls `.get()` on it today) — see Phase 3 for why.
5. **`PaymentAuthorizationType`** (section 4) — modeled on
   `financial_transactions.authorization_type`, separate from `provider`
   and `status`, so "this payment method doesn't auto-renew" is
   representable rather than assumed away.
6. **`MerchantAccessResolver`** (section 13) —
   `app/kernel/access/resolver.py`. `can_create_storefront` and
   `can_add_staff` are real: they wrap the existing
   `CapacityService` methods of the same name (unchanged — that class
   still owns the actual capacity arithmetic) and add the gate that was
   missing before this file existed: a merchant whose subscription has
   lapsed to `PAST_DUE`/`SUSPENDED`/anything other than `TRIALING`/`ACTIVE`
   can no longer pass a capability check just because the raw capacity
   numbers still had room. `can_publish_store`, `can_process_orders`,
   `can_use_premium_feature`, `can_reactivate_store` raise
   `NotImplementedError` naming exactly which non-existent domain each
   depends on — a resolver that silently allows a check it can't actually
   evaluate is worse than one that fails loudly.

## Already compliant — no build needed

- **Section 5** (Subscription belongs to Merchant Account, never Store) —
  confirmed true in the existing schema/relationships.
- **Section 7** (trial inherits the selected plan, not a separate
  `_TRIAL` plan; `merchant_trial_history` enforces eligibility
  historically) — confirmed true, previously verified in CRX-P0-019/020 too.
- **Section 12** (entitlements are merchant-level records with type/
  quantity/source/status/starts_at/ends_at, separate from plan config) —
  the shape is right. The *enforcement* bugs in this area (time-window
  checks, entitlements outliving a downgrade, concurrent-grant races)
  were already identified and staged in `PHASE-0-ACTUAL-STATUS.md` Stage
  B — unchanged by this pass, still open.
- **Section 14** (separate status authority per domain: User, Merchant,
  Subscription, Storefront, etc., never one global `ACTIVE` flag) —
  confirmed true by inspection: every relevant entity already has its
  own independent `status` column.

## Staged, with reasons (Phases 2-8)

**Phase 2 — Onboarding session service** (sections 48-52's *behavior*,
not just schema): create/resume/advance/expire, the optimistic-concurrency
check-and-increment on `version`, cross-device resume via secure link,
abandonment reminders at 1hr/24hr/7-day thresholds, step-event emission.
Needs Phase 1's schema, which now exists — this is pure application code,
buildable next with no external dependency.

**Phase 3 — Real payment provider adapters** (sections 3, 8, 9, 11, 24,
25, 47): `PaystackAdapter`, `FlutterwaveAdapter`, the webhook endpoints
that write to `provider_webhook_events`, signature verification, and the
reconciliation logic (webhook-arrives-twice-is-a-no-op, timeout-doesn't-
mean-failure, etc.). **Blocked on real sandbox API credentials** for both
providers — writing signature-verification and charge-initialization code
against remembered API shapes instead of each provider's actual current
documentation and a working sandbox is exactly the unverified-but-claimed
work this project has already paid to fix twice. This needs credentials
from Kratos (or explicit sign-off to build against public API docs only,
untested, clearly labeled as such) before it should start.

**Phase 4 — The full onboarding journey** (sections 16-37): the actual
step-by-step API (welcome → business info → account → OTP verify →
contact → plan → activation mode → delivery setup → first product →
branding/slug reservation → review-with-server-recompute → launch).
Depends on Phase 2 (session service) for every step, and Phase 3
specifically for the pay-now branch (the trial branch does not need
Phase 3 and could be built once Phase 2 lands). The launch transaction
itself calls the *existing* `OnboardingService.onboard_merchant` — that
method remains the provisioning engine underneath the journey, unchanged.

**Phase 5 — Minimal commerce loop** (sections 27-30, 41-45): Catalog/
Product (needed for the First Product step and for section 41's
end-to-end proof), Cart, Guest/Ghost Buyer checkout, Order, Fulfillment,
Logistics provider registry, delivery evidence normalization. None of
this exists in the codebase at all yet — this is the "Commerce OS" gap
identified in every prior review pass, now given its exact shape by
sections 27-45 of the locked architecture instead of a general
description.

**Phase 6 — Evidence/trust foundation** (section 43): append-only
evidence tables for payment/order/fulfillment/delivery/communication
events. Depends on Phase 3 and Phase 5 existing first, since evidence is
recorded *about* those domains' events.

**Phase 7 — Control Plane physical separation** (sections 38-39): a
genuinely separate Control Center service and database, with async
entitlement sync via the commerce outbox. Today: the service-to-service
auth boundary exists (CRX-P0-021), but Control Center itself is still not
a deployed service — this is an infrastructure/deployment decision, not
a code change this pass can make unilaterally.

**Phase 8 — Security/observability hardening applied throughout**
(sections 46, 53, 54): the 16-question failure contract, OTP throttling,
slug reservation races, encrypted onboarding-time provider credentials.
These apply *within* each phase as it's built, not as a separate
standalone deliverable — flagged here so they're not forgotten when
Phases 2-5 are implemented, not because they're deferred to "later."

## Sections that are principles, not build items

Sections 1, 2, 40, 55, 56, 57 are the architectural objective, the
activation-chain diagram, the definition of a successful activation, the
"what complete means" checklist, the final combined diagram, and the rule
Kratos put above the repository. These don't get a phase of their own —
they're the acceptance criteria every other phase is built against, and
they're recorded verbatim in project memory (not just this file) so
they survive independently of any single conversation.

## Verification status

Same standing caveat as every remediation doc in this repository:
`py_compile` clean across every new/touched file, migration chain
verified linear (001→022) by inspection, nothing run against a live
database, no CI run observed. The schema in this pass is additive only —
no existing table was altered destructively, no existing behavior was
changed except the `EXPIRED`→`TRIAL_EXPIRED` naming fix in the trial
worker, which is a correctness fix, not a breaking one (no application
code reads `SubscriptionStatus.EXPIRED` as a meaningful state to react to).
