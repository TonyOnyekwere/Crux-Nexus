# CRX-P0-027: Canonical Capacity Model + Entitlement Reconciliation Worker

**Date:** 2026-09-24
**Status:** Code-complete, runtime-unverified. Migration 028 has not run against a live database.

## Why this order, not "just add the worker"

Kratos and the architecture discussion both specified the same sequencing explicitly: establish one canonical entitlement/allocation model *before* adding a reconciliation worker, since a worker reconciling between three disagreeing models would formalize the confusion rather than resolve it. This document covers both steps, in that order.

## Step 1: Retired two dead, competing capacity models

Verified by grepping every symbol/table name across the entire codebase (not assumed) that two of the three tables flagged in prior reviews had **zero real usage anywhere**:

- **`storefront_entitlement_allocations`** (`StorefrontEntitlementAllocation`) — its own docstring describes the *identical* purpose as `staff_capacity_allocations` ("allows merchant-owned extra staff capacity to be distributed across storefronts"), with an equivalent schema. A duplicate from an earlier design iteration, superseded but never cleaned up.
- **`storefront_staff_capacity`** (`StorefrontStaffCapacity`) — a third, different approach: a cached/denormalized per-storefront capacity value, rather than the dynamically-computed approach `CapacityService` actually uses. Never adopted; would have needed its own cache-invalidation logic to ever be correct.

**What was done:** migration 028 drops both tables. Both ORM model files deleted. `app/database/models.py` registrations removed. `app/database/tenant_scope.py`'s `CONTROL_PLANE_TABLES` registry updated to drop the two retired names.

`staff_capacity_allocations` (`StaffCapacityAllocation`) is now unambiguously the single canonical model — the only one any service reads or writes, confirmed by the same grep.

## Step 2: Entitlement reconciliation worker (fifth loop)

Built strictly to the architectural principle both the discussion and Kratos were explicit about: **this worker never becomes an authorization authority.** A synchronous `POST /storefronts` or invitation-accept request is still answered in-request by `MerchantAccessResolver`/`CapacityService` — this worker only asks "is entitlement/allocation state healthy," on a 10-minute poll, never "is this specific request allowed."

Three operations, chosen specifically because they're deterministic or explicitly *not* auto-resolved where a real judgment call exists:

1. **`expire_lapsed_entitlements`** — `ACTIVE` entitlements past their `ends_at` move to `EXPIRED`. Emits `EntitlementExpired`. One row per transaction (`FOR UPDATE SKIP LOCKED`) — applying the exact lesson from CRX-P0-026's webhook-worker fix: a batch claim doesn't survive per-row commits.
2. **`cleanup_orphaned_allocations`** — an allocation whose entitlement is no longer `ACTIVE`, or whose tenant is `ARCHIVED`, is deleted. This is safe to automate: such an allocation has no valid interpretation other than stale.
3. **`detect_allocation_anomalies`** — flags (via `AllocationAnomalyDetected` outbox event and a warning log) any entitlement where total allocated quantity exceeds the entitlement's own granted quantity. **Deliberately does not auto-repair.** This scenario would only arise from an administrative reduction of an entitlement after allocations were already made — deciding *which* allocation to shrink is a governance decision, not something this worker should guess. Per the locked direction, that decision belongs to Control Center.

Wired into `app/workers/runner.py` as the fifth loop. Log line is now `Starting background worker process (5 loop(s))` — updated in `.railway/railway.ts`'s documented expectation to match.

## What this does not do, on purpose

Does not implement the broader "domain events → durable command queue → worker executes all lifecycle side effects" pattern the architecture discussion also proposed (e.g. `SubscriptionExpired`/`MerchantSuspensionRequested` as a general command-execution framework). That's a significant, cross-cutting architectural shift — this pass builds the one worker loop that was concretely scoped and sequenced, not the whole framework, which deserves its own dedicated design pass rather than being absorbed into a capacity-model cleanup.

Does not touch `EntitlementSource`/`PLAN_GRANT` semantics, pricing, or subscription state transitions — those are unrelated to what this pass was scoped to (the capacity/allocation model specifically).

## Verification status

`py_compile` clean across every file touched and a full `app/`+`migrations/` sweep. Migration chain verified linear 001→028 by inspection. No CRLF regressions. `.env` confirmed absent. Migration 028 (which drops two tables) has **not** been run against any database — standard caveat, but worth restating given this one is destructive (`DROP TABLE`), not additive like most prior migrations in this series.
