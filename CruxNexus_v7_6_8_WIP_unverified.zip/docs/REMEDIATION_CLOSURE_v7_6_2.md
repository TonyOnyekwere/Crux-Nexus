# CruxNexus v7.6.2 Remediation Closure

## Current review closure

| Review item | Closure |
|---|---|
| Commerce worker blocked by forced RLS | Closed. Dedicated `DATABASE_WORKER_URL`, non-superuser/NOBYPASSRLS role, explicit worker policies and role-level worker context. |
| Commerce RBAC inconsistent | Closed for current Commerce mutations. Product, inventory, storefront settings/publish, order mutation and staff entitlement mutations enforce the declared permission matrix. |
| Entitlement allocation authority | Closed. `MANAGE_STAFF` is required and allocation remains under the canonical entitlement service. |
| Subscription/governance suspension provenance | Closed. `TenantSuspension` records source, reason, restoration authority and governance override. |
| RLS context loss after commits | Closed in the identified checkout/provider paths by re-establishing transaction-local tenant context after durable commits; worker execution uses role-level worker context. |
| Immediate reservation release on definitive payment failure | Closed. Commerce payment verification, provider-not-found handling and checkout rejection release reservations atomically with the terminal state. |
| Hardcoded commercial lifecycle policy | Closed for grace/period policy. `CommerceGovernancePolicy` stores grace period, monthly/yearly period lengths and early-renewal policy. |
| Worker architecture | Closed at the MVP execution-boundary level. Existing lifecycle loops remain domain-specific; durable deferred commands use `worker_jobs` with leases, attempts, retry and dead-letter state. |
| Outbox only logged/published locally | Closed at transport level. Relay publishes to Redis Streams and persists transport identifiers and failures. |
| Durable audit missing | Closed. `audit_events` is append-only application audit storage for governance, suspension and staff-allocation actions. Control Center has its own durable audit table. |
| Control Center missing | Closed at service/database boundary. `apps/control-center-api` is separately deployable, has its own schema, admin RBAC/MFA, governance records and authenticated one-way synchronization into Commerce. |
| Provider registry governance missing | Closed at MVP governance-cache boundary. Control Center synchronizes provider enablement/priority/version into Commerce and payment initiation honors the synchronized enabled state. |
| Dependencies unpinned | Closed. Commerce and Control Center production dependency sets are pinned. |
| Celery/asyncio architecture drift | Closed. Celery is removed from executable Commerce dependencies; ADR-0011 establishes asyncio + durable jobs + Redis Streams. |
| Documentation drift | Closed for current runbook/current-state/worker architecture. Historical remediation records remain historical. |

## Runtime verification still required

These are not represented as passed because the authoring environment does not contain the required live infrastructure or provider credentials:

- PostgreSQL migration execution against a real database.
- Runtime-role RLS isolation with separate API and worker roles.
- Multi-session concurrency tests against PostgreSQL.
- Redis Streams transport behavior.
- Paystack sandbox initialization, verification, webhook, timeout and duplicate scenarios.
- Flutterwave sandbox initialization, verification, webhook/hash behavior and duplicate scenarios.
- SendGrid delivery.
- Production Railway deployment and rollback verification.

These are release verification gates, not source-level omissions.

## Product expansion domains

The canonical finished product still contains larger domains such as logistics/shipment tracking, multi-channel notifications, customer accounts, product variants, pricing/promotions, search, analytics/intelligence, evidence/trust/fraud, refunds/disputes, data export/exit, DR verification and frontend applications. They remain explicit subsequent product domains. They are not falsely marked as implemented by this remediation release.
