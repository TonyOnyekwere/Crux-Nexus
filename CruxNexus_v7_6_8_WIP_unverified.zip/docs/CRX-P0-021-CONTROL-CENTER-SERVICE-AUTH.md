# CRX-P0-021: Platform-Admin Access Corrected to Control-Center Service Auth

**Date:** 2026-09-16
**Status:** Code-complete, **not verified against a live database or CI**. Supersedes the platform-admin approach shipped in CRX-P0-019/020.

## What changed and why

CRX-P0-019 closed the `PATCH /tenants/{id}/status` dead-end by adding a
`users.is_platform_admin` flag, a `platform_admin_access` JWT type, and a
`POST /api/v1/identity/platform-admin/login` endpoint — modeling platform
admin as a special kind of user login inside commerce-api. CRX-P0-020
used the same mechanism (`get_current_platform_admin`) to lock down the
previously-unauthenticated `POST /api/v1/admin/entitlements/grant-plan-based`.

That was built without visibility into Control Center's actual design —
the repository only mentions it in two source comments, never a spec.
Clarified directly: **Control Center is a separate service with its own
database, with no direct access to commerce-api's database, specifically
so an incident in Control Center can't disrupt commercial traffic. It
manages, monitors, and controls the commerce plane (subscription
pricing, fraud suspension, etc.) purely by calling commerce-api's API.**

That changes the right shape for this authorization boundary:

- Commerce-api's `users` table is the merchant/customer identity plane.
  Control Center owns admin identity, RBAC, and audit entirely in its own
  database — that's the whole point of the separation. Putting
  `is_platform_admin` on commerce-api's `users` table re-coupled exactly
  what the database split was designed to keep apart, one layer up.
- The real trust boundary for `PATCH /tenants/{id}/status` and
  `POST /entitlements/grant-plan-based` isn't "which admin user is this,"
  it's "is this call really coming from Control Center." Control Center
  has already done its own authorization (RBAC/ABAC, whatever admin
  triggered the action) before it ever calls commerce-api. Commerce-api's
  job is to verify the *service*, not re-authenticate the human.

## What was removed

- `users.is_platform_admin` column and its migration (the file previously
  numbered `018_add_platform_admin_flag.py`). Deleted outright rather than
  reverted via a new migration — it was never applied to any real
  database (nothing in this project has been run against a live DB yet),
  so there's no deployed state to migrate away from.
- `PLATFORM_ADMIN_TOKEN_TYPE`, `create_platform_admin_access_token`,
  `get_current_platform_admin` from `app/auth/jwt_handler.py`.
- `POST /api/v1/identity/platform-admin/login` and
  `get_platform_admin_login_tracker` from `app/contexts/identity/api/routes.py`.

Migration `019_align_user_status_enum.py` (unrelated to platform admin —
it fixes the Postgres/Python `UserStatus` enum mismatch from CRX-P0-020)
was renumbered to `018` to keep the migration chain dense after the
platform-admin migration was deleted. Chain is 001→018, verified linear.

## What replaced it

**New file:** `app/auth/control_center_auth.py`

- `CONTROL_CENTER_SERVICE_TOKEN`: a shared secret (added to
  `app/config.py`, validated as a strong required value in production the
  same way `SECRET_KEY`/`JWT_SECRET_KEY` already are, auto-generated for
  local dev like the others).
- `verify_control_center_service`: a dependency that checks
  `Authorization: Bearer <token>` against that secret using
  `hmac.compare_digest` (constant-time, to avoid a timing side-channel on
  the comparison). Optionally reads `X-Acting-Admin-Id` /
  `X-Acting-Admin-Email` headers — Control Center's own assertion of
  which admin triggered the call, logged here for audit but **not**
  independently re-verified by commerce-api. Control Center already did
  that verification on its side; re-checking it here would require
  commerce-api to know about Control Center's admin directory, which is
  exactly the coupling the separate-database design avoids.
- Both `PATCH /tenants/{id}/status` and
  `POST /entitlements/grant-plan-based` now depend on this instead of the
  removed user-login-based check, and log the acting admin ID on success.

## What this means for standing up Control Center

Whoever builds Control Center needs to know:
- Send `Authorization: Bearer <CONTROL_CENTER_SERVICE_TOKEN>` on calls to
  commerce-api's platform-only endpoints. The token is a single shared
  secret for now, not per-admin — because there is no per-admin identity
  on commerce-api's side anymore, by design.
- Optionally send `X-Acting-Admin-Id`/`X-Acting-Admin-Email` for
  commerce-api's audit logs. This is advisory only.
- If/when this needs to be more than trust-one-shared-secret — e.g. key
  rotation without downtime, or multiple environments needing distinct
  credentials — the natural next step is asymmetric: Control Center holds
  a private key, signs a short-lived service token per request, and
  commerce-api verifies it with the corresponding public key
  (`CONTROL_CENTER_PUBLIC_KEY` or a JWKS endpoint) instead of comparing a
  static shared secret. Not built now because Control Center doesn't
  exist as code yet and a shared secret is enough to close the two live
  vulnerabilities today; flagging it so this isn't mistaken for the final
  design.

## Verification status

Same caveat as every prior remediation doc in this repository: `py_compile`
clean across every touched file, migration chain verified linear by
inspection, nothing run against a live database, no CI run observed.
