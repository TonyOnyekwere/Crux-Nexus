# CruxNexus Product Constitution

Status: NON-NEGOTIABLE PRODUCT CONSTRAINTS

These principles define what CruxNexus is. Implementation may evolve, but implementation must not redefine these product truths. Any proposed architectural change must preserve them and document any implementation consequence.

## 1. Own Your Storefront
CruxNexus is an own-your-storefront multi-tenant commerce ecosystem. It is not a merchant-type-specific application and not merely a storefront builder. Any legitimate merchant type can onboard.

## 2. Independent merchant environments
Every merchant receives an isolated tenant/storefront environment and a personalized storefront URL derived from the business identity. Merchant business data is isolated and portable.

## 3. Merchant control
Merchants control supported storefront presentation, products, inventory, pricing, promotions, fulfillment methods, payment methods, and other commerce configuration within their entitlements.

## 4. Platform invariants vs merchant decisions
CruxNexus enforces tenant isolation, financial integrity, authentication/authorization, inventory consistency, security, entitlement enforcement, and other platform invariants. Merchant business choices are configurable and must not be hard-coded as universal behavior.

## 5. Dynamic plans and entitlements
The Control Center owns tier configuration. Tiers govern capabilities and quantitative/resource limits. Plan capabilities and limits must be dynamically configurable without rewriting Commerce architecture.

## 6. Downgrade and suspension preservation
Plan downgrade, suspension, provider changes, and logistics changes must not destructively delete merchant business configuration or historical data. Capabilities not entitled at the new state are restricted while underlying data remains preserved.

## 7. Merchant-owned payments
Merchants own their payment-provider relationships. CruxNexus is not a payment provider, does not hold merchant/customer funds, and must not insert itself as the financial intermediary. CruxNexus records canonical transaction identity and evidence and consumes provider-confirmed state.

## 8. Merchant-configurable fulfillment
Fulfillment is configurable by the merchant. Pickup, merchant delivery, third-party delivery, shipping, zones, and future logistics adapters are capabilities, not universal merchant behavior.

## 9. Presentation/data separation
Storefront themes, fonts, layout, component slots, and presentation configuration remain separate from catalog, inventory, order, customer, and financial data.

## 10. Discovery without ownership collapse
A platform-wide discovery layer may expose merchants, but discovery never replaces or collapses independent storefront ownership.

## 11. Data portability
Merchants must be able to export their business data, including products, customers, orders, inventory, and other supported records.

## 12. Architecture governance
Control Center governs platform policy and tier configuration. Commerce executes merchant runtime behavior. Workers execute durable asynchronous lifecycle, reconciliation, and scheduled work. Silent product-definition changes are prohibited.

## 13. Confirmed product decisions (recorded from Kratos, October 2026)
These answers are binding inputs to implementation and do not change sections 1-12.

1. **Tiers = capabilities AND limits.** Tiers control which capabilities a merchant may use and impose limits (products, storage,
   staff, orders, bandwidth, customization depth, ...). Both are Control Center-owned data; changing them must never require
   rewriting architecture. (Implemented: `app/kernel/access/entitlement_policy.py`; keys are opaque strings.)
2. **Storefront customization** grows toward a **visual storefront builder** so merchants never need engineering knowledge.
   Until it exists, customization is configuration-driven (theme, fonts, layout, component slots) with a data model the builder
   will edit. Customization depth is tier-gated.
3. **Custom domains.** Every merchant gets a CruxNexus URL generated from the business name entered during onboarding.
   Custom domains are an **Enterprise-tier** capability; Starter and Business merchants may **purchase** the capability
   separately (add-on entitlement - not yet built).
4. **Merchant-owned payment providers.** Customer payments settle directly to the merchant's own provider account. CruxNexus
   receives transaction-state confirmation from the provider and never becomes, holds funds for, or participates in the
   provider journey. CruxNexus's own provider keys are for the platform/subscription relationship only.
5. **Fulfillment is fully merchant-configurable** (pickup, merchant delivery, third-party delivery, shipping, local zones, other),
   with no universal model assumed by CruxNexus.
6. **Cross-merchant discovery.** Customers can browse multiple merchants through an optional discovery layer that does not alter
   the independent-storefront model.
7. **Data portability.** Merchants can export products, customers, orders, inventory and other business data; portability is a
   core principle.
8. **Tier changes.** On downgrade or lapse, existing configuration is **preserved**, further use is **disabled**, and the feature
   is **restored automatically** when the entitlement returns. Applied tests: `tests/unit/test_entitlement_policy.py`.


## 14. Two payment relationships that must never be conflated (recorded from Kratos, October 2026)
- **A. Merchant -> CruxNexus (subscription).** Uses CruxNexus-owned provider credentials, the platform provider registry and the
  billing webhook inbox.
- **B. Customer -> Merchant (checkout).** Uses ONLY the merchant's own payment-provider account, through a merchant payment
  connection and sealed credentials. CruxNexus orchestrates the transaction and records provider-confirmed state (CNX transaction id,
  provider transaction id, merchant, order, amount, currency, provider, state, verification evidence, timestamps). It never receives,
  holds, or routes the money.
- **The channel merchants use to pay CruxNexus for their subscription can never, and will never, serve as a customer checkout gateway.**
  Enforced in CI by `scripts/check_payment_channel_separation.py` (AST gate) and `tests/unit/test_payment_channel_separation.py`.
- A merchant with no verified payment connection has **no online payment option**; pay-on-delivery, bank transfer and pickup remain
  merchant-level choices.

## 15. Tier policy is data (baseline recorded from Kratos, October 2026)
- Plans differ by capabilities and resource limits, never by merchant type; any legitimate merchant may use any plan.
- The baseline matrix lives in the Control Center as versioned data (`apps/control-center-api/app/seed/plan_policy_v1.json`) and is applied
  through an audited admin route, not hard-coded in Commerce. Changing a number (e.g. Business products 2,500 -> 5,000) is a Control Center
  change followed by sync; Commerce is not rewritten.
- Enterprise is bounded, not infinite: sufficiently high limits (or an explicit unlimited policy) so abuse limits stay possible.
- Add-ons (custom domain on Starter/Business, extra storefront, extra staff, storage, ...) are **entitlements**: an opaque key, a kind
  (capability | resource | add_on), a quantity, a validity window, and Control Center-stated grant metadata. No per-add-on columns.
- Downgrade/lapse never deletes configuration: it stays stored but inert, and returns when the entitlement does.


## 16. Gate 1 decisions (recorded from Kratos, October 2026)
- **Currency authority.** Supported currencies are NGN, GHS, KES, ZAR. A storefront has exactly one (default NGN); it is the single authority
  for every product, cart, order and payment. Checkout rejects any other currency; there are no mixed-currency carts or orders.
- **Subscription charge lock.** A PENDING provider transaction blocks a new subscription charge until it is terminal: SUCCESS, FAILED,
  ABANDONED, or NOT_FOUND where the provider gives sufficiently strong evidence. No timeout ever authorizes a second charge; a timeout may
  only trigger reconciliation.
- **Immutable credential revisions.** A merchant's payment credentials are never mutated. Replacing the provider account creates a new
  revision; every payment records the exact revision it was initiated with and is verified against it for life. A retired revision is kept
  while any payment that used it is unresolved or owed a refund, then purged.
- **Publication.** A storefront is public only when it has a published product, an enabled payment method, an enabled fulfillment method and
  contact details, AND its tenant is active, the merchant is commercially entitled, it is explicitly published and not suspended. One
  resolver enforces this for every public endpoint.
- **Reservations.** Bank transfer holds stock for a merchant-configurable window (default 24h); expiry releases it; a late confirmation
  re-checks stock and, if the units cannot be re-reserved, the payment becomes refund-required. An order is never revived merely because
  money arrived, and a deliberately cancelled order is never reopened. Pay on delivery holds stock from confirmation until fulfilled or
  cancelled, with no automatic expiry.
- **Legacy routes** that bypass the policy-aware implementations are retired (410), after confirming no consumer exists.
- **Rate limiting** is Redis-backed and identity-aware (login 10/min, credential intake 5/hour, checkout 30/min, webhooks 300/min keyed per
  merchant connection, not per shared provider IP).
- **Database roles.** Migrations/schema ownership, commerce runtime, worker runtime and Control Center runtime are separate roles; runtime
  roles never own schema or hold DDL privileges.
