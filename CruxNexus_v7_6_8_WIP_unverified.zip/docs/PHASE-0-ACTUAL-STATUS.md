# Phase 0 — Actual Status (Repository Evidence)

**Last updated:** 2026-09-16  
**Verdict:** **NOT COMPLETE** (~85–88%; five code-level gaps closed this update, none yet verified live — see Stop-the-Bleeding section below)

This document reflects **what the repository actually contains**, not self-declared completion labels in older remediation records.

---

## What is proven

| Area | Evidence |
|------|----------|
| Railway deployment boot | Container starts, Alembic runs, Uvicorn serves `/health/live` |
| Global identity model | `users.tenant_id` removed; membership-based access |
| Merchant ownership chain | `merchant_account_tenants`, capacity checks, ownership validation |
| JWT tenant tokens | Membership verified in `get_current_tenant_context()` |
| CI pipeline configured | `.github/workflows/ci.yml` at repo root |
| Outbox persistence | Migration 007, transactional append in onboarding |

## What is NOT proven

| Area | Gap |
|------|-----|
| Tenant data-plane RLS | `TENANT_SCOPED_TABLES = ()` — vacuous pass only |
| Tenants control-plane RLS | Migration `017` written per ADR-0009; **not run** — must verify app DB role isn't blocked by `FORCE ROW LEVEL SECURITY` first |
| Full CI green run | `ENVIRONMENT` typo blocking every job is fixed; a real green run has not been observed since |
| Railway acceptance suite | Boot proven; full auth/onboarding/concurrency flow not documented as green |
| Event transport | Relay marks `published`; external transport is Phase 1 |
| Performance baseline | Criteria exist in docs; measurements not automated |
| Onboarding idempotency | Now implemented (model + service + `Idempotency-Key` header); not exercised against a live DB |
| Tenant lifecycle admin gate | `PATCH /tenants/{id}/status` now reachable only by Control Center via service-to-service auth (`CRX-P0-021`); no admin UI/API exists at Control Center yet |
| Staff invitation delivery | Token lifetime bug fixed and a notification seam added; the seam only logs — no real email/SMS provider is wired in |

## Stop-the-Bleeding remediation (2026-09-16)

Five concrete issues found during a full review were fixed at the code
level; see `docs/CRX-P0-019-STOP-THE-BLEEDING-FIXES.md` for the complete
writeup. Summarized here because they change several rows above and
below — but note the caveat that follows the list: **none of this has
been run against a live database or through CI yet**, which keeps the
Phase 0 certification gate at the bottom of this document exactly where
it was.

1. `ci.yml` set `ENVIRONMENT: test`; `config.py` only accepted `testing`.
   Every CI job that imported the app should have failed at `Settings()`
   construction. Fixed to `testing`.
2. ADR-0009 described a `tenants` RLS policy as accepted-and-implemented;
   no migration ever created it. Migration `017` now does. **Not yet
   verified safe to run** — see the Implementation Note added to
   ADR-0009 about `FORCE ROW LEVEL SECURITY` and the application's DB
   role.
3. Migration `015` added a `merchant_onboarding_requests` idempotency
   table with no ORM model and no application code touching it — dead
   schema. Added the model and wired real `Idempotency-Key` handling
   into `OnboardingService.onboard_merchant`.
4. `PATCH /tenants/{id}/status` was hard-stubbed to always 403 — not
   because the state-machine logic was missing (it wasn't), but because
   there was no admin authorization model. Wired the route to the
   existing service logic, gated behind Control Center service-to-service
   auth (see the CRX-P0-021 correction below — the first fix here used a
   user-login-based `is_platform_admin` flag, since replaced).
5. Staff invitation creation discarded the raw invitation token right
   after hashing it, before any notification could use it — worse than
   the previously-known "no notification sent" gap, since no notification
   mechanism could ever have worked without this fix regardless. Fixed
   the token lifetime and added a `NotificationProvider` seam (currently
   log-only, honestly labeled as such — not a real email/SMS integration).

**What this does and does not mean:** all five changes are syntactically
verified (`py_compile` clean) and reasoned through carefully, including
one async-SQLAlchemy footgun (reading an expired attribute on a
committed object inside `AsyncSession`, which raises `MissingGreenlet`
rather than doing an implicit reload). None of them have been exercised
against a running Postgres instance, and CI has not been re-run since
the `ENVIRONMENT` fix. Treat these as **implemented, not proven** until
someone runs the migrations and test suite against a real database and
watches CI go green.

## Canonical capacity model + entitlement reconciliation worker (2026-09-24) — CRX-P0-027

Per the exact sequencing both Kratos and the architecture discussion
specified — fix the canonical entitlement/allocation model before adding
a reconciliation worker, not after — retired the two dead, competing
capacity tables (`storefront_entitlement_allocations`,
`storefront_staff_capacity`; migration 028), leaving
`staff_capacity_allocations` as the single model. Then added a fifth
worker loop (`entitlement_reconciliation.py`) that expires lapsed
entitlements, cleans up orphaned allocations, and flags (never
auto-repairs) allocation-exceeds-entitlement anomalies. Built strictly to
the locked principle that this worker never becomes a synchronous
authorization authority — `MerchantAccessResolver` still answers every
real-time "can this merchant do X" question. See
`docs/CRX-P0-027-CANONICAL-CAPACITY-MODEL-WORKER.md`.

## V7.1 Foundation Closure (2026-09-22) — CRX-P0-026

Closed the P0 items an independent review of v7 found still exploitable
inside the "hardened" foundation: staff invitations bypassed staff
capacity entirely, storefront creation bypassed `MerchantAccessResolver`
(merchant suspension wasn't checked), and staff allocation records
existed but were never read (every storefront got the merchant's full
extra-staff entitlement independently). Also closed: subscription
reactivation from `TRIAL_EXPIRED`/`SUSPENDED` was never implemented
despite being in the documented state machine, there was no API route to
actually initiate a subscription payment, and a concurrency bug in this
session's own webhook worker (`FOR UPDATE SKIP LOCKED` didn't survive the
batch's internal per-event commits). Two decisions were confirmed with
Kratos before starting rather than assumed: the real GitHub repo for the
Railway IaC file, and that reactivation restores all suspended
storefronts. See `docs/CRX-P0-026-V7-1-FOUNDATION-CLOSURE.md` for the
complete list, including what's explicitly still open (deprecated
staff endpoint still live, OTP resend race, pricing DB constraints,
payment-timeout-vs-failure handling, and more).

## RLS classification, Railway worker IaC, subscription activation (2026-09-19) — CRX-P0-025

The Railway worker service now has a proper `.railway/railway.ts`
definition (verified against Railway's current docs — Config as Code is
deprecated and can't create new services at all), RLS tables are now
explicitly classified (control-plane vs tenant-scoped) with a CI gate
that fails on anything unclassified, and the long-standing "webhook says
paid, nothing happens" gap is closed with a full, idempotent, never-
trust-the-webhook-alone activation orchestration. See
`docs/CRX-P0-025-SUBSCRIPTION-ACTIVATION-RLS-WORKER.md` for the complete
picture, including the required 5-category breakdown (code-fixed /
code-fixed-but-unverified / requires-Railway-action / requires-provider-
credentials / still-open) — none of this is claimed as "done" beyond
what's actually been run.

## Phase A security/correctness fixes (2026-09-18) — CRX-P0-024

An independent review of the v5 archive found several critical
authorization/state-transition holes in the code CRX-P0-023 had just
shipped — OTP destination hijacking, onboarding session hijacking, staff
invitations silently never committing, invitation identity-binding trust,
an invitation double-accept race, missing invitation RBAC, the old
onboarding bootstrap endpoint bypassing the new verification requirement
entirely, two Flutterwave adapter bugs, and weak webhook failure
handling. All were independently verified against the actual code before
fixing (one review claim — that the OTP channel set should become
WhatsApp-first — directly contradicted Kratos's own earlier, more
specific lock and was not followed). See
`docs/CRX-P0-024-PHASE-A-SECURITY-FIXES.md` for the complete list and
what's still staged (entitlement/capacity bugs, `MerchantAccessResolver`
wiring, worker races, idempotency lease/timeout — all pre-dating this
review, unchanged).

Also recorded: Kratos ran the Railway RLS role-verification query from
ADR-0009 and confirmed `postgres`/`rolsuper=true`/`rolbypassrls=true` is
the only role in use. Migration 017 is therefore currently safe to run
but currently inert (protects nothing yet) — the real design question
for a future role split is recorded in the ADR rather than solved here.

## Phase 2 + Gates 2/3 progress (2026-09-17, same day) — CRX-P0-023

Onboarding session engine (create/resume/advance with real optimistic
concurrency), full OTP verification (UNVERIFIED user status, otp_codes,
OTPProvider abstraction, working endpoints), and real Paystack/
Flutterwave adapters (built against current provider docs, not memory)
plus webhook ingestion are now built and compile-clean. Subscription
activation on successful payment and the ~12 step-specific journey
endpoints remain the next slice — see
`docs/CRX-P0-023-SESSION-ENGINE-PAYMENT-VERIFICATION.md` for the
complete breakdown. Per Kratos's explicit sequencing rule, no Commerce OS
or frontend work has started — everything this pass touches is
onboarding/verification/payment-foundation scope only.

## Locked Onboarding & Activation Architecture — Phase 1 (2026-09-17)

Kratos locked a complete 57-section Merchant Onboarding & Activation
Architecture as the implementation contract for onboarding. Phase 1
(schema/domain foundation with no external dependency) is built: the
full subscription state machine, `onboarding_sessions`/
`onboarding_step_events`, `financial_transactions`/
`provider_webhook_events`, a `PaymentProviderAdapter` interface/registry,
and a `MerchantAccessResolver`. See
`docs/CRX-P0-022-ONBOARDING-ACTIVATION-ARCHITECTURE.md` for the complete
section-by-section map — every one of the 57 sections is accounted for
as built, already-compliant, or staged with a named reason (mostly:
needs real Paystack/Flutterwave sandbox credentials, or needs Phase 1's
schema to exist first, which it now does).

This supersedes the "Stage A/B/C" framing below for onboarding-adjacent
items specifically — capacity/entitlement bugs (staff double-counting,
archived-storefront counting, entitlement time windows, downgrade
lifecycle, concurrent grants) are unchanged and still open, tracked
below as before.

## Follow-up from independent review (2026-09-16, second pass)

An independent review of the CRX-P0-019 output found five more
issues — one (an unauthenticated admin endpoint that could grant
arbitrary entitlements to any merchant) more severe than anything fixed
in the first pass. All five were verified against the code before fixing
and are recorded in `docs/CRX-P0-020-EXTERNAL-REVIEW-FOLLOWUP.md`.

**Third pass, same day:** the platform-admin mechanism CRX-P0-019/020
used to gate those two endpoints (`is_platform_admin` on `users`, a
commerce-api-owned login) was corrected after Control Center's actual
design was clarified: separate service, own database, no direct DB
access, calls commerce-api only over the API. Both endpoints now
authenticate Control Center as a service instead of modeling admin
access as a user login inside commerce-api. See
`docs/CRX-P0-021-CONTROL-CENTER-SERVICE-AUTH.md` for the full reasoning
and what changed.

That same review raised ~25 further findings. The ones confirmed as real
and requiring design decisions (not fixed yet — intentionally staged, not
missed) are, in the order we'd tackle them next:

**Stage A — remaining security gaps**
1. Invitation acceptance trusts a client-supplied `user_id` and can create
   accounts with an empty password hash — needs an actual auth-flow
   decision (claim-existing-account vs. fresh-signup-via-invite), not a patch.
2. Invitation acceptance has no row lock — a double-accept race is possible.
3. Suspended tenant membership / user status isn't checked at
   `switch-tenant` or in tenant-context resolution — inconsistent with
   what the resolver enforces elsewhere.
4. Removed/suspended memberships still appear in `GET /storefronts` listing.

**Stage B — capacity/entitlement correctness**
5. Two competing staff-capacity representations
   (`storefront_staff_capacity` vs `staff_capacity_allocations`) — pick one
   canonical model, don't patch both.
6. Archived storefronts still consume capacity in
   `get_active_storefront_count()`.
7. Entitlements don't check `starts_at`/`ends_at`, only `status`.
8. Plan-granted entitlements outlive a downgraded subscription.
9. Entitlement grants aren't row-locked — concurrent grants can exceed caps.

**Stage C — trustworthy CI**
10. Adversarial test suite has stale imports (`subscription_plan` module
    that no longer exists, `MembershipStatus.INACTIVE` that doesn't exist)
    and isn't included in the CI test command at all.
11. OpenAPI artifact (`openapi.json`) isn't verified against `app.openapi()`
    for all current routes — already visibly stale relative to
    `/invitations`, `/admin`, and the identity/tenant/admin route changes
    from the CRX-P0-019/020/021 fixes.
12. Dependency versions are all open-ended (`>=`), no lockfile.
13. `app/contexts/merchant` is unused scaffolding duplicate of
    `app/contexts/merchant_management` — remove if confirmed dead.
14. README claims Celery powers background jobs; the actual worker
    architecture is plain asyncio loops with no Celery app/broker anywhere.

None of Stage A-C is a live emergency the way the unauthenticated admin
endpoint was — that's why they're staged rather than rushed. But Stage A
should come before any real merchant data goes through invitation
acceptance, and Stage B should come before subscription tiers are treated
as commercial product behavior customers pay for.

## Corrections to older documentation

- **`tests/integration/test_tenant_isolation.py`** — removed; replaced by `test_auth_flow.py`, security tests, and architecture gates. Old remediation record #5/#6 claims are **superseded**.
- **RLS "PASS"** — control-plane authorization is implemented; tenant commerce table RLS is **not yet applicable** in Phase 0.
- **Outbox "complete"** — persistence foundation only; delivery transport not implemented.

## Remaining P0 blockers (as of this update)

| ID | Item | Status |
|----|------|--------|
| P0-A | Migration 008 repair merchant-tenant mapping | **In repo** — apply on Railway |
| P0-B | One owner merchant per user (DB index) | **In repo** (migration 008) |
| P0-C | One live subscription per merchant (DB index) | **In repo** (migration 008) |
| P0-D | Single tenant-context authority | **Done** — middleware subdomain-only; JWT via route deps |
| P0-E | Honest RLS claims | **Done** — `tenant_scope.py`, RLS script, docs updated |
| P0-F | Railway acceptance testing | **Runbook added** — `docs/runbooks/railway-acceptance.md`; execution pending |
| P0-G | Actual green CI run | **Pending** — push to GitHub and verify Actions |

## Phase 0 certification gate

Do **not** tag `PHASE-0-COMPLETE` until:

1. Migration 008 applied on Railway production/staging
2. GitHub Actions CI run is green (all jobs) — re-verify after the `ENVIRONMENT: testing` fix
3. Railway acceptance flow executed end-to-end
4. Restore/rollback drill documented and tested
5. Application DB role confirmed superuser/`BYPASSRLS` (or a role split completed) **before** migration 017 (`tenants` RLS) runs anywhere with live traffic
