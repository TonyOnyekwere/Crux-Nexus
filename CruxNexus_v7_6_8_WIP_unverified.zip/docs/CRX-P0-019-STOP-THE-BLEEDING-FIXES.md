# CRX-P0-019: Stop-the-Bleeding Fixes

**Date:** 2026-09-16
**Status:** Code-complete, **not verified against a live database or CI**. Read this document's Verification Note before treating anything below as done.

## Why this document exists

A full review of the repository found five concrete, reproducible issues —
one that should currently be breaking CI outright, two cases of
documentation claiming a protection existed when it didn't, one dead
schema table, and one feature that silently couldn't have worked end to
end. This document records exactly what changed and why, in the same
spirit as the other `CRX-P0-*` records, but with one difference: it is
explicit about what has and hasn't been verified, because overstating
verification is the exact failure mode that produced issues #2 and #4
below in the first place.

## Verification Note (read this first)

This pass had no network access and no live Postgres/Redis instance.
Every change was:
- reasoned through against the actual surrounding code (not written
  speculatively — each fix follows from reading the real call sites,
  models, and migrations it touches)
- checked with `python3 -m py_compile` across every file touched (catches
  syntax errors, not logic errors)

Every change was **not**:
- run against a live database
- exercised by the test suite
- run through CI

Treat this as "implemented, pending verification," not "fixed and proven."
The next step for all of this is: install dependencies, stand up Postgres,
run `alembic upgrade head`, run pytest, push and watch CI. None of that
was possible in this environment.

---

## 1. CI-breaking environment typo

**File:** `.github/workflows/ci.yml`

`ENVIRONMENT: test` was set globally; `app/config.py`'s validator only
accepts `{"development", "staging", "production", "testing"}`. Every job
that imports the app (which calls `get_settings()` at module load time in
`jwt_handler.py`) should have raised `ValueError` immediately.

**Fix:** changed to `ENVIRONMENT: testing`.

**Verification status:** not re-run. This is the single highest-confidence
fix in this document — it's a one-word string comparison — but "should
pass now" is still a prediction, not an observation, until CI actually runs.

## 2. `tenants` table RLS gap (ADR-0009 vs. reality)

**Files:** `migrations/versions/017_tenants_control_plane_rls.py` (new),
`docs/adr/ADR-0009-tenants-table-architecture.md`

ADR-0009 described a `USING (false)` RLS policy on `tenants` as
**ACCEPTED** and implemented. No migration from 001 through 016 ever ran
the `CREATE POLICY` statement. The table has had no RLS protection at all
since it was created.

**Fix:** migration 017 writes the policy exactly as ADR-0009 specifies.

**Verification status: explicitly NOT safe to run blind.** `FORCE ROW
LEVEL SECURITY` binds the owning role too, unless that role is a
superuser or has `BYPASSRLS`. Whether Railway's provisioned application
role has either exemption could not be determined from the codebase.
If it doesn't, this migration would lock the application's own
`TenantService` queries out of `tenants` — turning a documentation
accuracy problem into a production outage. See the Implementation Note
added to ADR-0009 for the exact check to run first
(`SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user;`).

## 3. Dead onboarding idempotency schema

**Files:** `app/contexts/onboarding/domain/onboarding_request.py` (new),
`app/database/models.py`, `app/contexts/onboarding/application/services.py`,
`app/contexts/onboarding/api/routes.py`, `app/kernel/errors/exceptions.py`,
`app/exceptions.py`

Migration 015 ("Make onboarding fully atomic and idempotent") created a
`merchant_onboarding_requests` table with an `idempotency_key` column. No
ORM model existed for it, and nothing in the application read or wrote
it. The onboarding endpoint accepted no idempotency key at all — the
*atomic* part of migration 015's title was true, the *idempotent* part
was not.

**Fix:**
- Added `MerchantOnboardingRequestRecord` (ORM model for the existing table).
- `OnboardingService.onboard_merchant` now accepts an optional
  `idempotency_key`. A new key gets a `pending` ledger row committed
  ahead of the main transaction; a retried request with the same key and
  same body replays the original result once `completed`; a different
  body with the same key raises `IdempotencyKeyConflictError` (409); a
  key still `pending` raises `OnboardingInProgressError` (409); a `failed`
  key's row is reused for the next retry rather than duplicated.
- `POST /api/v1/onboarding/merchant` now reads an `Idempotency-Key`
  header (optional — omitting it preserves the old behavior exactly).
- Along the way, fixed a latent async-SQLAlchemy bug in the failure
  handler: it originally would have read `onboarding_record.id` after a
  commit had already expired that object's attributes, which raises
  `MissingGreenlet` under `AsyncSession` rather than doing an implicit
  reload. Fixed by keying the failure lookup off the plain
  `idempotency_key` string argument instead of the ORM object's attribute.

**Verification status:** not run against a live DB. The replay path
(`_build_response_from_merchant_account`) re-derives the response from
`merchant_account_id` via joins rather than storing the full payload —
this logic has not been exercised against real data.

## 4. Tenant lifecycle dead end

> **Superseded:** the `is_platform_admin`/user-login mechanism described
> below was replaced the same day by Control Center service-to-service
> auth, once Control Center's actual design (separate service, own
> database, calls commerce-api only via its API) was clarified. See
> `docs/CRX-P0-021-CONTROL-CENTER-SERVICE-AUTH.md`. The underlying
> problem this section describes — the route was permanently
> unreachable — is still accurate; only the fix mechanism changed.


**Files:** `migrations/versions/018_add_platform_admin_flag.py` (new),
`app/contexts/identity/domain/entities.py`, `app/auth/jwt_handler.py`,
`app/contexts/identity/api/routes.py`, `app/contexts/tenant_management/api/routes.py`

`PATCH /tenants/{id}/status` was hard-coded to always return 403
`PLATFORM_ADMIN_REQUIRED`. The state-machine logic it should have called
(`TenantService.update_tenant_status`) was already fully correct — the
gap was purely the missing authorization model, meaning no tenant could
ever be suspended, offboarded, or archived through the API.

**Fix:**
- Migration 018 adds `users.is_platform_admin` (boolean, default false).
- Added `PLATFORM_ADMIN_TOKEN_TYPE`, `create_platform_admin_access_token`,
  and `get_current_platform_admin` (checks token type **and** a live DB
  read of the flag, so revoking admin access takes effect immediately,
  not only on token expiry) to `jwt_handler.py`.
- Added `POST /api/v1/identity/platform-admin/login` — deliberately
  separate from the main `/login` route so the already-tested consumer
  login path (lockout tracking, audit logging) is untouched.
- `PATCH /tenants/{id}/status` now calls the existing service method
  behind `get_current_platform_admin`.

**This is intentionally minimal — not an RBAC system.** Granting
`is_platform_admin` is a manual, out-of-band DB operation until a real
admin-management surface exists. That's a known, accepted limitation,
not an oversight.

**Verification status:** not run against a live DB. No test previously
existed for this route (grepped the test suite — zero references), so
this closes a real gap but also had zero prior coverage either way.

## 5. Staff invitation token was discarded before it could be sent

**Files:** `app/infrastructure/notifications.py` (new),
`app/contexts/billing/application/staff_invitation_service.py`,
`app/contexts/billing/api/staff_invitation_routes.py`

The original review flagged this as "invitations are created but nobody
is notified" (a bare `# TODO: Send notification via configured channel`).
Closer reading found it's worse: the raw invitation token was generated,
hashed into `token_hash` for storage, and then the local `token` variable
simply went out of scope. Only the hash was ever persisted, by design
(correct security practice) — but that means **no notification channel,
real or fake, could ever have delivered a usable invitation link**,
because the one piece of information a notification would need to send
was never kept alive long enough to send it.

**Fix:**
- Added `app/infrastructure/notifications.py`: a `NotificationProvider`
  interface and a `LoggingNotificationProvider` default implementation
  that logs a structured "would send" event and honestly reports
  `sent=False` — it does not claim to deliver anything, because it
  doesn't. `get_notification_provider()` is the single seam a real
  provider (SES/Postmark/Twilio/etc.) would be swapped in behind later.
- `create_invitation` now calls the provider with the raw token while
  it's still in scope, and sets `notification_sent_at` based on the
  actual result rather than leaving it permanently null.
- The invitation-created API response message no longer claims a
  notification "will be sent shortly" — it now reflects whether one
  actually was.

**Verification status:** not run. This closes the token-lifetime bug for
certain (it's a straightforward scoping fix, verifiable by reading the
diff), but "notifications work" still means "correctly logged," not
"delivered" — that requires a real provider, which was out of scope here.

---

## Repo hygiene (unrelated to the five fixes above, done alongside them)

- Normalized CRLF line endings to LF across ~20 files (mixed Windows/Unix
  editing had left the repo with inconsistent endings — flagged in the
  original review as a process signal).
- Removed `pytest_result.txt` and `pytest_out.txt` — stale, UTF-16-encoded
  local PowerShell test-run captures that had no reason to be committed.
  Added both to `.gitignore` to prevent recurrence.

## What this document does not claim

This does not close Phase 0. See `docs/PHASE-0-ACTUAL-STATUS.md` for the
certification gate, which still requires a real green CI run, a Railway
acceptance pass, a rollback drill, and — newly added as a precondition —
confirmation that the application's database role can safely run
migration 017 without RLS locking it out of its own tables.
