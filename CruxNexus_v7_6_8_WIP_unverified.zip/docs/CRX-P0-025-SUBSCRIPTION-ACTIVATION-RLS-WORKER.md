# CRX-P0-025: RLS Classification, Railway Worker IaC, Subscription Activation

**Date:** 2026-09-19
**Status:** Code-complete for what's listed below. Categorized explicitly below by verification status — do not read "code exists" as "gap closed" anywhere in this document.

## 1. Railway worker service

**Problem:** the worker code (`app/workers/runner.py`, dispatched via `entrypoint.sh`'s `PROCESS_TYPE` branch) has been correct and complete for several passes now. What was missing was ever actually creating a second Railway service to run it with `PROCESS_TYPE=worker` — `railway.toml` only ever configured the existing web service.

**What was done:** researched Railway's *current* config approach rather than guessing — confirmed via their own docs that `railway.toml`/`railway.json` (Config as Code) is deprecated as of this check, existing services keep working until 2026-12-01, but **new services cannot be created through it at all**. The current supported path is `.railway/railway.ts` (Infrastructure as Code). Wrote `.railway/railway.ts` declaring exactly one new resource — the worker service — and deliberately did not touch or redeclare the existing web service.

**One point of genuine, flagged ambiguity:** Railway's docs state a service can't be managed by both systems at once, and describe migrating a Config-as-Code service to IaC as an explicit step. Whether a project can have *some* services under the old system and *only new ones* under IaC simultaneously (the scenario here) isn't stated unambiguously either way in what's available. The file includes an explicit instruction: run `railway config plan` first (read-only, per Railway's own docs) and inspect the output before ever running `apply` — if the plan proposes touching the existing web service in any way, stop.

**Also added a fourth worker loop** (see section 3 below) — the log line to look for is now `Starting background worker process (4 loop(s))`, updated from 3.

**Category: requires Railway action.** Nothing about this can be verified from code. Kratos needs to run `railway config plan`, review it, and only then `apply` — then check the logs.

## 2. RLS classification (not "RLS complete" — read carefully)

Per explicit external review correction: **do not enable RLS on every table**, and do not treat classification as a substitute for the application-layer authorization that already protects these 20 control-plane tables today. RLS and application authorization are two separate, both-necessary layers — this section only concerns the RLS one.

**What was done:**
- `app/database/tenant_scope.py` now has an explicit `CONTROL_PLANE_TABLES` registry classifying all 20 tables that exist in the codebase today (verified by inspection — `merchant_accounts`, `users`, `otp_codes`, `tenants`, etc.) as control-plane, alongside the still-empty `TENANT_SCOPED_TABLES`. A `classify_table()` helper returns `"tenant_scoped"`, `"control_plane"`, or `"unclassified"`.
- `scripts/check_rls_coverage.py`'s previously-truly-vacuous pass now does one real thing even with zero tenant-scoped tables: queries the actual database for every table that exists and fails CI if any of them isn't in either registry. This is what turns "a new table might land with no RLS and nobody notices" from a real risk into something CI catches by construction.
- `app/contexts/billing/api/staff_invitation_routes.py`'s three tenant-scoped routes now use `get_verified_tenant_context` instead of `get_current_tenant_context` — the former also calls `set_postgres_rls_context` (`SET LOCAL app.current_tenant_id`), the latter doesn't. Both already shared the exact same authorization logic (confirmed by reading both implementations) — the only difference is whether the Postgres session variable a future tenant-scoped RLS policy would key off of actually gets set. This is forward-wiring only: no current policy reads that variable, so this has zero behavioral effect today and will not break anything.
- ADR-0009 now has a full "Role split design (proposed, not yet executed)" section: three concrete options for solving the `tenants`-table access-exception problem (a restricted `cruxnexus_app` role needs *some* legitimate path to `tenants`, since `TenantService`'s access is the intended pattern, not a bypass), a proposed `cruxnexus_migrate`/`cruxnexus_app` role split, and an explicit checklist for what "role split complete" requires. **None of it has been executed.** This is a proposal for Kratos to approve, not a decision the coding agent made unilaterally.

**Category: code-fixed (classification, CI gate, route wiring) + design proposed but explicitly not executed (role split).** The role split itself remains entirely undone by design — doing it without explicit sign-off risks exactly the outage scenario ADR-0009 has warned about since CRX-P0-019.

## 3. Subscription activation orchestration

The long-standing "webhook says paid, nothing happens" gap, flagged across every review since CRX-P0-023.

**Traced the existing lifecycle first** (per explicit review instruction, before writing anything): `POST /billing/webhooks/{provider}` → signature verification → persist to `provider_webhook_events` with `processed=False` → **stops there**. No code anywhere read those unprocessed rows or touched `FinancialTransaction`/`MerchantSubscription`. Also traced `SubscriptionPlan` and confirmed it has no pricing fields at all — nothing to invent a payment amount from.

**What was built:**
- Migration 027 adds `price_amount`/`price_currency`/`billing_interval` to `subscription_plans` — nullable, unpopulated. Real pricing is a business decision Kratos has already said not to invent; leaving these `NULL` and having the code refuse to proceed without them (see below) is what makes the missing parameter visible rather than worked around.
- `SubscriptionPaymentService.initiate_payment`: creates a `FinancialTransaction`, calls the configured provider adapter, transitions the subscription to `PAYMENT_PENDING`. Raises `PlanPricingNotConfiguredError` immediately if the plan has no price set — will not invent an amount or accept one from a caller.
- `SubscriptionPaymentService.process_webhook_event`: the reconciliation logic, built specifically around the explicit warning not to activate a subscription just because a webhook payload claims success:
  - Resolves the event to a specific `FinancialTransaction` via `provider_reference` — an event that doesn't resolve to a known transaction is treated as an anomaly (logged, marked processed, **not acted on**), never guessed at.
  - Always calls `adapter.verify_transaction` for independent confirmation — the webhook payload's own claimed status/amount are never trusted directly.
  - Cross-checks the verified amount/currency against what that specific transaction was created for; a mismatch is treated as a critical anomaly and does not activate anything.
  - Only transitions a subscription from `PAYMENT_PENDING`/`PAST_DUE` to `ACTIVE` — a subscription in any other state (e.g. already `CANCELLED`) is left alone even if a late webhook for an old transaction arrives, logged as a warning rather than silently overwritten.
  - Idempotent throughout: re-processing an already-`processed` event, or an event whose transaction is already `SUCCESSFUL`, is a clean no-op.
  - Emits `SubscriptionActivated`/`PaymentSuccessful`/`PaymentFailed` outbox events (two new `DomainEvent` values added, registered in `app/kernel/events/types.py`).
- `app/workers/webhook_reconciliation.py`: a fourth worker loop, `FOR UPDATE SKIP LOCKED` from the start (matching the discipline just applied to the other three loops), draining unprocessed verified events into `process_webhook_event`.

**What this deliberately does NOT add, and why that's not a gap:** no separate "entitlement activation" step — effective capacity is already computed dynamically from current subscription status (`MerchantAccessResolver`/`CapacityService`), so the status transition itself is the entitlement activation. No "storefront/tenant activation" mutation — `Tenant`/`MerchantAccount` status are independent authorities never coupled to payment success in this architecture; access is gated by checking subscription status at the point of use.

**Category: code-fixed, runtime-unverified.** This has never run against a live database, a real provider sandbox, or a real webhook delivery. The logic is sound by inspection and follows the exact chain repeatedly specified, but "compiles" and "is correct" are different claims, especially for money-handling code.

## Full status, in the five categories the review required

**1. Code-fixed (this session, all prior turns' items remain fixed):** onboarding idempotency fingerprint + lease/recovery, OTP row-locking + resend rate limits + authoritative destination, invitation role/RBAC/commit/identity-binding/password-policy/cancellation-ordering, session hijacking + server-generated tokens, `switch-tenant` and storefront-listing status consistency, merchant-suspension propagation, entitlement grant locking + time windows, trial-expiration and outbox-relay worker races, onboarding `LAUNCHING` recovery, RLS table classification + CI gate, `get_verified_tenant_context` wiring on invitation routes, subscription activation orchestration (webhook → financial transaction → subscription → outbox).

**2. Code-fixed but runtime-unverified:** everything in category 1 that touches a database at all — none of it has run against live Postgres/Redis. The subscription activation chain specifically has never seen a real webhook.

**3. Requires Railway action:** the worker service itself (`.railway/railway.ts` needs `plan` then `apply`, then log verification), and — once real tenant-owned tables exist — eventually the RLS role split cutover.

**4. Requires provider sandbox credentials:** Paystack and Flutterwave adapters are implemented and require sandbox verification; onboarding email OTP uses SendGrid and requires configured credentials.

**5. Still open, not touched this session:** `MerchantAccessResolver` still isn't the single capability authority (routes still call `CapacityService`/subscription checks directly in places); stale adversarial tests (wrong imports); adversarial tests missing from CI; the concurrency test that shares one session instead of proving a real race; stale OpenAPI artifact and no CI diff against it; unpinned dependencies; README's Celery/provider-status drift.

## Verification status

`py_compile` clean across every file touched this session (a large batch) and a full `app/`+`migrations/` sweep. Migration chain verified linear 001→027 by inspection. No CRLF regressions. `.env` confirmed absent. Nothing has been run against a live database — that remains Gate 1 (Railway/CI), unchanged from every prior doc in this series, and is now also what's needed to actually exercise the subscription activation logic for the first time.
