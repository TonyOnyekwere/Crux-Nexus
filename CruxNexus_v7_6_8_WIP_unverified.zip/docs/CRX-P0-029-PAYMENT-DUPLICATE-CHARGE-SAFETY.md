# CRX-P0-029 — Payment initiation: timeout vs failure (duplicate-charge safety)

Baseline: v7.3. Most important open item from CRX-P0-026.

## Problem
`initiate_payment` marked the transaction FAILED on ANY exception, including timeouts and 5xx,
where the provider may already have created a charge. A retry then created a second reference and
could double-bill. The pending row was also only flushed, not committed, before the provider call,
so a crash could leave a live provider charge with no local record.

## Changes
1. Error taxonomy (`payments/adapter.py`): `ProviderRejectedError` (4xx, or connect-phase failure so
   request never left), `ProviderOutcomeUnknownError` (read timeout, dropped connection, 5xx,
   unparseable body), `ProviderTransactionNotFoundError` (verify 404).
2. Paystack + Flutterwave adapters classify accordingly (initialize and verify).
3. `initiate_payment`: subscription row lock; commit PENDING transaction BEFORE provider call;
   `provider_reference = reference` up front (both adapters use our reference) so webhooks resolve
   even if initiation outcome was never seen; unknown outcome -> stays PENDING, subscription
   PAYMENT_PENDING, raises `PaymentOutcomeUnknownError`; rejection -> FAILED.
4. Before any new charge, earlier PENDING attempts for the subscription are verified with the
   provider: paid -> `PaymentAlreadyCompletedError`; provider unreachable ->
   `PriorPaymentUnverifiableError`. Never a second charge on uncertainty.
5. New `reconcile_transaction` + stale-pending sweeper (15 min) in the webhook worker: lost-webhook
   and unknown-outcome rows are resolved by asking the provider. Success/mismatch logic is now one
   shared `_apply_verification` used by both webhook and sweeper.
6. Late payment after the sweeper closed a checkout as abandoned now still activates: PAYMENT_FAILED
   added to reactivatable states (state machine already allows PAYMENT_FAILED -> ACTIVE).
7. Route: 202 `PAYMENT_OUTCOME_UNKNOWN`, 409 `PAYMENT_ALREADY_COMPLETED`, 503 `PRIOR_PAYMENT_UNVERIFIED`
   (Retry-After), 502 `PROVIDER_REJECTED`.

## Tests
`tests/unit/test_payment_initiation_safety.py` (adapter classification x2 providers; service:
timeout stays PENDING, rejection FAILED, commit-before-call, refuse when prior paid/unverifiable).

## Not verified
Nothing was executed (no pytest/SQLAlchemy/network here). Compile + static checkers only.
Sandbox behaviour to confirm: Flutterwave verify_by_reference response for an unknown tx_ref (assumed 404;
if it returns 400 + "No transaction was found", map it to ProviderTransactionNotFoundError);
Paystack verify 404 for unknown reference.
