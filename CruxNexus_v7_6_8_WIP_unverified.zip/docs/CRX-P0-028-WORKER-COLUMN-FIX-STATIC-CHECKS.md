# CRX-P0-028 — Worker column-name defect, adversarial test imports, static reference checks

Baseline: CruxNexus_fixed_v7_2_20260924.zip

## Defect fixed
`app/workers/entitlement_reconciliation.py` referenced `StaffCapacityAllocation.entitlement_id`
(3 sites: orphan-cleanup join, log line, anomaly-detection join). The model and the
`staff_capacity_allocations` migration (005) define the column as `merchant_entitlement_id`.
The worker would have raised `AttributeError` on first execution against a real database.
`py_compile` cannot detect this class of error. All three sites now use `merchant_entitlement_id`.
(`storefront_entitlement_allocations.entitlement_id` in migrations 003/028 is a different, retired table and is unchanged.)

## Adversarial test fixed
`tests/adversarial/test_tenant_isolation.py` imported from modules/paths that do not exist:
- `TenantMembership`, `TenantRole`, `MembershipStatus` -> now from `app.contexts.tenant_management.domain.membership`
- `SubscriptionPlan` -> now from `app.contexts.billing.domain.entities`

## New tooling (scripts/static_checks/)
- `check_model_attrs.py <app_dir>`: every `Model.attr` access resolves to a real column/attribute.
  Confirmed it flags the original worker bug (2 hits on v7.2) and reports 0 after the fix.
- `check_test_refs.py <app_dir> <tests_dir>`: test imports resolve; model constructor kwargs are real columns.
  Two known false positives: `TENANT_SCOPED_TABLES` (annotated assignment) and `tenant_scope` (submodule import).

## Not verified
No test suite was executed (no database in this environment). Checks are static only.
