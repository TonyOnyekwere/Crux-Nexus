# CRX-P0-024: Phase A Security/Correctness Fixes (v5 External Review)

**Date:** 2026-09-18
**Status:** Code-complete for what's listed below, not verified against a live database. Same standing caveat as every prior doc in this series.

## One instruction flagged, not followed

The v5 review's item #8 claimed the OTP channel restriction (`email`/`sms`)
contradicted an "intended WhatsApp-first direction" and should be
changed. That's the opposite of what Kratos explicitly locked earlier in
this engagement: *"Email/SMS OTP is the preferred/authoritative merchant
verification channel. Do not replace it with WhatsApp-first
verification."* Kept as built. Flagging this rather than silently
following either instruction, since they directly conflict and only
Kratos can resolve which one is current.

## Fixed and verified against the actual code before fixing

**OTP destination hijack (critical).** `request_code` accepted
`destination` directly from the client with no check that it belonged to
the authenticated user — a caller could request a code for an email/
number they don't control and still flip their own account to `ACTIVE`
(verification only checked `user_id`, not which destination the code
went to). Fixed: destination is now always derived server-side —
`user.email` for channel=email, `user.phone_number` for channel=sms.
Added `phone_number` to `users` (migration 025, nullable) since no field
existed for SMS to bind to at all; requesting SMS OTP without one set
now fails with a clear error rather than accepting a client-supplied
number.

**Onboarding session hijacking (critical).** `GET`/`PATCH /sessions/{id}`
had no possession check at all — a session UUID alone let anyone read or
mutate another merchant's in-progress onboarding data. Fixed: both now
require an `X-Device-Session-Token` header matching the session's own
token, compared with `hmac.compare_digest`. Noted in the route docstring
that once account-linking exists (Phase 4), an authenticated-owner path
should be added as an alternative — this is the baseline fix, not the
final model.

**Staff invitations never actually committing (critical).** Every method
in `StaffInvitationService` only called `flush()`, never `commit()`.
`get_db()` closes the session without committing on the way out, so
every "successful" invitation create/accept/cancel response was silently
rolled back the moment the request finished. Verified this directly
against `app/database/session.py` before fixing. Added real `commit()`
calls throughout.

**Staff invitation identity binding (critical).** `accept_invitation`
accepted a client-supplied `user_id` with zero verification — anyone
holding a valid invitation token could assign the resulting membership
to an arbitrary user. Also created accounts with `password_hash=""`, a
permanently unusable account. Fixed: removed `user_id` from the request
schema entirely. If the invited email already has an account, the caller
must be authenticated as that exact account (checked via an optional
bearer-token dependency, not trusted from the request body). If not, a
new account is created with a real hashed password
(`new_account_password`, required in that case), status `UNVERIFIED`
like every other new account.

**Staff invitation double-accept race (high).** No row lock — two
concurrent accept requests could both observe `PENDING` before either
committed. Fixed with `.with_for_update()` on the invitation `SELECT`,
matching the existing lock pattern already used elsewhere in this
codebase (`entitlement_allocation.py`, `tenant_management/services.py`).

**Staff invitation RBAC gap (high).** The route's own docstrings claimed
"only owners/managers can invite/cancel," but no permission check
existed anywhere — any active tenant member could create, cancel, or
list invitations. Fixed: create/cancel/list now all check
`Permission.MANAGE_STAFF` via the existing `has_permission` helper
(`app/auth/authorization.py`), which was simply never called.

**Old onboarding endpoint bypassing verification (critical).** The
original bootstrap endpoint (`POST /onboarding/merchant`) used
`get_current_merchant_context`, which only decoded the JWT — it never
checked the user's actual status. An `UNVERIFIED` user with a valid
global token could call it directly and receive a `TRIALING`
subscription and `ACTIVE` storefront without ever completing OTP
verification, defeating the entire point of introducing `UNVERIFIED`.
Fixed at the shared dependency level (also gates `create_storefront`,
the other caller, since granting additional storefront capacity is
equally commercially significant): now queries the user's DB status and
requires `ACTIVE`, returning `403 ACCOUNT_NOT_VERIFIED` otherwise.

**Payment adapter interface bug (high).** `PaymentProviderAdapter.
initialize_charge` never defined a `redirect_url` parameter at all — the
interface only had `payment_method`. `FlutterwaveAdapter` was passing
`payment_method` into Flutterwave's `redirect_url` field, so a call with
`payment_method="card"` would send `"redirect_url": "card"`, an invalid
URL. `PaystackAdapter`'s own docstring claimed it sent `callback_url` but
the actual request body never included it. Fixed: added `redirect_url`
as a proper, separate required parameter on the interface; both adapters
now use it correctly.

**Flutterwave `provider_reference` semantics mismatch (high).**
`initialize_charge` returned `tx_ref` (CruxNexus's own reference) as
`provider_reference`, but `verify_transaction` called
`/v3/transactions/{id}/verify`, which needs Flutterwave's own internal
numeric ID — a value that doesn't exist yet at the point CruxNexus needs
to verify. Rather than guess a fix, checked Flutterwave's current docs
first: a `GET /v3/transactions/verify_by_reference?tx_ref=...` endpoint
exists specifically for this case. Switched to it — `verify_transaction`
now takes the same `tx_ref`-shaped reference `initialize_charge` returns,
consistent with how Paystack's adapter already worked.

**Webhook hardening (high/medium).** Two fixes: an unconfigured provider
previously returned `200`, which risks the provider treating the event
as successfully delivered and never retrying once the adapter is
actually configured — now returns `503` (both providers' documented
retry signal). A signature-valid webhook with unparseable JSON or no
extractable event ID was previously still persisted with an empty
`event_id`, which can't be deduplicated correctly — now rejected with
`422` instead of stored.

## Documentation fix (not code)

**RLS/role-split finding recorded in ADR-0009.** Kratos ran the
requested query against the real Railway role:
`current_user=postgres, rolsuper=true, rolbypassrls=true` — and
confirmed this is the *only* role used by both the application and
migrations (no separate runtime/migration credential exists). This means
migration 017 is currently **safe to run** (a superuser is exempt from
`FORCE ROW LEVEL SECURITY`) but also currently **inert** — it protects
nothing, since no non-exempt role exists yet to be restricted by it.
Recorded in the ADR, along with the real design problem a future role
split must solve: `TenantService`'s own legitimate `SELECT`/`UPDATE`
access to `tenants` is the documented, intended control-plane pattern,
not a violation of it — a blanket `USING (false)` on a newly-restricted
application role would block that legitimate path exactly as hard as an
attacker. Not solved in this pass (real infrastructure design work); the
open questions are now written down instead of needing rediscovery.

## Explicitly not done this pass, staged from the same review

These are real findings from the v5 review, confirmed as legitimate, not
fixed here because of scope (this pass focused on identity/onboarding/
invitation/payment security specifically) — tracked in
`PHASE-0-ACTUAL-STATUS.md`'s Stage B alongside the entitlement/capacity
bugs that predate this review:

- OTP resend rate limiting / abuse controls
- OTP verification attempt-increment race (needs the same row-lock
  treatment just applied to invitation acceptance)
- `MerchantAccessResolver` not actually wired into `TenantService`/
  `CapacityService` as the single authority (still three competing
  decision points)
- Staff allocation duplicated across every storefront, archived
  storefronts still consuming capacity, entitlement time windows not
  checked, entitlement grant races — all pre-date this review, still open
- Merchant-account-level suspension not propagated into tenant-context
  resolution
- `switch-tenant` not rejecting `SUSPENDED` tenants (only `ARCHIVED`)
- Storefront listing not filtering non-`ACTIVE` memberships
- Trial expiration worker race (`FOR UPDATE SKIP LOCKED` needed for
  horizontal worker scaling)
- Onboarding sessions stuck in `LAUNCHING` after a crash (needs a
  recovery timeout to `RECOVERY_REQUIRED`)
- Idempotency ledger's `pending` rows have no lease/timeout — a crashed
  request permanently blocks retries with that key
- Onboarding idempotency fingerprint doesn't include `merchant_name`
- Subscription activation orchestration (webhook → verify → activate) —
  the next major slice, unchanged from CRX-P0-023
- Stale adversarial test suite (wrong imports, shared-session
  concurrency test that doesn't actually test concurrency), stale
  OpenAPI artifact, `PROJECT_ANALYSIS_REVIEW.md` describing a pre-v5
  state

## Verification status

`py_compile` clean across every file touched this pass and a full
`app/`+`migrations/` sweep. Migration chain verified linear 001→025 by
inspection. No CRLF regressions. `.env` confirmed absent. Nothing run
against a live database, Redis, or real provider sandbox — Gate 1
(Railway/CI), unchanged from every prior doc in this series.
