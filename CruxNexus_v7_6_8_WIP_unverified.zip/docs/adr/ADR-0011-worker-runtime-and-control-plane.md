# ADR-0011: Worker runtime and Control Plane execution boundary

## Status
Accepted for the current Commerce OS runtime.

## Decision
CruxNexus Commerce uses a dedicated asyncio worker runtime with a durable PostgreSQL job table and Redis Streams as the external event transport.

Celery is not part of the executable architecture and is removed from the Commerce dependency set.

The worker uses a dedicated PostgreSQL role with `NOSUPERUSER` and `NOBYPASSRLS`. Commerce RLS remains forced. Worker access to tenant-scoped Commerce tables is granted only through explicit worker policies and a role-level `app.worker_context=1` setting.

The execution chain is:

Control Center governance
→ Commerce synchronized governance state
→ durable outbox / worker job
→ worker claim + lease
→ idempotent handler
→ commit
→ audit/event

The worker is not granted PostgreSQL `BYPASSRLS` and the API runtime role is never reused for system-wide lifecycle execution.

## Control Center boundary

`apps/control-center-api` is a separately deployable FastAPI service with its own PostgreSQL database. It owns platform-admin identity, MFA, governance policy, plans, provider registry and platform audit. It synchronizes approved governance state into Commerce through authenticated platform endpoints.

Commerce does not connect directly to the Control Center database.

## Consequences

- Merchant traffic remains independent of Control Center availability after governance state has been synchronized.
- Worker lifecycle operations can safely operate across tenants without weakening merchant RLS.
- Deferred commands have durable attempts, leases, retries and dead-letter state.
- Outbox publication is backed by an actual transport rather than a log-only state change.
- Future worker handlers are added to the durable executor instead of creating another unrelated polling process.
