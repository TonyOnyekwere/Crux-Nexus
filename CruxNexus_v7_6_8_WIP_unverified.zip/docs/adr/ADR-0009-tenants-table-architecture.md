# ADR-0009: Tenants Table as Platform Control Plane Data

## Status
**ACCEPTED** — policy defined in migration `017_tenants_control_plane_rls.py`.

## Implementation Note (added during Stop-the-Bleeding remediation)

This ADR previously described the RLS policy below as accepted *and
implemented*. It was not: no migration prior to 017 ever ran the
`CREATE POLICY` statement, so `tenants` had zero RLS protection from
migration 001 onward despite this document and several `CRX-P0-*`
remediation records describing it as done. See
`docs/CRX-P0-019-STOP-THE-BLEEDING-FIXES.md` for how that was found.

Migration 017 now writes the policy exactly as specified below. It has
**not been run against any live database as part of this fix** and must
not be applied blind:

> `FORCE ROW LEVEL SECURITY` binds even the owning role unless that role
> is a superuser or has `BYPASSRLS`. Whether the application's database
> role (Railway-provisioned) has one of those exemptions was not
> verifiable from the codebase alone. If it does not, running this
> migration will lock the application's own `TenantService` queries out
> of the `tenants` table — a total outage for onboarding, storefront
> creation, and tenant lookups — not just close a documentation gap.

**Before running migration 017 anywhere real:** connect as the
application's actual runtime role and confirm via
`SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user;`
that at least one is `true`. If neither is true, this migration needs a
role split (a separate, restricted role for the app, with the
migration/admin role kept exempt) before it can ship — that is real
infrastructure work, not a one-line fix, and is not something this pass
attempted.

## Railway verification result (reported 2026-09-18)

The query above was run against the actual Railway application role.
Result: `current_user = postgres`, `rolsuper = true`, `rolbypassrls =
true`, and this `postgres` login is the *only* role the application (and
migrations) currently use — there is no separate runtime vs. migration
credential.

**What this means today:** migration 017's policy is safe to run — a
superuser is exempt from RLS regardless of `FORCE ROW LEVEL SECURITY`,
so nothing breaks. It also means the policy currently protects nothing:
`USING (false)` only binds a role that isn't a superuser/`BYPASSRLS`, and
none exists yet. This ADR's stated protection ("Denied direct SELECT")
is therefore inert, not active, until a role split happens.

**What this means for any future role split:** simply creating a second,
restricted `cruxnexus_app` role (`rolsuper=false`, `rolbypassrls=false`)
is not sufficient on its own. CruxNexus's own application code routinely
does `SELECT`/`UPDATE` against `tenants` through `TenantService` — that
is the documented, intended control-plane access pattern, not a
violation of it. A blanket `USING (false)` would block that legitimate
path exactly as hard as it blocks an attacker. Whoever designs the role
split needs to resolve this before flipping the runtime role away from
superuser, by doing one of:
- Granting the restricted application role explicit, narrower access
  (a dedicated policy allowing the specific access pattern
  `TenantService` needs, rather than a blanket deny), or
- Keeping `tenants` access on a privileged path (e.g. the app connects
  as a role that's still exempt from this specific policy, while other,
  genuinely lower-trust code paths use the restricted role), or
- Redesigning how the control plane accesses `tenants` entirely.

Migrations and the application also currently share one `DATABASE_URL`.
A real role split will need separate migration vs. runtime credentials
(e.g. `MIGRATION_DATABASE_URL` with elevated privileges, `DATABASE_URL`
restricted) — not attempted in this pass; recorded here so it isn't
rediscovered from scratch later.

## Role split design (proposed, not yet executed)

External review, 2026-09-19: do not invent and apply a role-split
migration unilaterally — this section is a proposal for Kratos to
review and approve before any of it runs against Railway. Nothing below
has been executed. The risk of getting this wrong is a production outage
(the app locked out of its own `tenants` table), which is exactly the
failure mode migration 017's own docstring already warned about.

**Why this can wait safely.** `TENANT_SCOPED_TABLES` is empty — there is
no tenant-owned commerce data yet, so there is nothing an RLS policy
needs to isolate today. The `postgres`/superuser/`bypassrls` role
currently in use is a real gap for defense-in-depth, but it is not
blocking anything functionally, and rushing the fix under
"gaps must be closed" pressure is how this table's `USING (false)`
policy could end up applied to a restricted role with no exception path
— breaking the app the moment it's connected as anything other than
superuser. Sequencing this after commerce tables exist (so the
tenant-scoped registry and the control-plane exception list are both
informed by what's actually built) is deliberate, not neglect.

**Proposed roles:**

| Role | Used by | RLS posture |
|---|---|---|
| `cruxnexus_migrate` | Alembic only (`MIGRATION_DATABASE_URL`) | Superuser or table-owner — needs `CREATE`/`ALTER` on every table, and must be able to write policies that bind other roles |
| `cruxnexus_app` | The running API and workers (`DATABASE_URL`) | Subject to RLS — this is the role a policy like `tenants`' `USING (false)` is meant to constrain |

**The `tenants` exception problem, and its proposed resolution.**
`TenantService` legitimately needs to `SELECT`/`UPDATE` `tenants` — that
is the intended control-plane access pattern (ADR text above), not a
bypass to close. A blanket `USING (false)` on `cruxnexus_app` would
block that alongside any attacker. Proposed options, in order of
preference, for Kratos to choose between (not for the coding agent to
pick unilaterally):

1. **A second, narrower policy for `cruxnexus_app` specifically**, granting exactly the access pattern `TenantService` uses (e.g. `USING (true)` scoped by an explicit application-level check, since `tenants` has no `tenant_id` column of its own to filter by — it *is* the tenant registry). This keeps a single application role but requires the policy author to enumerate the legitimate access shape precisely.
2. **A dedicated `cruxnexus_control_plane` role** (`BYPASSRLS` or its own permissive policy) used only by the small set of services/paths that legitimately touch control-plane tables like `tenants`, separate from a maximally-restricted `cruxnexus_app` used for tenant-owned data-plane tables once they exist. More roles to manage, but a cleaner blast radius.
3. **Keep `tenants` access on a privileged path entirely** (e.g. the control-plane API surface, once Control Center is a real separate service — CRX-P0-021) and never route ordinary commerce-plane traffic through a role that touches `tenants` at all.

**What must be true before switching `DATABASE_URL` away from the
current superuser role**, regardless of which option above is chosen:

- [ ] The chosen option is reviewed and approved (this is an
      infrastructure/security decision, not a code-review one)
- [ ] `cruxnexus_app` is created with the resulting grants and policies
      in a migration, tested against a real Postgres instance
- [ ] Every route that currently works is re-tested against
      `cruxnexus_app` specifically (not just "the app boots") — the
      Railway acceptance suite this ADR's earlier section already
      requires is the natural place for this
- [ ] `tenant_transaction()`/`get_verified_tenant_context()` are
      confirmed to be setting `app.current_tenant_id` on every path a
      future tenant-scoped policy will key off of (partially wired as of
      2026-09-19 — see `app/contexts/billing/api/staff_invitation_routes.py`
      for the routes switched from `get_current_tenant_context`; not yet
      audited across the entire route surface)
- [ ] `MIGRATION_DATABASE_URL` (elevated) and `DATABASE_URL` (restricted)
      are both configured in Railway and CI before the cutover, not after

This checklist, not "the migration file exists," is what "RLS role
split complete" means.

## Context
The `tenants` table represents CruxNexus's tenant registry and is fundamentally different from ordinary tenant-scoped data like `users`, `products`, or `orders`.

## Decision
**The `tenants` table is platform-control-plane data, not ordinary tenant-scoped data.**

### Architectural Classification
- **Platform Control Plane**: Administrative infrastructure managed by platform services
- **Tenant Commerce Plane**: Merchant data scoped to individual tenants

### Security Model
- **Direct Database Access**: Denied (RLS policy: `USING (false)`)
- **Application Services**: Only platform services may manipulate tenant records
- **Merchant Operations**: Must go through controlled application interfaces
- **Future RBAC**: Platform admin roles will have specific, scoped access

### RLS Policy
```sql
CREATE POLICY tenant_management_isolation ON tenants
USING (false)  -- Deny direct SELECT
WITH CHECK (false)  -- Deny direct INSERT/UPDATE/DELETE
```

### Rationale
1. **Platform Integrity**: Tenant lifecycle operations must be controlled and audited
2. **Security Boundary**: Merchants should not directly operate against tenant registry
3. **Data Model**: Tenants table contains platform infrastructure, not merchant data
4. **Future Evolution**: RBAC implementation will provide controlled platform admin access

## Consequences
- All tenant operations must go through application services
- Direct database queries against tenants table will fail
- Platform admin services will need dedicated authorization model
  (now answered: Control Center, a separate service with its own
  database and its own admin RBAC — see
  `docs/CRX-P0-021-CONTROL-CENTER-SERVICE-AUTH.md`. commerce-api trusts
  Control Center as a service; it does not implement admin RBAC itself.)
- Migration to proper RBAC in Phase 2+ will be required

## Future Evolution
- Phase 2: Implement platform admin RBAC with specific tenant management permissions
- Phase 3: Add audit logging for all tenant lifecycle operations
- Phase 4: Consider multi-region tenant registry with eventual consistency

## References
- CRX-P0-ENG-003 Finding #10 (tenants RLS policy architectural issue)
- Architecture Constitution §4.1 (Control/Commerce Plane Split)
- Architecture Constitution §15 (Multi-Tenant Security Model)